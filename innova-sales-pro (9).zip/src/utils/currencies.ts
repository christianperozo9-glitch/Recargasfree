import { formatMoney } from './format';

export type CurrencyCode =
  | 'VES'
  | 'COP'
  | 'CLP'
  | 'EUR'
  | 'ARS'
  | 'MXN'
  | 'PEN'
  | 'BRL'
  | 'DOP'
  | 'PAB';

export interface CurrencyInfo {
  code: CurrencyCode;
  name: string;
  country: string;
  symbol: string;
  shortLabel: string;
  rateLabel: string;
  apiSourceLabel: string;
  defaultRate: number;
  flag: string;
}

export const SUPPORTED_CURRENCIES: CurrencyInfo[] = [
  {
    code: 'VES',
    name: 'Bolívares',
    country: 'Venezuela',
    symbol: 'Bs',
    shortLabel: 'Bs',
    rateLabel: 'BCV',
    apiSourceLabel: 'BCV Oficial / DolarAPI',
    defaultRate: 45.5,
    flag: 'VE',
  },
  {
    code: 'COP',
    name: 'Pesos Colombianos',
    country: 'Colombia',
    symbol: 'COP $',
    shortLabel: 'COP',
    rateLabel: 'TRM COP',
    apiSourceLabel: 'API Tasa del Día (COP)',
    defaultRate: 4200,
    flag: 'CO',
  },
  {
    code: 'CLP',
    name: 'Pesos Chilenos',
    country: 'Chile',
    symbol: 'CLP $',
    shortLabel: 'CLP',
    rateLabel: 'Tasa CLP',
    apiSourceLabel: 'API Tasa del Día (CLP)',
    defaultRate: 950,
    flag: 'CL',
  },
  {
    code: 'EUR',
    name: 'Euro',
    country: 'Zona Euro',
    symbol: '€',
    shortLabel: '€',
    rateLabel: 'Tasa EUR',
    apiSourceLabel: 'API Tasa del Día (EUR)',
    defaultRate: 0.92,
    flag: 'EU',
  },
  {
    code: 'ARS',
    name: 'Pesos Argentinos',
    country: 'Argentina',
    symbol: 'ARS $',
    shortLabel: 'ARS',
    rateLabel: 'Tasa ARS',
    apiSourceLabel: 'API Tasa del Día (ARS)',
    defaultRate: 1050,
    flag: 'AR',
  },
  {
    code: 'MXN',
    name: 'Pesos Mexicanos',
    country: 'México',
    symbol: 'MXN $',
    shortLabel: 'MXN',
    rateLabel: 'Tasa MXN',
    apiSourceLabel: 'API Tasa del Día (MXN)',
    defaultRate: 20.2,
    flag: 'MX',
  },
  {
    code: 'PEN',
    name: 'Soles Peruanos',
    country: 'Perú',
    symbol: 'S/',
    shortLabel: 'S/',
    rateLabel: 'Tasa PEN',
    apiSourceLabel: 'API Tasa del Día (PEN)',
    defaultRate: 3.75,
    flag: 'PE',
  },
  {
    code: 'BRL',
    name: 'Reales Brasileños',
    country: 'Brasil',
    symbol: 'R$',
    shortLabel: 'R$',
    rateLabel: 'Tasa BRL',
    apiSourceLabel: 'API Tasa del Día (BRL)',
    defaultRate: 5.8,
    flag: 'BR',
  },
  {
    code: 'DOP',
    name: 'Pesos Dominicanos',
    country: 'Rep. Dominicana',
    symbol: 'RD$',
    shortLabel: 'RD$',
    rateLabel: 'Tasa DOP',
    apiSourceLabel: 'API Tasa del Día (DOP)',
    defaultRate: 60.5,
    flag: 'DO',
  },
  {
    code: 'PAB',
    name: 'Balboa',
    country: 'Panamá',
    symbol: 'B/.',
    shortLabel: 'B/.',
    rateLabel: 'Tasa PAB',
    apiSourceLabel: 'Paridad Oficial 1:1 USD',
    defaultRate: 1,
    flag: 'PA',
  },
];

const CURRENCY_MAP = new Map<CurrencyCode, CurrencyInfo>(
  SUPPORTED_CURRENCIES.map((c) => [c.code, c])
);

export function isSupportedCurrencyCode(code?: string | null): code is CurrencyCode {
  if (!code) return false;
  return CURRENCY_MAP.has(String(code).toUpperCase() as CurrencyCode);
}

export function getCurrencyInfo(code?: string | null): CurrencyInfo {
  const normalized = String(code || 'VES').toUpperCase() as CurrencyCode;
  return CURRENCY_MAP.get(normalized) || SUPPORTED_CURRENCIES[0];
}

export function formatRateNumber(rate: number, code?: string | null): string {
  const num = Number(rate);
  if (!Number.isFinite(num) || num <= 0) return '0.00';
  const normalized = String(code || 'VES').toUpperCase();
  if (normalized === 'EUR' || (num < 5 && num !== 1)) {
    return num.toFixed(4);
  }
  return num.toFixed(2);
}

export function formatLocalCurrency(amount: number, code?: string | null): string {
  const info = getCurrencyInfo(code);
  return `${formatMoney(amount)} ${info.shortLabel}`;
}
