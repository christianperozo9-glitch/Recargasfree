import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  createPinCredentials,
  db,
  handleFirestoreError,
  hashPin,
  logFirestoreError,
  logoutFirebase,
  MASTER_OWNER_EMAIL,
  OperationType,
  registerClientAuthAccount,
  sanitizeFirestoreId,
  stripUndefined,
  verifyPasswordForEmail,
  type RegisterAuthResult,
} from '../lib/firebase';
import type {
  AppConfig,
  BroadcastConfig,
  CartItem,
  CashierPermissions,
  CashierRecord,
  CierreDetalleItem,
  CierreDetalleVenta,
  CierreProductoSummary,
  CierreRecord,
  CustomerRecord,
  FiadoRecord,
  MembershipPayment,
  MembershipPaymentMethod,
  MembershipPlan,
  MembershipState,
  NetworkHealthStatus,
  OwnerChatMessage,
  PagoMovilConfig,
  PlatformConfig,
  PreRegistrationRecord,
  Product,
  PromoRecord,
  ProviderRecord,
  PublicPriceCheckerCatalog,
  SaleItem,
  SaleTransaction,
  ScheduledNotice,
  SplitPaymentLeg,
  SupplierPurchaseItem,
  SupplierPurchaseRecord,
  SupportTicket,
  SystemUserRecord,
  TallerRepair,
  TenantInvoiceConfig,
  TenantRecord,
  UserRole,
  VerificationDocRecord,
  VerificationDocStatus,
  VerificationRequestConfig,
  VoiceSettings,
} from '../types/pos';

export const DEFAULT_CASHIER_PERMISSIONS: Required<CashierPermissions> = {
  aplicar_rebajas: false,
  fiados: false,
  motor: false,
  taller: false,
  editar_tasas: false,
  cerrar_caja: false,
  anular_factura: false,
  herramientas: false,
};

export const FULL_CASHIER_PERMISSIONS: Required<CashierPermissions> = {
  aplicar_rebajas: true,
  fiados: true,
  motor: true,
  taller: true,
  editar_tasas: true,
  cerrar_caja: true,
  anular_factura: true,
  herramientas: true,
};
import { formatDateVE, round2 } from '../utils/format';
import {
  formatRateNumber,
  getCurrencyInfo,
  isSupportedCurrencyCode,
  type CurrencyCode,
  type CurrencyInfo,
} from '../utils/currencies';
import { defaultPlans } from '../utils/promotions';
import { generateCierrePDF, generateInvoicePDF } from '../utils/pdfGenerator';
import {
  buildEscPosCierreTicket,
  buildEscPosRasterLogoAsync,
  buildEscPosSaleTicket,
  buildEscPosTestTicket,
  detectAuthorizedPrinters,
  mergeInvoiceConfig,
  printBrowserCierreHtml,
  printBrowserReceiptHtml,
  writeBytesToPrinter,
  type ConnectedPrinterInfo,
  type InvoiceMode,
  type SerialPortLike,
  type TenantMetaForReceipt,
  type USBDeviceLike,
} from '../utils/thermalPrinter';
import {
  getPushPermission,
  isPushPreferenceEnabled,
  isPushSupported,
  requestPushPermission,
  sendSystemPushNotification,
  setPushPreferenceEnabled,
  type PushPermissionState,
} from '../utils/pushNotifications';
import {
  getConnectedScannerDevices,
  subscribeHardwareScans,
  subscribeScannerDevices,
  type ConnectedScannerDevice,
  type HardwareScanEvent,
} from '../utils/barcodeScanner';

export const IVA_RATE = 0.16;

export interface ToastMessage {
  id: number;
  text: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

export interface ThemeOption {
  id: string;
  name: string;
  c1: string;
  c2: string;
  accent?: string;
  tint?: string;
}

export const IG_THEMES: ThemeOption[] = [
  { id: 'innova', name: 'Celeste Cristal', c1: '#38bdf8', c2: '#06b6d4', accent: '#0284c7', tint: '#f0f9ff' },
  { id: 'royal', name: 'Índigo Perla', c1: '#818cf8', c2: '#60a5fa', accent: '#4f46e5', tint: '#eef2ff' },
  { id: 'sunset', name: 'Coral Brisa', c1: '#fb923c', c2: '#f472b6', accent: '#ea580c', tint: '#fff7ed' },
  { id: 'ocean', name: 'Aqua Marina', c1: '#22d3ee', c2: '#34d399', accent: '#0891b2', tint: '#ecfeff' },
  { id: 'slate', name: 'Menta Fresca', c1: '#34d399', c2: '#2dd4bf', accent: '#059669', tint: '#ecfdf5' },
  { id: 'emerald', name: 'Salvia Luz', c1: '#4ade80', c2: '#10b981', accent: '#16a34a', tint: '#f0fdf4' },
  { id: 'indigo', name: 'Cielo Nórdico', c1: '#60a5fa', c2: '#38bdf8', accent: '#2563eb', tint: '#eff6ff' },
  { id: 'purple', name: 'Lavanda Seda', c1: '#a78bfa', c2: '#c084fc', accent: '#7c3aed', tint: '#f5f3ff' },
  { id: 'rose', name: 'Rosa Cuarzo', c1: '#fb7185', c2: '#f472b6', accent: '#e11d48', tint: '#fff1f2' },
  { id: 'amber', name: 'Arena Dorada', c1: '#fbbf24', c2: '#fb923c', accent: '#d97706', tint: '#fffbeb' },
  { id: 'teal', name: 'Turquesa Mar', c1: '#2dd4bf', c2: '#38bdf8', accent: '#0d9488', tint: '#f0fdfa' },
];

export const DEFAULT_SCHEDULED_NOTICES: Record<string, ScheduledNotice> = {
  a1: { hora: '08:00', msg: 'Buenos días. Revisa tasas y abre caja.', activo: true },
  a2: { hora: '12:00', msg: 'Revisa el inventario y reposición.', activo: true },
  a3: { hora: '18:00', msg: 'Recordar hacer el cierre en el sistema general.', activo: true },
};

export const DEFAULT_PAGO_MOVIL: PagoMovilConfig = {
  banco: 'Banesco (0134)',
  tel: '04245655395',
  ci: 'V-20000000',
  titular: 'Innova Grup',
};

export const DEFAULT_WA_MEMBRESIA = '584245655395';

export const DEFAULT_MECHANICS: string[] = ['José', 'Jesús'];

export interface NotificationHistoryItem extends BroadcastConfig {
  key: string;
}

export type ViewMode = 'auto' | 'desktop' | 'mobile';

export interface RegisterTenantInput {
  email: string;
  password: string;
  nombre_local: string;
  razon_social?: string;
  rif?: string;
  direccion_fiscal?: string;
  telefono?: string;
  contacto_nombre?: string;
  admin_pin?: string;
  caja_pin?: string;
  cajero_nombre?: string;
  plan_key?: string;
  trial_days?: number;
  plan_label_override?: string;
  meta_usd?: number;
  logo_url?: string;
  invoice_config?: Partial<TenantInvoiceConfig>;
}

interface PosContextValue {
  // Connection & Auth
  connected: boolean;
  networkStatus: NetworkHealthStatus;
  networkLatencyMs: number | null;
  systemBusy: boolean;
  systemBusyLabel: string;
  setSystemBusyState: (busy: boolean, label?: string) => void;
  firebaseReady: boolean;
  authUser: User | null;
  role: UserRole;
  operatorName: string;
  operatorEmail: string;
  activeCashierKey: string | null;
  cashierPermissions: Required<CashierPermissions>;
  setSessionRole: (role: UserRole, name: string, email?: string) => void;
  logout: () => Promise<void>;

  // Multi-Tenant Context
  tenants: TenantRecord[];
  activeTenantId: string | null;
  setActiveTenantId: (id: string | null) => void;
  activeTenant: TenantRecord | null;
  platformConfig: PlatformConfig;
  updatePlatformConfig: (patch: Partial<PlatformConfig>) => Promise<void>;
  updateTenantSettings: (patch: Record<string, unknown>, targetTenantId?: string) => Promise<void>;
  updateTenantRecord: (tenantId: string, patch: Partial<TenantRecord>) => Promise<void>;
  registerNewTenantClient: (
    input: RegisterTenantInput
  ) => Promise<{ tenant: TenantRecord; authResult: RegisterAuthResult }>;
  deleteTenantNode: (tenantId: string) => Promise<void>;
  ensurePlatformDefaults: () => Promise<void>;

  // Responsive Display Mode
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  isMobileLayout: boolean;
  isWideViewport: boolean;

  // Store & Rates
  config: Partial<AppConfig>;
  localName: string;
  mechanics: string[];
  updateMechanics: (nextList: string[]) => Promise<void>;
  bcvRate: number;
  secondaryRate: number;
  tertiaryRate: number;
  localCurrencyCode: CurrencyCode;
  localCurrency: CurrencyInfo;
  rateEditable: boolean;
  setLocalCurrency: (code: CurrencyCode, autoSync?: boolean) => Promise<void>;
  setRateEditable: (editable: boolean) => Promise<void>;
  syncCurrencyRate: (codeOverride?: CurrencyCode, silent?: boolean) => Promise<number | null>;
  ratesSyncing: boolean;
  syncAllRates: (silent?: boolean) => Promise<void>;
  syncBcvRate: (silent?: boolean) => Promise<void>;
  syncUsdtRate: (silent?: boolean) => Promise<void>;
  updateRate: (kind: 'bcv' | 'secundaria' | 'terciaria', value: number) => Promise<void>;

  // Data collections (real-time synced from active tenant node)
  products: Product[];
  liveSales: SaleTransaction[];
  savedCierres: CierreRecord[];
  fiados: Record<string, Record<string, FiadoRecord>>;
  tallerPendientes: TallerRepair[];
  tallerCierres: Record<string, { reparaciones?: Record<string, TallerRepair> }>;
  cashiers: CashierRecord[];
  systemUsers: SystemUserRecord[];
  tickets: SupportTicket[];
  membershipPayments: MembershipPayment[];
  notificationHistory: NotificationHistoryItem[];
  providers: ProviderRecord[];
  supplierPurchases: SupplierPurchaseRecord[];
  customers: CustomerRecord[];
  verificationConfig: VerificationRequestConfig | null;
  verificationDocs: Record<string, VerificationDocRecord>;
  verificationPendingCount: number;
  preRegistrations: PreRegistrationRecord[];
  ownerChatMessages: OwnerChatMessage[];
  sendOwnerChatMessage: (
    tenantId: string,
    text: string,
    senderRole?: 'owner' | 'client' | 'ai_bot',
    aiGenerated?: boolean
  ) => Promise<void>;
  clearOwnerChat: (tenantId: string) => Promise<void>;
  saveTenantVerificationConfig: (
    tenantId: string,
    cfg: VerificationRequestConfig,
    notifyClient?: boolean
  ) => Promise<void>;
  submitClientVerificationDoc: (
    reqId: string,
    label: string,
    payload: { imagen?: string; detalle?: string }
  ) => Promise<void>;
  reviewTenantVerificationDoc: (
    tenantId: string,
    reqId: string,
    estado: VerificationDocStatus,
    notaPropietario?: string
  ) => Promise<void>;

  // Membership & Flags
  membership: MembershipState | null;
  membershipDaysLeft: number;
  membershipExpired: boolean;
  avisoMembresia: NonNullable<AppConfig['aviso_membresia']>;
  activeMembershipWarning: {
    titulo: string;
    mensaje: string;
    diasRestantes: number;
  } | null;
  dismissMembershipWarning: () => void;
  plans: Record<string, MembershipPlan>;
  planLinks: Record<string, string>;
  promos: PromoRecord[];
  pagoMovil: PagoMovilConfig | null;
  metodosPagoMembresia: MembershipPaymentMethod[];
  adminAccessBlocked: boolean;
  userFrozen: boolean;
  maintenanceMode: boolean;
  globalMaintenance: boolean;
  maintenanceMessage: string;
  runtimeError: string | null;
  clearRuntimeError: () => void;

  // Cart & POS State
  cart: CartItem[];
  selectedSaleRate: '1' | '2' | '3';
  setSelectedSaleRate: (rate: '1' | '2' | '3') => void;
  ivaActive: boolean;
  toggleIva: () => void;
  globalParallelOverrideVes: number | null;
  setGlobalParallelOverrideVes: (v: number | null) => void;
  addToCart: (product: Product, qty: number, saleUnit?: 'detal' | 'bulto') => void;
  updateCartQty: (cartKeyOrProductId: string, delta: number) => void;
  removeFromCart: (cartKeyOrProductId: string) => void;
  setCartItemDiscount: (cartKeyOrProductId: string, newPriceVes: number) => void;
  clearCart: () => void;
  getEffectiveUnitPrice: (product: Product, saleUnit?: 'detal' | 'bulto') => number;
  getActiveRateValue: () => number;
  cartTotals: {
    subtotalVes: number;
    ivaVes: number;
    totalVes: number;
    totalUsdBcv: number;
    modeLabel: string;
  };

  // Checkout, Invoices, Printers & Closures
  invoiceConfig: TenantInvoiceConfig;
  updateLocalInvoiceConfig: (patch: Partial<TenantInvoiceConfig>) => Promise<void>;
  invoiceMode: InvoiceMode;
  setInvoiceMode: (mode: InvoiceMode) => void;
  detectedPrinters: ConnectedPrinterInfo[];
  activePrinter: ConnectedPrinterInfo | null;
  lastCompletedSale: SaleTransaction | null;
  refreshPrinters: () => Promise<ConnectedPrinterInfo[]>;
  connectUsbPrinter: () => Promise<ConnectedPrinterInfo | null>;
  connectSerialPrinter: () => Promise<ConnectedPrinterInfo | null>;
  disconnectPrinters: () => void;
  sendTestPrint: () => Promise<void>;
  dispatchSaleInvoice: (
    sale: SaleTransaction,
    modeOverride?: InvoiceMode
  ) => Promise<'printer' | 'pdf' | 'browser' | 'none'>;
  processSale: (params: {
    paymentMethod: string;
    usdCustomAmount?: number | null;
    invoiceModeOverride?: InvoiceMode;
    referenciaPago?: string;
    casheaData?: {
      nivel: string;
      inicialUsd: number;
      cuotas: number;
    };
    splitPayments?: SplitPaymentLeg[];
    customerInfo?: {
      cedula?: string;
      nombre?: string;
    };
    fiadoData?: {
      cliente: string;
      cedula: string;
      telefono?: string;
      direccion?: string;
      nota?: string;
      modalidad?: 'credito' | 'contado_pendiente';
      cuotas: number;
      fecha_vencimiento?: string;
      limite_credito?: number;
      inicial_usd?: number;
    };
  }) => Promise<boolean>;
  deleteFiadoInvoice: (fiado: FiadoRecord, restoreStock?: boolean) => Promise<void>;
  buildCurrentCierrePayload: () => CierreRecord;
  executeShiftClose: (authorizedByLabel?: string) => Promise<CierreRecord>;
  verifyAdminAuthorization: (
    secret: string,
    mode: 'pin' | 'password'
  ) => Promise<{ ok: boolean; error?: string; label?: string }>;
  voidLiveSale: (sale: SaleTransaction, authorizedByLabel: string) => Promise<void>;
  voidClosureSale: (
    closure: CierreRecord,
    saleIndex: number,
    authorizedByLabel: string
  ) => Promise<void>;
  deleteSavedCierre: (closureKey: string) => Promise<void>;
  reprintSavedCierre: (
    cierre: CierreRecord,
    target: 'auto' | 'thermal' | 'browser' | 'pdf'
  ) => Promise<void>;

  // Registered Billing Customers
  saveCustomer: (
    data: Omit<CustomerRecord, 'key' | 'createdAt' | 'updatedAt'>,
    editKey?: string
  ) => Promise<void>;
  deleteCustomer: (customerKey: string) => Promise<void>;

  // Suppliers, Purchases & Public Price Checker
  saveProvider: (
    data: Omit<ProviderRecord, 'key' | 'createdAt' | 'updatedAt'>,
    editKey?: string
  ) => Promise<void>;
  deleteProvider: (providerKey: string) => Promise<void>;
  registerSupplierPurchase: (input: {
    numero_factura: string;
    providerId: string;
    providerNombre: string;
    providerRif?: string;
    fecha: string;
    items: SupplierPurchaseItem[];
    estado_pago: 'pagada' | 'pendiente';
    metodo_pago?: string;
    actualizar_stock: boolean;
    nota?: string;
  }) => Promise<void>;
  updateSupplierPurchaseStatus: (
    purchaseKey: string,
    estado: 'pagada' | 'pendiente'
  ) => Promise<void>;
  deleteSupplierPurchase: (purchaseKey: string) => Promise<void>;
  syncPublicPriceChecker: (override?: {
    activo?: boolean;
    mostrar_paralelo?: boolean;
    mostrar_stock?: boolean;
    mensaje?: string;
  }) => Promise<void>;

  // Hardware Barcode Scanners
  scannerDevices: ConnectedScannerDevice[];
  lastHardwareScan: HardwareScanEvent | null;

  // Notifications, Push, Audio & Theme
  pushSupported: boolean;
  pushPermission: PushPermissionState;
  pushEnabled: boolean;
  enablePushNotifications: () => Promise<boolean>;
  togglePushNotifications: () => Promise<boolean>;
  sendTestPushNotification: () => Promise<void>;
  toasts: ToastMessage[];
  notifyToast: (text: string, type?: ToastMessage['type']) => void;
  playBeep: (kind?: 'ok' | 'err' | 'tick') => void;
  speakText: (text: string, force?: boolean) => void;
  voiceSettings: VoiceSettings;
  activeBroadcast: BroadcastConfig | null;
  dismissBroadcast: () => void;
  deleteNotification: (notifKey: string) => Promise<void>;
  clearAllNotifications: () => Promise<void>;
  activeTheme: string;
  setLocalTheme: (themeId: string | null) => void;

  // Helpers
  loginCashierWithPin: (
    email: string,
    pin: string,
    tenantIdOverride?: string
  ) => Promise<{ ok: boolean; error?: string }>;
  registerSystemUserSession: (
    user: User,
    role: 'admin' | 'owner',
    tenantIdOverride?: string
  ) => Promise<void>;
}

const PosContext = createContext<PosContextValue | null>(null);

export const PosProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const connected = true;
  const networkStatus: NetworkHealthStatus = 'online';
  const networkLatencyMs: number | null = null;
  const [systemBusyCount, setSystemBusyCount] = useState(0);
  const [systemBusyLabel, setSystemBusyLabel] = useState('');
  const [firebaseReady, setFirebaseReady] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(null);

  const [role, setRole] = useState<UserRole>(() => {
    try {
      const savedRole = (sessionStorage.getItem('ig_role') as UserRole) || '';
      const savedEmail = (sessionStorage.getItem('ig_email') || '').trim().toLowerCase();
      if (savedRole === 'owner' && savedEmail !== MASTER_OWNER_EMAIL.toLowerCase()) {
        return '';
      }
      return savedRole;
    } catch {
      return '';
    }
  });
  const [operatorName, setOperatorName] = useState<string>(() => {
    try {
      return sessionStorage.getItem('ig_who') || '';
    } catch {
      return '';
    }
  });
  const [operatorEmail, setOperatorEmail] = useState<string>(() => {
    try {
      return sessionStorage.getItem('ig_email') || '';
    } catch {
      return '';
    }
  });
  const [activeCashierKey, setActiveCashierKeyState] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('ig_cashier_key') || null;
    } catch {
      return null;
    }
  });

  const setActiveCashierKey = useCallback((key: string | null) => {
    setActiveCashierKeyState(key);
    try {
      if (key) sessionStorage.setItem('ig_cashier_key', key);
      else sessionStorage.removeItem('ig_cashier_key');
    } catch {
      // ignore storage errors
    }
  }, []);

  const [activeTenantId, setActiveTenantIdState] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('ig_tenant_id') || null;
    } catch {
      return null;
    }
  });

  const setActiveTenantId = useCallback((id: string | null) => {
    setActiveTenantIdState(id);
    try {
      if (id) sessionStorage.setItem('ig_tenant_id', id);
      else sessionStorage.removeItem('ig_tenant_id');
    } catch {
      // ignore storage errors
    }
  }, []);

  // Multi-Tenant & Platform State
  const [platformConfig, setPlatformConfig] = useState<PlatformConfig>({});
  const [tenants, setTenants] = useState<TenantRecord[]>([]);
  const [tenantSettings, setTenantSettings] = useState<Partial<AppConfig>>({});
  const [localRateFallback, setLocalRateFallback] = useState<{ bcv: number; usdt: number }>({
    bcv: 45.5,
    usdt: 50.0,
  });

  const [products, setProducts] = useState<Product[]>([]);
  const [liveSales, setLiveSales] = useState<SaleTransaction[]>([]);
  const [savedCierres, setSavedCierres] = useState<CierreRecord[]>([]);
  const [fiados, setFiados] = useState<Record<string, Record<string, FiadoRecord>>>({});
  const [tallerPendientes, setTallerPendientes] = useState<TallerRepair[]>([]);
  const [tallerCierres, setTallerCierres] = useState<
    Record<string, { reparaciones?: Record<string, TallerRepair> }>
  >({});
  const [cashiers, setCashiers] = useState<CashierRecord[]>([]);
  const [systemUsers, setSystemUsers] = useState<SystemUserRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [membershipPayments, setMembershipPayments] = useState<MembershipPayment[]>([]);
  const [notificationHistory, setNotificationHistory] = useState<NotificationHistoryItem[]>([]);
  const [providers, setProviders] = useState<ProviderRecord[]>([]);
  const [supplierPurchases, setSupplierPurchases] = useState<SupplierPurchaseRecord[]>([]);
  const [customers, setCustomers] = useState<CustomerRecord[]>([]);
  const [verificationDocs, setVerificationDocs] = useState<Record<string, VerificationDocRecord>>({});
  const [preRegistrations, setPreRegistrations] = useState<PreRegistrationRecord[]>([]);
  const [ownerChatMessages, setOwnerChatMessages] = useState<OwnerChatMessage[]>([]);
  const lastVerificationAlertRef = useRef<number>(0);
  const seenPreRegKeysRef = useRef<Set<string> | null>(null);
  const [scannerDevices, setScannerDevices] = useState<ConnectedScannerDevice[]>(() =>
    getConnectedScannerDevices()
  );
  const [lastHardwareScan, setLastHardwareScan] = useState<HardwareScanEvent | null>(null);

  // POS Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedSaleRate, setSelectedSaleRate] = useState<'1' | '2' | '3'>('1');
  const [ivaActive, setIvaActive] = useState(false);
  const [globalParallelOverrideVes, setGlobalParallelOverrideVes] = useState<number | null>(null);
  const [ratesSyncing, setRatesSyncing] = useState(false);

  // Notifications & Audio
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [dismissedBroadcastKey, setDismissedBroadcastKey] = useState<string>(() => {
    try {
      return localStorage.getItem('ig_dismissed_broadcast') || '';
    } catch {
      return '';
    }
  });
  const [localTheme, setLocalThemeState] = useState<string | null>(() => {
    try {
      return localStorage.getItem('ig_theme');
    } catch {
      return null;
    }
  });

  const [dismissedWarningKey, setDismissedWarningKey] = useState<string>(() => {
    try {
      return localStorage.getItem('ig2w') || '';
    } catch {
      return '';
    }
  });
  const [runtimeError, setRuntimeError] = useState<string | null>(null);
  const clearRuntimeError = useCallback(() => setRuntimeError(null), []);

  const [viewMode, setViewModeState] = useState<ViewMode>(() => {
    try {
      const stored = localStorage.getItem('ig_view_mode');
      return stored === 'desktop' || stored === 'mobile' ? stored : 'auto';
    } catch {
      return 'auto';
    }
  });
  const [viewportIsMobile, setViewportIsMobile] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth < 1024;
  });

  const setSystemBusyState = useCallback((busy: boolean, label = '') => {
    setSystemBusyCount((prev) => Math.max(0, prev + (busy ? 1 : -1)));
    if (busy && label) {
      setSystemBusyLabel(label);
    } else if (!busy) {
      setSystemBusyLabel('');
    }
  }, []);

  // Connection badge stays in steady server-connected mode without unstable/offline alerts.

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(max-width: 1023px)');
    const sync = () => setViewportIsMobile(mq.matches);
    sync();
    mq.addEventListener('change', sync);
    return () => mq.removeEventListener('change', sync);
  }, []);

  const setViewMode = useCallback((mode: ViewMode) => {
    setViewModeState(mode);
    try {
      localStorage.setItem('ig_view_mode', mode);
    } catch {
      // ignore storage errors
    }
  }, []);

  const isMobileLayout = viewMode === 'mobile' || (viewMode === 'auto' && viewportIsMobile);
  const isWideViewport = !viewportIsMobile;

  // Invoice & Printer state
  const [invoiceMode, setInvoiceModeState] = useState<InvoiceMode>(() => {
    try {
      const saved = localStorage.getItem('ig_invoice_mode');
      return saved === 'pdf' || saved === 'printer' || saved === 'none' ? saved : 'auto';
    } catch {
      return 'auto';
    }
  });
  const [detectedPrinters, setDetectedPrinters] = useState<ConnectedPrinterInfo[]>([]);
  const [lastCompletedSale, setLastCompletedSale] = useState<SaleTransaction | null>(null);

  const setInvoiceMode = useCallback((mode: InvoiceMode) => {
    setInvoiceModeState(mode);
    try {
      localStorage.setItem('ig_invoice_mode', mode);
    } catch {
      // ignore
    }
  }, []);

  const [pushPermission, setPushPermission] = useState<PushPermissionState>(() => getPushPermission());
  const [pushEnabled, setPushEnabled] = useState<boolean>(() => isPushPreferenceEnabled());
  const pushSupported = isPushSupported();

  const audioCtxRef = useRef<AudioContext | null>(null);
  const lastBroadcastSeenRef = useRef<string>('');
  const lastScheduledMinuteRef = useRef<string>('');
  const seenTicketKeysRef = useRef<Set<string> | null>(null);
  const seenPaymentKeysRef = useRef<Set<string> | null>(null);
  const seenClientPaymentStatesRef = useRef<Record<string, string> | null>(null);
  const seenClientTicketRepliesRef = useRef<Record<string, number> | null>(null);

  const activeTenant = useMemo(
    () => tenants.find((t) => t.id === activeTenantId) || null,
    [activeTenantId, tenants]
  );

  const invoiceConfig: TenantInvoiceConfig = useMemo(() => {
    const baseCfg = {
      ...(activeTenant?.invoice_config || {}),
      ...(tenantSettings.invoice_config || {}),
    };
    const merged = mergeInvoiceConfig(Object.keys(baseCfg).length > 0 ? baseCfg : null);
    if (!merged.logo_data_url && (activeTenant?.logo_url || tenantSettings.logo_url)) {
      merged.logo_data_url = activeTenant?.logo_url || tenantSettings.logo_url || '';
    }
    return merged;
  }, [activeTenant?.invoice_config, activeTenant?.logo_url, tenantSettings.invoice_config, tenantSettings.logo_url]);

  const verificationConfig: VerificationRequestConfig | null = useMemo(
    () => activeTenant?.verificacion_datos || null,
    [activeTenant?.verificacion_datos]
  );

  const verificationPendingCount = useMemo(() => {
    if (!verificationConfig?.activo) return 0;
    const presetKeys = Object.entries(verificationConfig.requisitos || {})
      .filter(([, enabled]) => Boolean(enabled))
      .map(([reqKey]) => reqKey);
    const customKeys = (verificationConfig.requisitos_personalizados || [])
      .filter((c) => c.activo !== false)
      .map((c) => c.id);
    const allKeys = [...presetKeys, ...customKeys];
    return allKeys.filter((reqKey) => {
      const docState = verificationDocs[reqKey]?.estado;
      return docState !== 'verificado';
    }).length;
  }, [verificationConfig, verificationDocs]);

  const tenantMetaForReceipt: TenantMetaForReceipt = useMemo(() => {
    const sCfg = activeTenant?.seniat_config || {};
    const prefFac = sCfg.prefijo_factura || platformConfig.seniat_prefijo_factura || 'FAC-';
    const prefCtrl = sCfg.prefijo_control || platformConfig.seniat_prefijo_control || '00-';
    return {
      razonSocial: activeTenant?.razon_social || activeTenant?.nombre_local || '',
      rif: activeTenant?.rif || '',
      direccion: activeTenant?.direccion_fiscal || '',
      telefono: activeTenant?.telefono || '',
      seniatLegal: {
        activo: platformConfig.seniat_legal_activo === true,
        providencia:
          sCfg.providencia ||
          platformConfig.seniat_providencia ||
          'Providencia Administrativa SNAT/2011/00071 · SENIAT Venezuela',
        pieLegal:
          sCfg.pie_legal ||
          platformConfig.seniat_pie_legal ||
          'Documento fiscal emitido conforme a las regulaciones vigentes del SENIAT · República Bolivariana de Venezuela',
        prefijoFactura: prefFac,
        prefijoControl: prefCtrl,
        maquinaFiscal: sCfg.maquina_fiscal || '',
        ivaPorcentaje:
          typeof sCfg.iva_porcentaje === 'number'
            ? sCfg.iva_porcentaje
            : typeof platformConfig.seniat_iva_porcentaje === 'number'
            ? platformConfig.seniat_iva_porcentaje
            : 16,
      },
    };
  }, [
    activeTenant?.direccion_fiscal,
    activeTenant?.nombre_local,
    activeTenant?.razon_social,
    activeTenant?.rif,
    activeTenant?.seniat_config,
    activeTenant?.telefono,
    platformConfig.seniat_iva_porcentaje,
    platformConfig.seniat_legal_activo,
    platformConfig.seniat_pie_legal,
    platformConfig.seniat_prefijo_control,
    platformConfig.seniat_prefijo_factura,
    platformConfig.seniat_providencia,
  ]);

  // Unified config combining global platformConfig + selected tenant + tenantSettings
  const config: Partial<AppConfig> = useMemo(() => {
    return {
      nombre_local:
        tenantSettings.nombre_local ||
        activeTenant?.nombre_local ||
        platformConfig.nombre_plataforma ||
        'Innova Grup',
      tasa_bcv: Number(tenantSettings.tasa_bcv) || localRateFallback.bcv,
      tasa_secundaria: Number(tenantSettings.tasa_secundaria) || localRateFallback.usdt,
      tasa_terciaria: Number(tenantSettings.tasa_terciaria) || 52.0,
      moneda_local: isSupportedCurrencyCode(tenantSettings.moneda_local)
        ? tenantSettings.moneda_local
        : 'VES',
      tasa_editable: tenantSettings.tasa_editable !== false,
      whatsapp_close_phone: tenantSettings.whatsapp_close_phone || '',
      whatsapp_membresia: platformConfig.whatsapp_membresia || DEFAULT_WA_MEMBRESIA,
      whatsapp_soporte:
        platformConfig.whatsapp_soporte ||
        platformConfig.whatsapp_membresia ||
        DEFAULT_WA_MEMBRESIA,
      whatsapp_soporte_secundario: platformConfig.whatsapp_soporte_secundario || '',
      soporte_horario:
        platformConfig.soporte_horario || 'Lun–Sáb 8:00 a.m. – 8:00 p.m.',
      propietario_email: platformConfig.propietario_email || MASTER_OWNER_EMAIL,
      caja_abierta: tenantSettings.caja_abierta === true,
      admin_bloqueado: activeTenant?.admin_bloqueado === true,
      usuario_congelado: activeTenant?.congelado === true,
      mantenimiento: activeTenant?.mantenimiento === true,
      mantenimiento_global: platformConfig.mantenimiento_global === true,
      mantenimiento_mensaje: platformConfig.mantenimiento_mensaje || '',
      seniat_legal_activo: platformConfig.seniat_legal_activo === true,
      seniat_providencia:
        platformConfig.seniat_providencia ||
        'Providencia Administrativa SNAT/2011/00071 · SENIAT Venezuela',
      seniat_pie_legal:
        platformConfig.seniat_pie_legal ||
        'Documento fiscal emitido conforme a las regulaciones vigentes del SENIAT · República Bolivariana de Venezuela',
      consultor_precios_activo: tenantSettings.consultor_precios_activo === true,
      consultor_mostrar_paralelo: tenantSettings.consultor_mostrar_paralelo !== false,
      consultor_mostrar_stock: tenantSettings.consultor_mostrar_stock !== false,
      consultor_mensaje: tenantSettings.consultor_mensaje || '',
      tema: tenantSettings.tema || 'innova',
      meta_usd: Number(tenantSettings.meta_usd) || 0,
      broadcast: tenantSettings.broadcast || null,
      avisos: tenantSettings.avisos || DEFAULT_SCHEDULED_NOTICES,
      voz: tenantSettings.voz || platformConfig.voz,
      mecanicos: Array.isArray(tenantSettings.mecanicos)
        ? tenantSettings.mecanicos
        : DEFAULT_MECHANICS,
      membresia: activeTenant?.membresia || null,
      planes: platformConfig.planes || defaultPlans(),
      planes_links: platformConfig.planes_links || {},
      promos: platformConfig.promos || {},
      pago_movil: platformConfig.pago_movil || DEFAULT_PAGO_MOVIL,
      metodos_pago_membresia: Array.isArray(platformConfig.metodos_pago_membresia)
        ? platformConfig.metodos_pago_membresia
        : [],
      aviso_membresia: platformConfig.aviso_membresia,
      logo_url: invoiceConfig.logo_data_url || '',
      invoice_config: invoiceConfig,
      verificacion_datos: verificationConfig,
    };
  }, [activeTenant, invoiceConfig, localRateFallback.bcv, localRateFallback.usdt, platformConfig, tenantSettings, verificationConfig]);

  const mechanics = useMemo(() => {
    if (Array.isArray(tenantSettings.mecanicos)) {
      const cleaned = tenantSettings.mecanicos
        .map((m) => String(m || '').trim())
        .filter(Boolean);
      return cleaned;
    }
    return DEFAULT_MECHANICS;
  }, [tenantSettings.mecanicos]);


  const rawLocalName = config.nombre_local;
  const localName =
    rawLocalName && !/jj\s*repuestos/i.test(rawLocalName) ? rawLocalName : 'Innova Grup';
  const localCurrencyCode: CurrencyCode = isSupportedCurrencyCode(config.moneda_local)
    ? config.moneda_local
    : 'VES';
  const localCurrency = useMemo(() => getCurrencyInfo(localCurrencyCode), [localCurrencyCode]);
  const rateEditable = config.tasa_editable !== false;
  const bcvRate = Number(config.tasa_bcv) || localCurrency.defaultRate;
  const secondaryRate = Number(config.tasa_secundaria) || localCurrency.defaultRate;
  const tertiaryRate = Number(config.tasa_terciaria) || localCurrency.defaultRate;

  const voiceSettings: VoiceSettings = useMemo(
    () => ({
      activa: config.voz?.activa ?? false,
      vel: Number(config.voz?.vel) || 1,
      voz: config.voz?.voz || '',
      sonidos: config.voz?.sonidos !== false,
    }),
    [config.voz]
  );

  const notifyToast = useCallback((text: string, type: ToastMessage['type'] = 'info') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setToasts((prev) => [...prev.slice(-4), { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5500);
  }, []);

  const enablePushNotifications = useCallback(async (): Promise<boolean> => {
    if (!pushSupported) {
      notifyToast('Este navegador no soporta notificaciones push nativas.', 'warning');
      return false;
    }
    const res = await requestPushPermission();
    setPushPermission(res.permission);
    if (res.ok && res.permission === 'granted') {
      setPushPreferenceEnabled(true);
      setPushEnabled(true);
      notifyToast('Notificaciones push activadas para Android y Web.', 'success');
      void sendSystemPushNotification({
        title: `${localName} · Notificaciones activas`,
        body: 'Recibirás alertas de pagos, soporte y avisos en tiempo real.',
        tag: 'innova-push-enabled',
      });
      return true;
    }
    notifyToast(res.message, 'warning');
    return false;
  }, [localName, notifyToast, pushSupported]);

  const togglePushNotifications = useCallback(async (): Promise<boolean> => {
    if (pushEnabled && pushPermission === 'granted') {
      setPushPreferenceEnabled(false);
      setPushEnabled(false);
      notifyToast('Notificaciones push silenciadas en este dispositivo.', 'info');
      return false;
    }
    return enablePushNotifications();
  }, [enablePushNotifications, notifyToast, pushEnabled, pushPermission]);

  const sendTestPushNotification = useCallback(async () => {
    if (pushPermission !== 'granted') {
      const ok = await enablePushNotifications();
      if (!ok) return;
      return;
    }
    const sent = await sendSystemPushNotification({
      title: `${localName} · Alerta de Prueba`,
      body: 'Las notificaciones push en Android y Web están funcionando correctamente.',
      tag: `innova-test-${Date.now()}`,
      requireInteraction: false,
    });
    if (sent) {
      notifyToast('Notificación push de prueba enviada.', 'success');
    } else {
      notifyToast('Activa las notificaciones push para recibir alertas.', 'warning');
    }
  }, [enablePushNotifications, localName, notifyToast, pushPermission]);

  const playBeep = useCallback(
    (kind: 'ok' | 'err' | 'tick' = 'ok') => {
      if (!voiceSettings.sonidos) return;
      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtx) return;
        audioCtxRef.current = audioCtxRef.current || new AudioCtx();
        const ctx = audioCtxRef.current;
        if (ctx.state === 'suspended') ctx.resume();

        const playTone = (
          freq: number,
          dur: number,
          oscType: OscillatorType,
          vol: number,
          offset = 0
        ) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const start = ctx.currentTime + offset;
          osc.type = oscType;
          osc.frequency.value = freq;
          gain.gain.setValueAtTime(vol, start);
          gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + dur);
        };

        if (kind === 'ok') {
          playTone(880, 0.1, 'sine', 0.06, 0);
          playTone(1320, 0.14, 'sine', 0.06, 0.09);
        } else if (kind === 'err') {
          playTone(210, 0.2, 'sawtooth', 0.05, 0);
          playTone(150, 0.25, 'sawtooth', 0.05, 0.14);
        } else {
          playTone(1150, 0.025, 'square', 0.015, 0);
        }
      } catch {
        // ignore audio context errors
      }
    },
    [voiceSettings.sonidos]
  );

  const speakText = useCallback(
    (text: string, force = false) => {
      if (!force && !voiceSettings.activa) return;
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(String(text).slice(0, 220));
        utterance.lang = 'es-ES';
        utterance.rate = voiceSettings.vel || 1;
        const voices = window.speechSynthesis.getVoices();
        const match =
          voices.find((v) => v.name === voiceSettings.voz) ||
          voices.find((v) => /^es/i.test(v.lang));
        if (match) {
          utterance.voice = match;
          utterance.lang = match.lang;
        }
        window.speechSynthesis.speak(utterance);
      } catch {
        // ignore speech synthesis errors
      }
    },
    [voiceSettings]
  );

  const setSessionRole = useCallback(
    (newRole: UserRole, name: string, email = '') => {
      const cleanEmail = (email || auth.currentUser?.email || '').trim().toLowerCase();
      if (newRole === 'owner' && cleanEmail !== MASTER_OWNER_EMAIL.toLowerCase()) {
        notifyToast('Acceso denegado: solo el correo autorizado puede usar el Panel del Propietario.', 'error');
        setRole('');
        setOperatorName('');
        setOperatorEmail('');
        try {
          sessionStorage.removeItem('ig_role');
          sessionStorage.removeItem('ig_who');
          sessionStorage.removeItem('ig_email');
        } catch {
          // ignore storage errors
        }
        return;
      }

      setRole(newRole);
      setOperatorName(name);
      setOperatorEmail(email);
      try {
        if (newRole) {
          sessionStorage.setItem('ig_role', newRole);
          sessionStorage.setItem('ig_who', name);
          sessionStorage.setItem('ig_email', email);
        } else {
          sessionStorage.removeItem('ig_role');
          sessionStorage.removeItem('ig_who');
          sessionStorage.removeItem('ig_email');
        }
      } catch {
        // ignore storage errors
      }
    },
    [notifyToast]
  );

  const logout = useCallback(async () => {
    // Detach listeners first by clearing role and tenant before Firebase signOut
    setSessionRole('', '', '');
    setActiveCashierKey(null);
    setActiveTenantId(null);
    setCart([]);
    setProducts([]);
    setLiveSales([]);
    setSavedCierres([]);
    setFiados({});
    setTallerPendientes([]);
    setTallerCierres({});
    setCashiers([]);
    setSystemUsers([]);
    setTickets([]);
    setMembershipPayments([]);
    setNotificationHistory([]);
    setProviders([]);
    setSupplierPurchases([]);
    setCustomers([]);
    setVerificationDocs({});
    // Allow React one tick to unsubscribe active onSnapshot listeners before revoking auth
    await new Promise((resolve) => setTimeout(resolve, 40));
    try {
      await logoutFirebase();
    } catch {
      // ignore signOut errors
    }
  }, [setActiveCashierKey, setActiveTenantId, setSessionRole]);

  // Helper: update /platform/config using mergeFields so replacing nested maps (planes, promos, planes_links) truly deletes removed keys
  const updatePlatformConfig = useCallback(async (patch: Partial<PlatformConfig>) => {
    const path = 'platform/config';
    const cleanPayload = stripUndefined({ ...patch, updatedAt: Date.now() }) as Record<string, unknown>;
    try {
      await setDoc(doc(db, 'platform', 'config'), cleanPayload, {
        mergeFields: Object.keys(cleanPayload),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }, []);

  // Helper: update /tenants/{tid}/settings/config with optimistic UI sync + legacy key self-healing
  const updateTenantSettings = useCallback(
    async (patch: Record<string, unknown>, targetTenantId?: string) => {
      const tid = targetTenantId || activeTenantId;
      if (!tid) return;
      const isActive = !targetTenantId || targetTenantId === activeTenantId;
      if (isActive) {
        setTenantSettings((prev) => ({ ...prev, ...patch } as Partial<AppConfig>));
      }
      const path = `tenants/${tid}/settings/config`;
      const ref = doc(db, 'tenants', tid, 'settings', 'config');
      const payload = stripUndefined({ ...patch, updatedAt: Date.now() });
      try {
        await setDoc(ref, payload, { merge: true });
      } catch (err) {
        // Self-heal if an older Firestore settings doc has legacy keys blocked by isValidTenantSettings
        const ALLOWED_KEYS = new Set([
          'nombre_local',
          'tasa_bcv',
          'tasa_secundaria',
          'tasa_terciaria',
          'moneda_local',
          'tasa_editable',
          'whatsapp_close_phone',
          'caja_abierta',
          'tema',
          'meta_usd',
          'broadcast',
          'avisos',
          'voz',
          'mecanicos',
          'consultor_precios_activo',
          'consultor_mostrar_paralelo',
          'consultor_mostrar_stock',
          'consultor_mensaje',
          'logo_url',
          'invoice_config',
          'updatedAt',
        ]);
        try {
          const existingSnap = await getDoc(ref);
          const mergedRaw: Record<string, unknown> = {
            ...(existingSnap.exists() ? (existingSnap.data() as Record<string, unknown>) : {}),
            ...payload,
          };
          const cleanDoc: Record<string, unknown> = {};
          for (const [k, v] of Object.entries(mergedRaw)) {
            if (ALLOWED_KEYS.has(k) && v !== undefined) {
              cleanDoc[k] = v;
            }
          }
          await setDoc(ref, cleanDoc);
          return;
        } catch {
          handleFirestoreError(err, OperationType.WRITE, path);
        }
      }
    },
    [activeTenantId]
  );

  const updateMechanics = useCallback(
    async (nextList: string[]) => {
      const normalized = Array.from(
        new Set(nextList.map((m) => m.trim()).filter(Boolean))
      ).slice(0, 50);
      await updateTenantSettings({ mecanicos: normalized });
    },
    [updateTenantSettings]
  );

  // Helper: update /tenants/{tenantId}
  const updateTenantRecord = useCallback(async (tenantId: string, patch: Partial<TenantRecord>) => {
    const path = `tenants/${tenantId}`;
    try {
      await updateDoc(doc(db, 'tenants', tenantId), stripUndefined({ ...patch, updatedAt: Date.now() }));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }, []);

  const updateLocalInvoiceConfig = useCallback(
    async (patch: Partial<TenantInvoiceConfig>) => {
      const merged: TenantInvoiceConfig = {
        ...invoiceConfig,
        ...patch,
      };
      await updateTenantSettings({
        invoice_config: merged,
        ...(patch.logo_data_url !== undefined ? { logo_url: patch.logo_data_url } : {}),
      });
    },
    [invoiceConfig, updateTenantSettings]
  );

  const saveTenantVerificationConfig = useCallback(
    async (tenantId: string, cfg: VerificationRequestConfig, notifyClient = true) => {
      const now = Date.now();
      const customList = Array.isArray(cfg.requisitos_personalizados)
        ? cfg.requisitos_personalizados
            .filter((item) => item && item.id && item.label && item.label.trim().length > 0)
            .slice(0, 20)
            .map((item) => ({
              id: sanitizeFirestoreId(item.id, 'req'),
              label: item.label.trim().slice(0, 120),
              description: (item.description || '').trim().slice(0, 240),
              requiere_foto: item.requiere_foto !== false,
              activo: item.activo !== false,
            }))
        : [];
      const cleanCfg: VerificationRequestConfig = {
        activo: Boolean(cfg.activo),
        mensaje: (cfg.mensaje || '').trim().slice(0, 320),
        requisitos: cfg.requisitos || {},
        requisitos_foto: cfg.requisitos_foto || {},
        requisitos_personalizados: customList,
        activado_en: cfg.activo ? cfg.activado_en || now : cfg.activado_en || 0,
        updatedAt: now,
      };
      await updateTenantRecord(tenantId, { verificacion_datos: cleanCfg });

      if (cleanCfg.activo && notifyClient) {
        const presetCount = Object.values(cleanCfg.requisitos || {}).filter(Boolean).length;
        const customCount = customList.filter((c) => c.activo).length;
        const reqCount = presetCount + customCount;
        const notifTitle = 'Actualización y Verificación de Datos Requerida';
        const notifText =
          cleanCfg.mensaje ||
          `La administración solicita actualizar y verificar ${reqCount} requisito(s) de tu comercio. Ingresa desde la alerta superior del menú.`;
        const notifPayload: BroadcastConfig = {
          id: now,
          titulo: notifTitle,
          texto: notifText,
          tipo: 'warning',
          audiencia: 'all',
          con_voz: false,
          timestamp: now,
          enviado_por: auth.currentUser?.email || MASTER_OWNER_EMAIL,
        };
        try {
          await setDoc(doc(db, 'tenants', tenantId, 'notifications', `verif_${now}`), notifPayload);
          await updateTenantSettings({ broadcast: notifPayload }, tenantId);
        } catch {
          // non-blocking notification dispatch
        }
      }
    },
    [updateTenantRecord, updateTenantSettings]
  );

  const submitClientVerificationDoc = useCallback(
    async (
      reqId: string,
      label: string,
      payload: { imagen?: string; detalle?: string }
    ) => {
      if (!activeTenantId) return;
      const safeReqId = sanitizeFirestoreId(reqId, 'req').slice(0, 80);
      const path = `tenants/${activeTenantId}/verification_docs/${safeReqId}`;
      const existingDoc = verificationDocs[safeReqId];
      const nextDoc = stripUndefined({
        req_id: safeReqId,
        label: label.slice(0, 160),
        imagen: payload.imagen !== undefined ? payload.imagen : existingDoc?.imagen || '',
        detalle: (payload.detalle ?? existingDoc?.detalle ?? '').trim().slice(0, 600),
        estado: 'en_revision' as VerificationDocStatus,
        nota_propietario: '',
        subido_por: operatorName || operatorEmail || auth.currentUser?.email || 'Cliente',
        subido_en: Date.now(),
      });
      try {
        await setDoc(doc(db, 'tenants', activeTenantId, 'verification_docs', safeReqId), nextDoc, {
          merge: true,
        });
        playBeep('ok');
        notifyToast(`Documento "${label}" enviado a revisión del propietario.`, 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    },
    [activeTenantId, notifyToast, operatorEmail, operatorName, playBeep, verificationDocs]
  );

  const reviewTenantVerificationDoc = useCallback(
    async (
      tenantId: string,
      reqId: string,
      estado: VerificationDocStatus,
      notaPropietario = ''
    ) => {
      const safeReqId = sanitizeFirestoreId(reqId, 'req').slice(0, 80);
      const path = `tenants/${tenantId}/verification_docs/${safeReqId}`;
      const now = Date.now();
      const docRef = doc(db, 'tenants', tenantId, 'verification_docs', safeReqId);
      try {
        const snap = await getDoc(docRef);
        const existingData = snap.exists() ? (snap.data() as Partial<VerificationDocRecord>) : {};
        const payload = stripUndefined({
          req_id: safeReqId,
          label: existingData.label || safeReqId,
          imagen: existingData.imagen || '',
          detalle: existingData.detalle || '',
          estado,
          nota_propietario: notaPropietario.trim().slice(0, 400),
          subido_por: existingData.subido_por || '',
          subido_en: existingData.subido_en || now,
          revisado_en: now,
          revisado_por: auth.currentUser?.email || MASTER_OWNER_EMAIL,
        });
        await setDoc(docRef, payload);
        if (estado === 'rechazado' || estado === 'verificado') {
          const notifId = `verif_rev_${safeReqId}_${now}`;
          const notif: BroadcastConfig = {
            id: now,
            titulo:
              estado === 'verificado'
                ? `Documento Verificado: ${payload.label}`
                : `Documento Rechazado: ${payload.label}`,
            texto:
              estado === 'verificado'
                ? `Tu documento "${payload.label}" fue aprobado por el propietario.`
                : `Tu documento "${payload.label}" fue rechazado. ${
                    notaPropietario.trim() || 'Por favor sube una imagen clara y actualizada.'
                  }`,
            tipo: estado === 'verificado' ? 'info' : 'warning',
            audiencia: 'all',
            con_voz: false,
            timestamp: now,
            enviado_por: auth.currentUser?.email || MASTER_OWNER_EMAIL,
          };
          await setDoc(doc(db, 'tenants', tenantId, 'notifications', notifId), notif).catch(() => {});
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    },
    []
  );

  const sendOwnerChatMessage = useCallback(
    async (
      tenantId: string,
      text: string,
      senderRole: 'owner' | 'client' | 'ai_bot' = 'owner',
      aiGenerated = false
    ) => {
      const cleanText = text.trim().slice(0, 2000);
      if (!tenantId || !cleanText) return;
      const now = Date.now();
      const msgId = `msg_${now}_${Math.random().toString(36).slice(2, 6)}`;
      const path = `tenants/${tenantId}/owner_chat/${msgId}`;
      const payload = stripUndefined({
        senderRole,
        senderName:
          senderRole === 'ai_bot'
            ? 'Innova Grup · Asistente Virtual'
            : senderRole === 'owner'
            ? 'Propietario · Innova Grup'
            : operatorName || activeTenant?.nombre_local || 'Cliente',
        senderEmail: auth.currentUser?.email || operatorEmail || '',
        text: cleanText,
        aiGenerated: Boolean(aiGenerated),
        timestamp: now,
      });
      try {
        await setDoc(doc(db, 'tenants', tenantId, 'owner_chat', msgId), payload);
        if (senderRole === 'owner' || (senderRole === 'ai_bot' && role === 'owner')) {
          const notif: BroadcastConfig = {
            id: now,
            titulo:
              senderRole === 'ai_bot'
                ? 'Mensaje de Innova Grup · Asistente Virtual'
                : 'Mensaje del Propietario · Innova Grup',
            texto: cleanText.slice(0, 950),
            tipo: 'info',
            audiencia: 'all',
            con_voz: false,
            timestamp: now,
            enviado_por: payload.senderName,
          };
          await setDoc(doc(db, 'tenants', tenantId, 'notifications', `chat_${now}`), notif).catch(() => {});
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeTenant?.nombre_local, operatorEmail, operatorName, role]
  );

  const clearOwnerChat = useCallback(
    async (tenantId: string) => {
      if (!tenantId) return;
      const colRef = collection(db, 'tenants', tenantId, 'owner_chat');
      try {
        const snap = await getDocs(colRef);
        if (snap.empty) {
          notifyToast('El chat ya está vacío.', 'info');
          return;
        }
        const docs = snap.docs;
        for (let i = 0; i < docs.length; i += 400) {
          const chunk = docs.slice(i, i + 400);
          const batch = writeBatch(db);
          chunk.forEach((d) => batch.delete(d.ref));
          await batch.commit();
        }
        notifyToast('Conversación eliminada y restablecida.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `tenants/${tenantId}/owner_chat`);
      }
    },
    [notifyToast]
  );

  // Bootstrap global /platform/config defaults on Master Owner sign-in
  const ensurePlatformDefaults = useCallback(async () => {
    const cfgRef = doc(db, 'platform', 'config');
    try {
      const snap = await getDoc(cfgRef);
      if (!snap.exists()) {
        await setDoc(cfgRef, {
          nombre_plataforma: 'Innova Grup POS',
          propietario_email: MASTER_OWNER_EMAIL,
          whatsapp_membresia: DEFAULT_WA_MEMBRESIA,
          pago_movil: DEFAULT_PAGO_MOVIL,
          metodos_pago_membresia: [],
          planes: defaultPlans(),
          planes_links: {},
          promos: {},
          aviso_membresia: {
            dias: 5,
            activo: true,
            titulo: 'Tu membresía está por vencer',
            msg: 'Te quedan {dias} día(s) de membresía. Renueva a tiempo para no perder el acceso al sistema.',
          },
          voz: { activa: false, vel: 1, voz: '', sonidos: true },
          updatedAt: Date.now(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'platform/config');
    }
  }, []);

  // Register a brand new isolated Client/Tenant Node from Owner Panel
  const registerNewTenantClient = useCallback(
    async (
      input: RegisterTenantInput
    ): Promise<{ tenant: TenantRecord; authResult: RegisterAuthResult }> => {
      const cleanEmail = input.email.trim().toLowerCase();
      const now = Date.now();
      const authResult = await registerClientAuthAccount(
        cleanEmail,
        input.password,
        input.nombre_local.trim()
      );
      const tenantId = sanitizeFirestoreId(
        authResult.uid || `${cleanEmail.split('@')[0]}_${now}`,
        'tenant'
      );
      const ownerUid = authResult.uid || `pending_${tenantId}`;

      const selectedPlanKey = input.plan_key || 'p1';
      const chosenPlan =
        (platformConfig.planes && platformConfig.planes[selectedPlanKey]) ||
        defaultPlans()[selectedPlanKey] ||
        defaultPlans().p1;
      let expiresAtMs: number;
      let membershipLabel: string;
      if (typeof input.trial_days === 'number' && input.trial_days > 0) {
        expiresAtMs = now + input.trial_days * 86400000;
        membershipLabel = input.plan_label_override || `Regalo de Bienvenida (${input.trial_days} días)`;
      } else {
        const expDate = new Date();
        expDate.setMonth(expDate.getMonth() + (Number(chosenPlan?.meses) || 1));
        expiresAtMs = expDate.getTime();
        membershipLabel = input.plan_label_override || chosenPlan?.nombre || '1 Mes';
      }

      const adminCreds = input.admin_pin?.trim()
        ? await createPinCredentials(input.admin_pin.trim())
        : null;
      const cajaCreds = input.caja_pin?.trim()
        ? await createPinCredentials(input.caja_pin.trim())
        : null;

      const initialInvoiceCfg =
        input.logo_url || input.invoice_config
          ? mergeInvoiceConfig({
              ...(input.invoice_config || {}),
              ...(input.logo_url ? { logo_data_url: input.logo_url, mostrar_logo: true } : {}),
            })
          : undefined;

      const rawTenantDoc: TenantRecord = {
        id: tenantId,
        ownerUid,
        email: cleanEmail,
        nombre_local: input.nombre_local.trim(),
        razon_social: input.razon_social?.trim() || input.nombre_local.trim(),
        rif: input.rif?.trim() || '',
        direccion_fiscal: input.direccion_fiscal?.trim() || '',
        telefono: input.telefono?.trim() || '',
        contacto_nombre: input.contacto_nombre?.trim() || '',
        admin_pin_salt: adminCreds?.salt,
        admin_pin_hash: adminCreds?.hash,
        caja_pin_salt: cajaCreds?.salt,
        caja_pin_hash: cajaCreds?.hash,
        logo_url: input.logo_url || undefined,
        invoice_config: initialInvoiceCfg,
        membresia: {
          plan: typeof input.trial_days === 'number' && input.trial_days > 0 ? 'trial_5d' : selectedPlanKey,
          nombre: membershipLabel,
          vence: expiresAtMs,
          estado: 'activa',
        },
        activo: true,
        congelado: false,
        admin_bloqueado: false,
        mantenimiento: false,
        ultimo_acceso: now,
        createdAt: now,
        updatedAt: now,
        createdBy: auth.currentUser?.email || MASTER_OWNER_EMAIL,
      };
      const tenantDoc: TenantRecord = stripUndefined(rawTenantDoc as unknown as Record<string, unknown>) as unknown as TenantRecord;

      const batch = writeBatch(db);
      batch.set(doc(db, 'tenants', tenantId), tenantDoc);
      batch.set(
        doc(db, 'tenants', tenantId, 'settings', 'config'),
        stripUndefined({
          nombre_local: input.nombre_local.trim(),
          tasa_bcv: bcvRate || 45.5,
          tasa_secundaria: secondaryRate || 50.0,
          tasa_terciaria: tertiaryRate || 52.0,
          whatsapp_close_phone: input.telefono?.replace(/\D/g, '') || '',
          caja_abierta: false,
          tema: 'innova',
          meta_usd: Number(input.meta_usd) || 500,
          avisos: DEFAULT_SCHEDULED_NOTICES,
          voz: { activa: false, vel: 1, voz: '', sonidos: true },
          logo_url: input.logo_url || undefined,
          invoice_config: initialInvoiceCfg,
          updatedAt: now,
        })
      );

      const userDocId = sanitizeFirestoreId(cleanEmail, 'usr');
      batch.set(doc(db, 'tenants', tenantId, 'users', userDocId), {
        nombre: input.contacto_nombre?.trim() || input.nombre_local.trim(),
        email: cleanEmail,
        rol: 'admin',
        activo: true,
        creado: now,
      });

      if (cajaCreds) {
        const cashierId = `cashier_${now}`;
        batch.set(doc(db, 'tenants', tenantId, 'cashiers', cashierId), {
          nombre: input.cajero_nombre?.trim() || 'Cajero Principal',
          email: cleanEmail,
          telefono: input.telefono?.trim() || '',
          turno: 'Completo',
          activo: true,
          salt: cajaCreds.salt,
          hash: cajaCreds.hash,
          creado: now,
          permisos: { ...DEFAULT_CASHIER_PERMISSIONS },
        });
      }

      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `tenants/${tenantId}`);
      }

      setActiveTenantId(tenantId);
      return { tenant: tenantDoc, authResult };
    },
    [bcvRate, platformConfig.planes, secondaryRate, setActiveTenantId, tertiaryRate]
  );

  // Delete an entire isolated client node + subcollections
  const deleteTenantNode = useCallback(
    async (tenantId: string) => {
      const subcols = [
        'settings',
        'products',
        'sales',
        'closures',
        'fiados',
        'taller_pending',
        'taller_closures',
        'cashiers',
        'users',
        'tickets',
        'membership_payments',
        'notifications',
        'cash_openings',
        'providers',
        'supplier_purchases',
        'public_checker',
        'customers',
        'verification_docs',
        'owner_chat',
      ];
      try {
        for (const sub of subcols) {
          const snap = await getDocs(collection(db, 'tenants', tenantId, sub));
          if (!snap.empty) {
            const batch = writeBatch(db);
            snap.docs.forEach((d) => batch.delete(d.ref));
            await batch.commit();
          }
        }
        await deleteDoc(doc(db, 'tenants', tenantId));
        if (activeTenantId === tenantId) {
          setActiveTenantId(null);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `tenants/${tenantId}`);
      }
    },
    [activeTenantId, setActiveTenantId]
  );

  const registerSystemUserSession = useCallback(
    async (user: User, userRole: 'admin' | 'owner', tenantIdOverride?: string) => {
      const tid = tenantIdOverride || activeTenantId;
      if (!user?.email || !tid) return;
      const safeKey = sanitizeFirestoreId(user.uid || user.email);
      const path = `tenants/${tid}/users/${safeKey}`;
      try {
        await setDoc(
          doc(db, 'tenants', tid, 'users', safeKey),
          {
            nombre: user.displayName || user.email.split('@')[0],
            email: user.email.toLowerCase(),
            rol: userRole,
            activo: true,
            ultimo_acceso: Date.now(),
          },
          { merge: true }
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    },
    [activeTenantId]
  );

  const loginCashierWithPin = useCallback(
    async (
      email: string,
      pin: string,
      tenantIdOverride?: string
    ): Promise<{ ok: boolean; error?: string }> => {
      const cleanEmail = email.trim().toLowerCase();
      let lockState: { n?: number; until?: number } = {};
      try {
        lockState = JSON.parse(localStorage.getItem('ig_lk') || '{}');
      } catch {
        lockState = {};
      }
      if (lockState.until && lockState.until > Date.now()) {
        const secs = Math.ceil((lockState.until - Date.now()) / 1000);
        return { ok: false, error: `Demasiados intentos fallidos. Espera ${secs}s.` };
      }

      const currentAuth = auth.currentUser;
      if (!currentAuth) {
        return {
          ok: false,
          error: 'Primero autentica el comercio con correo y contraseña o Google para vincular esta terminal.',
        };
      }

      try {
        // Resolve tenant ID from override, activeTenantId, or Firestore tenants query
        let tid = tenantIdOverride || activeTenantId;
        if (!tid) {
          const byUid = await getDocs(
            query(collection(db, 'tenants'), where('ownerUid', '==', currentAuth.uid))
          );
          if (!byUid.empty) {
            tid = byUid.docs[0].id;
          } else {
            const byEmail = await getDocs(
              query(collection(db, 'tenants'), where('email', '==', cleanEmail))
            );
            if (!byEmail.empty) tid = byEmail.docs[0].id;
          }
        }
        if (!tid) {
          return {
            ok: false,
            error: 'No se encontró un comercio registrado para este usuario en Firestore.',
          };
        }

        const tenantSnap = await getDoc(doc(db, 'tenants', tid));
        if (tenantSnap.exists()) {
          const tData = tenantSnap.data() as TenantRecord;
          if (tData.activo === false) {
            return { ok: false, error: 'Este comercio se encuentra desactivado por el propietario.' };
          }
          if (tData.congelado) {
            return { ok: false, error: 'Terminal pausada o congelada por gerencia.' };
          }
        }

        const cashiersSnap = await getDocs(collection(db, 'tenants', tid, 'cashiers'));
        for (const cDoc of cashiersSnap.docs) {
          const cashier = cDoc.data() as Omit<CashierRecord, 'key'>;
          if (
            cashier &&
            cashier.activo !== false &&
            String(cashier.email || '').toLowerCase() === cleanEmail
          ) {
            const candidateHash = await hashPin(cashier.salt, pin);
            if (candidateHash === cashier.hash) {
              localStorage.removeItem('ig_lk');
              setActiveTenantId(tid);
              setActiveCashierKey(cDoc.id);
              setSessionRole('cashier', cashier.nombre, cleanEmail);
              playBeep('ok');
              speakText(`Bienvenido ${cashier.nombre}`);

              await updateDoc(doc(db, 'tenants', tid, 'cashiers', cDoc.id), {
                ultimo_acceso: Date.now(),
              }).catch(() => {});

              const settingsRef = doc(db, 'tenants', tid, 'settings', 'config');
              const openSnap = await getDoc(settingsRef);
              if (!openSnap.exists() || openSnap.data()?.caja_abierta !== true) {
                const now = new Date();
                const ts = now.getTime();
                await setDoc(settingsRef, { caja_abierta: true, updatedAt: ts }, { merge: true });
                await setDoc(doc(db, 'tenants', tid, 'cash_openings', String(ts)), {
                  tipo: 'APERTURA DE CAJA',
                  usuario: `${cleanEmail} (${cashier.nombre})`,
                  fecha: now.toLocaleDateString('es-VE'),
                  hora: now.toLocaleTimeString('es-VE'),
                  timestamp: ts,
                });
              }
              return { ok: true };
            }
          }
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, 'tenants/cashiers');
      }

      const fails = (lockState.n || 0) + 1;
      localStorage.setItem(
        'ig_lk',
        JSON.stringify({ n: fails >= 5 ? 0 : fails, until: fails >= 5 ? Date.now() + 60_000 : 0 })
      );
      playBeep('err');
      return {
        ok: false,
        error: fails >= 5 ? 'PIN bloqueado por 60 segundos.' : 'Correo o PIN de cajero incorrecto.',
      };
    },
    [activeTenantId, playBeep, setActiveCashierKey, setActiveTenantId, setSessionRole, speakText]
  );

  // Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setAuthUser(user);
      setFirebaseReady(true);
      if (!user) {
        // Clear session role if Firebase session expired
        setRole('');
      }
    });
    return () => unsub();
  }, []);

  // Platform config + Tenants directory listener (only when authenticated)
  useEffect(() => {
    if (!firebaseReady || !authUser) {
      setPlatformConfig({});
      setTenants([]);
      return;
    }

    const unsubs: Array<() => void> = [];

    unsubs.push(
      onSnapshot(
        doc(db, 'platform', 'config'),
        (snap) => {
          setPlatformConfig(snap.exists() ? (snap.data() as PlatformConfig) : {});
        },
        (err) => logFirestoreError(err, OperationType.GET, 'platform/config')
      )
    );

    // Enforce that non-master users can never keep an 'owner' session role
    if (role === 'owner' && (authUser.email || '').toLowerCase() !== MASTER_OWNER_EMAIL.toLowerCase()) {
      setSessionRole('', '', '');
    }

    const isOwnerSession =
      (authUser.email || '').toLowerCase() === MASTER_OWNER_EMAIL.toLowerCase();

    if (isOwnerSession) {
      unsubs.push(
        onSnapshot(
          collection(db, 'tenants'),
          (snap) => {
            const list = snap.docs
              .map((d) => ({ ...(d.data() as TenantRecord), id: d.id }))
              .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            setTenants(list);
          },
          (err) => logFirestoreError(err, OperationType.LIST, 'tenants')
        )
      );
    } else if (activeTenantId) {
      unsubs.push(
        onSnapshot(
          doc(db, 'tenants', activeTenantId),
          (snap) => {
            if (snap.exists()) {
              setTenants([{ ...(snap.data() as TenantRecord), id: snap.id }]);
            } else {
              setTenants([]);
            }
          },
          (err) => {
            logFirestoreError(err, OperationType.GET, `tenants/${activeTenantId}`);
            // Self-heal stale tenant ID left in sessionStorage from a different account
            if (/permission-denied|insufficient permissions/i.test(String(err?.message || err))) {
              setActiveTenantId(null);
            }
          }
        )
      );
    } else {
      const qTenants = query(collection(db, 'tenants'), where('ownerUid', '==', authUser.uid));
      unsubs.push(
        onSnapshot(
          qTenants,
          (snap) => {
            const list = snap.docs.map((d) => ({ ...(d.data() as TenantRecord), id: d.id }));
            setTenants(list);
            if (list.length > 0 && !activeTenantId) {
              setActiveTenantId(list[0].id);
            }
          },
          (err) => logFirestoreError(err, OperationType.LIST, 'tenants')
        )
      );
    }

    return () => {
      unsubs.forEach((fn) => fn());
    };
  }, [activeTenantId, authUser, firebaseReady, role, setActiveTenantId]);

  // Auto-select first tenant for Master Owner when tenants list arrives and none selected
  useEffect(() => {
    if (role === 'owner' && !activeTenantId && tenants.length > 0) {
      setActiveTenantId(tenants[0].id);
    }
  }, [activeTenantId, role, setActiveTenantId, tenants]);

  // Global Platform Tickets & Payments listeners for Master Owner
  useEffect(() => {
    if (!firebaseReady || !authUser || role !== 'owner') return;

    const unsubTickets = onSnapshot(
      collection(db, 'platform_tickets'),
      (snap) => {
        const list: SupportTicket[] = snap.docs
          .map((d) => {
            const v = d.data() as Omit<SupportTicket, 'key'>;
            return { ...v, key: d.id, msg: String(v.msg || ''), usuario: String(v.usuario || 'Usuario') };
          })
          .sort((a, b) => (b.t || 0) - (a.t || 0));

        if (seenTicketKeysRef.current === null) {
          seenTicketKeysRef.current = new Set(list.map((t) => t.key));
        } else {
          list.forEach((t) => {
            if (!seenTicketKeysRef.current!.has(t.key) && t.estado === 'nuevo') {
              seenTicketKeysRef.current!.add(t.key);
              const summary = `Nuevo ticket (${t.tenantName || t.usuario}): ${String(t.msg || '').slice(0, 70)}`;
              notifyToast(summary, 'info');
              playBeep('ok');
              void sendSystemPushNotification({
                title: `Soporte · ${t.tenantName || t.usuario}`,
                body: String(t.msg || 'Nuevo mensaje de soporte').slice(0, 140),
                tag: `ticket-${t.key}`,
              });
            }
          });
        }
        setTickets(list);
      },
      (err) => logFirestoreError(err, OperationType.LIST, 'platform_tickets')
    );

    const unsubPayments = onSnapshot(
      collection(db, 'platform_payments'),
      (snap) => {
        const list: MembershipPayment[] = snap.docs
          .map((d) => ({ ...(d.data() as Omit<MembershipPayment, 'key'>), key: d.id }))
          .sort((a, b) => (b.t || 0) - (a.t || 0));

        if (seenPaymentKeysRef.current === null) {
          seenPaymentKeysRef.current = new Set(list.map((p) => p.key));
        } else {
          list.forEach((p) => {
            if (!seenPaymentKeysRef.current!.has(p.key) && p.estado === 'pendiente') {
              seenPaymentKeysRef.current!.add(p.key);
              const summary = `Nuevo Pago Móvil (${p.tenantName || p.usuario}): ${p.nombre || 'Plan'} · Ref ${p.ref || '-'}`;
              notifyToast(summary, 'success');
              playBeep('ok');
              void sendSystemPushNotification({
                title: `Pago Móvil · ${p.tenantName || p.usuario}`,
                body: `${p.nombre || 'Membresía'} ($${Number(p.usd || 0).toFixed(2)}) · Ref: ${p.ref || 'N/A'}`,
                tag: `payment-${p.key}`,
              });
            }
          });
        }
        setMembershipPayments(list);
      },
      (err) => logFirestoreError(err, OperationType.LIST, 'platform_payments')
    );

    const unsubPreRegs = onSnapshot(
      collection(db, 'platform_preregistrations'),
      (snap) => {
        const list: PreRegistrationRecord[] = snap.docs
          .map((d) => ({ ...(d.data() as Omit<PreRegistrationRecord, 'id'>), id: d.id }))
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

        if (seenPreRegKeysRef.current === null) {
          seenPreRegKeysRef.current = new Set(list.map((r) => r.id));
        } else {
          list.forEach((r) => {
            if (!seenPreRegKeysRef.current!.has(r.id) && r.estado === 'pendiente') {
              seenPreRegKeysRef.current!.add(r.id);
              notifyToast(
                `Nuevo Pre-Registro de negocio: ${r.nombre_local} (${r.rif || r.email})`,
                'success'
              );
              playBeep('ok');
              void sendSystemPushNotification({
                title: `Pre-Registro · ${r.nombre_local}`,
                body: `${r.contacto_nombre} solicitó acceso para ${r.razon_social} (${r.rif}).`,
                tag: `prereg-${r.id}`,
              });
            }
          });
        }
        setPreRegistrations(list);
      },
      (err) => logFirestoreError(err, OperationType.LIST, 'platform_preregistrations')
    );

    return () => {
      unsubTickets();
      unsubPayments();
      unsubPreRegs();
    };
  }, [authUser, firebaseReady, notifyToast, playBeep, role]);

  // Isolated Tenant Subcollection Listeners for activeTenantId
  useEffect(() => {
    if (!firebaseReady || !authUser || !activeTenantId) {
      setTenantSettings({});
      setProducts([]);
      setLiveSales([]);
      setSavedCierres([]);
      setFiados({});
      setTallerPendientes([]);
      setTallerCierres({});
      setCashiers([]);
      setSystemUsers([]);
      setNotificationHistory([]);
      setProviders([]);
      setSupplierPurchases([]);
      setCustomers([]);
      setOwnerChatMessages([]);
      if (role !== 'owner') {
        setTickets([]);
        setMembershipPayments([]);
      }
      return;
    }

    const tid = activeTenantId;
    const unsubs: Array<() => void> = [];

    unsubs.push(
      onSnapshot(
        doc(db, 'tenants', tid, 'settings', 'config'),
        (snap) => {
          setTenantSettings(snap.exists() ? (snap.data() as Partial<AppConfig>) : {});
        },
        (err) => logFirestoreError(err, OperationType.GET, `tenants/${tid}/settings/config`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'products'),
        (snap) => {
          const list: Product[] = snap.docs.map((d) => {
            const item = d.data() as Record<string, unknown>;
            return {
              key: d.id,
              id: String(item.nombre || item.id || d.id),
              barcode: String(item.barcode || item.codigo || ''),
              categoria: String(item.categoria || '').trim(),
              price: Number(item.precio ?? item.price ?? 0) || 0,
              price2:
                item.precio2 !== undefined && item.precio2 !== null
                  ? Number(item.precio2)
                  : null,
              price3:
                item.precio3 !== undefined && item.precio3 !== null
                  ? Number(item.precio3)
                  : null,
              stock: item.stock !== undefined ? Number(item.stock) || 0 : 0,
              cost: Number(item.costo ?? item.cost ?? 0) || 0,
              image: String(item.imagen || item.image || ''),
              ivaIncluded: item.iva_incluido === true,
              ivaPct: Number(item.iva_pct) || 0,
              fraccionable: item.fraccionable === true,
              ventaPorBulto: item.venta_por_bulto === true,
              unidadesPorBulto:
                item.unidades_por_bulto !== undefined && item.unidades_por_bulto !== null
                  ? Math.max(0, Number(item.unidades_por_bulto) || 0)
                  : 0,
              precioBulto:
                item.precio_bulto !== undefined && item.precio_bulto !== null
                  ? Number(item.precio_bulto)
                  : null,
            };
          });
          setProducts(list);
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/products`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'sales'),
        (snap) => {
          const toItemsArr = (v: unknown): SaleItem[] =>
            Array.isArray(v)
              ? (v as SaleItem[])
              : v && typeof v === 'object'
              ? Object.values(v as Record<string, SaleItem>)
              : [];
          const list = snap.docs
            .map((d) => {
              const v = d.data() as SaleTransaction;
              return { ...v, key: d.id, items: toItemsArr(v.items) };
            })
            .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
          setLiveSales(list);
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/sales`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'closures'),
        (snap) => {
          const toArr = <T,>(v: unknown): T[] =>
            Array.isArray(v)
              ? (v as T[])
              : v && typeof v === 'object'
              ? Object.values(v as Record<string, T>)
              : [];
          const list = snap.docs
            .map((d) => {
              const v = d.data() as CierreRecord;
              return {
                ...v,
                key: d.id,
                productos_vendidos: toArr<CierreProductoSummary>(v.productos_vendidos),
                detalle_ventas: toArr<CierreDetalleVenta>(v.detalle_ventas),
                totales_metodos_ves:
                  v.totales_metodos_ves && typeof v.totales_metodos_ves === 'object'
                    ? v.totales_metodos_ves
                    : {},
                totales_metodos_usd:
                  v.totales_metodos_usd && typeof v.totales_metodos_usd === 'object'
                    ? v.totales_metodos_usd
                    : {},
              };
            })
            .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
          setSavedCierres(list);
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/closures`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'fiados'),
        (snap) => {
          const grouped: Record<string, Record<string, FiadoRecord>> = {};
          snap.docs.forEach((d) => {
            const data = d.data() as FiadoRecord;
            const ced = String(data.cedula || 'SIN_CED');
            const tsKey = String(data.ts || d.id);
            if (!grouped[ced]) grouped[ced] = {};
            grouped[ced][tsKey] = { ...data, cedula: ced, ts: tsKey, docKey: d.id };
          });
          setFiados(grouped);
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/fiados`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'taller_pending'),
        (snap) => {
          setTallerPendientes(
            snap.docs
              .map((d) => ({ ...(d.data() as TallerRepair), key: d.id }))
              .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/taller_pending`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'taller_closures'),
        (snap) => {
          const map: Record<string, { reparaciones?: Record<string, TallerRepair> }> = {};
          snap.docs.forEach((d) => {
            map[d.id] = d.data() as { reparaciones?: Record<string, TallerRepair> };
          });
          setTallerCierres(map);
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/taller_closures`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'cashiers'),
        (snap) => {
          setCashiers(
            snap.docs.map((d) => {
              const v = d.data() as Omit<CashierRecord, 'key'>;
              return {
                ...v,
                key: d.id,
                nombre: String(v.nombre || 'Cajero'),
                email: String(v.email || ''),
              };
            })
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/cashiers`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'users'),
        (snap) => {
          setSystemUsers(
            snap.docs.map((d) => ({ ...(d.data() as Omit<SystemUserRecord, 'key'>), key: d.id }))
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/users`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'notifications'),
        (snap) => {
          setNotificationHistory(
            snap.docs
              .map((d) => ({ ...(d.data() as BroadcastConfig), key: d.id }))
              .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/notifications`)
      )
    );

    if (role !== 'owner') {
      unsubs.push(
        onSnapshot(
          collection(db, 'tenants', tid, 'tickets'),
          (snap) => {
            const list = snap.docs
              .map((d) => ({ ...(d.data() as Omit<SupportTicket, 'key'>), key: d.id }))
              .sort((a, b) => (b.t || 0) - (a.t || 0));
            const latestReply = (tk: SupportTicket) => {
              const replies = tk.resp ? Object.values(tk.resp) : [];
              if (replies.length === 0) return null;
              return replies.reduce((acc, r) => ((r.t || 0) >= (acc.t || 0) ? r : acc), replies[0]);
            };
            if (seenClientTicketRepliesRef.current === null) {
              const init: Record<string, number> = {};
              list.forEach((tk) => {
                init[tk.key] = latestReply(tk)?.t || 0;
              });
              seenClientTicketRepliesRef.current = init;
            } else {
              list.forEach((tk) => {
                const prevTs = seenClientTicketRepliesRef.current?.[tk.key] || 0;
                const latest = latestReply(tk);
                if (latest && (latest.t || 1) > prevTs) {
                  seenClientTicketRepliesRef.current![tk.key] = latest.t || Date.now();
                  notifyToast(`Soporte respondió tu ticket: ${latest.msg.slice(0, 70)}`, 'info');
                  playBeep('ok');
                  void sendSystemPushNotification({
                    title: 'Respuesta de Soporte · Innova Grup',
                    body: latest.msg.slice(0, 140),
                    tag: `reply-${tk.key}`,
                  });
                }
              });
            }
            setTickets(list);
          },
          (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/tickets`)
        )
      );

      unsubs.push(
        onSnapshot(
          collection(db, 'tenants', tid, 'membership_payments'),
          (snap) => {
            const list = snap.docs
              .map((d) => ({ ...(d.data() as Omit<MembershipPayment, 'key'>), key: d.id }))
              .sort((a, b) => (b.t || 0) - (a.t || 0));
            if (seenClientPaymentStatesRef.current === null) {
              const init: Record<string, string> = {};
              list.forEach((p) => {
                init[p.key] = p.estado;
              });
              seenClientPaymentStatesRef.current = init;
            } else {
              list.forEach((p) => {
                const prevEstado = seenClientPaymentStatesRef.current?.[p.key];
                if (prevEstado && prevEstado !== p.estado) {
                  seenClientPaymentStatesRef.current![p.key] = p.estado;
                  const label =
                    p.estado === 'aprobado'
                      ? 'aprobado y tu membresía fue renovada'
                      : p.estado === 'en_revision'
                      ? 'puesto en revisión'
                      : p.estado === 'rechazado'
                      ? 'rechazado'
                      : p.estado;
                  notifyToast(`Tu Pago Móvil (Ref ${p.ref || '-'}) fue ${label}.`, p.estado === 'aprobado' ? 'success' : 'warning');
                  playBeep(p.estado === 'aprobado' ? 'ok' : 'err');
                  void sendSystemPushNotification({
                    title: 'Actualización de Membresía · Innova Grup',
                    body: `Tu Pago Móvil Ref ${p.ref || '-'} (${p.nombre || 'Plan'}) fue ${label}.`,
                    tag: `mem-status-${p.key}`,
                  });
                } else if (!prevEstado) {
                  seenClientPaymentStatesRef.current![p.key] = p.estado;
                }
              });
            }
            setMembershipPayments(list);
          },
          (err) =>
            logFirestoreError(err, OperationType.LIST, `tenants/${tid}/membership_payments`)
        )
      );
    }

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'providers'),
        (snap) => {
          setProviders(
            snap.docs
              .map((d) => ({ ...(d.data() as Omit<ProviderRecord, 'key'>), key: d.id }))
              .sort((a, b) => a.nombre.localeCompare(b.nombre))
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/providers`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'supplier_purchases'),
        (snap) => {
          setSupplierPurchases(
            snap.docs
              .map((d) => ({ ...(d.data() as Omit<SupplierPurchaseRecord, 'key'>), key: d.id }))
              .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/supplier_purchases`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'customers'),
        (snap) => {
          setCustomers(
            snap.docs
              .map((d) => ({ ...(d.data() as Omit<CustomerRecord, 'key'>), key: d.id }))
              .sort((a, b) => (a.nombre || '').localeCompare(b.nombre || ''))
          );
        },
        (err) => logFirestoreError(err, OperationType.LIST, `tenants/${tid}/customers`)
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'verification_docs'),
        (snap) => {
          const map: Record<string, VerificationDocRecord> = {};
          snap.docs.forEach((d) => {
            const v = d.data() as Omit<VerificationDocRecord, 'key'>;
            map[d.id] = {
              ...v,
              key: d.id,
              req_id: v.req_id || d.id,
            };
          });
          setVerificationDocs(map);
        },
        () => {
          // ignore if collection not yet created
        }
      )
    );

    unsubs.push(
      onSnapshot(
        collection(db, 'tenants', tid, 'owner_chat'),
        (snap) => {
          const list: OwnerChatMessage[] = snap.docs
            .map((d) => ({ ...(d.data() as Omit<OwnerChatMessage, 'id'>), id: d.id }))
            .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
          setOwnerChatMessages(list);
        },
        () => {
          // ignore if collection not yet created
        }
      )
    );

    return () => {
      unsubs.forEach((fn) => fn());
    };
  }, [activeTenantId, authUser, firebaseReady, role]);

  // Immediate alert + notification when Owner activates Data Verification for this tenant
  useEffect(() => {
    if (!verificationConfig?.activo || role === 'owner' || !role) return;
    const stamp = verificationConfig.activado_en || verificationConfig.updatedAt || 1;
    if (lastVerificationAlertRef.current === stamp) return;
    lastVerificationAlertRef.current = stamp;
    notifyToast(
      'Atención: Se requiere actualización y verificación de datos del comercio. Revisa la alerta superior.',
      'warning'
    );
    playBeep('err');
    void sendSystemPushNotification({
      title: `${localName} · Verificación de Datos Requerida`,
      body:
        verificationConfig.mensaje ||
        'Tu cuenta amerita una actualización y verificación de documentos. Ingresa desde el menú superior.',
      tag: `innova-verif-${stamp}`,
      requireInteraction: true,
    });
  }, [localName, notifyToast, playBeep, role, verificationConfig]);

  // Live-resolved granular cashier permissions (POS Sales ONLY by default for cashiers; full for admin/owner)
  const cashierPermissions = useMemo<Required<CashierPermissions>>(() => {
    if (role === 'admin' || role === 'owner') {
      return FULL_CASHIER_PERMISSIONS;
    }
    if (role !== 'cashier') {
      return DEFAULT_CASHIER_PERMISSIONS;
    }
    const matched =
      (activeCashierKey ? cashiers.find((c) => c.key === activeCashierKey) : null) ||
      cashiers.find(
        (c) =>
          c.nombre.trim().toLowerCase() === operatorName.trim().toLowerCase() &&
          c.email.trim().toLowerCase() === operatorEmail.trim().toLowerCase()
      );
    const p = matched?.permisos || {};
    return {
      aplicar_rebajas: p.aplicar_rebajas === true,
      fiados: p.fiados === true,
      motor: p.motor === true,
      taller: p.taller === true,
      editar_tasas: p.editar_tasas === true,
      cerrar_caja: p.cerrar_caja === true,
      anular_factura: p.anular_factura === true,
      herramientas: p.herramientas === true,
    };
  }, [activeCashierKey, cashiers, operatorEmail, operatorName, role]);

  // Subscribe to connected hardware scanners & scan events
  useEffect(() => {
    const unsubDev = subscribeScannerDevices((devs) => setScannerDevices(devs));
    const unsubScan = subscribeHardwareScans((ev) => setLastHardwareScan(ev));
    return () => {
      unsubDev();
      unsubScan();
    };
  }, []);

  // Safe multi-source rate fetcher (Backend API -> direct CORS DolarAPI fallback)
  const fetchLiveRate = useCallback(async (kind: 'bcv' | 'usdt'): Promise<number> => {
    const parseJsonSafe = async (resp: Response): Promise<Record<string, unknown> | null> => {
      try {
        const text = await resp.text();
        if (!text || text.trim().startsWith('<')) return null;
        return JSON.parse(text) as Record<string, unknown>;
      } catch {
        return null;
      }
    };

    // 1. Try local Express proxy first
    try {
      const res = await fetch(`/api/rates/${kind}`, { cache: 'no-store' });
      const data = await parseJsonSafe(res);
      const val = Number(data?.rate || 0);
      if (res.ok && Number.isFinite(val) && val > 0) {
        return round2(val);
      }
    } catch {
      // fall through to direct CORS fallback
    }

    // 2. Direct browser CORS fallback (ve.dolarapi.com)
    const directUrl =
      kind === 'bcv'
        ? 'https://ve.dolarapi.com/v1/dolares/oficial'
        : 'https://ve.dolarapi.com/v1/dolares/paralelo';
    try {
      const res = await fetch(directUrl, { cache: 'no-store' });
      const data = await parseJsonSafe(res);
      const val = Number(data?.promedio || data?.venta || 0);
      if (res.ok && Number.isFinite(val) && val > 0) {
        return round2(val);
      }
    } catch {
      // fall through to full list
    }

    // 3. Direct list fallback
    const listRes = await fetch('https://ve.dolarapi.com/v1/dolares', { cache: 'no-store' });
    const listText = await listRes.text();
    const list = JSON.parse(listText) as Array<{ fuente?: string; promedio?: number; venta?: number }>;
    const targetFuente = kind === 'bcv' ? 'oficial' : 'paralelo';
    const found = Array.isArray(list)
      ? list.find((it) => String(it.fuente || '').toLowerCase() === targetFuente)
      : null;
    const rateVal = Number(found?.promedio || found?.venta || 0);
    if (!Number.isFinite(rateVal) || rateVal <= 0) {
      throw new Error(
        kind === 'bcv'
          ? 'No se pudo obtener la tasa BCV en este momento'
          : 'No se pudo obtener la tasa Paralelo/USDT en este momento'
      );
    }
    return round2(rateVal);
  }, []);

  const fetchLiveCurrencyRate = useCallback(
    async (code: CurrencyCode): Promise<{ rate: number; source: string }> => {
      if (code === 'VES') {
        const val = await fetchLiveRate('bcv');
        return { rate: val, source: 'BCV Oficial' };
      }
      if (code === 'PAB') {
        return { rate: 1, source: 'Paridad USD' };
      }

      const normalizePrecision = (val: number) =>
        code === 'EUR' || (val < 5 && val !== 1)
          ? Number(val.toFixed(4))
          : Number(val.toFixed(2));

      // 1. Primary backend proxy route (/api/rates/currency)
      try {
        const res = await fetch(`/api/rates/currency?code=${encodeURIComponent(code)}`, {
          cache: 'no-store',
        });
        const text = await res.text();
        if (text && !text.trim().startsWith('<')) {
          const data = JSON.parse(text) as { rate?: number; source?: string };
          const val = Number(data?.rate || 0);
          if (res.ok && Number.isFinite(val) && val > 0) {
            return { rate: normalizePrecision(val), source: data?.source || 'API Diaria' };
          }
        }
      } catch {
        // fallback to direct public API
      }

      // 2. Direct open.er-api fallback
      try {
        const erRes = await fetch('https://open.er-api.com/v6/latest/USD', { cache: 'no-store' });
        if (erRes.ok) {
          const erJson = (await erRes.json()) as { rates?: Record<string, number> };
          const val = Number(erJson.rates?.[code] || 0);
          if (Number.isFinite(val) && val > 0) {
            return { rate: normalizePrecision(val), source: 'open-er-api' };
          }
        }
      } catch {
        // fallback to CDN currency API
      }

      // 3. Direct jsDelivr Fawaz Ahmed CDN fallback
      const cdnRes = await fetch(
        'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json',
        { cache: 'no-store' }
      );
      if (cdnRes.ok) {
        const cdnJson = (await cdnRes.json()) as { usd?: Record<string, number> };
        const val = Number(cdnJson.usd?.[code.toLowerCase()] || 0);
        if (Number.isFinite(val) && val > 0) {
          return { rate: normalizePrecision(val), source: 'jsdelivr-currency-api' };
        }
      }

      throw new Error(`No se pudo consultar la tasa del día para ${code}.`);
    },
    [fetchLiveRate]
  );

  const syncCurrencyRate = useCallback(
    async (codeOverride?: CurrencyCode, silent = false): Promise<number | null> => {
      const targetCode = codeOverride || localCurrencyCode;
      const targetInfo = getCurrencyInfo(targetCode);
      if (!silent) setRatesSyncing(true);
      try {
        const { rate: rateVal } = await fetchLiveCurrencyRate(targetCode);
        const isSwitching = Boolean(codeOverride && codeOverride !== localCurrencyCode);
        const patch: Record<string, unknown> = {
          tasa_bcv: rateVal,
          moneda_local: targetCode,
        };
        // Keep secondary & tertiary aligned when switching to a different currency scale
        if (isSwitching && targetCode !== 'VES') {
          patch.tasa_secundaria = rateVal;
          patch.tasa_terciaria = rateVal;
        } else if (targetCode !== 'VES') {
          // If secondary/tertiary still look like an unrelated scale, align them gently
          const secRatio = rateVal > 0 ? secondaryRate / rateVal : 1;
          const terRatio = rateVal > 0 ? tertiaryRate / rateVal : 1;
          if (!Number.isFinite(secRatio) || secRatio > 2.5 || secRatio < 0.4) {
            patch.tasa_secundaria = rateVal;
          }
          if (!Number.isFinite(terRatio) || terRatio > 2.5 || terRatio < 0.4) {
            patch.tasa_terciaria = rateVal;
          }
        }

        setLocalRateFallback((prev) => ({
          ...prev,
          bcv: rateVal,
          usdt: typeof patch.tasa_secundaria === 'number' ? (patch.tasa_secundaria as number) : prev.usdt,
        }));
        setTenantSettings((prev) => ({ ...prev, ...patch } as Partial<AppConfig>));

        let savedToCloud = true;
        if (authUser && activeTenantId && role) {
          try {
            await updateTenantSettings(patch);
          } catch (persistErr) {
            savedToCloud = false;
            console.error('Error guardando tasa de moneda en la nube:', persistErr);
          }
        }

        if (!silent) {
          notifyToast(
            savedToCloud
              ? `Tasa ${targetInfo.code} actualizada: 1 USD = ${formatRateNumber(rateVal, targetCode)} ${targetInfo.shortLabel}`
              : `Tasa ${targetInfo.code} aplicada (${formatRateNumber(rateVal, targetCode)} ${targetInfo.shortLabel}). Guardado en nube pendiente.`,
            savedToCloud ? 'success' : 'warning'
          );
          playBeep('ok');
        }
        return rateVal;
      } catch (err) {
        if (!silent) {
          const msg =
            err instanceof Error && !err.message.startsWith('{')
              ? err.message
              : `No se pudo consultar la tasa del día para ${targetInfo.name}.`;
          notifyToast(msg, 'error');
          playBeep('err');
        }
        return null;
      } finally {
        if (!silent) setRatesSyncing(false);
      }
    },
    [
      activeTenantId,
      authUser,
      fetchLiveCurrencyRate,
      localCurrencyCode,
      notifyToast,
      playBeep,
      role,
      secondaryRate,
      tertiaryRate,
      updateTenantSettings,
    ]
  );

  const setLocalCurrency = useCallback(
    async (code: CurrencyCode, autoSync = true) => {
      if (!isSupportedCurrencyCode(code)) return;
      const info = getCurrencyInfo(code);
      setTenantSettings((prev) => ({ ...prev, moneda_local: code }));
      if (authUser && activeTenantId && role) {
        try {
          await updateTenantSettings({ moneda_local: code });
        } catch (err) {
          console.error('Error guardando moneda local:', err);
        }
      }
      if (autoSync) {
        const synced = await syncCurrencyRate(code, false);
        if (synced === null) {
          // Fallback to sensible default rate for that currency if offline
          await updateTenantSettings({
            moneda_local: code,
            tasa_bcv: info.defaultRate,
            tasa_secundaria: info.defaultRate,
            tasa_terciaria: info.defaultRate,
          });
        }
      } else {
        notifyToast(`Moneda de trabajo cambiada a USD ($) + ${info.name} (${info.shortLabel})`, 'success');
        playBeep('ok');
      }
    },
    [activeTenantId, authUser, notifyToast, playBeep, role, syncCurrencyRate, updateTenantSettings]
  );

  const setRateEditable = useCallback(
    async (editable: boolean) => {
      setTenantSettings((prev) => ({ ...prev, tasa_editable: editable }));
      if (authUser && activeTenantId && role) {
        try {
          await updateTenantSettings({ tasa_editable: editable });
        } catch (err) {
          console.error('Error guardando permiso de tasa editable:', err);
        }
      }
      notifyToast(
        editable
          ? 'Edición manual de tasas habilitada.'
          : 'Tasa bloqueada a sincronización automática por API.',
        'info'
      );
    },
    [activeTenantId, authUser, notifyToast, role, updateTenantSettings]
  );

  // Exchange Rate Sync via cached Express backend endpoints + direct fallback
  const syncBcvRate = useCallback(
    async (silent = false) => {
      await syncCurrencyRate(localCurrencyCode, silent);
    },
    [localCurrencyCode, syncCurrencyRate]
  );

  const syncUsdtRate = useCallback(
    async (silent = false) => {
      if (localCurrencyCode !== 'VES') {
        await syncCurrencyRate(localCurrencyCode, silent);
        return;
      }
      if (!silent) setRatesSyncing(true);
      try {
        const rateVal = await fetchLiveRate('usdt');
        setLocalRateFallback((prev) => ({ ...prev, usdt: rateVal }));
        setTenantSettings((prev) => ({ ...prev, tasa_secundaria: rateVal }));
        let savedToCloud = true;
        if (authUser && activeTenantId && role) {
          try {
            await updateTenantSettings({ tasa_secundaria: rateVal });
          } catch (persistErr) {
            savedToCloud = false;
            console.error('Error guardando tasa USDT en la nube:', persistErr);
          }
        }
        if (!silent) {
          notifyToast(
            savedToCloud
              ? `Tasa Paralelo/USDT actualizada a ${rateVal.toFixed(2)} Bs`
              : `Tasa USDT aplicada (${rateVal.toFixed(2)} Bs). Sincronización en nube pendiente.`,
            savedToCloud ? 'success' : 'warning'
          );
          playBeep('ok');
        }
      } catch (err) {
        if (!silent) {
          const msg =
            err instanceof Error && !err.message.startsWith('{')
              ? err.message
              : 'No se pudo consultar la tasa USDT. Intenta de nuevo en unos segundos.';
          notifyToast(msg, 'error');
          playBeep('err');
        }
      } finally {
        if (!silent) setRatesSyncing(false);
      }
    },
    [
      activeTenantId,
      authUser,
      fetchLiveRate,
      localCurrencyCode,
      notifyToast,
      playBeep,
      role,
      syncCurrencyRate,
      updateTenantSettings,
    ]
  );

  const syncAllRates = useCallback(
    async (silent = false) => {
      if (localCurrencyCode !== 'VES') {
        await syncCurrencyRate(localCurrencyCode, silent);
        return;
      }
      if (!silent) setRatesSyncing(true);
      try {
        const [bcvRes, usdtRes] = await Promise.allSettled([
          fetchLiveRate('bcv'),
          fetchLiveRate('usdt'),
        ]);
        const nextBcv = bcvRes.status === 'fulfilled' ? bcvRes.value : null;
        const nextUsdt = usdtRes.status === 'fulfilled' ? usdtRes.value : null;

        if (nextBcv === null && nextUsdt === null) {
          throw new Error('No se pudieron consultar las tasas en este momento. Verifica tu conexión.');
        }

        const patch: Record<string, number> = {};
        if (nextBcv !== null) patch.tasa_bcv = nextBcv;
        if (nextUsdt !== null) patch.tasa_secundaria = nextUsdt;

        setLocalRateFallback((prev) => ({
          bcv: nextBcv ?? prev.bcv,
          usdt: nextUsdt ?? prev.usdt,
        }));
        setTenantSettings((prev) => ({ ...prev, ...patch }));

        let savedToCloud = true;
        if (authUser && activeTenantId && role) {
          try {
            await updateTenantSettings(patch);
          } catch (persistErr) {
            savedToCloud = false;
            console.error('Error guardando tasas en la nube:', persistErr);
          }
        }

        if (!silent) {
          const parts: string[] = [];
          if (nextBcv !== null) parts.push(`BCV: ${nextBcv.toFixed(2)} Bs`);
          if (nextUsdt !== null) parts.push(`Paralelo: ${nextUsdt.toFixed(2)} Bs`);
          notifyToast(
            savedToCloud
              ? `Tasas actualizadas · ${parts.join(' · ')}`
              : `Tasas aplicadas (${parts.join(' · ')}). Pendiente de guardar en la nube.`,
            savedToCloud ? 'success' : 'warning'
          );
          playBeep('ok');
        }
      } catch (err) {
        if (!silent) {
          const msg =
            err instanceof Error && !err.message.startsWith('{')
              ? err.message
              : 'No se pudieron actualizar las tasas. Intenta de nuevo en unos segundos.';
          notifyToast(msg, 'error');
          playBeep('err');
        }
      } finally {
        if (!silent) setRatesSyncing(false);
      }
    },
    [
      activeTenantId,
      authUser,
      fetchLiveRate,
      localCurrencyCode,
      notifyToast,
      playBeep,
      role,
      syncCurrencyRate,
      updateTenantSettings,
    ]
  );

  const updateRate = useCallback(
    async (kind: 'bcv' | 'secundaria' | 'terciaria', value: number) => {
      if (!Number.isFinite(value) || value <= 0) return;
      const rounded =
        localCurrencyCode === 'EUR' || (value < 5 && value !== 1)
          ? Number(value.toFixed(4))
          : round2(value);
      const field =
        kind === 'bcv' ? 'tasa_bcv' : kind === 'secundaria' ? 'tasa_secundaria' : 'tasa_terciaria';
      setLocalRateFallback((prev) => ({
        ...prev,
        bcv: kind === 'bcv' ? rounded : prev.bcv,
        usdt: kind === 'secundaria' ? rounded : prev.usdt,
      }));
      setTenantSettings((prev) => ({ ...prev, [field]: rounded }));
      if (authUser && activeTenantId && role) {
        try {
          await updateTenantSettings({ [field]: rounded });
        } catch (err) {
          console.error('Error actualizando tasa en la nube:', err);
          notifyToast(
            `Tasa aplicada localmente (${formatRateNumber(rounded, localCurrencyCode)} ${localCurrency.shortLabel}), pero falló el guardado en la nube.`,
            'warning'
          );
          playBeep('err');
          return;
        }
      }
      notifyToast(
        `Tasa actualizada a ${formatRateNumber(rounded, localCurrencyCode)} ${localCurrency.shortLabel}`,
        'success'
      );
      playBeep('ok');
    },
    [
      activeTenantId,
      authUser,
      localCurrency.shortLabel,
      localCurrencyCode,
      notifyToast,
      playBeep,
      role,
      updateTenantSettings,
    ]
  );

  // Auto-sync active working currency rate once on initial load (never overwrites if user already set a custom rate after load)
  const initialCurrencySyncedRef = useRef<string>('');
  useEffect(() => {
    const key = `${activeTenantId || 'guest'}_${localCurrencyCode}`;
    if (initialCurrencySyncedRef.current === key) return;
    initialCurrencySyncedRef.current = key;
    if (!tenantSettings.tasa_bcv || !rateEditable) {
      void syncCurrencyRate(localCurrencyCode, true);
    }
  }, [activeTenantId, localCurrencyCode, rateEditable, syncCurrencyRate, tenantSettings.tasa_bcv]);

  // Scheduled notices watcher (lightweight, runs every 20s)
  useEffect(() => {
    const notices = config.avisos || DEFAULT_SCHEDULED_NOTICES;
    const timer = setInterval(() => {
      if (!role) return;
      const now = new Date();
      const hm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(
        2,
        '0'
      )}`;
      if (lastScheduledMinuteRef.current === hm) return;
      Object.values(notices).forEach((notice) => {
        if (notice && notice.activo && notice.hora === hm) {
          lastScheduledMinuteRef.current = hm;
          notifyToast(notice.msg, 'info');
          playBeep('ok');
          speakText(notice.msg);
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            try {
              new Notification(localName, { body: notice.msg });
            } catch {
              // ignore
            }
          }
        }
      });
    }, 20_000);
    return () => clearInterval(timer);
  }, [config.avisos, localName, notifyToast, playBeep, role, speakText]);

  // Broadcast notification watcher (target audience + audio/voice)
  const activeBroadcast = useMemo(() => {
    const b = config.broadcast;
    if (!b || !b.texto) return null;
    if (b.audiencia && b.audiencia !== 'all' && role && b.audiencia !== role) {
      return null;
    }
    const key = `${b.timestamp || 0}_${b.texto}`;
    if (key === dismissedBroadcastKey) return null;
    return b;
  }, [config.broadcast, dismissedBroadcastKey, role]);

  useEffect(() => {
    if (!activeBroadcast) return;
    const key = `${activeBroadcast.timestamp || 0}_${activeBroadcast.texto}`;
    if (lastBroadcastSeenRef.current === key) return;
    lastBroadcastSeenRef.current = key;
    playBeep(
      activeBroadcast.tipo === 'warning' || activeBroadcast.tipo === 'critical' ? 'err' : 'ok'
    );
    if (activeBroadcast.con_voz) {
      speakText(`${activeBroadcast.titulo || 'Aviso'}. ${activeBroadcast.texto}`, true);
    }
    void sendSystemPushNotification({
      title: activeBroadcast.titulo || localName,
      body: activeBroadcast.texto,
      tag: `broadcast-${activeBroadcast.timestamp || Date.now()}`,
    });
  }, [activeBroadcast, localName, playBeep, speakText]);

  const dismissBroadcast = useCallback(() => {
    const b = config.broadcast;
    if (b) {
      const key = `${b.timestamp || 0}_${b.texto}`;
      setDismissedBroadcastKey(key);
      try {
        localStorage.setItem('ig_dismissed_broadcast', key);
      } catch {
        // ignore
      }
    }
  }, [config.broadcast]);

  const setLocalTheme = useCallback((themeId: string | null) => {
    setLocalThemeState(themeId);
    try {
      if (themeId) localStorage.setItem('ig_theme', themeId);
      else localStorage.removeItem('ig_theme');
    } catch {
      // ignore
    }
  }, []);

  const activeTheme = useMemo(() => {
    const valid = IG_THEMES.map((t) => t.id);
    const chosen = localTheme || config.tema || 'innova';
    return valid.includes(chosen) ? chosen : 'innova';
  }, [config.tema, localTheme]);

  // Global runtime error listener — ignore non-fatal browser, HMR/WebSocket, YouTube, network, and Firestore noise
  useEffect(() => {
    const IGNORABLE_ERROR_RE =
      /ResizeObserver|Script error|WebSocket|HMR|vite|AbortError|aborted|Failed to fetch|NetworkError|Load failed|auth\/|permission-denied|PERMISSION_DENIED|insufficient permissions|unavailable|client is offline|Firestore Error|operationType|NotAllowedError|NotFoundError|SecurityError|ServiceWorker|play\(\)|speechSynthesis|youtube|ytimg|postMessage|No device selected/i;

    const onError = (e: ErrorEvent) => {
      const msg = String(e.message || e.error?.message || '').trim();
      if (!msg || IGNORABLE_ERROR_RE.test(msg)) return;
      // Ignore cross-origin script errors without filename
      if (!e.filename || !e.filename.startsWith(window.location.origin)) return;
      console.error('Unhandled app error:', msg);
      setRuntimeError(msg);
    };
    const onRejection = (e: PromiseRejectionEvent) => {
      const msg =
        e.reason instanceof Error
          ? e.reason.message
          : typeof e.reason === 'string'
          ? e.reason
          : '';
      if (!msg || IGNORABLE_ERROR_RE.test(msg)) return;
      console.error('Unhandled promise rejection:', msg);
    };
    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onRejection);
    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onRejection);
    };
  }, []);

  // Live 60s clock tick so membership countdown decrements automatically day-by-day and locks at 0
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  useEffect(() => {
    const syncClock = () => setNowTick(Date.now());
    const id = setInterval(syncClock, 60_000);
    window.addEventListener('focus', syncClock);
    document.addEventListener('visibilitychange', syncClock);
    return () => {
      clearInterval(id);
      window.removeEventListener('focus', syncClock);
      document.removeEventListener('visibilitychange', syncClock);
    };
  }, []);

  // Membership, Warnings & Promotions
  const membership = config.membresia || null;
  const membershipDaysLeft = useMemo(() => {
    if (!membership || membership.estado === 'suspendida' || !membership.vence) return 0;
    const diff = membership.vence - nowTick;
    if (diff <= 0) return 0;
    return Math.ceil(diff / 86_400_000);
  }, [membership, nowTick]);

  const membershipExpired = Boolean(
    activeTenant &&
      (!membership ||
        membership.estado === 'suspendida' ||
        !membership.vence ||
        membership.vence <= nowTick)
  );
  const avisoMembresia = useMemo(
    () => ({
      dias: Number(config.aviso_membresia?.dias) || 5,
      activo: config.aviso_membresia?.activo !== false,
      titulo: config.aviso_membresia?.titulo || 'Tu membresía está por vencer',
      msg:
        config.aviso_membresia?.msg ||
        'Te quedan {dias} día(s) de membresía. Renueva a tiempo para no perder el acceso al sistema.',
    }),
    [config.aviso_membresia]
  );

  const activeMembershipWarning = useMemo(() => {
    if (!role || role === 'owner' || membershipExpired || !membership?.vence) return null;
    if (!avisoMembresia.activo) return null;
    const diasRestantes = membershipDaysLeft;
    if (diasRestantes > avisoMembresia.dias || diasRestantes <= 0) return null;
    const warnKey = `${new Date(nowTick).toDateString()}_${diasRestantes}`;
    if (warnKey === dismissedWarningKey) return null;
    return {
      titulo: avisoMembresia.titulo,
      mensaje: String(avisoMembresia.msg).replace(/\{dias\}/g, String(diasRestantes)),
      diasRestantes,
    };
  }, [avisoMembresia, dismissedWarningKey, membership, membershipDaysLeft, membershipExpired, nowTick, role]);

  const dismissMembershipWarning = useCallback(() => {
    if (!membership?.vence) return;
    const warnKey = `${new Date(nowTick).toDateString()}_${membershipDaysLeft}`;
    setDismissedWarningKey(warnKey);
    try {
      localStorage.setItem('ig2w', warnKey);
    } catch {
      // ignore
    }
  }, [membership, membershipDaysLeft, nowTick]);

  const plans = useMemo(
    () =>
      config.planes && typeof config.planes === 'object' && Object.keys(config.planes).length > 0
        ? config.planes
        : defaultPlans(),
    [config.planes]
  );
  const planLinks = useMemo(
    () => (config.planes_links && typeof config.planes_links === 'object' ? config.planes_links : {}),
    [config.planes_links]
  );
  const promos = useMemo(() => {
    const obj = config.promos && typeof config.promos === 'object' ? config.promos : {};
    return Object.entries(obj)
      .filter(([, p]) => p && typeof p === 'object')
      .map(([id, p]) => ({ ...p, id }));
  }, [config.promos]);

  // Cart & Pricing Helpers (Detal, Fraccionable & Por Bulto)
  // El precio de venta en USD es el mismo en todas las tasas; lo que varía es su cálculo en Bolívares según la tasa aplicada.
  const getEffectiveUnitPrice = useCallback(
    (product: Product, saleUnit: 'detal' | 'bulto' = 'detal') => {
      if (
        saleUnit === 'bulto' &&
        product.ventaPorBulto &&
        (Number(product.unidadesPorBulto) || 0) > 1
      ) {
        const customBulto = Number(product.precioBulto);
        if (Number.isFinite(customBulto) && customBulto > 0) {
          return round2(customBulto);
        }
        return round2((Number(product.price) || 0) * Number(product.unidadesPorBulto));
      }
      return Number(product.price) || 0;
    },
    []
  );

  const getActiveRateValue = useCallback(() => {
    if (selectedSaleRate === '1') return bcvRate;
    if (selectedSaleRate === '2') return secondaryRate;
    return tertiaryRate;
  }, [bcvRate, secondaryRate, selectedSaleRate, tertiaryRate]);

  const toggleIva = useCallback(() => setIvaActive((v) => !v), []);

  const getItemUnitsPerPack = (item: Pick<CartItem, 'product' | 'saleUnit'>) =>
    item.saleUnit === 'bulto' &&
    item.product.ventaPorBulto &&
    (Number(item.product.unidadesPorBulto) || 0) > 1
      ? Number(item.product.unidadesPorBulto)
      : 1;

  const getCartLineId = (item: Pick<CartItem, 'product' | 'saleUnit' | 'cartKey'>) =>
    item.cartKey || `${item.product.key}__${item.saleUnit || 'detal'}`;

  const addToCart = useCallback(
    (product: Product, rawQty: number, saleUnit: 'detal' | 'bulto' = 'detal') => {
      if (role !== 'owner' && membershipExpired) {
        notifyToast('Membresía vencida (0 días). Renueva para realizar ventas.', 'error');
        playBeep('err');
        return;
      }
      const isBulto =
        saleUnit === 'bulto' &&
        product.ventaPorBulto === true &&
        (Number(product.unidadesPorBulto) || 0) > 1;
      const effectiveUnit: 'detal' | 'bulto' = isBulto ? 'bulto' : 'detal';
      const unitsPerPack = isBulto ? Number(product.unidadesPorBulto) : 1;
      const qty =
        !isBulto && product.fraccionable
          ? round2(rawQty)
          : Math.max(1, Math.round(rawQty));
      const addedUnits = round2(qty * unitsPerPack);
      if (qty <= 0 || addedUnits > product.stock) {
        notifyToast(
          isBulto
            ? `Stock insuficiente: ${qty} bulto(s) requieren ${addedUnits} uds y hay ${product.stock} uds disponibles.`
            : 'Cantidad no válida o excede el stock disponible.',
          'warning'
        );
        playBeep('err');
        return;
      }
      setGlobalParallelOverrideVes(null);
      const lineKey = `${product.key}__${effectiveUnit}`;
      setCart((prev) => {
        const reservedUnitsForProduct = prev
          .filter((i) => i.product.key === product.key)
          .reduce((sum, i) => sum + i.quantity * getItemUnitsPerPack(i), 0);
        if (round2(reservedUnitsForProduct + addedUnits) > product.stock) {
          notifyToast(
            `La suma (${round2(reservedUnitsForProduct + addedUnits)} uds) excede el stock disponible (${product.stock} uds).`,
            'warning'
          );
          playBeep('err');
          return prev;
        }
        const existing = prev.find((i) => getCartLineId(i) === lineKey);
        if (existing) {
          playBeep('tick');
          return prev.map((i) =>
            getCartLineId(i) === lineKey ? { ...i, quantity: round2(i.quantity + qty) } : i
          );
        }
        playBeep('tick');
        return [
          ...prev,
          {
            product,
            quantity: qty,
            customDiscountVes: null,
            saleUnit: effectiveUnit,
            cartKey: lineKey,
          },
        ];
      });
    },
    [membershipExpired, notifyToast, playBeep, role]
  );

  const matchesCartTarget = (item: CartItem, cartKeyOrProductId: string) =>
    getCartLineId(item) === cartKeyOrProductId ||
    item.product.key === cartKeyOrProductId ||
    item.product.id === cartKeyOrProductId;

  const updateCartQty = useCallback(
    (cartKeyOrProductId: string, delta: number) => {
      setGlobalParallelOverrideVes(null);
      setCart((prev) => {
        const target = prev.find((i) => matchesCartTarget(i, cartKeyOrProductId));
        if (!target) return prev;
        const targetLineId = getCartLineId(target);
        const isBulto = target.saleUnit === 'bulto';
        const step = !isBulto && target.product.fraccionable ? delta : Math.round(delta);
        const nextQty = round2(target.quantity + step);
        if (nextQty <= 0) {
          return prev.filter((i) => getCartLineId(i) !== targetLineId);
        }
        const otherUnitsForProduct = prev
          .filter((i) => i.product.key === target.product.key && getCartLineId(i) !== targetLineId)
          .reduce((sum, i) => sum + i.quantity * getItemUnitsPerPack(i), 0);
        const totalNeededUnits = round2(
          otherUnitsForProduct + nextQty * getItemUnitsPerPack(target)
        );
        if (totalNeededUnits > target.product.stock) {
          notifyToast(
            `Excede el inventario disponible (${target.product.stock} uds).`,
            'warning'
          );
          playBeep('err');
          return prev;
        }
        return prev.map((i) =>
          getCartLineId(i) === targetLineId ? { ...i, quantity: nextQty } : i
        );
      });
    },
    [notifyToast, playBeep]
  );

  const removeFromCart = useCallback((cartKeyOrProductId: string) => {
    setGlobalParallelOverrideVes(null);
    setCart((prev) => prev.filter((i) => !matchesCartTarget(i, cartKeyOrProductId)));
  }, []);

  const setCartItemDiscount = useCallback(
    (cartKeyOrProductId: string, newPriceVes: number) => {
      if (newPriceVes <= 0) return;
      setGlobalParallelOverrideVes(null);
      let label = cartKeyOrProductId;
      setCart((prev) =>
        prev.map((i) => {
          if (matchesCartTarget(i, cartKeyOrProductId)) {
            label = i.saleUnit === 'bulto' ? `${i.product.id} (Bulto)` : i.product.id;
            return { ...i, customDiscountVes: round2(newPriceVes) };
          }
          return i;
        })
      );
      notifyToast(`Rebaja aplicada a ${label}`, 'success');
    },
    [notifyToast]
  );

  const clearCart = useCallback(() => {
    setCart([]);
    setGlobalParallelOverrideVes(null);
    setIvaActive(false);
  }, []);

  const cartTotals = useMemo(() => {
    const rate = getActiveRateValue();
    let subtotalVes = 0;
    cart.forEach((item) => {
      const unitBs =
        item.customDiscountVes !== null
          ? item.customDiscountVes
          : getEffectiveUnitPrice(item.product, item.saleUnit || 'detal') * rate;
      subtotalVes += unitBs * item.quantity;
    });
    if (globalParallelOverrideVes !== null) {
      subtotalVes = globalParallelOverrideVes;
    }
    const factor = ivaActive ? 1 + IVA_RATE : 1;
    const totalVes = subtotalVes * factor;
    const ivaVes = totalVes - subtotalVes;
    const totalUsdBcv = rate > 0 ? totalVes / rate : 0;

    let modeLabel = `${localCurrency.rateLabel} (${formatRateNumber(bcvRate, localCurrencyCode)} ${localCurrency.shortLabel})`;
    if (selectedSaleRate === '2')
      modeLabel = `${localCurrencyCode === 'VES' ? 'Paralelo 1' : 'Tasa Ref. 2'} (${formatRateNumber(secondaryRate, localCurrencyCode)} ${localCurrency.shortLabel})`;
    if (selectedSaleRate === '3')
      modeLabel = `${localCurrencyCode === 'VES' ? 'Paralelo 2' : 'Tasa Ref. 3'} (${formatRateNumber(tertiaryRate, localCurrencyCode)} ${localCurrency.shortLabel})`;
    if (globalParallelOverrideVes !== null) modeLabel = 'Precio Legal / Paralelo';
    if (ivaActive) modeLabel += ` + IVA ${Math.round(IVA_RATE * 100)}%`;

    return {
      subtotalVes: round2(subtotalVes),
      ivaVes: round2(ivaVes),
      totalVes: round2(totalVes),
      totalUsdBcv: round2(totalUsdBcv),
      modeLabel,
    };
  }, [
    bcvRate,
    cart,
    getActiveRateValue,
    getEffectiveUnitPrice,
    globalParallelOverrideVes,
    ivaActive,
    localCurrency.rateLabel,
    localCurrency.shortLabel,
    localCurrencyCode,
    secondaryRate,
    selectedSaleRate,
    tertiaryRate,
  ]);

  // Printer Detection & Auto-Connect
  const refreshPrinters = useCallback(async (): Promise<ConnectedPrinterInfo[]> => {
    const list = await detectAuthorizedPrinters();
    setDetectedPrinters(list);
    return list;
  }, []);

  useEffect(() => {
    void refreshPrinters();
    const nav = navigator as unknown as {
      usb?: {
        addEventListener?: (e: string, cb: () => void) => void;
        removeEventListener?: (e: string, cb: () => void) => void;
      };
      serial?: {
        addEventListener?: (e: string, cb: () => void) => void;
        removeEventListener?: (e: string, cb: () => void) => void;
      };
    };
    const onHwChange = () => {
      void refreshPrinters();
    };
    nav.usb?.addEventListener?.('connect', onHwChange);
    nav.usb?.addEventListener?.('disconnect', onHwChange);
    nav.serial?.addEventListener?.('connect', onHwChange);
    nav.serial?.addEventListener?.('disconnect', onHwChange);
    return () => {
      nav.usb?.removeEventListener?.('connect', onHwChange);
      nav.usb?.removeEventListener?.('disconnect', onHwChange);
      nav.serial?.removeEventListener?.('connect', onHwChange);
      nav.serial?.removeEventListener?.('disconnect', onHwChange);
    };
  }, [refreshPrinters]);

  const activePrinter = detectedPrinters[0] || null;

  const connectUsbPrinter = useCallback(async (): Promise<ConnectedPrinterInfo | null> => {
    const nav = navigator as unknown as {
      usb?: { requestDevice: (opts: { filters: unknown[] }) => Promise<USBDeviceLike> };
    };
    if (!nav.usb) {
      notifyToast('WebUSB no está disponible en este navegador.', 'warning');
      return null;
    }
    try {
      const device = await nav.usb.requestDevice({ filters: [] });
      const info: ConnectedPrinterInfo = {
        id: `usb_${device.vendorId || 'u'}_${device.productId || Date.now()}`,
        name: device.productName || device.manufacturerName || 'Impresora USB',
        kind: 'usb',
        device,
      };
      setDetectedPrinters((prev) => [info, ...prev.filter((p) => p.id !== info.id)]);
      playBeep('ok');
      notifyToast(`Impresora USB conectada: ${info.name}`, 'success');
      return info;
    } catch {
      notifyToast('Selección de impresora USB cancelada.', 'info');
      return null;
    }
  }, [notifyToast, playBeep]);

  const connectSerialPrinter = useCallback(async (): Promise<ConnectedPrinterInfo | null> => {
    const nav = navigator as unknown as {
      serial?: { requestPort: () => Promise<SerialPortLike> };
    };
    if (!nav.serial) {
      notifyToast('WebSerial no está disponible en este navegador.', 'warning');
      return null;
    }
    try {
      const port = await nav.serial.requestPort();
      const portInfo = port.getInfo?.() || {};
      const info: ConnectedPrinterInfo = {
        id: `serial_${portInfo.usbVendorId || 'p'}_${portInfo.usbProductId || Date.now()}`,
        name: portInfo.usbVendorId
          ? `Impresora Serial (VID ${portInfo.usbVendorId.toString(16).toUpperCase()})`
          : 'Impresora Puerto Serial',
        kind: 'serial',
        port,
      };
      setDetectedPrinters((prev) => [info, ...prev.filter((p) => p.id !== info.id)]);
      playBeep('ok');
      notifyToast(`Impresora serial conectada: ${info.name}`, 'success');
      return info;
    } catch {
      notifyToast('Selección de puerto serial cancelada.', 'info');
      return null;
    }
  }, [notifyToast, playBeep]);

  const disconnectPrinters = useCallback(() => {
    setDetectedPrinters([]);
    notifyToast('Lista de impresoras desconectada de la sesión.', 'info');
  }, [notifyToast]);

  const sendTestPrint = useCallback(async () => {
    const target = activePrinter;
    if (!target) {
      const sampleSale: SaleTransaction = {
        fecha: formatDateVE(new Date()),
        hora: new Date().toLocaleTimeString('es-VE'),
        timestamp: Date.now(),
        metodo_pago: 'Pago Móvil',
        referencia_pago: '00984512',
        monto_total_ves: round2(15 * bcvRate),
        monto_total_usd_bcv: 15,
        tasa_bcv_momento: bcvRate,
        iva_aplicado: false,
        iva_porcentaje: 0,
        monto_iva_ves: 0,
        monto_iva_usd: 0,
        items: [
          {
            id: 'Producto de Prueba Térmica',
            cantidad: 1,
            precio_unitario_bs: round2(15 * bcvRate),
            precio_unitario_usd: 15,
            costo_unitario_usd: 10,
          },
        ],
        usuario: operatorName || 'Caja',
        cajero_nombre: operatorName || 'Caja',
      };
      notifyToast('Imprimiendo prueba con el formato térmico configurado del local.', 'info');
      printBrowserReceiptHtml(sampleSale, localName, invoiceConfig, tenantMetaForReceipt);
      return;
    }
    try {
      const rasterLogo =
        invoiceConfig.mostrar_logo && invoiceConfig.logo_data_url
          ? await buildEscPosRasterLogoAsync(
              invoiceConfig.logo_data_url,
              invoiceConfig.ancho_papel,
              invoiceConfig.intensidad_impresion
            )
          : null;
      const ok = await writeBytesToPrinter(
        target,
        buildEscPosTestTicket(localName, invoiceConfig, rasterLogo)
      );
      if (ok) {
        playBeep('ok');
        notifyToast(`Ticket de prueba enviado a ${target.name}`, 'success');
      }
    } catch (err) {
      playBeep('err');
      notifyToast(
        `Error imprimiendo prueba en ${target.name}: ${
          err instanceof Error ? err.message : 'revisa conexión'
        }`,
        'warning'
      );
    }
  }, [activePrinter, bcvRate, invoiceConfig, localName, notifyToast, operatorName, playBeep, tenantMetaForReceipt]);

  const dispatchSaleInvoice = useCallback(
    async (
      sale: SaleTransaction,
      modeOverride?: InvoiceMode
    ): Promise<'printer' | 'pdf' | 'browser' | 'none'> => {
      const effectiveMode = modeOverride || invoiceMode;
      if (effectiveMode === 'none') return 'none';

      const defaultPrinterPref = invoiceConfig.impresora_predeterminada || 'navegador';

      // Direct ESC/POS USB or Serial printer when connected
      if ((effectiveMode === 'auto' || effectiveMode === 'printer') && activePrinter) {
        try {
          const rasterLogo =
            invoiceConfig.mostrar_logo && invoiceConfig.logo_data_url
              ? await buildEscPosRasterLogoAsync(
                  invoiceConfig.logo_data_url,
                  invoiceConfig.ancho_papel,
                  invoiceConfig.intensidad_impresion
                )
              : null;
          const bytes = buildEscPosSaleTicket(
            sale,
            localName,
            invoiceConfig,
            tenantMetaForReceipt,
            rasterLogo
          );
          const copies = invoiceConfig.copias === 2 ? 2 : 1;
          let ok = false;
          for (let c = 0; c < copies; c++) {
            ok = await writeBytesToPrinter(activePrinter, bytes);
          }
          if (ok) {
            notifyToast(`Ticket impreso automáticamente en ${activePrinter.name}.`, 'success');
            return 'printer';
          }
        } catch {
          notifyToast(
            `No se pudo imprimir en ${activePrinter.name}; generando PDF de respaldo.`,
            'warning'
          );
          generateInvoicePDF(sale, localName, invoiceConfig, tenantMetaForReceipt);
          return 'pdf';
        }
      }

      if (
        effectiveMode === 'printer' ||
        (effectiveMode === 'auto' &&
          invoiceConfig.auto_imprimir &&
          defaultPrinterPref === 'navegador')
      ) {
        printBrowserReceiptHtml(sale, localName, invoiceConfig, tenantMetaForReceipt);
        notifyToast(
          invoiceConfig.impresora_nombre
            ? `Ticket térmico enviado (${invoiceConfig.impresora_nombre}).`
            : 'Impresión térmica enviada al diálogo de impresora del equipo.',
          'info'
        );
        return 'browser';
      }

      generateInvoicePDF(sale, localName, invoiceConfig, tenantMetaForReceipt);
      notifyToast(`Factura PDF FAC-${String(sale.timestamp).slice(-8)} descargada.`, 'success');
      return 'pdf';
    },
    [activePrinter, invoiceConfig, invoiceMode, localName, notifyToast, tenantMetaForReceipt]
  );

  // Process Sale + Atomic Fiado / Cashea / Pago Mixto / Optional Customer Billing inside isolated tenant node
  const processSale = useCallback(
    async (params: {
      paymentMethod: string;
      usdCustomAmount?: number | null;
      invoiceModeOverride?: InvoiceMode;
      referenciaPago?: string;
      casheaData?: {
        nivel: string;
        inicialUsd: number;
        cuotas: number;
      };
      splitPayments?: SplitPaymentLeg[];
      customerInfo?: {
        cedula?: string;
        nombre?: string;
      };
      fiadoData?: {
        cliente: string;
        cedula: string;
        telefono?: string;
        direccion?: string;
        nota?: string;
        modalidad?: 'credito' | 'contado_pendiente';
        cuotas: number;
        fecha_vencimiento?: string;
        limite_credito?: number;
        inicial_usd?: number;
      };
    }): Promise<boolean> => {
      if (role !== 'owner' && membershipExpired) {
        notifyToast('Sistema bloqueado por membresía en 0 días. Renueva para facturar.', 'error');
        playBeep('err');
        return false;
      }
      if (cart.length === 0) return false;
      if (!activeTenantId) {
        notifyToast('Selecciona o vincula un nodo de comercio antes de facturar.', 'warning');
        return false;
      }
      const {
        paymentMethod,
        usdCustomAmount,
        invoiceModeOverride,
        referenciaPago,
        casheaData,
        splitPayments,
        customerInfo,
        fiadoData,
      } = params;
      if (!paymentMethod) {
        notifyToast('Selecciona un método de pago.', 'warning');
        return false;
      }

      const rateToUse = getActiveRateValue();
      let totalBs = 0;
      const itemsProcessed: SaleItem[] = cart.map((item) => {
        const isBulto =
          item.saleUnit === 'bulto' &&
          item.product.ventaPorBulto === true &&
          (Number(item.product.unidadesPorBulto) || 0) > 1;
        const unitsPerPack = isBulto ? Number(item.product.unidadesPorBulto) : 1;
        const unitUsd = getEffectiveUnitPrice(item.product, isBulto ? 'bulto' : 'detal');
        const unitBs =
          item.customDiscountVes !== null ? item.customDiscountVes : unitUsd * rateToUse;
        totalBs += unitBs * item.quantity;
        return stripUndefined({
          id: isBulto ? `${item.product.id} (Bulto ×${unitsPerPack})` : item.product.id,
          key: item.product.key,
          cantidad: item.quantity,
          precio_unitario_bs: round2(unitBs),
          precio_unitario_usd: round2(unitUsd),
          costo_unitario_usd: round2((Number(item.product.cost) || 0) * unitsPerPack),
          es_bulto: isBulto ? true : undefined,
          unidades_por_bulto: isBulto ? unitsPerPack : undefined,
          unidades_descontadas: round2(item.quantity * unitsPerPack),
        }) as SaleItem;
      });

      if (globalParallelOverrideVes !== null) {
        totalBs = globalParallelOverrideVes;
      }

      let totalUsdBcv = rateToUse > 0 ? totalBs / rateToUse : 0;
      if (paymentMethod === 'Efectivo Dolar' && usdCustomAmount && usdCustomAmount > 0) {
        totalUsdBcv = usdCustomAmount;
        totalBs = usdCustomAmount * rateToUse;
      }

      const factor = ivaActive ? 1 + IVA_RATE : 1;
      const ivaBs = totalBs * (factor - 1);
      const ivaUsd = rateToUse > 0 ? ivaBs / rateToUse : 0;
      totalBs *= factor;
      totalUsdBcv *= factor;

      const fullTotalBs = round2(totalBs);
      const fullTotalUsd = round2(totalUsdBcv);

      let closureTotalBs = fullTotalBs;
      let closureTotalUsd = fullTotalUsd;
      let casheaFields: Partial<SaleTransaction> = {};

      if (paymentMethod === 'Cashea' && casheaData) {
        const clampedInicialUsd = round2(
          Math.max(0, Math.min(fullTotalUsd, Number(casheaData.inicialUsd) || 0))
        );
        const inicialBs =
          fullTotalUsd > 0
            ? round2(fullTotalBs * (clampedInicialUsd / fullTotalUsd))
            : round2(clampedInicialUsd * rateToUse);
        const restanteUsd = round2(Math.max(0, fullTotalUsd - clampedInicialUsd));
        const restanteBs = round2(Math.max(0, fullTotalBs - inicialBs));
        const cuotas = Math.max(1, Math.round(Number(casheaData.cuotas) || 3));
        const cuotaUsd = round2(restanteUsd / cuotas);

        // En el cierre solo se refleja la inicial aprobada en caja; el restante queda pendiente
        closureTotalBs = inicialBs;
        closureTotalUsd = clampedInicialUsd;
        casheaFields = {
          cashea_nivel: casheaData.nivel || 'Manual',
          cashea_inicial_usd: clampedInicialUsd,
          cashea_inicial_ves: inicialBs,
          cashea_restante_usd: restanteUsd,
          cashea_restante_ves: restanteBs,
          cashea_cuotas: cuotas,
          cashea_cuota_usd: cuotaUsd,
          cashea_total_venta_usd: fullTotalUsd,
          cashea_total_venta_ves: fullTotalBs,
        };
      }

      const cleanSplitLegs: SplitPaymentLeg[] | undefined =
        paymentMethod === 'Pago Mixto' && Array.isArray(splitPayments) && splitPayments.length > 0
          ? splitPayments
              .filter((leg) => Number(leg.monto_ves) > 0 || Number(leg.monto_usd) > 0)
              .slice(0, 20)
              .map((leg) => ({
                metodo: String(leg.metodo || 'Efectivo Bs').trim().slice(0, 60),
                monto_ves: round2(Number(leg.monto_ves) || 0),
                monto_usd: round2(Number(leg.monto_usd) || 0),
                ...(leg.referencia?.trim() ? { referencia: leg.referencia.trim().slice(0, 60) } : {}),
              }))
          : undefined;

      const cleanCliCedula = (customerInfo?.cedula || fiadoData?.cedula || '').trim().slice(0, 40);
      const cleanCliNombre = (customerInfo?.nombre || fiadoData?.cliente || '').trim().slice(0, 140);

      const now = new Date();
      const timestamp = now.getTime();
      const operatorLabel =
        role === 'cashier' && operatorName
          ? `${operatorName} (${operatorEmail || 'Cajero'})`
          : authUser?.email || operatorName || 'Cajero Operativo';

      const cleanRefPago = (referenciaPago || '').trim().slice(0, 60);

      // Compute correlative SENIAT invoice & control numbers when Modo Fiscal is active
      const isSeniatActive = platformConfig.seniat_legal_activo === true;
      const curSeniatCfg = activeTenant?.seniat_config || {};
      let numeroFactura: string | undefined;
      let numeroControl: string | undefined;
      let nextSeniatCfg: TenantRecord['seniat_config'] | null = null;
      if (isSeniatActive) {
        const prefFac = (curSeniatCfg.prefijo_factura || platformConfig.seniat_prefijo_factura || 'FAC-').trim();
        const prefCtrl = (curSeniatCfg.prefijo_control || platformConfig.seniat_prefijo_control || '00-').trim();
        const nextFacNum = Math.max(1, Math.floor(Number(curSeniatCfg.factura_actual) || 1));
        const nextCtrlNum = Math.max(1, Math.floor(Number(curSeniatCfg.control_actual) || 1));
        numeroFactura = `${prefFac}${String(nextFacNum).padStart(8, '0')}`;
        numeroControl = `${prefCtrl}${String(nextCtrlNum).padStart(8, '0')}`;
        nextSeniatCfg = {
          ...curSeniatCfg,
          prefijo_factura: prefFac,
          factura_actual: nextFacNum + 1,
          prefijo_control: prefCtrl,
          control_actual: nextCtrlNum + 1,
        };
      }

      const ventaPayload: SaleTransaction = stripUndefined({
        fecha: formatDateVE(now),
        hora: now.toLocaleTimeString('es-VE'),
        timestamp,
        metodo_pago: paymentMethod,
        referencia_pago: cleanRefPago || undefined,
        monto_total_ves: closureTotalBs,
        monto_total_usd_bcv: closureTotalUsd,
        tasa_bcv_momento: rateToUse,
        iva_aplicado: ivaActive,
        iva_porcentaje: ivaActive ? Math.round(IVA_RATE * 100) : 0,
        monto_iva_ves: round2(ivaBs),
        monto_iva_usd: round2(ivaUsd),
        ...casheaFields,
        pagos_mixtos: cleanSplitLegs,
        cliente_cedula: cleanCliCedula || undefined,
        cliente_nombre: cleanCliNombre || undefined,
        numero_factura: numeroFactura,
        numero_control: numeroControl,
        items: itemsProcessed,
        usuario: operatorLabel,
        cajero_nombre: operatorName || null,
      }) as SaleTransaction;

      const batch = writeBatch(db);
      const saleDocId = String(timestamp);
      batch.set(doc(db, 'tenants', activeTenantId, 'sales', saleDocId), ventaPayload);
      if (isSeniatActive && nextSeniatCfg) {
        batch.update(doc(db, 'tenants', activeTenantId), {
          seniat_config: nextSeniatCfg,
          updatedAt: timestamp,
        });
      }

      // Aggregate total unit deductions per product key (handles mixed bulto + detal lines for same product)
      const unitsToDeductByKey: Record<string, { stock: number; deduct: number }> = {};
      cart.forEach((item) => {
        const units = round2(item.quantity * getItemUnitsPerPack(item));
        if (!unitsToDeductByKey[item.product.key]) {
          unitsToDeductByKey[item.product.key] = { stock: item.product.stock, deduct: 0 };
        }
        unitsToDeductByKey[item.product.key].deduct = round2(
          unitsToDeductByKey[item.product.key].deduct + units
        );
      });
      Object.entries(unitsToDeductByKey).forEach(([prodKey, info]) => {
        const newStock = Math.max(0, round2(info.stock - info.deduct));
        batch.update(doc(db, 'tenants', activeTenantId, 'products', prodKey), {
          stock: newStock,
          updatedAt: timestamp,
        });
      });

      // Upsert registered billing customer if optional cedula & nombre were provided
      if (cleanCliCedula && cleanCliNombre) {
        const custDocId = sanitizeFirestoreId(cleanCliCedula.toLowerCase(), 'cli');
        const existingCust = customers.find(
          (c) => c.key === custDocId || c.cedula.toLowerCase() === cleanCliCedula.toLowerCase()
        );
        const custTargetKey = existingCust?.key || custDocId;
        batch.set(
          doc(db, 'tenants', activeTenantId, 'customers', custTargetKey),
          stripUndefined({
            cedula: cleanCliCedula,
            nombre: cleanCliNombre,
            telefono: existingCust?.telefono || fiadoData?.telefono?.trim() || '',
            direccion: existingCust?.direccion || fiadoData?.direccion?.trim() || '',
            email: existingCust?.email || '',
            nota: existingCust?.nota || '',
            compras_count: (Number(existingCust?.compras_count) || 0) + 1,
            total_comprado_usd: round2((Number(existingCust?.total_comprado_usd) || 0) + fullTotalUsd),
            ultima_compra: timestamp,
            createdAt: existingCust?.createdAt || timestamp,
            updatedAt: timestamp,
          }),
          { merge: true }
        );
      }

      if (paymentMethod === 'Fiado' && fiadoData) {
        const cleanCedula = fiadoData.cedula.replace(/\D/g, '') || '0';
        const fiadoDocId = sanitizeFirestoreId(`${cleanCedula}_${timestamp}`, 'fiado');
        const modalidad =
          fiadoData.modalidad === 'contado_pendiente' ? 'contado_pendiente' : 'credito';
        const fiadoRecord: Record<string, unknown> = {
          cliente: fiadoData.cliente.trim(),
          cedula: cleanCedula,
          telefono: fiadoData.telefono?.trim() || '',
          direccion: fiadoData.direccion?.trim() || '',
          nota: fiadoData.nota?.trim() || '',
          modalidad,
          numero_factura: `FIA-${String(timestamp).slice(-6)}`,
          cuotas: modalidad === 'contado_pendiente' ? 1 : Math.max(1, fiadoData.cuotas || 1),
          fecha_vencimiento: fiadoData.fecha_vencimiento || '',
          limite_credito: fiadoData.limite_credito || 0,
          items: cart.map((i) => {
            const isBulto =
              i.saleUnit === 'bulto' &&
              i.product.ventaPorBulto === true &&
              (Number(i.product.unidadesPorBulto) || 0) > 1;
            const upb = isBulto ? Number(i.product.unidadesPorBulto) : 1;
            return {
              key: i.product.key,
              nombre: isBulto ? `${i.product.id} (Bulto ×${upb})` : i.product.id,
              cant: i.quantity,
              usd: round2(getEffectiveUnitPrice(i.product, isBulto ? 'bulto' : 'detal')),
              base: round2(i.product.price),
              ...(isBulto
                ? { es_bulto: true, unidades_por_bulto: upb, unidades_descontadas: round2(i.quantity * upb) }
                : { unidades_descontadas: round2(i.quantity) }),
            };
          }),
          iva: factor,
          fecha: now.toLocaleString('es-VE'),
          ts: timestamp,
          estado: 'abierto',
          creado_por: operatorLabel,
        };

        if (fiadoData.inicial_usd && fiadoData.inicial_usd > 0) {
          fiadoRecord.abonos = {
            [String(timestamp)]: {
              usd: round2(fiadoData.inicial_usd),
              bs: round2(fiadoData.inicial_usd * rateToUse),
              tasa: rateToUse,
              tipo: 'inicial',
              metodo: 'Inicial en caja',
              fecha: now.toLocaleString('es-VE'),
              ts: timestamp,
              cobrado_por: operatorLabel,
            },
          };
        }

        batch.set(doc(db, 'tenants', activeTenantId, 'fiados', fiadoDocId), fiadoRecord);
      }

      try {
        await batch.commit();
        setLastCompletedSale({ ...ventaPayload, key: saleDocId });
        clearCart();
        playBeep('ok');
        notifyToast(
          paymentMethod === 'Fiado'
            ? `Fiado registrado para ${fiadoData?.cliente} y stock descontado.`
            : paymentMethod === 'Cashea' && casheaFields.cashea_inicial_usd !== undefined
            ? `Cashea aprobado: Inicial $${casheaFields.cashea_inicial_usd.toFixed(2)} · Pendiente $${(casheaFields.cashea_restante_usd || 0).toFixed(2)} (${casheaFields.cashea_cuotas} cuotas). Stock descontado.`
            : cleanSplitLegs
            ? `Pago fraccionado (${cleanSplitLegs.length} métodos) procesado con éxito.`
            : 'Venta procesada y almacenada con éxito.',
          'success'
        );
        void dispatchSaleInvoice(ventaPayload, invoiceModeOverride);
        return true;
      } catch (err) {
        playBeep('err');
        handleFirestoreError(err, OperationType.WRITE, `tenants/${activeTenantId}/sales`);
        return false;
      }
    },
    [
      activeTenant?.seniat_config,
      activeTenantId,
      authUser,
      cart,
      clearCart,
      customers,
      dispatchSaleInvoice,
      getActiveRateValue,
      getEffectiveUnitPrice,
      globalParallelOverrideVes,
      ivaActive,
      membershipExpired,
      notifyToast,
      operatorEmail,
      operatorName,
      platformConfig.seniat_legal_activo,
      platformConfig.seniat_prefijo_control,
      platformConfig.seniat_prefijo_factura,
      playBeep,
      role,
    ]
  );

  // Delete a fiado invoice (caller must enforce verifyAdminAuthorization before calling)
  const deleteFiadoInvoice = useCallback(
    async (fiado: FiadoRecord, restoreStock = false) => {
      if (!activeTenantId) return;
      const docId = fiado.docKey || sanitizeFirestoreId(`${fiado.cedula}_${fiado.ts}`, 'fiado');
      const now = Date.now();
      const batch = writeBatch(db);
      batch.delete(doc(db, 'tenants', activeTenantId, 'fiados', docId));

      if (restoreStock && fiado.estado !== 'pagado') {
        const itemsArr = Array.isArray(fiado.items) ? fiado.items : Object.values(fiado.items || {});
        const deltaByKey: Record<string, number> = {};
        itemsArr.forEach((it) => {
          const matched =
            (it.key ? products.find((p) => p.key === it.key) : null) ||
            products.find(
              (p) => p.id.trim().toLowerCase() === String(it.nombre || '').trim().toLowerCase()
            );
          if (matched) {
            const restoreUnits = Number(it.unidades_descontadas ?? it.cant) || 0;
            deltaByKey[matched.key] = round2((deltaByKey[matched.key] || 0) + restoreUnits);
          }
        });
        Object.entries(deltaByKey).forEach(([prodKey, qty]) => {
          const prod = products.find((p) => p.key === prodKey);
          if (prod && qty > 0) {
            batch.update(doc(db, 'tenants', activeTenantId, 'products', prodKey), {
              stock: round2((Number(prod.stock) || 0) + qty),
              updatedAt: now,
            });
          }
        });
      }

      try {
        await batch.commit();
        playBeep('ok');
        notifyToast(
          `Factura fiada ${fiado.numero_factura || fiado.cliente} eliminada${
            restoreStock ? ' y stock restablecido' : ''
          }.`,
          'success'
        );
      } catch (err) {
        playBeep('err');
        handleFirestoreError(err, OperationType.DELETE, `tenants/${activeTenantId}/fiados/${docId}`);
      }
    },
    [activeTenantId, notifyToast, playBeep, products]
  );

  // Build Cierre de Caja Payload
  const buildCurrentCierrePayload = useCallback((): CierreRecord => {
    let totalGeneralBs = 0;
    let totalGeneralUsd = 0;
    const totalsByMethodBs: Record<string, number> = {};
    const totalsByMethodUsd: Record<string, number> = {};
    let casheaInicialTotalUsd = 0;
    let casheaInicialTotalBs = 0;
    let casheaPendienteUsd = 0;
    let casheaPendienteBs = 0;

    liveSales.forEach((v) => {
      const m = v.metodo_pago || 'Desconocido';
      const bs = Number(v.monto_total_ves) || 0;
      const usd = Number(v.monto_total_usd_bcv) || 0;
      totalGeneralBs += bs;
      totalGeneralUsd += usd;

      if (Array.isArray(v.pagos_mixtos) && v.pagos_mixtos.length > 0) {
        v.pagos_mixtos.forEach((leg) => {
          const lm = leg.metodo || 'Otros';
          totalsByMethodBs[lm] = round2((totalsByMethodBs[lm] || 0) + (Number(leg.monto_ves) || 0));
          totalsByMethodUsd[lm] = round2((totalsByMethodUsd[lm] || 0) + (Number(leg.monto_usd) || 0));
        });
      } else {
        totalsByMethodBs[m] = round2((totalsByMethodBs[m] || 0) + bs);
        totalsByMethodUsd[m] = round2((totalsByMethodUsd[m] || 0) + usd);
      }

      if (m === 'Cashea') {
        casheaInicialTotalUsd += Number(v.cashea_inicial_usd ?? usd) || 0;
        casheaInicialTotalBs += Number(v.cashea_inicial_ves ?? bs) || 0;
        casheaPendienteUsd += Number(v.cashea_restante_usd) || 0;
        casheaPendienteBs += Number(v.cashea_restante_ves) || 0;
      }
    });

    const prodMap: Record<string, CierreProductoSummary> = {};
    const detalleVentas: CierreDetalleVenta[] = [];
    let ivaTotalBs = 0;
    let ivaTotalUsd = 0;
    let subtotalProdBs = 0;

    liveSales
      .slice()
      .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0))
      .forEach((v) => {
        const tasa = Number(v.tasa_bcv_momento) || bcvRate || 1;
        const itemsArr: SaleItem[] = Array.isArray(v.items)
          ? v.items
          : v.items
          ? Object.values(v.items as Record<string, SaleItem>)
          : [];
        const resumen: string[] = [];
        const itemsDet: CierreDetalleItem[] = [];

        itemsArr.forEach((it) => {
          const nombre = String(it.id || 'Producto');
          const q = Number(it.cantidad) || 0;
          const bs = (Number(it.precio_unitario_bs) || 0) * q;
          if (!prodMap[nombre]) {
            prodMap[nombre] = { nombre, cantidad: 0, total_ves: 0, total_usd: 0 };
          }
          prodMap[nombre].cantidad += q;
          prodMap[nombre].total_ves += bs;
          prodMap[nombre].total_usd += bs / tasa;
          subtotalProdBs += bs;
          resumen.push(`${nombre} x${Math.round(q * 100) / 100}`);
          itemsDet.push({
            nombre,
            cantidad: round2(q),
            precio_ves: round2(Number(it.precio_unitario_bs) || 0),
            subtotal_ves: round2(bs),
          });
        });

        const vIvaBs = Number(v.monto_iva_ves) || 0;
        const vIvaUsd = Number(v.monto_iva_usd) || 0;
        ivaTotalBs += vIvaBs;
        ivaTotalUsd += vIvaUsd;

        const itemsSum = itemsDet.reduce((a, x) => a + x.subtotal_ves, 0);
        const isCashea = v.metodo_pago === 'Cashea';
        const vRestanteBs = isCashea ? Number(v.cashea_restante_ves) || 0 : 0;
        detalleVentas.push(
          stripUndefined({
            hora: v.hora || '',
            metodo: isCashea
              ? `Cashea${v.cashea_nivel ? ` (${v.cashea_nivel})` : ''} · Solo inicial`
              : Array.isArray(v.pagos_mixtos) && v.pagos_mixtos.length > 0
              ? `Pago Mixto (${v.pagos_mixtos.map((l) => l.metodo).join(' + ')})`
              : v.metodo_pago || '',
            productos: resumen.join(', '),
            items: itemsDet,
            iva_ves: round2(vIvaBs),
            ajuste_ves: round2((Number(v.monto_total_ves) || 0) + vRestanteBs - itemsSum - vIvaBs),
            total_ves: round2(Number(v.monto_total_ves) || 0),
            usuario: v.usuario || '',
            cashea_inicial_usd: isCashea ? round2(Number(v.cashea_inicial_usd ?? v.monto_total_usd_bcv) || 0) : undefined,
            cashea_restante_usd: isCashea ? round2(Number(v.cashea_restante_usd) || 0) : undefined,
            cashea_restante_ves: isCashea ? round2(vRestanteBs) : undefined,
            cashea_cuotas: isCashea ? Number(v.cashea_cuotas) || 3 : undefined,
            cashea_total_venta_ves: isCashea ? round2(Number(v.cashea_total_venta_ves) || 0) : undefined,
            pagos_mixtos: Array.isArray(v.pagos_mixtos) && v.pagos_mixtos.length > 0 ? v.pagos_mixtos : undefined,
            cliente_nombre: v.cliente_nombre || undefined,
            cliente_cedula: v.cliente_cedula || undefined,
          }) as CierreDetalleVenta
        );
      });

    const productosVendidos = Object.values(prodMap)
      .sort((a, b) => b.total_ves - a.total_ves)
      .map((p) => ({
        nombre: p.nombre,
        cantidad: round2(p.cantidad),
        total_ves: round2(p.total_ves),
        total_usd: round2(p.total_usd),
      }));

    const now = new Date();
    return stripUndefined({
      fecha: formatDateVE(now),
      hora: now.toLocaleTimeString('es-VE'),
      timestamp: now.getTime(),
      total_general_ves: round2(totalGeneralBs),
      total_general_usd: round2(totalGeneralUsd),
      totales_metodos_ves: totalsByMethodBs,
      totales_metodos_usd: totalsByMethodUsd,
      cantidad_ventas: liveSales.length,
      productos_vendidos: productosVendidos,
      detalle_ventas: detalleVentas,
      subtotal_productos_ves: round2(subtotalProdBs),
      ajuste_ves: round2(totalGeneralBs + casheaPendienteBs - subtotalProdBs - ivaTotalBs),
      total_iva_ves: round2(ivaTotalBs),
      total_iva_usd: round2(ivaTotalUsd),
      cashea_inicial_total_usd: casheaInicialTotalUsd > 0 ? round2(casheaInicialTotalUsd) : undefined,
      cashea_inicial_total_ves: casheaInicialTotalBs > 0 ? round2(casheaInicialTotalBs) : undefined,
      cashea_pendiente_usd: casheaPendienteUsd > 0 ? round2(casheaPendienteUsd) : undefined,
      cashea_pendiente_ves: casheaPendienteBs > 0 ? round2(casheaPendienteBs) : undefined,
      cerrado_por: operatorName || authUser?.email || 'Cajero Operativo',
    }) as CierreRecord;
  }, [authUser, bcvRate, liveSales, operatorName]);

  const executeShiftClose = useCallback(
    async (authorizedByLabel?: string): Promise<CierreRecord> => {
      if (role !== 'owner' && membershipExpired) {
        throw new Error('Membresía vencida (0 días). Renueva antes de cerrar turno.');
      }
      const baseCierre = buildCurrentCierrePayload();
      const cierre: CierreRecord = authorizedByLabel
        ? { ...baseCierre, cerrado_por: `${baseCierre.cerrado_por} · Aut: ${authorizedByLabel}` }
        : baseCierre;
      if (!activeTenantId) throw new Error('No hay un comercio activo para cerrar turno.');

      // Si hay impresora conectada/seleccionada, imprime ticket detallado de cierre
      let printedThermal = false;
      if (activePrinter) {
        try {
          const ok = await writeBytesToPrinter(
            activePrinter,
            buildEscPosCierreTicket(cierre, localName)
          );
          if (ok) printedThermal = true;
        } catch {
          // continúa con el PDF automático
        }
      }

      // Siempre genera el PDF automático al cerrar turno
      try {
        generateCierrePDF(cierre, localName, invoiceConfig);
      } catch {
        // PDF download non-blocking
      }

      try {
        const batch = writeBatch(db);
        const { key: _ignoredKey, ...cierreClean } = cierre;
        batch.set(
          doc(db, 'tenants', activeTenantId, 'closures', String(cierre.timestamp)),
          stripUndefined(cierreClean)
        );
        liveSales.forEach((s) => {
          if (s.key) {
            batch.delete(doc(db, 'tenants', activeTenantId, 'sales', s.key));
          }
        });
        batch.set(
          doc(db, 'tenants', activeTenantId, 'settings', 'config'),
          { caja_abierta: false, updatedAt: Date.now() },
          { merge: true }
        );
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `tenants/${activeTenantId}/closures`);
      }

      notifyToast(
        printedThermal
          ? `Cierre sincronizado, impreso en ${activePrinter?.name} y PDF generado.`
          : 'Cierre de caja sincronizado y PDF automático descargado.',
        'success'
      );
      playBeep('ok');
      await logout();
      return cierre;
    },
    [
      activePrinter,
      activeTenantId,
      buildCurrentCierrePayload,
      liveSales,
      localName,
      logout,
      membershipExpired,
      notifyToast,
      playBeep,
      role,
    ]
  );

  // Admin-only authorization gate for closing shift (NEVER accepts Cashier PIN)
  const verifyAdminAuthorization = useCallback(
    async (
      secret: string,
      mode: 'pin' | 'password'
    ): Promise<{ ok: boolean; error?: string; label?: string }> => {
      const cleanSecret = secret.trim();
      if (!cleanSecret) {
        return { ok: false, error: 'Ingresa la clave o PIN administrativo.' };
      }

      if (mode === 'pin') {
        if (!activeTenant?.admin_pin_salt || !activeTenant?.admin_pin_hash) {
          return {
            ok: false,
            error:
              'Este comercio aún no tiene un PIN Administrativo configurado. Usa la Contraseña de Administrador.',
          };
        }
        const computed = await hashPin(activeTenant.admin_pin_salt, cleanSecret);
        if (computed === activeTenant.admin_pin_hash) {
          return { ok: true, label: 'PIN Admin' };
        }
        return {
          ok: false,
          error: 'PIN Administrativo inválido. El PIN de cajero no autoriza cierres de caja.',
        };
      }

      const candidateEmails = Array.from(
        new Set(
          [activeTenant?.email, role === 'owner' ? authUser?.email : undefined]
            .map((e) => (e || '').trim().toLowerCase())
            .filter(Boolean)
        )
      );
      if (candidateEmails.length === 0) {
        return { ok: false, error: 'No se encontró correo de administrador para validar.' };
      }
      for (const em of candidateEmails) {
        const ok = await verifyPasswordForEmail(em, secret);
        if (ok) {
          return { ok: true, label: `Admin (${em})` };
        }
      }
      return {
        ok: false,
        error: 'Contraseña de administrador incorrecta.',
      };
    },
    [activeTenant, authUser?.email, role]
  );

  const deleteSavedCierre = useCallback(
    async (closureKey: string) => {
      if (!activeTenantId || !closureKey) return;
      const path = `tenants/${activeTenantId}/closures/${closureKey}`;
      try {
        await deleteDoc(doc(db, 'tenants', activeTenantId, 'closures', closureKey));
        notifyToast('Cierre eliminado del historial.', 'success');
        playBeep('ok');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeTenantId, notifyToast, playBeep]
  );

  const reprintSavedCierre = useCallback(
    async (cierre: CierreRecord, target: 'auto' | 'thermal' | 'browser' | 'pdf') => {
      if (target === 'pdf') {
        generateCierrePDF(cierre, localName, invoiceConfig);
        notifyToast('Copia PDF del cierre descargada.', 'success');
        return;
      }
      if ((target === 'thermal' || target === 'auto') && activePrinter) {
        try {
          const ok = await writeBytesToPrinter(
            activePrinter,
            buildEscPosCierreTicket(cierre, localName)
          );
          if (ok) {
            notifyToast(`Copia enviada a impresora térmica (${activePrinter.name}).`, 'success');
            playBeep('ok');
            return;
          }
        } catch {
          notifyToast('Error enviando a impresora térmica; usando impresión de navegador.', 'warning');
        }
      }
      printBrowserCierreHtml(cierre, localName, invoiceConfig);
      notifyToast('Copia del cierre enviada a impresión.', 'info');
    },
    [activePrinter, invoiceConfig, localName, notifyToast, playBeep]
  );

  // Suppliers & Purchase Invoices CRUD
  const saveProvider = useCallback(
    async (
      data: Omit<ProviderRecord, 'key' | 'createdAt' | 'updatedAt'>,
      editKey?: string
    ) => {
      if (!activeTenantId) return;
      const now = Date.now();
      const key = editKey || `prov_${now}_${Math.random().toString(36).slice(2, 6)}`;
      const path = `tenants/${activeTenantId}/providers/${key}`;
      const existingProv = editKey ? providers.find((p) => p.key === editKey) : undefined;
      try {
        await setDoc(
          doc(db, 'tenants', activeTenantId, 'providers', key),
          stripUndefined({
            ...data,
            nombre: data.nombre.trim(),
            activo: data.activo !== false,
            createdAt: existingProv?.createdAt || now,
            updatedAt: now,
          }),
          { merge: true }
        );
        notifyToast(
          editKey ? `Proveedor "${data.nombre}" actualizado.` : `Proveedor "${data.nombre}" registrado.`,
          'success'
        );
        playBeep('ok');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    },
    [activeTenantId, notifyToast, playBeep, providers]
  );

  const deleteProvider = useCallback(
    async (providerKey: string) => {
      if (!activeTenantId || !providerKey) return;
      const path = `tenants/${activeTenantId}/providers/${providerKey}`;
      try {
        await deleteDoc(doc(db, 'tenants', activeTenantId, 'providers', providerKey));
        notifyToast('Proveedor eliminado.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeTenantId, notifyToast]
  );

  const registerSupplierPurchase = useCallback(
    async (input: {
      numero_factura: string;
      providerId: string;
      providerNombre: string;
      providerRif?: string;
      fecha: string;
      items: SupplierPurchaseItem[];
      estado_pago: 'pagada' | 'pendiente';
      metodo_pago?: string;
      actualizar_stock: boolean;
      nota?: string;
    }) => {
      if (!activeTenantId) return;
      const now = Date.now();
      const docKey = `comp_${now}_${Math.random().toString(36).slice(2, 6)}`;
      const cleanItems = input.items.map((it) => ({
        ...it,
        cantidad: round2(Number(it.cantidad) || 0),
        costo_unitario_usd: round2(Number(it.costo_unitario_usd) || 0),
        subtotal_usd: round2((Number(it.cantidad) || 0) * (Number(it.costo_unitario_usd) || 0)),
      }));
      const totalUsd = round2(cleanItems.reduce((acc, it) => acc + it.subtotal_usd, 0));
      const totalBs = round2(totalUsd * bcvRate);

      const batch = writeBatch(db);
      batch.set(
        doc(db, 'tenants', activeTenantId, 'supplier_purchases', docKey),
        stripUndefined({
          numero_factura: input.numero_factura.trim(),
          providerId: input.providerId,
          providerNombre: input.providerNombre.trim(),
          providerRif: input.providerRif?.trim() || '',
          fecha: input.fecha,
          items: cleanItems,
          total_usd: totalUsd,
          total_bs: totalBs,
          tasa: bcvRate,
          estado_pago: input.estado_pago,
          metodo_pago: input.metodo_pago?.trim() || '',
          actualizar_stock: input.actualizar_stock,
          nota: input.nota?.trim() || '',
          registrado_por: operatorName || authUser?.email || 'Admin',
          createdAt: now,
        })
      );

      if (input.actualizar_stock) {
        cleanItems.forEach((it) => {
          if (it.productKey) {
            const existingProd = products.find((p) => p.key === it.productKey);
            if (existingProd) {
              batch.update(doc(db, 'tenants', activeTenantId, 'products', existingProd.key), {
                stock: round2(existingProd.stock + it.cantidad),
                costo: it.costo_unitario_usd > 0 ? it.costo_unitario_usd : existingProd.cost,
                updatedAt: now,
              });
            }
          }
        });
      }

      try {
        await batch.commit();
        notifyToast(
          `Factura #${input.numero_factura} registrada${input.actualizar_stock ? ' y stock sumado' : ''}.`,
          'success'
        );
        playBeep('ok');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `tenants/${activeTenantId}/supplier_purchases`);
      }
    },
    [activeTenantId, authUser?.email, bcvRate, notifyToast, operatorName, playBeep, products]
  );

  const updateSupplierPurchaseStatus = useCallback(
    async (purchaseKey: string, estado: 'pagada' | 'pendiente') => {
      if (!activeTenantId || !purchaseKey) return;
      try {
        await updateDoc(doc(db, 'tenants', activeTenantId, 'supplier_purchases', purchaseKey), {
          estado_pago: estado,
        });
        notifyToast(`Factura marcada como ${estado}.`, 'success');
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.UPDATE,
          `tenants/${activeTenantId}/supplier_purchases/${purchaseKey}`
        );
      }
    },
    [activeTenantId, notifyToast]
  );

  const deleteSupplierPurchase = useCallback(
    async (purchaseKey: string) => {
      if (!activeTenantId || !purchaseKey) return;
      try {
        await deleteDoc(doc(db, 'tenants', activeTenantId, 'supplier_purchases', purchaseKey));
        notifyToast('Factura de compra eliminada.', 'success');
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.DELETE,
          `tenants/${activeTenantId}/supplier_purchases/${purchaseKey}`
        );
      }
    },
    [activeTenantId, notifyToast]
  );

  // Sync PII-free public price checker snapshot document
  const syncPublicPriceChecker = useCallback(
    async (override?: {
      activo?: boolean;
      mostrar_paralelo?: boolean;
      mostrar_stock?: boolean;
      mensaje?: string;
    }) => {
      if (!activeTenantId) return;
      const activo =
        override?.activo !== undefined
          ? override.activo
          : config.consultor_precios_activo === true;
      const payload: PublicPriceCheckerCatalog = stripUndefined({
        activo,
        nombre_local: localName,
        tasa_bcv: bcvRate,
        tasa_secundaria: secondaryRate,
        tasa_terciaria: tertiaryRate,
        mostrar_paralelo:
          override?.mostrar_paralelo !== undefined
            ? override.mostrar_paralelo
            : config.consultor_mostrar_paralelo !== false,
        mostrar_stock:
          override?.mostrar_stock !== undefined
            ? override.mostrar_stock
            : config.consultor_mostrar_stock !== false,
        mensaje:
          override?.mensaje !== undefined
            ? override.mensaje
            : config.consultor_mensaje || '',
        updatedAt: Date.now(),
        items: products.slice(0, 2400).map((p) => ({
          id: p.key,
          nombre: p.id,
          barcode: p.barcode || '',
          categoria: p.categoria || '',
          precio: Number(p.price) || 0,
          stock: Number(p.stock) || 0,
          iva_incluido: p.ivaIncluded === true,
          iva_pct: Number(p.ivaPct) || 0,
          fraccionable: p.fraccionable === true,
        })),
      }) as PublicPriceCheckerCatalog;

      try {
        await setDoc(doc(db, 'tenants', activeTenantId, 'public_checker', 'catalog'), payload);
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.WRITE,
          `tenants/${activeTenantId}/public_checker/catalog`
        );
      }
    },
    [
      activeTenantId,
      bcvRate,
      config.consultor_mensaje,
      config.consultor_mostrar_paralelo,
      config.consultor_mostrar_stock,
      config.consultor_precios_activo,
      localName,
      products,
      secondaryRate,
      tertiaryRate,
    ]
  );

  // Debounced auto-sync of public price checker catalog while active
  useEffect(() => {
    if (!activeTenantId || (role !== 'admin' && role !== 'owner')) return;
    if (config.consultor_precios_activo !== true) return;
    const t = setTimeout(() => {
      void syncPublicPriceChecker();
    }, 900);
    return () => clearTimeout(t);
  }, [
    activeTenantId,
    bcvRate,
    config.consultor_mensaje,
    config.consultor_mostrar_paralelo,
    config.consultor_mostrar_stock,
    config.consultor_precios_activo,
    localName,
    products,
    role,
    secondaryRate,
    syncPublicPriceChecker,
    tertiaryRate,
  ]);

  // Void an open shift sale (removes from current shift/closure and restores inventory stock atomically)
  const voidLiveSale = useCallback(
    async (sale: SaleTransaction, authorizedByLabel: string) => {
      if (!activeTenantId || !sale.key) return;
      const now = Date.now();
      const batch = writeBatch(db);
      batch.delete(doc(db, 'tenants', activeTenantId, 'sales', sale.key));

      const itemsArr: SaleItem[] = Array.isArray(sale.items) ? sale.items : [];
      const stockDeltaByKey: Record<string, number> = {};
      itemsArr.forEach((it) => {
        const matched =
          (it.key ? products.find((p) => p.key === it.key) : null) ||
          products.find((p) => p.id.trim().toLowerCase() === String(it.id || '').trim().toLowerCase());
        if (matched) {
          const restoreUnits = Number(it.unidades_descontadas ?? it.cantidad) || 0;
          stockDeltaByKey[matched.key] = round2((stockDeltaByKey[matched.key] || 0) + restoreUnits);
        }
      });

      Object.entries(stockDeltaByKey).forEach(([prodKey, qtyToRestore]) => {
        const prod = products.find((p) => p.key === prodKey);
        if (prod && qtyToRestore > 0) {
          batch.update(doc(db, 'tenants', activeTenantId, 'products', prodKey), {
            stock: round2((Number(prod.stock) || 0) + qtyToRestore),
            updatedAt: now,
          });
        }
      });

      try {
        await batch.commit();
        playBeep('ok');
        notifyToast(
          `Factura FAC-${String(sale.timestamp).slice(-8)} anulada (Aut: ${authorizedByLabel}). Stock restablecido.`,
          'success'
        );
      } catch (err) {
        playBeep('err');
        handleFirestoreError(err, OperationType.DELETE, `tenants/${activeTenantId}/sales/${sale.key}`);
      }
    },
    [activeTenantId, notifyToast, playBeep, products]
  );

  // Void a specific invoice inside a saved closure (recalculates closure totals or deletes closure if empty, and restores stock)
  const voidClosureSale = useCallback(
    async (closure: CierreRecord, saleIndex: number, authorizedByLabel: string) => {
      if (!activeTenantId || !closure.key) return;
      const detalle = Array.isArray(closure.detalle_ventas) ? closure.detalle_ventas : [];
      const targetSale = detalle[saleIndex];
      if (!targetSale) return;

      const now = Date.now();
      const batch = writeBatch(db);

      // Restore stock for items in the voided closure sale (including Bulto ×N lines)
      const stockDeltaByKey: Record<string, number> = {};
      (targetSale.items || []).forEach((it) => {
        const rawName = String(it.nombre || '').trim();
        const bultoMatch = rawName.match(/^(.*)\s+\(Bulto\s*[×x](\d+(?:\.\d+)?)\)$/i);
        const baseName = (bultoMatch ? bultoMatch[1] : rawName).trim().toLowerCase();
        const multiplier = bultoMatch ? Math.max(1, Number(bultoMatch[2]) || 1) : 1;
        const matched = products.find(
          (p) =>
            p.id.trim().toLowerCase() === rawName.toLowerCase() ||
            p.id.trim().toLowerCase() === baseName
        );
        if (matched) {
          stockDeltaByKey[matched.key] = round2(
            (stockDeltaByKey[matched.key] || 0) + (Number(it.cantidad) || 0) * multiplier
          );
        }
      });
      Object.entries(stockDeltaByKey).forEach(([prodKey, qtyToRestore]) => {
        const prod = products.find((p) => p.key === prodKey);
        if (prod && qtyToRestore > 0) {
          batch.update(doc(db, 'tenants', activeTenantId, 'products', prodKey), {
            stock: round2((Number(prod.stock) || 0) + qtyToRestore),
            updatedAt: now,
          });
        }
      });

      const remaining = detalle.filter((_, idx) => idx !== saleIndex);
      const closureRef = doc(db, 'tenants', activeTenantId, 'closures', closure.key);

      if (remaining.length === 0) {
        batch.delete(closureRef);
      } else {
        const approxRate =
          closure.total_general_usd > 0
            ? closure.total_general_ves / closure.total_general_usd
            : bcvRate || 1;
        let nextTotalVes = 0;
        let nextTotalUsd = 0;
        let nextIvaVes = 0;
        let nextSubVes = 0;
        let nextCasheaIniUsd = 0;
        let nextCasheaIniVes = 0;
        let nextCasheaPendUsd = 0;
        let nextCasheaPendVes = 0;
        const nextMetVes: Record<string, number> = {};
        const nextMetUsd: Record<string, number> = {};
        const prodMap: Record<string, CierreProductoSummary> = {};

        remaining.forEach((v) => {
          const vBs = Number(v.total_ves) || 0;
          const vUsd = approxRate > 0 ? round2(vBs / approxRate) : 0;
          nextTotalVes += vBs;
          nextTotalUsd += vUsd;
          nextIvaVes += Number(v.iva_ves) || 0;

          if (Array.isArray(v.pagos_mixtos) && v.pagos_mixtos.length > 0) {
            v.pagos_mixtos.forEach((leg) => {
              const lm = leg.metodo || 'Otros';
              nextMetVes[lm] = round2((nextMetVes[lm] || 0) + (Number(leg.monto_ves) || 0));
              nextMetUsd[lm] = round2((nextMetUsd[lm] || 0) + (Number(leg.monto_usd) || 0));
            });
          } else {
            const mKey = v.metodo.startsWith('Cashea') ? 'Cashea' : v.metodo || 'Otros';
            nextMetVes[mKey] = round2((nextMetVes[mKey] || 0) + vBs);
            nextMetUsd[mKey] = round2((nextMetUsd[mKey] || 0) + vUsd);
          }

          if (v.cashea_inicial_usd !== undefined) {
            nextCasheaIniUsd += Number(v.cashea_inicial_usd) || 0;
            nextCasheaIniVes += vBs;
            nextCasheaPendUsd += Number(v.cashea_restante_usd) || 0;
            nextCasheaPendVes += Number(v.cashea_restante_ves) || 0;
          }

          (v.items || []).forEach((it) => {
            const sub = Number(it.subtotal_ves) || 0;
            nextSubVes += sub;
            if (!prodMap[it.nombre]) {
              prodMap[it.nombre] = { nombre: it.nombre, cantidad: 0, total_ves: 0, total_usd: 0 };
            }
            prodMap[it.nombre].cantidad = round2(prodMap[it.nombre].cantidad + (Number(it.cantidad) || 0));
            prodMap[it.nombre].total_ves = round2(prodMap[it.nombre].total_ves + sub);
            prodMap[it.nombre].total_usd = round2(
              prodMap[it.nombre].total_usd + (approxRate > 0 ? sub / approxRate : 0)
            );
          });
        });

        const updatedClosure = stripUndefined({
          fecha: closure.fecha,
          hora: closure.hora,
          timestamp: closure.timestamp,
          total_general_ves: round2(nextTotalVes),
          total_general_usd: round2(nextTotalUsd),
          totales_metodos_ves: nextMetVes,
          totales_metodos_usd: nextMetUsd,
          cantidad_ventas: remaining.length,
          productos_vendidos: Object.values(prodMap).sort((a, b) => b.total_ves - a.total_ves),
          detalle_ventas: remaining,
          subtotal_productos_ves: round2(nextSubVes),
          ajuste_ves: round2(nextTotalVes + nextCasheaPendVes - nextSubVes - nextIvaVes),
          total_iva_ves: round2(nextIvaVes),
          total_iva_usd: round2(approxRate > 0 ? nextIvaVes / approxRate : 0),
          cashea_inicial_total_usd: nextCasheaIniUsd > 0 ? round2(nextCasheaIniUsd) : undefined,
          cashea_inicial_total_ves: nextCasheaIniVes > 0 ? round2(nextCasheaIniVes) : undefined,
          cashea_pendiente_usd: nextCasheaPendUsd > 0 ? round2(nextCasheaPendUsd) : undefined,
          cashea_pendiente_ves: nextCasheaPendVes > 0 ? round2(nextCasheaPendVes) : undefined,
          cerrado_por: closure.cerrado_por || 'Admin',
        });
        batch.set(closureRef, updatedClosure);
      }

      try {
        await batch.commit();
        playBeep('ok');
        notifyToast(
          `Factura del cierre anulada (Aut: ${authorizedByLabel}). Totales actualizados y stock restablecido.`,
          'success'
        );
      } catch (err) {
        playBeep('err');
        handleFirestoreError(err, OperationType.UPDATE, `tenants/${activeTenantId}/closures/${closure.key}`);
      }
    },
    [activeTenantId, bcvRate, notifyToast, playBeep, products]
  );

  // Billing Customers CRUD
  const saveCustomer = useCallback(
    async (data: Omit<CustomerRecord, 'key' | 'createdAt' | 'updatedAt'>, editKey?: string) => {
      if (!activeTenantId) return;
      const now = Date.now();
      const cleanCedula = data.cedula.trim().slice(0, 40);
      const cleanNombre = data.nombre.trim().slice(0, 140);
      if (!cleanCedula || !cleanNombre) return;
      const key = editKey || sanitizeFirestoreId(cleanCedula.toLowerCase(), 'cli');
      const existing = customers.find((c) => c.key === key);
      const path = `tenants/${activeTenantId}/customers/${key}`;
      try {
        await setDoc(
          doc(db, 'tenants', activeTenantId, 'customers', key),
          stripUndefined({
            cedula: cleanCedula,
            nombre: cleanNombre,
            telefono: (data.telefono || '').trim().slice(0, 40),
            direccion: (data.direccion || '').trim().slice(0, 240),
            email: (data.email || '').trim().slice(0, 180),
            nota: (data.nota || '').trim().slice(0, 300),
            compras_count: existing?.compras_count ?? data.compras_count ?? 0,
            total_comprado_usd: existing?.total_comprado_usd ?? data.total_comprado_usd ?? 0,
            ultima_compra: existing?.ultima_compra ?? data.ultima_compra,
            createdAt: existing?.createdAt || now,
            updatedAt: now,
          })
        );
        playBeep('ok');
        notifyToast(editKey ? 'Cliente actualizado.' : 'Cliente registrado para facturación.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    },
    [activeTenantId, customers, notifyToast, playBeep]
  );

  const deleteCustomer = useCallback(
    async (customerKey: string) => {
      if (!activeTenantId) return;
      const path = `tenants/${activeTenantId}/customers/${customerKey}`;
      try {
        await deleteDoc(doc(db, 'tenants', activeTenantId, 'customers', customerKey));
        notifyToast('Cliente eliminado.', 'info');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeTenantId, notifyToast]
  );

  // Notifications Inbox Management (delete single or clear all)
  const deleteNotification = useCallback(
    async (notifKey: string) => {
      if (!activeTenantId || !notifKey) return;
      if (notifKey === '__active_broadcast__') {
        try {
          await updateTenantSettings({ broadcast: null });
          notifyToast('Notificación eliminada.', 'success');
          playBeep('ok');
        } catch (err) {
          console.error('Error eliminando broadcast:', err);
          notifyToast('No se pudo eliminar el aviso.', 'error');
        }
        return;
      }
      const target = notificationHistory.find((n) => n.key === notifKey);
      const path = `tenants/${activeTenantId}/notifications/${notifKey}`;
      try {
        await deleteDoc(doc(db, 'tenants', activeTenantId, 'notifications', notifKey));
        if (
          target &&
          config.broadcast &&
          config.broadcast.texto === target.texto &&
          config.broadcast.titulo === target.titulo
        ) {
          await updateTenantSettings({ broadcast: null }).catch(() => undefined);
        }
        notifyToast('Notificación eliminada.', 'success');
        playBeep('ok');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeTenantId, config.broadcast, notificationHistory, notifyToast, playBeep, updateTenantSettings]
  );

  const clearAllNotifications = useCallback(async () => {
    if (!activeTenantId) return;
    try {
      const batch = writeBatch(db);
      notificationHistory.forEach((n) => {
        batch.delete(doc(db, 'tenants', activeTenantId, 'notifications', n.key));
      });
      await batch.commit();
      if (config.broadcast) {
        await updateTenantSettings({ broadcast: null }).catch(() => undefined);
      }
      notifyToast('Bandeja de notificaciones vaciada.', 'success');
      playBeep('ok');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `tenants/${activeTenantId}/notifications`);
    }
  }, [activeTenantId, config.broadcast, notificationHistory, notifyToast, playBeep, updateTenantSettings]);

  const systemBusy = ratesSyncing || systemBusyCount > 0;

  const value: PosContextValue = {
    connected,
    networkStatus,
    networkLatencyMs,
    systemBusy,
    systemBusyLabel: systemBusyLabel || (ratesSyncing ? 'Sincronizando tasas de cambio...' : ''),
    setSystemBusyState,
    firebaseReady,
    authUser,
    role,
    operatorName,
    operatorEmail,
    activeCashierKey,
    cashierPermissions,
    setSessionRole,
    logout,
    tenants,
    activeTenantId,
    setActiveTenantId,
    activeTenant,
    platformConfig,
    updatePlatformConfig,
    updateTenantSettings,
    updateTenantRecord,
    registerNewTenantClient,
    deleteTenantNode,
    ensurePlatformDefaults,
    viewMode,
    setViewMode,
    isMobileLayout,
    isWideViewport,
    config,
    localName,
    mechanics,
    updateMechanics,
    bcvRate,
    secondaryRate,
    tertiaryRate,
    localCurrencyCode,
    localCurrency,
    rateEditable,
    setLocalCurrency,
    setRateEditable,
    syncCurrencyRate,
    ratesSyncing,
    syncAllRates,
    syncBcvRate,
    syncUsdtRate,
    updateRate,
    products,
    liveSales,
    savedCierres,
    fiados,
    tallerPendientes,
    tallerCierres,
    cashiers,
    systemUsers,
    tickets,
    membershipPayments,
    notificationHistory,
    providers,
    supplierPurchases,
    customers,
    verificationConfig,
    verificationDocs,
    verificationPendingCount,
    preRegistrations,
    ownerChatMessages,
    sendOwnerChatMessage,
    clearOwnerChat,
    saveTenantVerificationConfig,
    submitClientVerificationDoc,
    reviewTenantVerificationDoc,
    membership,
    membershipDaysLeft,
    membershipExpired,
    avisoMembresia,
    activeMembershipWarning,
    dismissMembershipWarning,
    plans,
    planLinks,
    promos,
    pagoMovil: config.pago_movil || null,
    metodosPagoMembresia: Array.isArray(config.metodos_pago_membresia)
      ? config.metodos_pago_membresia
      : [],
    adminAccessBlocked: config.admin_bloqueado === true,
    userFrozen: config.usuario_congelado === true,
    maintenanceMode:
      platformConfig.mantenimiento_global === true || config.mantenimiento === true,
    globalMaintenance: platformConfig.mantenimiento_global === true,
    maintenanceMessage: platformConfig.mantenimiento_mensaje || '',
    runtimeError,
    clearRuntimeError,
    cart,
    selectedSaleRate,
    setSelectedSaleRate,
    ivaActive,
    toggleIva,
    globalParallelOverrideVes,
    setGlobalParallelOverrideVes,
    addToCart,
    updateCartQty,
    removeFromCart,
    setCartItemDiscount,
    clearCart,
    getEffectiveUnitPrice,
    getActiveRateValue,
    cartTotals,
    invoiceConfig,
    updateLocalInvoiceConfig,
    invoiceMode,
    setInvoiceMode,
    detectedPrinters,
    activePrinter,
    lastCompletedSale,
    refreshPrinters,
    connectUsbPrinter,
    connectSerialPrinter,
    disconnectPrinters,
    sendTestPrint,
    dispatchSaleInvoice,
    processSale,
    deleteFiadoInvoice,
    buildCurrentCierrePayload,
    executeShiftClose,
    verifyAdminAuthorization,
    voidLiveSale,
    voidClosureSale,
    deleteSavedCierre,
    reprintSavedCierre,
    saveCustomer,
    deleteCustomer,
    saveProvider,
    deleteProvider,
    registerSupplierPurchase,
    updateSupplierPurchaseStatus,
    deleteSupplierPurchase,
    syncPublicPriceChecker,
    scannerDevices,
    lastHardwareScan,
    pushSupported,
    pushPermission,
    pushEnabled,
    enablePushNotifications,
    togglePushNotifications,
    sendTestPushNotification,
    toasts,
    notifyToast,
    playBeep,
    speakText,
    voiceSettings,
    activeBroadcast,
    dismissBroadcast,
    deleteNotification,
    clearAllNotifications,
    activeTheme,
    setLocalTheme,
    loginCashierWithPin,
    registerSystemUserSession,
  };

  return <PosContext.Provider value={value}>{children}</PosContext.Provider>;
};

export function usePos(): PosContextValue {
  const ctx = useContext(PosContext);
  if (!ctx) throw new Error('usePos debe usarse dentro de PosProvider');
  return ctx;
}

export async function createCashierRecord(
  tenantId: string,
  data: {
    nombre: string;
    email: string;
    pin: string;
    telefono?: string;
    turno?: string;
    permisos?: CashierRecord['permisos'];
  }
) {
  const creds = await createPinCredentials(data.pin);
  const id = `c_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const path = `tenants/${tenantId}/cashiers/${id}`;
  try {
    await setDoc(doc(db, 'tenants', tenantId, 'cashiers', id), {
      nombre: data.nombre.trim(),
      email: data.email.trim().toLowerCase(),
      telefono: data.telefono?.trim() || '',
      turno: data.turno?.trim() || 'General',
      activo: true,
      salt: creds.salt,
      hash: creds.hash,
      creado: Date.now(),
      permisos: data.permisos ? { ...DEFAULT_CASHIER_PERMISSIONS, ...data.permisos } : { ...DEFAULT_CASHIER_PERMISSIONS },
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function removeCashierRecord(tenantId: string, key: string) {
  const path = `tenants/${tenantId}/cashiers/${key}`;
  try {
    await deleteDoc(doc(db, 'tenants', tenantId, 'cashiers', key));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}
