import React from 'react';

interface InnovaLogoProps {
  size?: number;
  className?: string;
}

export const InnovaLogo: React.FC<InnovaLogoProps> = ({ size = 44, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="ig-logo-bg" x1="4" y1="4" x2="60" y2="60" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#38bdf8" />
        <stop offset="0.52" stopColor="#0ea5e9" />
        <stop offset="1" stopColor="#06b6d4" />
      </linearGradient>
      <linearGradient id="ig-logo-accent" x1="16" y1="10" x2="50" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#ffffff" />
        <stop offset="0.55" stopColor="#e0f2fe" />
        <stop offset="1" stopColor="#a5f3fc" />
      </linearGradient>
    </defs>
    <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#ig-logo-bg)" />
    <path d="M4 20C20 12 42 12 60 24V38C42 26 20 26 4 36Z" fill="#ffffff" fillOpacity="0.18" />
    <rect x="27" y="22" width="10" height="25" rx="4.5" fill="#ffffff" />
    <circle cx="32" cy="14.5" r="4.8" fill="url(#ig-logo-accent)" />
    <path
      d="M15 46.5C24.5 52 39.5 52 49 44.5"
      stroke="url(#ig-logo-accent)"
      strokeWidth="3.2"
      strokeLinecap="round"
    />
  </svg>
);
