import React, { useEffect, useMemo, useState } from 'react';
import {
  Building2,
  CheckCircle2,
  FileCheck2,
  Hash,
  Printer,
  Save,
  Scale,
  ShieldAlert,
  ShieldCheck,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import type { SeniatFiscalConfig, TenantRecord } from '../types/pos';

const DEFAULT_PROVIDENCIA = 'Providencia Administrativa SNAT/2011/00071 · SENIAT Venezuela';
const DEFAULT_PIE_LEGAL =
  'Documento fiscal emitido conforme a las regulaciones vigentes del SENIAT · República Bolivariana de Venezuela';

export const OwnerSeniatTab: React.FC = () => {
  const {
    platformConfig,
    updatePlatformConfig,
    tenants,
    activeTenantId,
    updateTenantRecord,
    notifyToast,
  } = usePos();

  // Global SENIAT Modo Fiscal state
  const [modoFiscalGlobal, setModoFiscalGlobal] = useState(
    platformConfig.seniat_legal_activo === true
  );
  const [globalPrefijoFactura, setGlobalPrefijoFactura] = useState(
    platformConfig.seniat_prefijo_factura || 'FAC-'
  );
  const [globalPrefijoControl, setGlobalPrefijoControl] = useState(
    platformConfig.seniat_prefijo_control || '00-'
  );
  const [globalIvaPct, setGlobalIvaPct] = useState(
    typeof platformConfig.seniat_iva_porcentaje === 'number'
      ? String(platformConfig.seniat_iva_porcentaje)
      : '16'
  );
  const [globalProvidencia, setGlobalProvidencia] = useState(
    platformConfig.seniat_providencia || DEFAULT_PROVIDENCIA
  );
  const [globalPieLegal, setGlobalPieLegal] = useState(
    platformConfig.seniat_pie_legal || DEFAULT_PIE_LEGAL
  );
  const [savingGlobal, setSavingGlobal] = useState(false);

  // Per-client SENIAT fiscal identity & invoice numbering
  const [selectedClientId, setSelectedClientId] = useState<string>(
    activeTenantId || tenants[0]?.id || ''
  );
  const selectedTenant: TenantRecord | undefined = useMemo(
    () => tenants.find((t) => t.id === selectedClientId) || tenants[0],
    [tenants, selectedClientId]
  );

  const [nombreLocal, setNombreLocal] = useState('');
  const [razonSocial, setRazonSocial] = useState('');
  const [rif, setRif] = useState('');
  const [direccionFiscal, setDireccionFiscal] = useState('');
  const [telefono, setTelefono] = useState('');
  const [prefijoFactura, setPrefijoFactura] = useState('FAC-');
  const [facturaActual, setFacturaActual] = useState('1');
  const [prefijoControl, setPrefijoControl] = useState('00-');
  const [controlActual, setControlActual] = useState('1');
  const [maquinaFiscal, setMaquinaFiscal] = useState('');
  const [ivaPctClient, setIvaPctClient] = useState('16');
  const [providenciaClient, setProvidenciaClient] = useState('');
  const [pieLegalClient, setPieLegalClient] = useState('');
  const [savingClient, setSavingClient] = useState(false);

  useEffect(() => {
    setModoFiscalGlobal(platformConfig.seniat_legal_activo === true);
    setGlobalPrefijoFactura(platformConfig.seniat_prefijo_factura || 'FAC-');
    setGlobalPrefijoControl(platformConfig.seniat_prefijo_control || '00-');
    setGlobalIvaPct(
      typeof platformConfig.seniat_iva_porcentaje === 'number'
        ? String(platformConfig.seniat_iva_porcentaje)
        : '16'
    );
    setGlobalProvidencia(platformConfig.seniat_providencia || DEFAULT_PROVIDENCIA);
    setGlobalPieLegal(platformConfig.seniat_pie_legal || DEFAULT_PIE_LEGAL);
  }, [platformConfig]);

  useEffect(() => {
    if (!selectedClientId && tenants.length > 0) {
      setSelectedClientId(activeTenantId || tenants[0].id);
    }
  }, [activeTenantId, selectedClientId, tenants]);

  useEffect(() => {
    if (!selectedTenant) return;
    const sc = selectedTenant.seniat_config || {};
    setNombreLocal(selectedTenant.nombre_local || '');
    setRazonSocial(selectedTenant.razon_social || selectedTenant.nombre_local || '');
    setRif(selectedTenant.rif || '');
    setDireccionFiscal(selectedTenant.direccion_fiscal || '');
    setTelefono(selectedTenant.telefono || '');
    setPrefijoFactura(sc.prefijo_factura || platformConfig.seniat_prefijo_factura || 'FAC-');
    setFacturaActual(String(Math.max(1, Math.floor(Number(sc.factura_actual) || 1))));
    setPrefijoControl(sc.prefijo_control || platformConfig.seniat_prefijo_control || '00-');
    setControlActual(String(Math.max(1, Math.floor(Number(sc.control_actual) || 1))));
    setMaquinaFiscal(sc.maquina_fiscal || '');
    setIvaPctClient(
      typeof sc.iva_porcentaje === 'number'
        ? String(sc.iva_porcentaje)
        : typeof platformConfig.seniat_iva_porcentaje === 'number'
        ? String(platformConfig.seniat_iva_porcentaje)
        : '16'
    );
    setProvidenciaClient(sc.providencia || '');
    setPieLegalClient(sc.pie_legal || '');
  }, [
    selectedTenant,
    platformConfig.seniat_iva_porcentaje,
    platformConfig.seniat_prefijo_control,
    platformConfig.seniat_prefijo_factura,
  ]);

  const handleToggleModoFiscalInstant = async () => {
    const nextVal = !modoFiscalGlobal;
    setModoFiscalGlobal(nextVal);
    setSavingGlobal(true);
    try {
      await updatePlatformConfig({
        seniat_legal_activo: nextVal,
        seniat_providencia: globalProvidencia.trim() || DEFAULT_PROVIDENCIA,
        seniat_pie_legal: globalPieLegal.trim() || DEFAULT_PIE_LEGAL,
        seniat_prefijo_factura: globalPrefijoFactura.trim() || 'FAC-',
        seniat_prefijo_control: globalPrefijoControl.trim() || '00-',
        seniat_iva_porcentaje: Math.max(0, Math.min(30, Number(globalIvaPct) || 16)),
      });
      notifyToast(
        nextVal
          ? 'Modo Fiscal SENIAT ACTIVADO: todas las facturas incluirán respaldo legal obligatorio.'
          : 'Modo Fiscal SENIAT desactivado.',
        nextVal ? 'success' : 'info'
      );
    } finally {
      setSavingGlobal(false);
    }
  };

  const handleSaveGlobalSeniat = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingGlobal(true);
    try {
      await updatePlatformConfig({
        seniat_legal_activo: modoFiscalGlobal,
        seniat_providencia: globalProvidencia.trim() || DEFAULT_PROVIDENCIA,
        seniat_pie_legal: globalPieLegal.trim() || DEFAULT_PIE_LEGAL,
        seniat_prefijo_factura: globalPrefijoFactura.trim().slice(0, 24) || 'FAC-',
        seniat_prefijo_control: globalPrefijoControl.trim().slice(0, 24) || '00-',
        seniat_iva_porcentaje: Math.max(0, Math.min(30, Number(globalIvaPct) || 16)),
      });
      notifyToast('Parámetros globales SENIAT guardados correctamente.', 'success');
    } finally {
      setSavingGlobal(false);
    }
  };

  const handleSaveClientSeniat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTenant) return;
    setSavingClient(true);
    try {
      const seniatCfg: SeniatFiscalConfig = {
        prefijo_factura: prefijoFactura.trim().slice(0, 20) || 'FAC-',
        factura_actual: Math.max(1, Math.floor(Number(facturaActual) || 1)),
        prefijo_control: prefijoControl.trim().slice(0, 20) || '00-',
        control_actual: Math.max(1, Math.floor(Number(controlActual) || 1)),
        maquina_fiscal: maquinaFiscal.trim().slice(0, 60),
        iva_porcentaje: Math.max(0, Math.min(30, Number(ivaPctClient) || 16)),
        providencia: providenciaClient.trim().slice(0, 200),
        pie_legal: pieLegalClient.trim().slice(0, 320),
      };
      await updateTenantRecord(selectedTenant.id, {
        nombre_local: nombreLocal.trim() || selectedTenant.nombre_local,
        razon_social: razonSocial.trim() || nombreLocal.trim() || selectedTenant.nombre_local,
        rif: rif.trim().toUpperCase(),
        direccion_fiscal: direccionFiscal.trim(),
        telefono: telefono.trim(),
        seniat_config: seniatCfg,
      });
      notifyToast(
        `Datos fiscales y numeración SENIAT actualizados para "${nombreLocal.trim() || selectedTenant.nombre_local}".`,
        'success'
      );
    } finally {
      setSavingClient(false);
    }
  };

  const previewFacturaNum = `${(prefijoFactura || 'FAC-').trim()}${String(
    Math.max(1, Math.floor(Number(facturaActual) || 1))
  ).padStart(8, '0')}`;
  const previewControlNum = `${(prefijoControl || '00-').trim()}${String(
    Math.max(1, Math.floor(Number(controlActual) || 1))
  ).padStart(8, '0')}`;
  const previewProvidencia = providenciaClient.trim() || globalProvidencia.trim() || DEFAULT_PROVIDENCIA;
  const previewPie = pieLegalClient.trim() || globalPieLegal.trim() || DEFAULT_PIE_LEGAL;
  const previewIva = Math.max(0, Math.min(30, Number(ivaPctClient) || 16));

  return (
    <div className="space-y-5">
      {/* Global Modo Fiscal Master Banner */}
      <div
        className={`rounded-2xl border p-5 shadow-sm transition-colors ${
          modoFiscalGlobal
            ? 'bg-emerald-50/90 border-emerald-300'
            : 'bg-amber-50/90 border-amber-300'
        }`}
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${
                modoFiscalGlobal
                  ? 'bg-emerald-600 text-white'
                  : 'bg-amber-500 text-white'
              }`}
            >
              <Scale className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-extrabold text-slate-900">
                  Modo Fiscal · Respaldo Legal SENIAT Venezuela
                </h2>
                <span
                  className={`px-2.5 py-0.5 rounded-md text-[11px] font-black uppercase tracking-wider ${
                    modoFiscalGlobal
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-200 text-amber-950'
                  }`}
                >
                  {modoFiscalGlobal ? 'MODO FISCAL ACTIVO' : 'MODO FISCAL INACTIVO'}
                </span>
              </div>
              <p className="text-xs text-slate-700 mt-1 max-w-2xl leading-relaxed">
                Al habilitar el <strong>Modo Fiscal</strong>, todas las facturas impresas (térmica
                ESC/POS 58mm/80mm, térmica HTML y PDF A4) incluirán obligatoriamente el encabezado{' '}
                <strong>SENIAT</strong>, Razón Social, RIF, Domicilio Fiscal, numeración correlativa
                de Factura y N° de Control, Máquina Fiscal/Serie, Base Imponible, IVA y Providencia
                Administrativa vigente.
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={savingGlobal}
            onClick={() => void handleToggleModoFiscalInstant()}
            className={`px-5 py-3 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2.5 shrink-0 transition cursor-pointer shadow-sm disabled:opacity-60 ${
              modoFiscalGlobal
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            {modoFiscalGlobal ? (
              <>
                <ShieldCheck className="w-4 h-4" /> Modo Fiscal Activado (Desactivar)
              </>
            ) : (
              <>
                <ShieldAlert className="w-4 h-4" /> Activar Modo Fiscal Obligatorio
              </>
            )}
          </button>
        </div>

        {/* Global SENIAT Defaults Form */}
        <form
          onSubmit={handleSaveGlobalSeniat}
          className="mt-4 pt-4 border-t border-slate-200/80 grid grid-cols-1 md:grid-cols-4 gap-3"
        >
          <div>
            <label className="text-[11px] font-bold text-slate-600 uppercase">
              Prefijo Factura Global
            </label>
            <input
              type="text"
              value={globalPrefijoFactura}
              onChange={(e) => setGlobalPrefijoFactura(e.target.value)}
              placeholder="FAC-"
              className="mt-1 w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-slate-600 uppercase">
              Prefijo N° Control Global
            </label>
            <input
              type="text"
              value={globalPrefijoControl}
              onChange={(e) => setGlobalPrefijoControl(e.target.value)}
              placeholder="00-"
              className="mt-1 w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-slate-600 uppercase">
              Alícuota IVA Base (%)
            </label>
            <input
              type="number"
              step="0.5"
              min="0"
              max="30"
              value={globalIvaPct}
              onChange={(e) => setGlobalIvaPct(e.target.value)}
              className="mt-1 w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-slate-600 uppercase">
              Providencia Administrativa
            </label>
            <input
              type="text"
              value={globalProvidencia}
              onChange={(e) => setGlobalProvidencia(e.target.value)}
              className="mt-1 w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900"
            />
          </div>
          <div className="md:col-span-3">
            <label className="text-[11px] font-bold text-slate-600 uppercase">
              Pie Legal Obligatorio Global (SENIAT)
            </label>
            <input
              type="text"
              value={globalPieLegal}
              onChange={(e) => setGlobalPieLegal(e.target.value)}
              className="mt-1 w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-900"
            />
          </div>
          <div className="flex items-end">
            <button
              type="submit"
              disabled={savingGlobal}
              className="w-full py-2 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
            >
              <Save className="w-3.5 h-3.5" />
              {savingGlobal ? 'Guardando...' : 'Guardar Globales'}
            </button>
          </div>
        </form>
      </div>

      {/* Per-Client Fiscal Parameters & Live SENIAT Receipt Preview */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
        <div className="xl:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-sky-600" />
                Parámetros Fiscales y Numeración por Comercio
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configura RIF, Razón Social, Domicilio y correlativos oficiales SENIAT de cada cliente.
              </p>
            </div>
            <select
              value={selectedTenant?.id || ''}
              onChange={(e) => setSelectedClientId(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 min-w-[210px]"
            >
              {tenants.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.nombre_local} ({t.rif || 'Sin RIF'})
                </option>
              ))}
            </select>
          </div>

          {!selectedTenant ? (
            <div className="py-12 text-center text-sm text-slate-500">
              No hay comercios registrados todavía.
            </div>
          ) : (
            <form onSubmit={handleSaveClientSeniat} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-600 uppercase">
                    Nombre Comercial *
                  </label>
                  <input
                    type="text"
                    required
                    value={nombreLocal}
                    onChange={(e) => setNombreLocal(e.target.value)}
                    className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 uppercase">
                    Razón Social Legal (SENIAT) *
                  </label>
                  <input
                    type="text"
                    required
                    value={razonSocial}
                    onChange={(e) => setRazonSocial(e.target.value)}
                    placeholder="Inversiones Ejemplo, C.A."
                    className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 uppercase">
                    RIF del Contribuyente *
                  </label>
                  <input
                    type="text"
                    required
                    value={rif}
                    onChange={(e) => setRif(e.target.value.toUpperCase())}
                    placeholder="J-12345678-9"
                    className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-extrabold text-slate-900 uppercase"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 uppercase">
                    Teléfono Fiscal
                  </label>
                  <input
                    type="text"
                    value={telefono}
                    onChange={(e) => setTelefono(e.target.value)}
                    placeholder="0412-0000000"
                    className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[11px] font-bold text-slate-600 uppercase">
                    Domicilio Fiscal Completo *
                  </label>
                  <input
                    type="text"
                    required
                    value={direccionFiscal}
                    onChange={(e) => setDireccionFiscal(e.target.value)}
                    placeholder="Av. Principal, Edif. Centro, Local PB, Municipio, Estado"
                    className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium text-slate-900"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <div className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5 mb-2.5">
                  <Hash className="w-3.5 h-3.5 text-emerald-600" />
                  Numeración Correlativa de Facturas y Control
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Prefijo Factura
                    </label>
                    <input
                      type="text"
                      value={prefijoFactura}
                      onChange={(e) => setPrefijoFactura(e.target.value)}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Próxima Factura N°
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={facturaActual}
                      onChange={(e) => setFacturaActual(e.target.value)}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Prefijo Control
                    </label>
                    <input
                      type="text"
                      value={prefijoControl}
                      onChange={(e) => setPrefijoControl(e.target.value)}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Próximo Control N°
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={controlActual}
                      onChange={(e) => setControlActual(e.target.value)}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Máquina Fiscal / Serie Imprenta Autorizada
                    </label>
                    <input
                      type="text"
                      value={maquinaFiscal}
                      onChange={(e) => setMaquinaFiscal(e.target.value.toUpperCase())}
                      placeholder="Ej: Z1B8012345 o SERIE-A"
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      IVA Aplicable (%)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="30"
                      step="0.5"
                      value={ivaPctClient}
                      onChange={(e) => setIvaPctClient(e.target.value)}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 mt-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Providencia Personalizada (opcional — deja vacío para usar la global)
                    </label>
                    <input
                      type="text"
                      value={providenciaClient}
                      onChange={(e) => setProvidenciaClient(e.target.value)}
                      placeholder={globalProvidencia}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase">
                      Pie Legal Personalizado (opcional — deja vacío para usar el global)
                    </label>
                    <input
                      type="text"
                      value={pieLegalClient}
                      onChange={(e) => setPieLegalClient(e.target.value)}
                      placeholder={globalPieLegal}
                      className="mt-1 w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <span className="text-[11px] text-slate-500 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Los correlativos avanzan automáticamente al registrar cada venta en Modo Fiscal.
                </span>
                <button
                  type="submit"
                  disabled={savingClient}
                  className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-sm disabled:opacity-60"
                >
                  <FileCheck2 className="w-4 h-4" />
                  {savingClient ? 'Guardando...' : 'Guardar Parámetros SENIAT del Cliente'}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Live Thermal Fiscal Invoice Preview */}
        <div className="xl:col-span-5 bg-slate-900 rounded-2xl p-5 text-white flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Printer className="w-4 h-4 text-sky-400" />
              <span className="text-xs font-extrabold uppercase tracking-wider text-slate-200">
                Vista Previa Factura Fiscal
              </span>
            </div>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                modoFiscalGlobal
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}
            >
              {modoFiscalGlobal ? 'Respaldo SENIAT ON' : 'Modo Estándar'}
            </span>
          </div>

          <div className="bg-white text-slate-900 rounded-xl p-4 font-mono text-[11px] leading-snug shadow-inner flex-1 max-w-[330px] mx-auto w-full border border-slate-300">
            {modoFiscalGlobal && (
              <div className="text-center font-extrabold text-[10px] border border-slate-900 py-1 px-2 mb-2 tracking-wider">
                SENIAT · FACTURA LEGAL VENEZUELA
              </div>
            )}
            <div className="text-center font-black text-sm uppercase">
              {nombreLocal || selectedTenant?.nombre_local || 'COMERCIO DEMO'}
            </div>
            {modoFiscalGlobal && razonSocial && (
              <div className="text-center font-bold text-[10.5px] text-slate-700">
                {razonSocial}
              </div>
            )}
            <div className="text-center text-[10.5px]">
              <strong>RIF:</strong> {rif || 'J-00000000-0'}
            </div>
            {direccionFiscal && (
              <div className="text-center text-[10px] text-slate-600">{direccionFiscal}</div>
            )}
            {telefono && <div className="text-center text-[10px] text-slate-600">Tel: {telefono}</div>}

            <div className="text-center font-extrabold text-xs mt-2">
              FACTURA N° {previewFacturaNum}
            </div>
            {modoFiscalGlobal && (
              <div className="text-center font-bold text-[10.5px]">
                N° DE CONTROL: {previewControlNum}
              </div>
            )}
            {modoFiscalGlobal && maquinaFiscal && (
              <div className="text-center text-[10px] text-slate-700">
                MÁQUINA FISCAL: {maquinaFiscal}
              </div>
            )}
            <div className="text-center text-[10px] text-slate-500 mt-0.5">
              {new Date().toLocaleDateString('es-VE')} · {new Date().toLocaleTimeString('es-VE')}
            </div>

            <div className="border-t border-dashed border-slate-400 my-2" />
            <div className="text-[10.5px]">Cliente: CONSUMIDOR FINAL · CI/RIF: N/A</div>
            <div className="text-[10.5px]">Método: Pago Móvil · Tasa BCV: 92,50 Bs</div>
            <div className="border-t border-dashed border-slate-400 my-2" />

            <div className="flex justify-between text-[10.5px]">
              <span>1x Producto Ejemplo</span>
              <span>925,00 Bs</span>
            </div>
            <div className="border-t border-dashed border-slate-400 my-2" />

            <div className="space-y-0.5 text-[10.5px]">
              <div className="flex justify-between">
                <span>Base Imponible (G):</span>
                <span>797,41 Bs</span>
              </div>
              <div className="flex justify-between">
                <span>IVA ({previewIva}%):</span>
                <span>127,59 Bs</span>
              </div>
              <div className="flex justify-between font-black text-xs pt-1">
                <span>TOTAL VES:</span>
                <span>925,00 Bs</span>
              </div>
              <div className="flex justify-between font-bold text-[10.5px] text-slate-700">
                <span>EQUIV. USD (BCV):</span>
                <span>$10.00</span>
              </div>
            </div>

            <div className="border-t border-dashed border-slate-400 my-2" />
            {modoFiscalGlobal ? (
              <div className="text-center space-y-1">
                <div className="font-bold text-[9.5px] text-slate-800">{previewProvidencia}</div>
                <div className="text-[9px] text-slate-600">{previewPie}</div>
              </div>
            ) : (
              <div className="text-center text-[10px] text-amber-700 font-semibold">
                Activa el Modo Fiscal para imprimir respaldo legal SENIAT obligatorio.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
