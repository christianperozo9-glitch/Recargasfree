// Android & Web Push Notifications Utility powered by Service Worker
const PUSH_PREF_KEY = 'ig_push_enabled';

export type PushPermissionState = NotificationPermission | 'unsupported';

let swRegistrationPromise: Promise<ServiceWorkerRegistration | null> | null = null;

export function isPushSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    'Notification' in window &&
    'serviceWorker' in navigator
  );
}

export function getPushPermission(): NotificationPermission | 'unsupported' {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
  return Notification.permission;
}

export function isPushPreferenceEnabled(): boolean {
  try {
    const raw = localStorage.getItem(PUSH_PREF_KEY);
    if (raw === null) return getPushPermission() === 'granted';
    return raw === '1';
  } catch {
    return getPushPermission() === 'granted';
  }
}

export function setPushPreferenceEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(PUSH_PREF_KEY, enabled ? '1' : '0');
  } catch {
    // ignore storage errors
  }
}

export async function registerPosServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return null;
  if (!swRegistrationPromise) {
    swRegistrationPromise = navigator.serviceWorker
      .register('/sw.js', { scope: '/' })
      .then((reg) => reg)
      .catch(() => null);
  }
  return swRegistrationPromise;
}

export async function requestPushPermission(): Promise<{
  ok: boolean;
  permission: NotificationPermission | 'unsupported';
  message: string;
}> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return {
      ok: false,
      permission: 'unsupported',
      message: 'Tu navegador no soporta notificaciones push nativas.',
    };
  }

  await registerPosServiceWorker();

  let permission = Notification.permission;
  if (permission === 'default') {
    try {
      permission = await Notification.requestPermission();
    } catch {
      permission = 'denied';
    }
  }

  if (permission === 'granted') {
    setPushPreferenceEnabled(true);
    return {
      ok: true,
      permission,
      message: 'Notificaciones push activadas para Android y Web.',
    };
  }

  setPushPreferenceEnabled(false);
  return {
    ok: false,
    permission,
    message:
      permission === 'denied'
        ? 'Permiso bloqueado en el navegador. Habilita las notificaciones en la configuración del sitio.'
        : 'Permiso de notificaciones no concedido.',
  };
}

export async function sendSystemPushNotification(params: {
  title: string;
  body: string;
  tag?: string;
  url?: string;
  force?: boolean;
  requireInteraction?: boolean;
}): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) return false;
  if (Notification.permission !== 'granted') return false;
  if (!params.force && !isPushPreferenceEnabled()) return false;

  const title = params.title || 'Innova Grup POS';
  const body = params.body || '';
  const tag = params.tag || `innova_pos_${Date.now()}`;
  const url = params.url || '/';

  try {
    const reg =
      (await registerPosServiceWorker()) ||
      (await navigator.serviceWorker?.getRegistration?.('/')) ||
      null;

    if (reg && typeof reg.showNotification === 'function') {
      await reg.showNotification(title, {
        body,
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        tag,
        data: { url },
      });
      return true;
    }

    if (reg?.active) {
      reg.active.postMessage({
        type: 'SHOW_NOTIFICATION',
        title,
        body,
        tag,
        url,
      });
      return true;
    }
  } catch {
    // Fallback to direct Notification API below
  }

  try {
    new Notification(title, {
      body,
      icon: '/pwa-192x192.png',
      tag,
    });
    return true;
  } catch {
    return false;
  }
}
