import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  BarChart3,
  Building2,
  Calendar,
  Loader2,
  RefreshCw,
  Store,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { db } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import type { CierreRecord, SaleTransaction } from '../types/pos';
import { formatMoney, round2 } from '../utils/format';

interface DayBucket {
  dateKey: string;
  label: string;
  fullDate: string;
  usd: number;
  ves: number;
  txCount: number;
  isToday: boolean;
}

type ScopeMode = 'active' | 'global';
type CurrencyMode = 'usd' | 'ves';

function toLocalDateKey(ts: number): string {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`;
}

function buildEmpty7Days(): { buckets: DayBucket[]; map: Map<string, DayBucket>; startTs: number } {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const buckets: DayBucket[] = [];
  const map = new Map<string, DayBucket>();

  for (let offset = 6; offset >= 0; offset--) {
    const d = new Date(todayStart.getTime() - offset * 86_400_000);
    const key = toLocalDateKey(d.getTime());
    const weekday = d
      .toLocaleDateString('es-VE', { weekday: 'short' })
      .replace('.', '')
      .slice(0, 3);
    const dayNum = String(d.getDate()).padStart(2, '0');
    const isToday = offset === 0;
    const label = isToday
      ? 'Hoy'
      : `${weekday.charAt(0).toUpperCase()}${weekday.slice(1)} ${dayNum}`;
    const fullDate = d.toLocaleDateString('es-VE', {
      weekday: 'long',
      day: '2-digit',
      month: 'short',
    });

    const bucket: DayBucket = {
      dateKey: key,
      label,
      fullDate: fullDate.charAt(0).toUpperCase() + fullDate.slice(1),
      usd: 0,
      ves: 0,
      txCount: 0,
      isToday,
    };
    buckets.push(bucket);
    map.set(key, bucket);
  }

  return {
    buckets,
    map,
    startTs: todayStart.getTime() - 6 * 86_400_000,
  };
}

export const OwnerDailySalesChart: React.FC = () => {
  const { activeTenant, tenants, liveSales, savedCierres } = usePos();

  const [scope, setScope] = useState<ScopeMode>(activeTenant ? 'active' : 'global');
  const [currency, setCurrency] = useState<CurrencyMode>('usd');
  const [globalLoading, setGlobalLoading] = useState(false);
  const [globalError, setGlobalError] = useState('');
  const [globalData, setGlobalData] = useState<DayBucket[] | null>(null);
  const [globalStoresLoaded, setGlobalStoresLoaded] = useState(0);

  // If no active tenant is selected, default to global scope
  useEffect(() => {
    if (!activeTenant && scope === 'active') {
      setScope('global');
    }
  }, [activeTenant, scope]);

  // Compute last 7 days from active tenant's real-time liveSales + savedCierres
  const active7Days = useMemo(() => {
    const { buckets, map, startTs } = buildEmpty7Days();

    liveSales.forEach((sale) => {
      const ts = Number(sale.timestamp) || 0;
      if (ts < startTs) return;
      const bucket = map.get(toLocalDateKey(ts));
      if (!bucket) return;
      bucket.usd = round2(bucket.usd + (Number(sale.monto_total_usd_bcv) || 0));
      bucket.ves = round2(bucket.ves + (Number(sale.monto_total_ves) || 0));
      bucket.txCount += 1;
    });

    savedCierres.forEach((cierre) => {
      const ts = Number(cierre.timestamp) || 0;
      if (ts < startTs) return;
      const bucket = map.get(toLocalDateKey(ts));
      if (!bucket) return;
      bucket.usd = round2(bucket.usd + (Number(cierre.total_general_usd) || 0));
      bucket.ves = round2(bucket.ves + (Number(cierre.total_general_ves) || 0));
      bucket.txCount += Number(cierre.cantidad_ventas) || 0;
    });

    return buckets;
  }, [liveSales, savedCierres]);

  // Fetch & aggregate last 7 days across all registered tenants when Global scope is active
  const loadGlobal7Days = useCallback(async () => {
    if (tenants.length === 0) {
      setGlobalData(buildEmpty7Days().buckets);
      setGlobalStoresLoaded(0);
      return;
    }
    setGlobalLoading(true);
    setGlobalError('');
    try {
      const { buckets, map, startTs } = buildEmpty7Days();
      const targetTenants = tenants.slice(0, 40);
      let loadedCount = 0;

      await Promise.all(
        targetTenants.map(async (tenant) => {
          try {
            const [salesSnap, closuresSnap] = await Promise.all([
              getDocs(
                query(
                  collection(db, 'tenants', tenant.id, 'sales'),
                  where('timestamp', '>=', startTs)
                )
              ),
              getDocs(
                query(
                  collection(db, 'tenants', tenant.id, 'closures'),
                  where('timestamp', '>=', startTs)
                )
              ),
            ]);

            salesSnap.forEach((d) => {
              const s = d.data() as SaleTransaction;
              const ts = Number(s.timestamp) || 0;
              const bucket = map.get(toLocalDateKey(ts));
              if (!bucket) return;
              bucket.usd = round2(bucket.usd + (Number(s.monto_total_usd_bcv) || 0));
              bucket.ves = round2(bucket.ves + (Number(s.monto_total_ves) || 0));
              bucket.txCount += 1;
            });

            closuresSnap.forEach((d) => {
              const c = d.data() as CierreRecord;
              const ts = Number(c.timestamp) || 0;
              const bucket = map.get(toLocalDateKey(ts));
              if (!bucket) return;
              bucket.usd = round2(bucket.usd + (Number(c.total_general_usd) || 0));
              bucket.ves = round2(bucket.ves + (Number(c.total_general_ves) || 0));
              bucket.txCount += Number(c.cantidad_ventas) || 0;
            });

            loadedCount += 1;
          } catch {
            // Skip any tenant node that fails individually without breaking the chart
          }
        })
      );

      setGlobalStoresLoaded(loadedCount);
      setGlobalData(buckets);
    } catch {
      setGlobalError('No se pudieron cargar las ventas consolidadas de los últimos 7 días.');
    } finally {
      setGlobalLoading(false);
    }
  }, [tenants]);

  useEffect(() => {
    if (scope === 'global') {
      void loadGlobal7Days();
    }
  }, [scope, loadGlobal7Days]);

  const chartData = useMemo(() => {
    if (scope === 'global') {
      return globalData || buildEmpty7Days().buckets;
    }
    return active7Days;
  }, [scope, globalData, active7Days]);

  const metrics = useMemo(() => {
    const valOf = (b: DayBucket) => (currency === 'usd' ? b.usd : b.ves);
    const total = round2(chartData.reduce((acc, b) => acc + valOf(b), 0));
    const avg = round2(total / 7);
    const totalTx = chartData.reduce((acc, b) => acc + b.txCount, 0);

    let peak = chartData[0] || null;
    chartData.forEach((b) => {
      if (!peak || valOf(b) > valOf(peak)) peak = b;
    });

    // Compare recent 3 days vs previous 3 days to indicate revenue trend
    const prev3 = chartData.slice(1, 4).reduce((acc, b) => acc + valOf(b), 0);
    const last3 = chartData.slice(4, 7).reduce((acc, b) => acc + valOf(b), 0);
    let trendPct: number | null = null;
    if (prev3 > 0) {
      trendPct = round2(((last3 - prev3) / prev3) * 100);
    } else if (last3 > 0) {
      trendPct = 100;
    }

    return {
      total,
      avg,
      totalTx,
      peak,
      peakVal: peak ? valOf(peak) : 0,
      trendPct,
      hasSales: total > 0 || totalTx > 0,
    };
  }, [chartData, currency]);

  const formatMetric = (val: number) =>
    currency === 'usd' ? `$${formatMoney(val)}` : `Bs. ${formatMoney(val)}`;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-6 space-y-5">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-200 text-sky-600 flex items-center justify-center shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 tracking-tight">
              Ventas Diarias — Últimos 7 Días
            </h3>
            <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              {scope === 'active' && activeTenant
                ? `Tendencia de ingresos de ${activeTenant.nombre_local}`
                : `Consolidado global (${globalStoresLoaded || tenants.length} comercio${
                    (globalStoresLoaded || tenants.length) === 1 ? '' : 's'
                  })`}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Scope Switcher */}
          {activeTenant && (
            <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200 text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setScope('active')}
                className={`px-2.5 py-1.5 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                  scope === 'active'
                    ? 'bg-white text-sky-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Store className="w-3.5 h-3.5" /> Comercio activo
              </button>
              <button
                type="button"
                onClick={() => setScope('global')}
                className={`px-2.5 py-1.5 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                  scope === 'global'
                    ? 'bg-white text-sky-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" /> Todos
              </button>
            </div>
          )}

          {/* Currency Switcher */}
          <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200 text-[11px] font-bold">
            <button
              type="button"
              onClick={() => setCurrency('usd')}
              className={`px-2.5 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer ${
                currency === 'usd'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              USD ($)
            </button>
            <button
              type="button"
              onClick={() => setCurrency('ves')}
              className={`px-2.5 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer ${
                currency === 'ves'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Bs.
            </button>
          </div>

          {scope === 'global' && (
            <button
              type="button"
              disabled={globalLoading}
              onClick={() => void loadGlobal7Days()}
              title="Actualizar consolidado de 7 días"
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 transition cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${globalLoading ? 'animate-spin' : ''}`} />
            </button>
          )}
        </div>
      </div>

      {/* Single-Elevation Tabular KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 border-y border-slate-100 py-3.5">
        <div className="px-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Ingresos (7 días)
          </p>
          <div className="mt-1 flex items-baseline gap-2 flex-wrap">
            <span className="text-xl sm:text-2xl font-extrabold font-mono tabular-nums text-slate-950">
              {formatMetric(metrics.total)}
            </span>
            {metrics.trendPct !== null && (
              <span
                className={`inline-flex items-center gap-0.5 text-[11px] font-extrabold font-mono tabular-nums ${
                  metrics.trendPct >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {metrics.trendPct >= 0 ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5" />
                )}
                {metrics.trendPct >= 0 ? '+' : ''}
                {metrics.trendPct}%
              </span>
            )}
          </div>
        </div>

        <div className="px-1 sm:border-l sm:border-slate-100 sm:pl-4">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Promedio Diario
          </p>
          <p className="mt-1 text-xl sm:text-2xl font-extrabold font-mono tabular-nums text-slate-900">
            {formatMetric(metrics.avg)}
          </p>
        </div>

        <div className="px-1 sm:border-l sm:border-slate-100 sm:pl-4">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Día Pico · Transacciones
          </p>
          <p className="mt-1 text-sm sm:text-base font-extrabold text-slate-900 tabular-nums">
            {metrics.peak && metrics.peakVal > 0 ? (
              <>
                <span>{metrics.peak.label}</span>{' '}
                <span className="font-mono text-sky-700">({formatMetric(metrics.peakVal)})</span>
              </>
            ) : (
              <span className="text-slate-400 font-semibold">Sin registros</span>
            )}
          </p>
          <p className="text-[11px] font-mono tabular-nums text-slate-500 mt-0.5">
            {metrics.totalTx} venta{metrics.totalTx === 1 ? '' : 's'} en los últimos 7 días
          </p>
        </div>
      </div>

      {globalError && (
        <div className="text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2.5">
          {globalError}
        </div>
      )}

      {/* Recharts 7-Day Daily Sales BarChart */}
      <div className="relative w-full h-[270px]">
        {scope === 'global' && globalLoading ? (
          <div className="h-full flex flex-col items-center justify-center gap-2 text-xs font-semibold text-slate-500">
            <Loader2 className="w-6 h-6 animate-spin text-sky-600" />
            Calculando ingresos consolidados de los últimos 7 días...
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 12, right: 12, left: 4, bottom: 4 }}
              barCategoryGap="24%"
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis
                dataKey="label"
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#475569', fontSize: 12, fontWeight: 600 }}
                dy={6}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                width={currency === 'usd' ? 58 : 74}
                tick={{ fill: '#64748b', fontSize: 11, fontFamily: 'monospace' }}
                tickFormatter={(v: number) =>
                  currency === 'usd'
                    ? `$${v >= 1000 ? `${(v / 1000).toFixed(1)}k` : v}`
                    : `${v >= 1000 ? `${(v / 1000).toFixed(1)}k` : v}`
                }
              />
              <Tooltip
                cursor={{ fill: 'rgba(14, 165, 233, 0.08)', radius: 8 }}
                content={({ active, payload }) => {
                  if (!active || !payload || payload.length === 0) return null;
                  const point = payload[0].payload as DayBucket;
                  return (
                    <div className="bg-slate-950 text-white rounded-xl border border-slate-800 px-3.5 py-2.5 shadow-xl text-xs space-y-1">
                      <p className="font-extrabold text-sky-300">{point.fullDate}</p>
                      <div className="flex items-center justify-between gap-5 font-mono tabular-nums">
                        <span className="text-slate-300">Ingresos USD:</span>
                        <span className="font-bold text-white">${formatMoney(point.usd)}</span>
                      </div>
                      <div className="flex items-center justify-between gap-5 font-mono tabular-nums">
                        <span className="text-slate-300">Ingresos Bs.:</span>
                        <span className="font-bold text-emerald-300">
                          Bs. {formatMoney(point.ves)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-5 font-mono tabular-nums pt-1 border-t border-slate-800">
                        <span className="text-slate-400">Transacciones:</span>
                        <span className="font-bold text-sky-200">{point.txCount}</span>
                      </div>
                    </div>
                  );
                }}
              />
              <Bar
                dataKey={currency}
                name={currency === 'usd' ? 'Ingresos USD' : 'Ingresos Bs.'}
                radius={[8, 8, 0, 0]}
                maxBarSize={48}
              >
                {chartData.map((entry) => {
                  const isPeak =
                    metrics.peakVal > 0 &&
                    (currency === 'usd' ? entry.usd : entry.ves) === metrics.peakVal;
                  const fill = entry.isToday
                    ? '#059669'
                    : isPeak
                    ? '#0284c7'
                    : '#38bdf8';
                  return <Cell key={entry.dateKey} fill={fill} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {!metrics.hasSales && !globalLoading && (
        <p className="text-xs text-slate-500 text-center pt-1">
          Aún no se registran ventas en los últimos 7 días para esta vista. Las barras se actualizarán
          automáticamente al emitir nuevas facturas o cierres de caja.
        </p>
      )}
    </div>
  );
};
