import React from 'react';

export interface CasheaLevelPreset {
  id: string;
  label: string;
  shortLabel: string;
  inicialPct: number;
  hint: string;
}

export const CASHEA_LEVEL_PRESETS: CasheaLevelPreset[] = [
  { id: 'manual', label: 'Manual (Libre)', shortLabel: 'Manual', inicialPct: 0, hint: 'Escribe la inicial directamente' },
  { id: 'nivel1', label: 'Nivel 1 · Inicial 60%', shortLabel: 'Nivel 1 (60%)', inicialPct: 60, hint: 'Financia 40%' },
  { id: 'nivel2', label: 'Nivel 2 · Inicial 50%', shortLabel: 'Nivel 2 (50%)', inicialPct: 50, hint: 'Financia 50%' },
  { id: 'nivel3', label: 'Nivel 3 · Inicial 40%', shortLabel: 'Nivel 3 (40%)', inicialPct: 40, hint: 'Financia 60%' },
  { id: 'nivel4', label: 'Nivel 4 · Inicial 35%', shortLabel: 'Nivel 4 (35%)', inicialPct: 35, hint: 'Financia 65%' },
  { id: 'nivel5', label: 'Nivel 5 · Inicial 25%', shortLabel: 'Nivel 5 (25%)', inicialPct: 25, hint: 'Financia 75%' },
  { id: 'nivel6', label: 'Nivel 6 · Inicial 20%', shortLabel: 'Nivel 6 (20%)', inicialPct: 20, hint: 'Financia 80%' },
];

export const CasheaLogo: React.FC<{ size?: number; showWordmark?: boolean; darkText?: boolean }> = ({
  size = 24,
  showWordmark = false,
  darkText = true,
}) => (
  <span className="inline-flex items-center gap-1.5 shrink-0 select-none">
    <svg
      width={size}
      height={size}
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect width="36" height="36" rx="9" fill="#FFDD00" />
      <path
        d="M23.8 13.1C22.4 11.4 20.4 10.4 18.1 10.4C13.8 10.4 10.5 13.7 10.5 18C10.5 22.3 13.8 25.6 18.1 25.6C20.5 25.6 22.6 24.5 24 22.7"
        stroke="#111827"
        strokeWidth="3.6"
        strokeLinecap="round"
      />
      <circle cx="25.5" cy="18" r="2.2" fill="#111827" />
    </svg>
    {showWordmark && (
      <span
        className={`font-extrabold tracking-tight text-sm leading-none ${
          darkText ? 'text-slate-900' : 'text-white'
        }`}
      >
        cashea
      </span>
    )}
  </span>
);
