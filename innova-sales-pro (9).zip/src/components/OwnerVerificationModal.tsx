import React, { useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import {
  Camera,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Eye,
  FileWarning,
  Plus,
  Save,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  X,
  XCircle,
} from 'lucide-react';
import { db } from '../lib/firebase';
import type {
  CustomVerificationRequirement,
  TenantRecord,
  VerificationDocRecord,
  VerificationDocStatus,
  VerificationRequestConfig,
  VerificationRequirementKey,
} from '../types/pos';
import {
  buildDefaultVerificationRequisitos,
  VERIFICATION_REQUIREMENTS,
} from '../constants/verificationRequirements';

interface OwnerVerificationModalProps {
  client: TenantRecord;
  onClose: () => void;
  onSaveConfig: (
    tenantId: string,
    cfg: VerificationRequestConfig,
    notifyClient?: boolean
  ) => Promise<void>;
  onReviewDoc: (
    tenantId: string,
    reqId: string,
    estado: VerificationDocStatus,
    notaPropietario?: string
  ) => Promise<void>;
  onNotify: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

interface UnifiedReqItem {
  key: string;
  label: string;
  description: string;
  requiereFoto: boolean;
  isCustom: boolean;
}

export const OwnerVerificationModal: React.FC<OwnerVerificationModalProps> = ({
  client,
  onClose,
  onSaveConfig,
  onReviewDoc,
  onNotify,
}) => {
  const existingCfg = client.verificacion_datos || null;

  const [activo, setActivo] = useState<boolean>(existingCfg?.activo === true);
  const [mensaje, setMensaje] = useState<string>(
    existingCfg?.mensaje ||
      'Por seguridad y cumplimiento normativo, requerimos actualizar y verificar los documentos seleccionados de tu comercio.'
  );
  const [requisitos, setRequisitos] = useState<Record<VerificationRequirementKey, boolean>>(() => ({
    ...buildDefaultVerificationRequisitos(),
    ...(existingCfg?.requisitos || {}),
  }));
  const [requisitosFoto, setRequisitosFoto] = useState<Record<string, boolean>>(() => {
    const base: Record<string, boolean> = {};
    VERIFICATION_REQUIREMENTS.forEach((r) => {
      base[r.key] = existingCfg?.requisitos_foto?.[r.key] !== false;
    });
    return { ...base, ...(existingCfg?.requisitos_foto || {}) };
  });
  const [customReqs, setCustomReqs] = useState<CustomVerificationRequirement[]>(() =>
    Array.isArray(existingCfg?.requisitos_personalizados)
      ? existingCfg.requisitos_personalizados
      : []
  );

  // Add custom requirement form
  const [newCustomLabel, setNewCustomLabel] = useState('');
  const [newCustomDesc, setNewCustomDesc] = useState('');
  const [newCustomPhoto, setNewCustomPhoto] = useState(true);

  const [docs, setDocs] = useState<Record<string, VerificationDocRecord>>({});
  const [rejectionNotes, setRejectionNotes] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [reviewingKey, setReviewingKey] = useState<string | null>(null);
  const [zoomImage, setZoomImage] = useState<{ src: string; title: string } | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'tenants', client.id, 'verification_docs'),
      (snap) => {
        const map: Record<string, VerificationDocRecord> = {};
        snap.docs.forEach((d) => {
          const data = d.data() as Omit<VerificationDocRecord, 'key'>;
          map[d.id] = {
            ...data,
            key: d.id,
            req_id: data.req_id || d.id,
          };
        });
        setDocs(map);
      },
      () => {
        // ignore empty subcollection error
      }
    );
    return () => unsub();
  }, [client.id]);

  const activeReqList = useMemo<UnifiedReqItem[]>(() => {
    const presets: UnifiedReqItem[] = VERIFICATION_REQUIREMENTS.filter((r) =>
      Boolean(requisitos[r.key])
    ).map((r) => ({
      key: r.key,
      label: r.label,
      description: r.description,
      requiereFoto: requisitosFoto[r.key] !== false,
      isCustom: false,
    }));

    const customs: UnifiedReqItem[] = customReqs
      .filter((c) => c.activo !== false)
      .map((c) => ({
        key: c.id,
        label: c.label,
        description: c.description || 'Requisito personalizado solicitado por el propietario.',
        requiereFoto: c.requiere_foto !== false,
        isCustom: true,
      }));

    return [...presets, ...customs];
  }, [requisitos, requisitosFoto, customReqs]);

  const stats = useMemo(() => {
    let verificado = 0;
    let enRevision = 0;
    let rechazado = 0;
    let pendiente = 0;
    activeReqList.forEach((r) => {
      const st = docs[r.key]?.estado || 'pendiente';
      if (st === 'verificado') verificado += 1;
      else if (st === 'en_revision') enRevision += 1;
      else if (st === 'rechazado') rechazado += 1;
      else pendiente += 1;
    });
    return { verificado, enRevision, rechazado, pendiente, total: activeReqList.length };
  }, [activeReqList, docs]);

  const toggleReq = (key: VerificationRequirementKey) => {
    setRequisitos((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const togglePresetPhoto = (key: VerificationRequirementKey) => {
    setRequisitosFoto((prev) => ({ ...prev, [key]: prev[key] === false ? true : false }));
  };

  const setAllReqs = (val: boolean) => {
    const next = {} as Record<VerificationRequirementKey, boolean>;
    VERIFICATION_REQUIREMENTS.forEach((r) => {
      next[r.key] = val;
    });
    setRequisitos(next);
    setCustomReqs((prev) => prev.map((c) => ({ ...c, activo: val })));
  };

  const handleAddCustomRequirement = () => {
    const cleanLabel = newCustomLabel.trim();
    if (!cleanLabel) {
      onNotify('Escribe el nombre del requisito que deseas solicitar al cliente.', 'warning');
      return;
    }
    const slug = cleanLabel
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 32);
    const id = `custom_${slug || 'req'}_${Date.now().toString(36)}`;
    const nextItem: CustomVerificationRequirement = {
      id,
      label: cleanLabel,
      description: newCustomDesc.trim() || 'Adjunta la información o fotografía solicitada.',
      requiere_foto: newCustomPhoto,
      activo: true,
    };
    setCustomReqs((prev) => [...prev, nextItem]);
    setRequisitosFoto((prev) => ({ ...prev, [id]: newCustomPhoto }));
    setNewCustomLabel('');
    setNewCustomDesc('');
    setNewCustomPhoto(true);
    onNotify(`Requisito "${cleanLabel}" agregado. Recuerda guardar para notificar al cliente.`, 'info');
  };

  const toggleCustomActive = (id: string) => {
    setCustomReqs((prev) => prev.map((c) => (c.id === id ? { ...c, activo: !c.activo } : c)));
  };

  const toggleCustomPhoto = (id: string) => {
    setCustomReqs((prev) =>
      prev.map((c) => (c.id === id ? { ...c, requiere_foto: !c.requiere_foto } : c))
    );
    setRequisitosFoto((prev) => ({ ...prev, [id]: prev[id] === false ? true : false }));
  };

  const removeCustomReq = (id: string) => {
    setCustomReqs((prev) => prev.filter((c) => c.id !== id));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (activo && activeReqList.length === 0) {
      onNotify('Activa al menos un requisito para solicitar la verificación al cliente.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const mergedPhotoFlags: Record<string, boolean> = { ...requisitosFoto };
      customReqs.forEach((c) => {
        mergedPhotoFlags[c.id] = c.requiere_foto !== false;
      });
      await onSaveConfig(
        client.id,
        {
          activo,
          mensaje: mensaje.trim(),
          requisitos,
          requisitos_foto: mergedPhotoFlags,
          requisitos_personalizados: customReqs,
          activado_en: activo ? Date.now() : existingCfg?.activado_en || 0,
          updatedAt: Date.now(),
        },
        activo
      );
      onNotify(
        activo
          ? `Verificación activada para ${client.nombre_local}. Alerta y notificación enviadas de inmediato.`
          : `Solicitud de verificación desactivada para ${client.nombre_local}.`,
        'success'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleReview = async (reqId: string, estado: 'verificado' | 'rechazado') => {
    const note = (rejectionNotes[reqId] || '').trim();
    if (estado === 'rechazado' && !note) {
      onNotify(
        'Escribe brevemente el motivo del rechazo para que el cliente sepa qué corregir.',
        'warning'
      );
      return;
    }
    setReviewingKey(reqId);
    try {
      await onReviewDoc(client.id, reqId, estado, estado === 'rechazado' ? note : '');
      onNotify(
        estado === 'verificado'
          ? 'Documento marcado como VERIFICADO.'
          : 'Documento marcado como RECHAZADO y notificado al cliente.',
        estado === 'verificado' ? 'success' : 'warning'
      );
    } finally {
      setReviewingKey(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[185] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4">
      <div className="bg-white rounded-3xl border border-slate-200 max-w-5xl w-full max-h-[94vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-amber-50 via-white to-sky-50 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
                Actualización y Verificación de Datos · {client.nombre_local}
              </h3>
              <p className="text-xs text-slate-500 truncate">
                Solicita cualquier requisito, activa el envío de foto y aprueba o rechaza cada recaudo
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer shrink-0"
            aria-label="Cerrar verificador"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          {/* Left: Activation & Requirement Selection */}
          <form onSubmit={handleSave} className="lg:col-span-5 p-4 sm:p-5 space-y-4 text-xs">
            {/* Master Toggle */}
            <div
              className={`p-4 rounded-2xl border transition-colors ${
                activo ? 'bg-amber-50/80 border-amber-300' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                    {activo ? (
                      <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                    ) : (
                      <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                    Solicitud de Actualización de Datos
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    {activo
                      ? 'ACTIVA: Aparece alerta fija en el cliente y se habilita el envío de fotos/documentos.'
                      : 'Desactivada: El cliente opera normalmente sin solicitud pendiente.'}
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={activo}
                  onClick={() => setActivo((v) => !v)}
                  className={`relative inline-flex h-7 w-13 shrink-0 items-center rounded-full transition-colors cursor-pointer ${
                    activo ? 'bg-amber-500' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform ${
                      activo ? 'translate-x-7' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Custom message */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Mensaje de Alerta / Instrucción para el Cliente
              </label>
              <textarea
                rows={2}
                value={mensaje}
                onChange={(e) => setMensaje(e.target.value)}
                maxLength={300}
                placeholder="Indica plazo o instrucción para subir los documentos..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl resize-none"
              />
            </div>

            {/* Add ANY Custom Requirement */}
            <div className="p-3 rounded-2xl bg-indigo-50/60 border border-indigo-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-indigo-950 text-[11px] uppercase tracking-wide">
                  + Solicitar Cualquier Requisito Personalizado
                </span>
              </div>
              <input
                type="text"
                value={newCustomLabel}
                onChange={(e) => setNewCustomLabel(e.target.value)}
                placeholder="Ej: Patente de Industria y Comercio, Cédula de Socio, Foto del Local..."
                maxLength={100}
                className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-xl text-xs"
              />
              <input
                type="text"
                value={newCustomDesc}
                onChange={(e) => setNewCustomDesc(e.target.value)}
                placeholder="Instrucción breve (opcional)..."
                maxLength={220}
                className="w-full px-3 py-1.5 bg-white border border-indigo-100 rounded-xl text-[11px]"
              />
              <div className="flex items-center justify-between gap-2 pt-0.5">
                <label className="inline-flex items-center gap-1.5 text-[11px] font-bold text-indigo-900 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newCustomPhoto}
                    onChange={(e) => setNewCustomPhoto(e.target.checked)}
                    className="w-3.5 h-3.5 accent-indigo-600"
                  />
                  <Camera className="w-3.5 h-3.5 text-indigo-600" />
                  Solicitar foto al cliente
                </label>
                <button
                  type="button"
                  onClick={handleAddCustomRequirement}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] inline-flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Agregar
                </button>
              </div>
            </div>

            {/* Requirements Selector */}
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="font-bold text-slate-800">
                  Requisitos Activos ({activeReqList.length})
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setAllReqs(true)}
                    className="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 font-semibold text-[11px] cursor-pointer"
                  >
                    Todos
                  </button>
                  <button
                    type="button"
                    onClick={() => setAllReqs(false)}
                    className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold text-[11px] cursor-pointer"
                  >
                    Ninguno
                  </button>
                </div>
              </div>

              <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
                {/* Custom requirements list */}
                {customReqs.map((creq) => {
                  const uploaded = docs[creq.id];
                  return (
                    <div
                      key={creq.id}
                      className={`p-2.5 rounded-xl border transition-colors space-y-1.5 ${
                        creq.activo
                          ? 'bg-indigo-50/60 border-indigo-200'
                          : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <input
                          type="checkbox"
                          checked={creq.activo !== false}
                          onChange={() => toggleCustomActive(creq.id)}
                          className="mt-0.5 w-4 h-4 accent-indigo-600 shrink-0 cursor-pointer"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-slate-900">
                              {creq.label}{' '}
                              <span className="text-[10px] font-extrabold text-indigo-700">
                                · Personalizado
                              </span>
                            </span>
                            <button
                              type="button"
                              onClick={() => removeCustomReq(creq.id)}
                              className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                              title="Eliminar requisito personalizado"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          {creq.description && (
                            <p className="text-[11px] text-slate-500 leading-snug">
                              {creq.description}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="pl-6 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => toggleCustomPhoto(creq.id)}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer border ${
                            creq.requiere_foto !== false
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                              : 'bg-slate-100 border-slate-200 text-slate-500'
                          }`}
                        >
                          <Camera className="w-3 h-3" />
                          {creq.requiere_foto !== false ? 'Foto requerida: SÍ' : 'Foto: Opcional'}
                        </button>
                        {uploaded && (
                          <span
                            className={`text-[10px] font-bold uppercase ${
                              uploaded.estado === 'verificado'
                                ? 'text-emerald-700'
                                : uploaded.estado === 'rechazado'
                                ? 'text-rose-700'
                                : 'text-amber-700'
                            }`}
                          >
                            {uploaded.estado === 'en_revision' ? 'En revisión' : uploaded.estado}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}

                {/* Preset requirements */}
                {VERIFICATION_REQUIREMENTS.map((req) => {
                  const enabled = Boolean(requisitos[req.key]);
                  const photoReq = requisitosFoto[req.key] !== false;
                  const uploaded = docs[req.key];
                  return (
                    <div
                      key={req.key}
                      className={`p-2.5 rounded-xl border transition-colors space-y-1.5 ${
                        enabled
                          ? 'bg-sky-50/70 border-sky-200'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <label className="flex items-start gap-2.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={enabled}
                          onChange={() => toggleReq(req.key)}
                          className="mt-0.5 w-4 h-4 accent-sky-600 shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-slate-900">{req.label}</span>
                            {uploaded && (
                              <span
                                className={`text-[10px] font-bold uppercase ${
                                  uploaded.estado === 'verificado'
                                    ? 'text-emerald-700'
                                    : uploaded.estado === 'rechazado'
                                    ? 'text-rose-700'
                                    : 'text-amber-700'
                                }`}
                              >
                                {uploaded.estado === 'en_revision'
                                  ? 'En revisión'
                                  : uploaded.estado}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                            {req.description}
                          </p>
                        </div>
                      </label>
                      {enabled && (
                        <div className="pl-6">
                          <button
                            type="button"
                            onClick={() => togglePresetPhoto(req.key)}
                            className={`px-2 py-0.5 rounded-lg text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer border ${
                              photoReq
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                                : 'bg-slate-100 border-slate-200 text-slate-500'
                            }`}
                          >
                            <Camera className="w-3 h-3" />
                            {photoReq ? 'Solicitar foto: ACTIVADO' : 'Solicitar foto: Opcional'}
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 text-white font-bold inline-flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <Save className="w-4 h-4" />
              {saving
                ? 'Guardando y notificando...'
                : activo
                ? 'Guardar y Enviar Alerta al Cliente'
                : 'Guardar Configuración (Desactivada)'}
            </button>
          </form>

          {/* Right: Live Uploaded Documents Review Panel */}
          <div className="lg:col-span-7 p-4 sm:p-5 bg-slate-50/60 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wide">
                  Documentos Subidos por el Cliente
                </h4>
                <p className="text-[11px] text-slate-500">
                  Revisa las fotos en pantalla completa y marca cada requisito como Verificado o Rechazado
                </p>
              </div>
              <div className="flex items-center gap-2 text-[11px] font-bold tabular-nums">
                <span className="text-emerald-700">{stats.verificado} Verif.</span>
                <span className="text-slate-300">·</span>
                <span className="text-sky-700">{stats.enRevision} Revisión</span>
                <span className="text-slate-300">·</span>
                <span className="text-rose-700">{stats.rechazado} Rechaz.</span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-500">{stats.pendiente} Pend.</span>
              </div>
            </div>

            {activeReqList.length === 0 ? (
              <div className="p-8 rounded-2xl bg-white border border-dashed border-slate-300 text-center text-xs text-slate-500">
                Selecciona o agrega al menos un requisito a la izquierda para gestionar los recaudos de este cliente.
              </div>
            ) : (
              <div className="space-y-3">
                {activeReqList.map((req) => {
                  const docData = docs[req.key];
                  const status: VerificationDocStatus = docData?.estado || 'pendiente';
                  const hasImage = Boolean(docData?.imagen);
                  const isBusy = reviewingKey === req.key;

                  return (
                    <div
                      key={req.key}
                      className={`p-3.5 rounded-2xl bg-white border shadow-2xs space-y-3 ${
                        status === 'verificado'
                          ? 'border-emerald-200'
                          : status === 'rechazado'
                          ? 'border-rose-200'
                          : status === 'en_revision'
                          ? 'border-sky-200'
                          : 'border-slate-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="flex items-start gap-3 min-w-0 flex-1">
                          {hasImage ? (
                            <button
                              type="button"
                              onClick={() =>
                                setZoomImage({ src: docData!.imagen!, title: req.label })
                              }
                              className="w-16 h-16 rounded-xl border border-slate-200 overflow-hidden bg-slate-100 shrink-0 cursor-pointer hover:ring-2 hover:ring-sky-400 relative group"
                              title="Ver imagen en tamaño completo"
                            >
                              <img
                                src={docData!.imagen}
                                alt={req.label}
                                className="w-full h-full object-cover"
                              />
                              <span className="absolute inset-0 bg-slate-950/35 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                                <Eye className="w-4 h-4" />
                              </span>
                            </button>
                          ) : (
                            <div className="w-16 h-16 rounded-xl border border-dashed border-slate-300 bg-slate-50 flex flex-col items-center justify-center text-slate-400 shrink-0 text-[10px]">
                              <FileWarning className="w-4 h-4 mb-0.5" />
                              Sin foto
                            </div>
                          )}

                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <h5 className="text-xs font-extrabold text-slate-900">
                                {req.label}
                              </h5>
                              {req.requiereFoto && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-sky-50 text-sky-700 border border-sky-100 inline-flex items-center gap-1">
                                  <Camera className="w-2.5 h-2.5" /> Foto
                                </span>
                              )}
                              <span
                                className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md ${
                                  status === 'verificado'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : status === 'rechazado'
                                    ? 'bg-rose-100 text-rose-800'
                                    : status === 'en_revision'
                                    ? 'bg-sky-100 text-sky-800'
                                    : 'bg-slate-100 text-slate-600'
                                }`}
                              >
                                {status === 'en_revision'
                                  ? 'Enviado · En revisión'
                                  : status === 'verificado'
                                  ? 'Verificado'
                                  : status === 'rechazado'
                                  ? 'Rechazado'
                                  : 'Pendiente por subir'}
                              </span>
                            </div>

                            {docData?.detalle ? (
                              <p className="text-xs text-slate-700 mt-1 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                                {docData.detalle}
                              </p>
                            ) : (
                              <p className="text-[11px] text-slate-400 mt-1">
                                {hasImage
                                  ? 'Sin notas adicionales del cliente.'
                                  : 'Aún no ha sido cargado por el cliente.'}
                              </p>
                            )}

                            {docData?.subido_en && (
                              <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Subido el {new Date(docData.subido_en).toLocaleString('es-VE')}
                                {docData.subido_por ? ` por ${docData.subido_por}` : ''}
                              </p>
                            )}

                            {docData?.nota_propietario && status === 'rechazado' && (
                              <p className="text-[11px] text-rose-700 font-semibold mt-1">
                                Motivo de rechazo: {docData.nota_propietario}
                              </p>
                            )}
                          </div>
                        </div>

                        {hasImage && (
                          <button
                            type="button"
                            onClick={() =>
                              setZoomImage({ src: docData!.imagen!, title: req.label })
                            }
                            className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                          >
                            <Eye className="w-3.5 h-3.5" /> Ver Imagen
                          </button>
                        )}
                      </div>

                      {/* Approve / Reject Controls */}
                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
                        <input
                          type="text"
                          value={rejectionNotes[req.key] ?? docData?.nota_propietario ?? ''}
                          onChange={(e) =>
                            setRejectionNotes((prev) => ({ ...prev, [req.key]: e.target.value }))
                          }
                          placeholder="Motivo si se rechaza (ej. imagen borrosa o documento vencido)..."
                          maxLength={250}
                          className="flex-1 min-w-[200px] px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                        />
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => void handleReview(req.key, 'verificado')}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1 cursor-pointer transition-colors ${
                            status === 'verificado'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-200'
                          }`}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Verificado
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => void handleReview(req.key, 'rechazado')}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1 cursor-pointer transition-colors ${
                            status === 'rechazado'
                              ? 'bg-rose-600 text-white'
                              : 'bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200'
                          }`}
                        >
                          <XCircle className="w-3.5 h-3.5" /> Rechazar
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fullscreen Document Zoom Preview */}
      {zoomImage && (
        <div
          className="fixed inset-0 z-[210] bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setZoomImage(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">{zoomImage.title}</span>
              <button
                type="button"
                onClick={() => setZoomImage(null)}
                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 bg-slate-900 flex items-center justify-center overflow-auto max-h-[80vh]">
              <img
                src={zoomImage.src}
                alt={zoomImage.title}
                className="max-w-full max-h-[75vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
