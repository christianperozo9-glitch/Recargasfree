import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Eye,
  Send,
  Upload,
  X,
  XCircle,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import { VERIFICATION_REQUIREMENTS } from '../constants/verificationRequirements';
import { compressImageFile } from '../utils/format';

interface ClientVerificationModalProps {
  open: boolean;
  onClose: () => void;
}

interface ClientRequestedItem {
  key: string;
  label: string;
  description: string;
  detailPlaceholder: string;
  requiereFoto: boolean;
}

export const ClientVerificationModal: React.FC<ClientVerificationModalProps> = ({
  open,
  onClose,
}) => {
  const {
    verificationConfig,
    verificationDocs,
    submitClientVerificationDoc,
    notifyToast,
  } = usePos();

  const [draftImages, setDraftImages] = useState<Record<string, string>>({});
  const [draftDetails, setDraftDetails] = useState<Record<string, string>>({});
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);
  const [submittingKey, setSubmittingKey] = useState<string | null>(null);
  const [previewImg, setPreviewImg] = useState<{ src: string; label: string } | null>(null);

  const requestedItems = useMemo<ClientRequestedItem[]>(() => {
    if (!verificationConfig) return [];
    const presets: ClientRequestedItem[] = VERIFICATION_REQUIREMENTS.filter((r) =>
      Boolean(verificationConfig.requisitos?.[r.key])
    ).map((r) => ({
      key: r.key,
      label: r.label,
      description: r.description,
      detailPlaceholder: r.detailPlaceholder,
      requiereFoto: verificationConfig.requisitos_foto?.[r.key] !== false,
    }));

    const customs: ClientRequestedItem[] = (verificationConfig.requisitos_personalizados || [])
      .filter((c) => c.activo !== false)
      .map((c) => ({
        key: c.id,
        label: c.label,
        description: c.description || 'Requisito solicitado por el propietario del sistema.',
        detailPlaceholder: 'Escribe detalles, número de documento o comentario...',
        requiereFoto:
          c.requiere_foto !== false && verificationConfig.requisitos_foto?.[c.id] !== false,
      }));

    return [...presets, ...customs];
  }, [verificationConfig]);

  const verifiedCount = useMemo(
    () => requestedItems.filter((r) => verificationDocs[r.key]?.estado === 'verificado').length,
    [requestedItems, verificationDocs]
  );

  if (!open || !verificationConfig?.activo) return null;

  const processFileForReq = async (reqKey: string, file: File) => {
    setUploadingKey(reqKey);
    try {
      const dataUrl = await compressImageFile(file, 900, 0.78);
      setDraftImages((prev) => ({ ...prev, [reqKey]: dataUrl }));
      notifyToast('Foto cargada. Haz clic en "Enviar Documento" para remitirla.', 'info');
    } catch (err) {
      notifyToast(
        err instanceof Error ? err.message : 'No se pudo procesar la imagen seleccionada.',
        'error'
      );
    } finally {
      setUploadingKey(null);
    }
  };

  const handlePasteForReq = async (
    reqKey: string,
    e: React.ClipboardEvent<HTMLDivElement>
  ) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          await processFileForReq(reqKey, file);
          return;
        }
      }
    }
  };

  const handleSubmitReq = async (item: ClientRequestedItem) => {
    const currentDoc = verificationDocs[item.key];
    const img = draftImages[item.key] ?? currentDoc?.imagen ?? '';
    const detail = (draftDetails[item.key] ?? currentDoc?.detalle ?? '').trim();
    if (item.requiereFoto && !img) {
      notifyToast(
        `El requisito "${item.label}" requiere adjuntar una fotografía antes de enviar.`,
        'warning'
      );
      return;
    }
    if (!img && !detail) {
      notifyToast('Sube una foto/captura o escribe los datos solicitados antes de enviar.', 'warning');
      return;
    }
    setSubmittingKey(item.key);
    try {
      await submitClientVerificationDoc(item.key, item.label, {
        imagen: img,
        detalle: detail,
      });
      setDraftImages((prev) => {
        const copy = { ...prev };
        delete copy[item.key];
        return copy;
      });
    } finally {
      setSubmittingKey(null);
    }
  };

  const pct =
    requestedItems.length > 0 ? Math.round((verifiedCount / requestedItems.length) * 100) : 0;

  return (
    <div className="fixed inset-0 z-[175] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4">
      <div className="bg-white rounded-3xl border border-slate-200 max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-amber-50 via-white to-orange-50 border-b border-amber-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                Actualización y Verificación de Datos Requerida
              </h3>
              <p className="text-xs text-slate-600">
                Adjunta la foto y datos de cada requisito solicitado por el propietario
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 cursor-pointer shrink-0"
            aria-label="Cerrar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message + Progress */}
        <div className="px-5 py-3 bg-amber-50/50 border-b border-slate-200 space-y-2">
          {verificationConfig.mensaje && (
            <p className="text-xs text-amber-950 font-medium flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>{verificationConfig.mensaje}</span>
            </p>
          )}
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
            <span>
              Progreso de verificación: {verifiedCount} de {requestedItems.length} verificados
            </span>
            <span className="font-mono text-sky-700">{pct}%</span>
          </div>
          <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-sky-500 to-emerald-500 transition-all duration-300"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>

        {/* Requirements List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
          {requestedItems.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No hay requisitos específicos seleccionados en este momento.
            </div>
          ) : (
            requestedItems.map((req) => {
              const existing = verificationDocs[req.key];
              const status = existing?.estado || 'pendiente';
              const activeImage = draftImages[req.key] ?? existing?.imagen ?? '';
              const activeDetail = draftDetails[req.key] ?? existing?.detalle ?? '';
              const isUploading = uploadingKey === req.key;
              const isSubmitting = submittingKey === req.key;
              const isVerified = status === 'verificado';

              return (
                <div
                  key={req.key}
                  onPaste={(e) => void handlePasteForReq(req.key, e)}
                  className={`p-4 rounded-2xl border space-y-3 transition-colors ${
                    isVerified
                      ? 'bg-emerald-50/40 border-emerald-200'
                      : status === 'rechazado'
                      ? 'bg-rose-50/40 border-rose-200'
                      : status === 'en_revision'
                      ? 'bg-sky-50/40 border-sky-200'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-xs sm:text-sm font-extrabold text-slate-900">
                          {req.label}
                        </h4>
                        {req.requiereFoto && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 text-[10px] font-extrabold">
                            <Camera className="w-3 h-3" /> Foto requerida
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{req.description}</p>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 ${
                        isVerified
                          ? 'bg-emerald-100 text-emerald-800'
                          : status === 'rechazado'
                          ? 'bg-rose-100 text-rose-800'
                          : status === 'en_revision'
                          ? 'bg-sky-100 text-sky-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isVerified ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" /> Verificado
                        </>
                      ) : status === 'rechazado' ? (
                        <>
                          <XCircle className="w-3.5 h-3.5" /> Rechazado · Corregir
                        </>
                      ) : status === 'en_revision' ? (
                        <>
                          <Clock className="w-3.5 h-3.5" /> En revisión
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5" /> Pendiente
                        </>
                      )}
                    </span>
                  </div>

                  {status === 'rechazado' && existing?.nota_propietario && (
                    <div className="px-3 py-2 rounded-xl bg-rose-100/70 border border-rose-200 text-xs text-rose-900 font-semibold">
                      Observación del propietario: {existing.nota_propietario}
                    </div>
                  )}

                  <div className="flex flex-wrap items-start gap-3">
                    {/* Image Box */}
                    <div className="w-24 h-24 rounded-xl border border-slate-200 bg-white overflow-hidden flex items-center justify-center shrink-0 relative">
                      {activeImage ? (
                        <>
                          <img
                            src={activeImage}
                            alt={req.label}
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() => setPreviewImg({ src: activeImage, label: req.label })}
                            className="absolute bottom-1 right-1 p-1 rounded-md bg-slate-900/75 text-white hover:bg-slate-900 cursor-pointer"
                            title="Ampliar"
                          >
                            <Eye className="w-3 h-3" />
                          </button>
                        </>
                      ) : (
                        <span className="text-[10px] text-slate-400 text-center px-2">
                          {req.requiereFoto ? 'Adjunta foto (Cámara o archivo)' : 'Foto opcional (Ctrl+V)'}
                        </span>
                      )}
                    </div>

                    {/* Inputs */}
                    <div className="flex-1 min-w-[210px] space-y-2">
                      <input
                        type="text"
                        disabled={isVerified}
                        value={activeDetail}
                        onChange={(e) =>
                          setDraftDetails((prev) => ({ ...prev, [req.key]: e.target.value }))
                        }
                        placeholder={req.detailPlaceholder}
                        maxLength={500}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl disabled:opacity-60"
                      />

                      {!isVerified && (
                        <div className="flex flex-wrap items-center gap-2">
                          <label className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer">
                            <Upload className="w-3.5 h-3.5" />
                            {isUploading
                              ? 'Procesando...'
                              : activeImage
                              ? 'Cambiar Foto'
                              : 'Subir Foto'}
                            <input
                              type="file"
                              accept="image/*"
                              disabled={isUploading}
                              onChange={(e) => {
                                const f = e.target.files?.[0];
                                if (f) void processFileForReq(req.key, f);
                                e.target.value = '';
                              }}
                              className="hidden"
                            />
                          </label>

                          <label className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer">
                            <Camera className="w-3.5 h-3.5" /> Tomar Foto
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              disabled={isUploading}
                              onChange={(e) => {
                                const f = e.target.files?.[0];
                                if (f) void processFileForReq(req.key, f);
                                e.target.value = '';
                              }}
                              className="hidden"
                            />
                          </label>

                          <button
                            type="button"
                            disabled={isSubmitting || isUploading}
                            onClick={() => void handleSubmitReq(req)}
                            className="ml-auto px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5" />
                            {isSubmitting
                              ? 'Enviando...'
                              : status === 'en_revision'
                              ? 'Actualizar Envío'
                              : 'Enviar Documento'}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2 text-xs">
          <span className="text-slate-500">
            Tus fotografías se comprimen automáticamente y solo son visibles para el propietario del sistema.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 font-semibold text-slate-700 cursor-pointer shrink-0"
          >
            Cerrar
          </button>
        </div>
      </div>

      {previewImg && (
        <div
          className="fixed inset-0 z-[210] bg-slate-950/85 flex items-center justify-center p-4"
          onClick={() => setPreviewImg(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">{previewImg.label}</span>
              <button
                type="button"
                onClick={() => setPreviewImg(null)}
                className="p-1.5 rounded-lg bg-slate-100 text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 bg-slate-900 flex justify-center">
              <img
                src={previewImg.src}
                alt={previewImg.label}
                className="max-h-[75vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
