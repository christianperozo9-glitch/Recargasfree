import React, { useEffect, useRef, useState } from 'react';
import { doc, writeBatch } from 'firebase/firestore';
import {
  AlertTriangle,
  Barcode,
  Bot,
  Camera,
  Check,
  CheckCircle2,
  Copy,
  Crown,
  ExternalLink,
  EyeOff,
  Headphones,
  Keyboard,
  Loader2,
  MessageCircle,
  Moon,
  Music,
  Pause,
  Play,
  Printer,
  RotateCcw,
  RotateCw,
  Search,
  Send,
  ShieldCheck,
  SkipBack,
  SkipForward,
  Sliders,
  Sparkles,
  Square,
  Sun,
  Trash2,
  Upload,
  Usb,
  Volume2,
  VolumeX,
  Wifi,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import type { PagoMovilVerificationResult } from '../types/pos';
import { compressImageFile, formatMoney, round2 } from '../utils/format';
import {
  connectWebHidScanner,
  connectWebSerialScanner,
  connectWebUsbScanner,
  getScannerCapabilities,
  isGlobalScannerWedgeEnabled,
  setGlobalScannerWedgeEnabled,
} from '../utils/barcodeScanner';
import {
  bonusMonthsWithPromos,
  describePromo,
  effectiveDiscountWithPromos,
} from '../utils/promotions';

/* ================= BARCODE CAMERA SCANNER MODAL ================= */
interface BarcodeScannerModalProps {
  open: boolean;
  onClose: () => void;
  onDetected: (code: string) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  open,
  onClose,
  onDetected,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [camError, setCamError] = useState('');

  useEffect(() => {
    if (!open) return;
    let stream: MediaStream | null = null;
    let cancelled = false;
    let timerId: number | undefined;

    async function startCamera() {
      setCamError('');
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        const DetectorCtor = (
          window as unknown as {
            BarcodeDetector?: new (opts?: { formats: string[] }) => {
              detect: (src: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>>;
            };
          }
        ).BarcodeDetector;
        if (DetectorCtor && videoRef.current) {
          const detector = new DetectorCtor({
            formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'qr_code'],
          });
          const tick = async () => {
            if (cancelled || !videoRef.current) return;
            try {
              const found = await detector.detect(videoRef.current);
              if (found.length > 0 && found[0].rawValue) {
                onDetected(found[0].rawValue);
                onClose();
                return;
              }
            } catch {
              // ignore frame errors
            }
            timerId = window.setTimeout(tick, 320);
          };
          timerId = window.setTimeout(tick, 400);
        }
      } catch {
        setCamError('Cámara no disponible o permiso denegado. Puedes escribir el código abajo.');
      }
    }

    void startCamera();
    return () => {
      cancelled = true;
      if (timerId) clearTimeout(timerId);
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, [onClose, onDetected, open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[170] bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-sky-600" />
            <h3 className="text-sm font-bold text-slate-900">Escáner de Código de Barras</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          <div className="relative aspect-video bg-slate-900 rounded-xl overflow-hidden flex items-center justify-center">
            <video ref={videoRef} playsInline muted className="w-full h-full object-cover" />
            {camError && (
              <p className="absolute inset-x-4 text-center text-xs text-slate-200 bg-slate-900/80 p-3 rounded-xl">
                {camError}
              </p>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (manualCode.trim()) {
                onDetected(manualCode.trim());
                setManualCode('');
                onClose();
              }
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="O escribe el código manualmente..."
              className="flex-1 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-semibold cursor-pointer"
            >
              Usar
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
            >
              Cancelar
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

/* ================= PERIPHERALS (USB / HID / SERIAL) MODAL ================= */
interface DevicesModalProps {
  open: boolean;
  onClose: () => void;
}

export const DevicesModal: React.FC<DevicesModalProps> = ({ open, onClose }) => {
  const {
    detectedPrinters,
    activePrinter,
    refreshPrinters,
    connectUsbPrinter,
    connectSerialPrinter,
    disconnectPrinters,
    sendTestPrint,
    invoiceConfig,
    updateLocalInvoiceConfig,
    invoiceMode,
    setInvoiceMode,
    scannerDevices,
    lastHardwareScan,
    notifyToast,
    playBeep,
  } = usePos();
  const [scanning, setScanning] = useState(false);
  const [savingCfg, setSavingCfg] = useState(false);
  const [wedgeActive, setWedgeActive] = useState(() => isGlobalScannerWedgeEnabled());
  const [connectingScanner, setConnectingScanner] = useState(false);

  if (!open) return null;

  const caps = getScannerCapabilities();

  const handleQuickInvoicePatch = async (patch: Parameters<typeof updateLocalInvoiceConfig>[0]) => {
    setSavingCfg(true);
    try {
      await updateLocalInvoiceConfig(patch);
      notifyToast('Ajuste de facturación e impresora guardado.', 'success');
    } catch {
      notifyToast('No se pudo guardar el ajuste de impresora.', 'error');
    } finally {
      setSavingCfg(false);
    }
  };

  const handleScan = async () => {
    setScanning(true);
    try {
      const list = await refreshPrinters();
      if (list.length > 0) {
        notifyToast(`Se detectaron ${list.length} impresora(s) autorizada(s).`, 'success');
      } else {
        notifyToast('No hay impresoras autorizadas aún. Vincula una vía USB o Serial.', 'info');
      }
    } finally {
      setScanning(false);
    }
  };

  const handleToggleWedge = () => {
    const next = !wedgeActive;
    setGlobalScannerWedgeEnabled(next);
    setWedgeActive(next);
    notifyToast(
      next
        ? 'Detector Universal de Lector de Barras (USB / Inalámbrico) activado.'
        : 'Detector Universal de Lector de Barras pausado.',
      next ? 'success' : 'info'
    );
  };

  const handleConnectScanner = async (kind: 'hid' | 'serial' | 'usb') => {
    setConnectingScanner(true);
    try {
      const dev =
        kind === 'hid'
          ? await connectWebHidScanner()
          : kind === 'serial'
          ? await connectWebSerialScanner()
          : await connectWebUsbScanner();
      if (dev) {
        playBeep('ok');
        notifyToast(`Lector vinculado: ${dev.name}`, 'success');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'No se pudo vincular el dispositivo.';
      if (!msg.toLowerCase().includes('no device selected')) {
        notifyToast(msg, 'warning');
      }
    } finally {
      setConnectingScanner(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[155] bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl border border-slate-200 max-w-2xl w-full p-5 space-y-4 shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-sky-100 border border-sky-200 text-sky-700 flex items-center justify-center shrink-0">
              <Printer className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-extrabold text-slate-900 truncate">
                Facturación Precisa, Impresoras Térmicas y Periféricos
              </h3>
              <p className="text-[11px] text-slate-500 truncate">
                Conecta tu impresora USB/Serial/Navegador, calibra papel e intensidad y configura lectores de barras
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer shrink-0"
            aria-label="Cerrar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* === 1. PRECISION BILLING & THERMAL PRINTER CONNECTION === */}
        <div className="p-4 rounded-2xl bg-sky-50/60 border border-sky-200 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-sky-600" />
                Conexión de Impresora y Facturación Precisa
              </h4>
              <p className="text-[11px] text-slate-600">
                {activePrinter
                  ? `Conectada: ${activePrinter.name} (${activePrinter.kind.toUpperCase()})`
                  : `Perfil asignado: ${invoiceConfig.impresora_nombre || 'Impresora Térmica'} · ${invoiceConfig.ancho_papel}`}
              </p>
            </div>
            {savingCfg && (
              <span className="text-[11px] font-semibold text-sky-700 inline-flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Guardando...
              </span>
            )}
          </div>

          {/* Connection buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <button
              type="button"
              disabled={scanning}
              onClick={() => void handleScan()}
              className="py-2.5 px-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCw className={`w-3.5 h-3.5 ${scanning ? 'animate-spin' : ''}`} /> Detectar Impresora
            </button>
            <button
              type="button"
              onClick={() => void connectUsbPrinter()}
              className="py-2.5 px-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Usb className="w-4 h-4" /> Conectar USB
            </button>
            <button
              type="button"
              onClick={() => void connectSerialPrinter()}
              className="py-2.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" /> Puerto Serial COM
            </button>
          </div>

          {detectedPrinters.length > 0 ? (
            <div className="space-y-2">
              {detectedPrinters.map((d) => (
                <div
                  key={d.id}
                  className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-900 flex items-center justify-between gap-2"
                >
                  <span className="inline-flex items-center gap-2 truncate">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="truncate">{d.name}</span>
                  </span>
                  <span className="text-[10px] uppercase font-mono text-emerald-700 shrink-0">
                    {d.kind} · Conectada
                  </span>
                </div>
              ))}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void sendTestPrint()}
                  className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" /> Imprimir Ticket de Prueba
                </button>
                <button
                  type="button"
                  onClick={disconnectPrinters}
                  className="px-3 py-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold cursor-pointer"
                >
                  Desconectar
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-white border border-dashed border-sky-200 text-[11px] text-slate-600">
              <span>
                Sin USB/Serial directo vinculado: puedes imprimir vía navegador/Bluetooth o PDF automático.
              </span>
              <button
                type="button"
                onClick={() => void sendTestPrint()}
                className="px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 font-bold inline-flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Printer className="w-3.5 h-3.5" /> Prueba de Impresión
              </button>
            </div>
          )}

          {/* Precision billing mode */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-700 block">
              Modo de Emisión de Factura al Cobrar
            </span>
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {(
                [
                  { id: 'auto', label: 'Automático (Impresora o PDF)' },
                  { id: 'printer', label: 'Siempre Térmica / Navegador' },
                  { id: 'pdf', label: 'Siempre PDF automático' },
                  { id: 'none', label: 'Solo registrar venta' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setInvoiceMode(opt.id)}
                  className={`px-2.5 py-2 rounded-xl border font-semibold text-left cursor-pointer ${
                    invoiceMode === opt.id
                      ? 'bg-sky-600 border-sky-600 text-white'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Paper Width, Intensity, Copies & Precision Switches */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">Papel Térmico</span>
              <div className="grid grid-cols-2 gap-1">
                {(['58mm', '80mm'] as const).map((w) => (
                  <button
                    key={w}
                    type="button"
                    disabled={savingCfg}
                    onClick={() => void handleQuickInvoicePatch({ ancho_papel: w })}
                    className={`py-1.5 rounded-lg font-bold cursor-pointer ${
                      invoiceConfig.ancho_papel === w
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {w}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">Intensidad Tinta</span>
              <select
                value={invoiceConfig.intensidad_impresion || 'normal'}
                disabled={savingCfg}
                onChange={(e) =>
                  void handleQuickInvoicePatch({
                    intensidad_impresion: e.target.value as NonNullable<
                      typeof invoiceConfig.intensidad_impresion
                    >,
                  })
                }
                className="w-full px-2 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-semibold text-xs"
              >
                <option value="suave">Suave</option>
                <option value="normal">Normal</option>
                <option value="oscura">Oscura</option>
                <option value="extra_oscura">Extra Oscura</option>
              </select>
            </div>

            <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">Copias por Venta</span>
              <div className="grid grid-cols-2 gap-1">
                {([1, 2] as const).map((c) => (
                  <button
                    key={c}
                    type="button"
                    disabled={savingCfg}
                    onClick={() => void handleQuickInvoicePatch({ copias: c })}
                    className={`py-1.5 rounded-lg font-bold cursor-pointer ${
                      invoiceConfig.copias === c
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {c} {c === 1 ? 'Copia' : 'Copias'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 text-[11px]">
            {(
              [
                { key: 'auto_imprimir', label: 'Auto-imprimir al cobrar' },
                { key: 'corte_automatico', label: 'Corte automático' },
                { key: 'abrir_gaveta', label: 'Abrir gaveta' },
                { key: 'mostrar_logo', label: 'Imprimir logotipo del local' },
              ] as const
            ).map((sw) => (
              <label
                key={sw.key}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 cursor-pointer font-semibold text-slate-700"
              >
                <input
                  type="checkbox"
                  disabled={savingCfg}
                  checked={Boolean(invoiceConfig[sw.key])}
                  onChange={(e) =>
                    void handleQuickInvoicePatch({ [sw.key]: e.target.checked })
                  }
                  className="w-3.5 h-3.5 accent-sky-600"
                />
                {sw.label}
              </label>
            ))}
          </div>
        </div>

        {/* === 2. UNIVERSAL BARCODE SCANNER DETECTOR === */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Barcode className="w-4 h-4 text-sky-600 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">
                  Lector de Códigos de Barras y Detector Universal
                </h4>
                <p className="text-[11px] text-slate-500">
                  Compatible con pistolas USB por cable, adaptadores inalámbricos 2.4GHz, Bluetooth HID y lectores Serial/WebHID.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleToggleWedge}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer whitespace-nowrap ${
                wedgeActive
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
              }`}
            >
              {wedgeActive ? 'Detección Universal Activa' : 'Activar Detección Universal'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <button
              type="button"
              disabled={connectingScanner || !caps.webHid}
              onClick={() => void handleConnectScanner('hid')}
              className="py-2 px-2.5 rounded-xl bg-white hover:bg-sky-50 border border-slate-200 disabled:opacity-50 text-slate-800 font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              title="Conectar lector USB en modo WebHID POS"
            >
              <Usb className="w-3.5 h-3.5 text-sky-600" />
              <span>Detector USB / HID</span>
            </button>
            <button
              type="button"
              disabled={connectingScanner || !caps.webSerial}
              onClick={() => void handleConnectScanner('serial')}
              className="py-2 px-2.5 rounded-xl bg-white hover:bg-sky-50 border border-slate-200 disabled:opacity-50 text-slate-800 font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              title="Conectar receptor inalámbrico o serial COM / SPP"
            >
              <Wifi className="w-3.5 h-3.5 text-emerald-600" />
              <span>Inalámbrico / Serial COM</span>
            </button>
            <button
              type="button"
              disabled={connectingScanner || !caps.webUsb}
              onClick={() => void handleConnectScanner('usb')}
              className="py-2 px-2.5 rounded-xl bg-white hover:bg-sky-50 border border-slate-200 disabled:opacity-50 text-slate-800 font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              title="Detectar receptor USB directo"
            >
              <Barcode className="w-3.5 h-3.5 text-indigo-600" />
              <span>Detectar Receptor USB</span>
            </button>
          </div>

          {scannerDevices.length > 0 && (
            <div className="space-y-1.5">
              {scannerDevices.map((sd) => (
                <div
                  key={sd.id}
                  className="px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-900 flex items-center justify-between gap-2"
                >
                  <span className="inline-flex items-center gap-2 truncate">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate">{sd.name}</span>
                  </span>
                  <span className="text-[10px] font-mono uppercase text-emerald-700 shrink-0">
                    {sd.transport} · {sd.status}
                  </span>
                </div>
              ))}
            </div>
          )}

          <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="min-w-0">
              <span className="text-[11px] font-bold text-slate-700 block">
                Probador en vivo (apunta y escanea cualquier código de barras)
              </span>
              {lastHardwareScan ? (
                <p className="text-[11px] font-mono text-emerald-700 mt-0.5 truncate">
                  Último escaneo: <b>{lastHardwareScan.code}</b> · {lastHardwareScan.deviceName || lastHardwareScan.transport} ({lastHardwareScan.latencyMs}ms)
                </p>
              ) : (
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Esperando lectura desde lector USB, dongle inalámbrico 2.4GHz o Bluetooth HID...
                </p>
              )}
            </div>
            {lastHardwareScan && (
              <span className="px-2 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-mono text-[11px] font-bold">
                Detectado
              </span>
            )}
          </div>
        </div>

        <div className="pt-2 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-white cursor-pointer"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};

/* ================= PERSISTENT YOUTUBE BACKGROUND MUSIC PLAYER ================= */
export interface MusicTrack {
  id: string;
  title: string;
  channel: string;
  duration?: string;
  thumbnail?: string;
}

export interface MusicPlayerStateSummary {
  active: boolean;
  playing: boolean;
  title: string;
  channel: string;
  thumbnail?: string;
}

export interface MusicExternalCommand {
  type: 'toggle' | 'next' | 'prev' | 'cancel';
  seq: number;
}

interface MusicPlayerModalProps {
  open: boolean;
  onClose: () => void;
  onStateChange?: (summary: MusicPlayerStateSummary) => void;
  externalCommand?: MusicExternalCommand | null;
}

interface YTPlayerInstance {
  playVideo: () => void;
  pauseVideo: () => void;
  stopVideo: () => void;
  loadVideoById: (videoId: string) => void;
  setVolume: (vol: number) => void;
  mute: () => void;
  unMute: () => void;
  seekTo?: (seconds: number, allowSeekAhead?: boolean) => void;
  getCurrentTime?: () => number;
  getDuration?: () => number;
  setPlaybackQuality?: (quality: string) => void;
  destroy: () => void;
  getIframe?: () => HTMLIFrameElement | null;
}

function formatAudioSeconds(secs: number): string {
  if (!Number.isFinite(secs) || secs <= 0) return '0:00';
  const total = Math.floor(secs);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

interface YTNamespace {
  Player: new (
    element: HTMLElement | string,
    options: {
      videoId: string;
      host?: string;
      width?: string | number;
      height?: string | number;
      playerVars?: Record<string, string | number>;
      events?: {
        onReady?: (ev: { target: YTPlayerInstance }) => void;
        onStateChange?: (ev: { data: number; target: YTPlayerInstance }) => void;
        onError?: (ev: { data: number; target: YTPlayerInstance }) => void;
      };
    }
  ) => YTPlayerInstance;
}

type WindowWithYT = Window & {
  YT?: YTNamespace;
  onYouTubeIframeAPIReady?: () => void;
};

let ytApiPromise: Promise<YTNamespace> | null = null;

function loadYouTubeIframeApi(): Promise<YTNamespace> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('Window unavailable'));
  }
  const win = window as WindowWithYT;
  if (win.YT && typeof win.YT.Player === 'function') {
    return Promise.resolve(win.YT);
  }
  if (ytApiPromise) return ytApiPromise;

  ytApiPromise = new Promise<YTNamespace>((resolve, reject) => {
    let settled = false;
    const finishResolve = (yt: YTNamespace) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timeoutId);
      window.clearInterval(pollId);
      resolve(yt);
    };
    const finishReject = (err: Error) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timeoutId);
      window.clearInterval(pollId);
      ytApiPromise = null;
      reject(err);
    };

    const prevReady = win.onYouTubeIframeAPIReady;
    win.onYouTubeIframeAPIReady = () => {
      try {
        prevReady?.();
      } catch {
        // ignore previous handler error
      }
      if (win.YT && typeof win.YT.Player === 'function') {
        finishResolve(win.YT);
      }
    };

    const pollId = window.setInterval(() => {
      if (win.YT && typeof win.YT.Player === 'function') {
        finishResolve(win.YT);
      }
    }, 150);

    const timeoutId = window.setTimeout(() => {
      finishReject(new Error('Tiempo de espera agotado al cargar YouTube Player API'));
    }, 6500);

    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[src*="youtube.com/iframe_api"]'
    );
    if (!existingScript) {
      const script = document.createElement('script');
      script.src = 'https://www.youtube.com/iframe_api';
      script.async = true;
      script.onerror = () => finishReject(new Error('No se pudo cargar YouTube IFrame API'));
      document.head.appendChild(script);
    }
  });

  return ytApiPromise;
}

const DEFAULT_CURATED_TRACKS: MusicTrack[] = [
  {
    id: 'jfKfPfyJRdk',
    title: 'Lofi Hip Hop Radio · Concentración',
    channel: 'Lofi Girl',
    duration: 'EN VIVO',
    thumbnail: 'https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg',
  },
  {
    id: '4xDzrJKXOOY',
    title: 'Synthwave Chill Instrumental',
    channel: 'Lofi Girl Synthwave',
    duration: 'EN VIVO',
    thumbnail: 'https://i.ytimg.com/vi/4xDzrJKXOOY/mqdefault.jpg',
  },
  {
    id: 'Dx5qFachd3A',
    title: 'Relaxing Jazz Piano Café',
    channel: 'Cafe Music BGM',
    duration: 'EN VIVO',
    thumbnail: 'https://i.ytimg.com/vi/Dx5qFachd3A/mqdefault.jpg',
  },
  {
    id: '36YnV9STBqc',
    title: 'Acoustic Instrumental Ambient Mix',
    channel: 'Ambient Worlds',
    duration: '2:00:00',
    thumbnail: 'https://i.ytimg.com/vi/36YnV9STBqc/mqdefault.jpg',
  },
  {
    id: 'lTRiuFIWV54',
    title: '1 A.M Study Session · Chill Lofi Beats',
    channel: 'Lofi Girl',
    duration: '1:01:28',
    thumbnail: 'https://i.ytimg.com/vi/lTRiuFIWV54/mqdefault.jpg',
  },
];

async function searchYouTubeClientFallback(
  q: string,
  signal: AbortSignal
): Promise<MusicTrack[]> {
  const pipedEndpoints = [
    `https://api.piped.private.coffee/search?q=${encodeURIComponent(q)}&filter=videos`,
    `https://pipedapi.kavin.rocks/search?q=${encodeURIComponent(q)}&filter=videos`,
  ];

  for (const ep of pipedEndpoints) {
    if (signal.aborted) return [];
    try {
      const res = await fetch(ep, { signal, headers: { Accept: 'application/json' } });
      if (!res.ok) continue;
      const json = (await res.json()) as {
        items?: Array<{
          url?: string;
          title?: string;
          uploaderName?: string;
          thumbnail?: string;
          duration?: number;
        }>;
      };
      const out: MusicTrack[] = [];
      const seen = new Set<string>();
      for (const it of json.items || []) {
        const match = String(it.url || '').match(/v=([a-zA-Z0-9_-]{11})/);
        const id = match?.[1] || '';
        if (!id || seen.has(id)) continue;
        seen.add(id);
        const secs = Number(it.duration) || 0;
        const mins = Math.floor(secs / 60);
        const rem = secs % 60;
        out.push({
          id,
          title: String(it.title || 'YouTube Audio'),
          channel: String(it.uploaderName || 'YouTube'),
          duration: secs > 0 ? `${mins}:${String(rem).padStart(2, '0')}` : 'EN VIVO',
          thumbnail: it.thumbnail || `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
        });
        if (out.length >= 14) break;
      }
      if (out.length > 0) return out;
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') throw err;
    }
  }

  const invidiousEndpoints = [
    `https://inv.nadeko.net/api/v1/search?q=${encodeURIComponent(q)}&type=video`,
  ];
  for (const ep of invidiousEndpoints) {
    if (signal.aborted) return [];
    try {
      const res = await fetch(ep, { signal, headers: { Accept: 'application/json' } });
      if (!res.ok) continue;
      const rows = (await res.json()) as Array<{
        videoId?: string;
        title?: string;
        author?: string;
        lengthSeconds?: number;
      }>;
      if (!Array.isArray(rows)) continue;
      const out: MusicTrack[] = [];
      const seen = new Set<string>();
      for (const it of rows) {
        const id = typeof it.videoId === 'string' ? it.videoId : '';
        if (!id || !/^[a-zA-Z0-9_-]{11}$/.test(id) || seen.has(id)) continue;
        seen.add(id);
        const secs = Number(it.lengthSeconds) || 0;
        const mins = Math.floor(secs / 60);
        const rem = secs % 60;
        out.push({
          id,
          title: String(it.title || 'YouTube Audio'),
          channel: String(it.author || 'YouTube'),
          duration: secs > 0 ? `${mins}:${String(rem).padStart(2, '0')}` : 'EN VIVO',
          thumbnail: `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
        });
        if (out.length >= 14) break;
      }
      if (out.length > 0) return out;
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') throw err;
    }
  }

  return [];
}

export const MusicPlayerModal: React.FC<MusicPlayerModalProps> = ({
  open,
  onClose,
  onStateChange,
  externalCommand,
}) => {
  const { notifyToast } = usePos();
  const [query, setQuery] = useState('');
  const [tracks, setTracks] = useState<MusicTrack[]>(DEFAULT_CURATED_TRACKS);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedTrack, setSelectedTrack] = useState<MusicTrack | null>(null);
  const [active, setActive] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(80);
  const [loading, setLoading] = useState(false);
  const [debouncing, setDebouncing] = useState(false);
  const [searchInfo, setSearchInfo] = useState<string>('');
  const [playerNotice, setPlayerNotice] = useState<string>('');
  const [useFallbackIframe, setUseFallbackIframe] = useState(false);
  const [blockedIds, setBlockedIds] = useState<Record<string, true>>({});
  const [audioCurrentSec, setAudioCurrentSec] = useState(0);
  const [audioDurationSec, setAudioDurationSec] = useState(0);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('ig_music_player_dark') === '1';
    } catch {
      return false;
    }
  });

  const toggleDarkMode = () => {
    setDarkMode((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('ig_music_player_dark', next ? '1' : '0');
      } catch {
        // ignore storage errors
      }
      return next;
    });
  };

  const playerHostRef = useRef<HTMLDivElement | null>(null);
  const fallbackIframeRef = useRef<HTMLIFrameElement | null>(null);
  const ytPlayerRef = useRef<YTPlayerInstance | null>(null);
  const ytReadyRef = useRef<boolean>(false);
  const loadedVideoIdRef = useRef<string>('');
  const lastCmdSeqRef = useRef<number>(0);
  const debounceTimerRef = useRef<number | null>(null);
  const abortCtrlRef = useRef<AbortController | null>(null);
  const lastFetchedKeyRef = useRef<string>('');
  const skipNextDebounceRef = useRef<boolean>(false);
  const activeRef = useRef<boolean>(active);
  const volumeRef = useRef<number>(volume);
  const mutedRef = useRef<boolean>(muted);
  const tracksRef = useRef<MusicTrack[]>(tracks);
  const currentIdxRef = useRef<number>(currentIdx);
  const blockedIdsRef = useRef<Set<string>>(new Set());
  const consecutiveErrorsRef = useRef<number>(0);
  const searchCacheRef = useRef<Map<string, { items: MusicTrack[]; curated: boolean }>>(new Map());

  const currentTrack = selectedTrack || tracks[currentIdx] || tracks[0];
  const currentTrackRef = useRef<MusicTrack | undefined>(currentTrack);

  useEffect(() => {
    activeRef.current = active;
  }, [active]);
  useEffect(() => {
    volumeRef.current = volume;
  }, [volume]);
  useEffect(() => {
    mutedRef.current = muted;
  }, [muted]);
  useEffect(() => {
    tracksRef.current = tracks;
  }, [tracks]);
  useEffect(() => {
    currentIdxRef.current = currentIdx;
  }, [currentIdx]);
  useEffect(() => {
    currentTrackRef.current = currentTrack;
  }, [currentTrack]);

  const sendYtCommand = (func: string, args: unknown[] = []) => {
    const player = ytPlayerRef.current;
    if (player && ytReadyRef.current) {
      try {
        if (func === 'playVideo') player.playVideo();
        else if (func === 'pauseVideo') player.pauseVideo();
        else if (func === 'stopVideo') player.stopVideo();
        else if (func === 'mute') player.mute();
        else if (func === 'unMute') player.unMute();
        else if (func === 'setVolume' && typeof args[0] === 'number') player.setVolume(args[0]);
        return;
      } catch {
        // fall through to postMessage fallback
      }
    }
    try {
      fallbackIframeRef.current?.contentWindow?.postMessage(
        JSON.stringify({ event: 'command', func, args }),
        '*'
      );
    } catch {
      // ignore cross-origin postMessage errors
    }
  };

  const destroyYtPlayer = () => {
    ytReadyRef.current = false;
    loadedVideoIdRef.current = '';
    if (ytPlayerRef.current) {
      try {
        ytPlayerRef.current.stopVideo();
      } catch {
        // ignore
      }
      try {
        ytPlayerRef.current.destroy();
      } catch {
        // ignore
      }
      ytPlayerRef.current = null;
    }
    if (playerHostRef.current) {
      playerHostRef.current.innerHTML = '';
    }
  };

  const pickNextPlayableTrack = (fromIdx: number, list: MusicTrack[]): { track: MusicTrack; idx: number } | null => {
    if (list.length === 0) return null;
    for (let step = 1; step <= list.length; step++) {
      const idx = (fromIdx + step) % list.length;
      const candidate = list[idx];
      if (candidate && !blockedIdsRef.current.has(candidate.id)) {
        return { track: candidate, idx };
      }
    }
    return null;
  };

  const handleTrackErrorSkipRef = useRef<(errorCode: number) => void>(() => {});
  handleTrackErrorSkipRef.current = (errorCode: number) => {
    const failing = currentTrackRef.current;
    if (failing?.id) {
      blockedIdsRef.current.add(failing.id);
      setBlockedIds((prev) => (prev[failing.id] ? prev : { ...prev, [failing.id]: true }));
    }

    consecutiveErrorsRef.current += 1;
    const list = tracksRef.current;
    const curIndex = list.findIndex((t) => t.id === failing?.id);
    const startIdx = curIndex >= 0 ? curIndex : currentIdxRef.current;

    if (consecutiveErrorsRef.current <= 6) {
      const next = pickNextPlayableTrack(startIdx, list);
      if (next) {
        setPlayerNotice(
          errorCode === 101 || errorCode === 150
            ? 'Esta pista tiene reproducción restringida por su canal. Probando siguiente versión de audio...'
            : 'No se pudo cargar esta pista de audio. Saltando automáticamente a la siguiente...'
        );
        setCurrentIdx(next.idx);
        setSelectedTrack(next.track);
        setActive(true);
        setPlaying(true);
        return;
      }
    }

    // All search items were restricted; try a guaranteed embeddable curated stream once
    const safeFallback = DEFAULT_CURATED_TRACKS.find((t) => !blockedIdsRef.current.has(t.id));
    if (safeFallback && consecutiveErrorsRef.current <= 7) {
      setPlayerNotice(
        'Las pistas de esta búsqueda están restringidas para audio externo. Reproduciendo emisora musical compatible.'
      );
      setSelectedTrack(safeFallback);
      setActive(true);
      setPlaying(true);
      return;
    }

    setPlaying(false);
    setPlayerNotice(
      'Esta pista de audio está restringida por derechos de autor. Selecciona otra versión o artista en la lista.'
    );
  };

  const handleTrackEndedRef = useRef<() => void>(() => {});
  handleTrackEndedRef.current = () => {
    const list = tracksRef.current;
    const curId = currentTrackRef.current?.id;
    const curIndex = list.findIndex((t) => t.id === curId);
    const next = pickNextPlayableTrack(curIndex >= 0 ? curIndex : currentIdxRef.current, list);
    if (next) {
      setCurrentIdx(next.idx);
      setSelectedTrack(next.track);
      setActive(true);
      setPlaying(true);
    } else {
      setPlaying(false);
    }
  };

  // Mount & drive official YouTube IFrame Player API
  useEffect(() => {
    if (!active || !currentTrack) {
      destroyYtPlayer();
      return;
    }
    if (useFallbackIframe) return;

    let cancelled = false;
    const targetVideoId = currentTrack.id;

    // If YT.Player is already mounted and ready, switch track cleanly without destroying iframe
    if (ytPlayerRef.current && ytReadyRef.current) {
      if (loadedVideoIdRef.current !== targetVideoId) {
        loadedVideoIdRef.current = targetVideoId;
        setAudioCurrentSec(0);
        setAudioDurationSec(0);
        try {
          ytPlayerRef.current.loadVideoById(targetVideoId);
          ytPlayerRef.current.setPlaybackQuality?.('small');
          ytPlayerRef.current.setVolume(volumeRef.current);
          if (mutedRef.current) ytPlayerRef.current.mute();
          else ytPlayerRef.current.unMute();
          ytPlayerRef.current.playVideo();
        } catch {
          destroyYtPlayer();
        }
      }
      return;
    }

    void loadYouTubeIframeApi()
      .then((YT) => {
        if (cancelled || !activeRef.current) return;
        const hostEl = playerHostRef.current;
        if (!hostEl) return;

        destroyYtPlayer();
        const mountNode = document.createElement('div');
        mountNode.className = 'w-full h-full';
        hostEl.appendChild(mountNode);
        loadedVideoIdRef.current = targetVideoId;
        setAudioCurrentSec(0);
        setAudioDurationSec(0);

        ytPlayerRef.current = new YT.Player(mountNode, {
          videoId: targetVideoId,
          host: 'https://www.youtube.com',
          width: '100%',
          height: '100%',
          playerVars: {
            autoplay: 1,
            playsinline: 1,
            rel: 0,
            controls: 0,
            fs: 0,
            disablekb: 1,
            enablejsapi: 1,
          },
          events: {
            onReady: (ev) => {
              if (cancelled) return;
              ytReadyRef.current = true;
              try {
                const iframe = ev.target.getIframe?.();
                if (iframe) {
                  iframe.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
                  iframe.setAttribute('allow', 'autoplay; encrypted-media');
                  iframe.style.width = '100%';
                  iframe.style.height = '100%';
                  iframe.style.border = '0';
                }
              } catch {
                // ignore
              }
              try {
                ev.target.setPlaybackQuality?.('small');
                ev.target.setVolume(volumeRef.current);
                if (mutedRef.current) ev.target.mute();
                else ev.target.unMute();
                ev.target.playVideo();
              } catch {
                // ignore
              }
            },
            onStateChange: (ev) => {
              if (cancelled) return;
              if (ev.data === 1) {
                // PLAYING
                consecutiveErrorsRef.current = 0;
                setPlaying(true);
                setPlayerNotice('');
                try {
                  ev.target.setPlaybackQuality?.('small');
                  const dur = ev.target.getDuration?.() || 0;
                  if (Number.isFinite(dur) && dur > 0) setAudioDurationSec(dur);
                } catch {
                  // ignore
                }
              } else if (ev.data === 2) {
                // PAUSED
                setPlaying(false);
              } else if (ev.data === 0) {
                // ENDED -> auto-advance to next track
                handleTrackEndedRef.current();
              }
            },
            onError: (ev) => {
              if (cancelled) return;
              handleTrackErrorSkipRef.current(ev.data);
            },
          },
        });
      })
      .catch(() => {
        if (!cancelled) {
          setUseFallbackIframe(true);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [active, currentTrack?.id, useFallbackIframe]);

  // Poll audio playback progress while modal is visible and audio is active
  useEffect(() => {
    if (!active || !open) return;
    const poll = () => {
      const p = ytPlayerRef.current;
      if (!p || !ytReadyRef.current) return;
      try {
        const cur = p.getCurrentTime?.() || 0;
        const dur = p.getDuration?.() || 0;
        if (Number.isFinite(cur) && cur >= 0) setAudioCurrentSec(cur);
        if (Number.isFinite(dur) && dur >= 0) setAudioDurationSec(dur);
      } catch {
        // ignore
      }
    };
    poll();
    const timer = window.setInterval(poll, 500);
    return () => window.clearInterval(timer);
  }, [active, open, currentTrack?.id]);

  useEffect(() => {
    if (!onStateChange) return;
    onStateChange({
      active,
      playing,
      title: currentTrack?.title || '',
      channel: currentTrack?.channel || '',
      thumbnail: currentTrack?.thumbnail,
    });
  }, [active, currentTrack?.channel, currentTrack?.thumbnail, currentTrack?.title, onStateChange, playing]);

  const handleTogglePlayPause = () => {
    if (!active) {
      consecutiveErrorsRef.current = 0;
      setPlayerNotice('');
      setSelectedTrack(currentTrack || null);
      setActive(true);
      setPlaying(true);
      return;
    }
    if (playing) {
      sendYtCommand('pauseVideo');
      setPlaying(false);
    } else {
      sendYtCommand('playVideo');
      setPlaying(true);
    }
  };

  const handleCancelMusic = () => {
    destroyYtPlayer();
    sendYtCommand('stopVideo');
    setPlaying(false);
    setActive(false);
    setSelectedTrack(null);
    setPlayerNotice('');
    consecutiveErrorsRef.current = 0;
    notifyToast('Reproducción de música cancelada.', 'info');
  };

  const handleNextTrack = () => {
    if (tracks.length === 0) return;
    consecutiveErrorsRef.current = 0;
    setPlayerNotice('');
    const next = pickNextPlayableTrack(currentIdx, tracks);
    const nextIdx = next ? next.idx : (currentIdx + 1) % tracks.length;
    setCurrentIdx(nextIdx);
    setSelectedTrack(tracks[nextIdx] || null);
    setActive(true);
    setPlaying(true);
  };

  const handlePrevTrack = () => {
    if (tracks.length === 0) return;
    consecutiveErrorsRef.current = 0;
    setPlayerNotice('');
    const prevIdx = (currentIdx - 1 + tracks.length) % tracks.length;
    setCurrentIdx(prevIdx);
    setSelectedTrack(tracks[prevIdx] || null);
    setActive(true);
    setPlaying(true);
  };

  useEffect(() => {
    if (!externalCommand || externalCommand.seq === lastCmdSeqRef.current) return;
    lastCmdSeqRef.current = externalCommand.seq;
    if (externalCommand.type === 'toggle') {
      handleTogglePlayPause();
    } else if (externalCommand.type === 'next') {
      handleNextTrack();
    } else if (externalCommand.type === 'prev') {
      handlePrevTrack();
    } else if (externalCommand.type === 'cancel') {
      handleCancelMusic();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalCommand]);

  const executeYouTubeSearch = async (
    rawQ: string,
    opts: { autoPlayFirst?: boolean; silentErrors?: boolean } = {}
  ) => {
    const clean = rawQ.trim();
    if (!clean) {
      if (!opts.silentErrors) {
        notifyToast('Escribe el nombre de una canción, artista o género musical.', 'warning');
      }
      return;
    }

    const normKey = clean.toLowerCase().replace(/\s+/g, ' ');
    const cached = searchCacheRef.current.get(normKey);
    if (cached && cached.items.length > 0) {
      lastFetchedKeyRef.current = normKey;
      setTracks(cached.items);
      if (opts.autoPlayFirst || !activeRef.current) {
        setCurrentIdx(0);
      }
      if (opts.autoPlayFirst) {
        consecutiveErrorsRef.current = 0;
        setPlayerNotice('');
        setSelectedTrack(cached.items[0] || null);
        setActive(true);
        setPlaying(true);
      }
      setSearchInfo(
        cached.curated
          ? `Mostrando emisoras compatibles para "${clean}"`
          : `${cached.items.length} resultados de YouTube para "${clean}"`
      );
      setLoading(false);
      setDebouncing(false);
      return;
    }

    // Cancel any previous in-flight search request so stale responses never overwrite newer results
    abortCtrlRef.current?.abort();
    const ctrl = new AbortController();
    abortCtrlRef.current = ctrl;

    setLoading(true);
    setDebouncing(false);

    const applyResults = (items: MusicTrack[], curated: boolean) => {
      lastFetchedKeyRef.current = normKey;
      if (!curated && items.length > 0) {
        if (searchCacheRef.current.size > 40) {
          const oldestKey = searchCacheRef.current.keys().next().value;
          if (oldestKey) searchCacheRef.current.delete(oldestKey);
        }
        searchCacheRef.current.set(normKey, { items, curated });
      }
      setTracks(items);
      if (opts.autoPlayFirst || !activeRef.current) {
        setCurrentIdx(0);
      }
      if (opts.autoPlayFirst && items[0]) {
        consecutiveErrorsRef.current = 0;
        setPlayerNotice('');
        setSelectedTrack(items[0]);
        setActive(true);
        setPlaying(true);
      }
      setSearchInfo(
        curated
          ? `Mostrando emisoras verificadas de respaldo para "${clean}"`
          : `${items.length} resultados de YouTube para "${clean}"`
      );
    };

    try {
      let resolvedItems: MusicTrack[] = [];
      let isCurated = false;

      // 1. Primary backend proxy (YouTube InnerTube JSON API + cache)
      try {
        const res = await fetch(`/api/music/search?q=${encodeURIComponent(clean)}`, {
          signal: ctrl.signal,
          headers: { Accept: 'application/json' },
        });
        const contentType = res.headers.get('content-type') || '';
        if (res.ok && contentType.includes('application/json')) {
          const data = (await res.json()) as {
            items?: MusicTrack[];
            curated?: boolean;
          };
          if (Array.isArray(data.items) && data.items.length > 0) {
            resolvedItems = data.items;
            isCurated = Boolean(data.curated);
          }
        }
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        // Fall through to client-side search fallback
      }

      if (ctrl.signal.aborted) return;

      // 2. Client-side direct CORS fallback (handles static hosting or transient proxy hiccups)
      if (resolvedItems.length === 0 || isCurated) {
        try {
          const directItems = await searchYouTubeClientFallback(clean, ctrl.signal);
          if (ctrl.signal.aborted) return;
          if (directItems.length > 0) {
            resolvedItems = directItems;
            isCurated = false;
          }
        } catch (err) {
          if (err instanceof DOMException && err.name === 'AbortError') return;
        }
      }

      if (ctrl.signal.aborted) return;

      if (resolvedItems.length > 0) {
        applyResults(resolvedItems, isCurated);
      } else {
        applyResults(DEFAULT_CURATED_TRACKS, true);
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      applyResults(DEFAULT_CURATED_TRACKS, true);
      if (!opts.silentErrors) {
        notifyToast('Se activaron emisoras de respaldo mientras se restablece la búsqueda de YouTube.', 'info');
      }
    } finally {
      if (abortCtrlRef.current === ctrl) {
        setLoading(false);
      }
    }
  };

  // Debounced live YouTube search (450ms) when typing rapidly
  useEffect(() => {
    if (debounceTimerRef.current !== null) {
      window.clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }

    if (skipNextDebounceRef.current) {
      skipNextDebounceRef.current = false;
      setDebouncing(false);
      return;
    }

    const clean = query.trim();
    const normKey = clean.toLowerCase().replace(/\s+/g, ' ');
    if (clean.length < 2) {
      setDebouncing(false);
      return;
    }
    if (normKey === lastFetchedKeyRef.current) {
      setDebouncing(false);
      return;
    }

    setDebouncing(true);
    debounceTimerRef.current = window.setTimeout(() => {
      debounceTimerRef.current = null;
      void executeYouTubeSearch(clean, { autoPlayFirst: false, silentErrors: true });
    }, 450);

    return () => {
      if (debounceTimerRef.current !== null) {
        window.clearTimeout(debounceTimerRef.current);
        debounceTimerRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  // Cleanup pending timer, abort controller, and YT player on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current !== null) {
        window.clearTimeout(debounceTimerRef.current);
      }
      abortCtrlRef.current?.abort();
      destroyYtPlayer();
    };
  }, []);

  const handleSearch = (rawQ: string) => {
    if (debounceTimerRef.current !== null) {
      window.clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }
    setDebouncing(false);
    void executeYouTubeSearch(rawQ, { autoPlayFirst: true, silentErrors: false });
  };

  const handleVolumeChange = (nextVol: number) => {
    setVolume(nextVol);
    setMuted(nextVol === 0);
    sendYtCommand('setVolume', [nextVol]);
    if (nextVol === 0) sendYtCommand('mute');
    else sendYtCommand('unMute');
  };

  const handleToggleMute = () => {
    const nextMuted = !muted;
    setMuted(nextMuted);
    sendYtCommand(nextMuted ? 'mute' : 'unMute');
  };

  const handleSeekAudio = (targetSec: number) => {
    setAudioCurrentSec(targetSec);
    try {
      if (ytPlayerRef.current && ytReadyRef.current && ytPlayerRef.current.seekTo) {
        ytPlayerRef.current.seekTo(targetSec, true);
        return;
      }
      sendYtCommand('seekTo', [targetSec, true]);
    } catch {
      // ignore seek errors
    }
  };

  const fallbackEmbedSrc =
    active && currentTrack && useFallbackIframe
      ? `https://www.youtube.com/embed/${currentTrack.id}?autoplay=1&enablejsapi=1&playsinline=1&controls=0&fs=0&rel=0`
      : '';

  const isLiveAudio =
    currentTrack?.duration === 'EN VIVO' || (active && playing && audioDurationSec === 0);

  return (
    <>
      {/* Headless Audio-Only Engine: permanently invisible, zero video displayed, prevents Chrome/Android suspension */}
      <div
        aria-hidden="true"
        className={
          active
            ? 'fixed bottom-0 right-0 z-0 w-[220px] h-[126px] opacity-[0.01] pointer-events-none overflow-hidden'
            : 'hidden'
        }
      >
        {active && currentTrack && (
          useFallbackIframe && fallbackEmbedSrc ? (
            <iframe
              ref={fallbackIframeRef}
              key={currentTrack.id}
              title={`Audio: ${currentTrack.title}`}
              src={fallbackEmbedSrc}
              referrerPolicy="strict-origin-when-cross-origin"
              allow="autoplay; encrypted-media"
              onLoad={() => {
                window.setTimeout(() => {
                  sendYtCommand('setVolume', [volume]);
                  if (muted) sendYtCommand('mute');
                }, 600);
              }}
              className="w-full h-full border-0"
            />
          ) : (
            <div ref={playerHostRef} className="w-full h-full" />
          )
        )}
      </div>

      {/* Audio-Only Modal UI (NO video player displayed) */}
      {open && (
        <div
          className={`fixed inset-0 z-[160] backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 transition-colors ${
            darkMode ? 'bg-black/80' : 'bg-slate-950/60'
          }`}
        >
          <div
            className={`rounded-3xl border max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl transition-colors duration-200 ${
              darkMode
                ? 'bg-slate-950 border-slate-800 text-slate-100'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            {/* Header */}
            <div
              className={`px-5 py-3.5 border-b flex items-center justify-between gap-2 transition-colors ${
                darkMode
                  ? 'border-slate-800 bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900'
                  : 'border-slate-200 bg-gradient-to-r from-sky-50 via-white to-cyan-50'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-9 h-9 rounded-xl text-white flex items-center justify-center shrink-0 ${
                    darkMode ? 'bg-sky-500/20 border border-sky-400/30 text-sky-300' : 'bg-sky-600'
                  }`}
                >
                  <Headphones className={`w-4 h-4 ${playing ? 'animate-pulse' : ''}`} />
                </div>
                <div className="min-w-0">
                  <h3
                    className={`text-sm font-extrabold truncate ${
                      darkMode ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    Reproductor de Audio del Local
                  </h3>
                  <p
                    className={`text-[11px] truncate ${
                      darkMode ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    Solo música y audio · Sin video · Sigue sonando al ocultar
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  role="switch"
                  aria-checked={darkMode}
                  onClick={toggleDarkMode}
                  className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
                    darkMode
                      ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-amber-300'
                      : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                  }`}
                  title={darkMode ? 'Cambiar reproductor a Modo Claro' : 'Activar Modo Oscuro del reproductor'}
                >
                  {darkMode ? (
                    <>
                      <Sun className="w-3.5 h-3.5 text-amber-300" />
                      <span className="hidden sm:inline">Modo Claro</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-3.5 h-3.5 text-indigo-600" />
                      <span className="hidden sm:inline">Modo Oscuro</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer transition-colors ${
                    darkMode
                      ? 'bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30'
                      : 'bg-sky-100 hover:bg-sky-200 text-sky-800'
                  }`}
                  title="Ocultar ventana y seguir escuchando música en segundo plano"
                >
                  <EyeOff className="w-3.5 h-3.5" /> Ocultar
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {/* Music Search Bar (with automatic 450ms debounce) */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSearch(query);
                }}
                className="flex gap-2"
              >
                <div className="relative flex-1">
                  <Search
                    className={`w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 ${
                      darkMode ? 'text-slate-500' : 'text-slate-400'
                    }`}
                  />
                  <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Buscar canción, artista o género musical (solo audio)..."
                    className={`w-full pl-9 pr-8 py-2.5 text-xs rounded-xl border focus:outline-none transition-colors ${
                      darkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-100 placeholder:text-slate-500 focus:border-sky-400'
                        : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-sky-400'
                    }`}
                  />
                  {query && (
                    <button
                      type="button"
                      onClick={() => {
                        skipNextDebounceRef.current = true;
                        abortCtrlRef.current?.abort();
                        setQuery('');
                        setDebouncing(false);
                        setLoading(false);
                        setSearchInfo('');
                      }}
                      className={`absolute right-2.5 top-1/2 -translate-y-1/2 cursor-pointer ${
                        darkMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-700'
                      }`}
                      aria-label="Limpiar búsqueda"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                  {loading ? 'Buscando...' : 'Buscar'}
                </button>
              </form>

              {/* Quick Genre Chips */}
              <div className="flex flex-wrap gap-1.5 text-[11px]">
                {[
                  'Jazz Café Instrumental',
                  'Lofi Chill Beats',
                  'Salsa Clásica Mix',
                  'Merengue Clásico',
                  'Pop Latino Mix',
                  'Música Relajante Tienda',
                ].map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => {
                      skipNextDebounceRef.current = true;
                      setQuery(g);
                      handleSearch(g);
                    }}
                    className={`px-2.5 py-1 rounded-lg font-semibold cursor-pointer transition-colors ${
                      darkMode
                        ? 'bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-sky-300'
                        : 'bg-slate-100 hover:bg-sky-50 hover:text-sky-700 text-slate-700'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>

              {(debouncing || loading || searchInfo) && (
                <p
                  className={`text-[11px] font-semibold px-3 py-1.5 rounded-xl border flex items-center gap-2 ${
                    darkMode
                      ? 'text-sky-300 bg-sky-950/60 border-sky-800/70'
                      : 'text-sky-700 bg-sky-50 border-sky-100'
                  }`}
                >
                  {(debouncing || loading) && <Loader2 className="w-3 h-3 animate-spin shrink-0" />}
                  <span>
                    {loading
                      ? `Buscando música para "${query.trim()}"...`
                      : debouncing
                      ? `Preparando búsqueda para "${query.trim()}"...`
                      : searchInfo}
                  </span>
                </p>
              )}

              {playerNotice && (
                <p
                  className={`text-[11px] font-semibold px-3 py-1.5 rounded-xl border flex items-center gap-2 ${
                    darkMode
                      ? 'text-amber-300 bg-amber-950/50 border-amber-800/70'
                      : 'text-amber-800 bg-amber-50 border-amber-200'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span>{playerNotice}</span>
                </p>
              )}

              {/* Audio-Only Now Playing Deck (No video screen) */}
              {currentTrack && (
                <div
                  className={`rounded-2xl border p-4 shadow-inner space-y-3 text-white ${
                    darkMode
                      ? 'border-slate-800 bg-gradient-to-br from-slate-900 via-black to-sky-950/70'
                      : 'border-slate-200 bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-slate-800 shrink-0 border border-white/10 shadow-md">
                      {currentTrack.thumbnail ? (
                        <img
                          src={currentTrack.thumbnail}
                          alt={currentTrack.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-sky-700">
                          <Music className="w-7 h-7 text-white" />
                        </div>
                      )}
                      {active && playing && (
                        <div className="absolute inset-0 bg-slate-950/45 flex items-end justify-center gap-1 pb-2.5">
                          <span className="w-1 h-3 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1 h-5 bg-cyan-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1 h-3.5 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                            active && playing
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                              : active
                              ? 'bg-amber-500/20 text-amber-200 border border-amber-400/30'
                              : 'bg-sky-500/20 text-sky-200 border border-sky-400/30'
                          }`}
                        >
                          {active && playing
                            ? isLiveAudio
                              ? 'Solo Audio · En Vivo'
                              : 'Solo Audio · Reproduciendo'
                            : active
                            ? 'Solo Audio · En Pausa'
                            : 'Modo Solo Audio'}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm font-extrabold text-white line-clamp-2 leading-snug">
                        {currentTrack.title}
                      </p>
                      <p className="text-[11px] text-slate-300 truncate mt-0.5">
                        {currentTrack.channel}
                      </p>
                    </div>
                  </div>

                  {/* Audio Progress & Seek Bar */}
                  {active ? (
                    <div className="space-y-1">
                      {audioDurationSec > 0 ? (
                        <>
                          <input
                            type="range"
                            min={0}
                            max={Math.floor(audioDurationSec)}
                            value={Math.min(Math.floor(audioCurrentSec), Math.floor(audioDurationSec))}
                            onChange={(e) => handleSeekAudio(Number(e.target.value))}
                            className="w-full h-1.5 accent-sky-400 cursor-pointer"
                            aria-label="Progreso del audio"
                          />
                          <div className="flex items-center justify-between text-[10px] font-mono text-slate-300">
                            <span>{formatAudioSeconds(audioCurrentSec)}</span>
                            <span>{formatAudioSeconds(audioDurationSec)}</span>
                          </div>
                        </>
                      ) : (
                        <div className="flex items-center justify-between text-[10px] font-mono text-sky-300 bg-white/5 rounded-lg px-2.5 py-1.5">
                          <span className="inline-flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${playing ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                            {playing ? 'Transmitiendo audio continuo' : 'Audio en pausa'}
                          </span>
                          <span>{currentTrack.duration || 'AUDIO'}</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          consecutiveErrorsRef.current = 0;
                          setPlayerNotice('');
                          setSelectedTrack(currentTrack);
                          setActive(true);
                          setPlaying(true);
                        }}
                        className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-md"
                      >
                        <Play className="w-3.5 h-3.5" /> Reproducir Audio
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Audio Transport Controls Bar */}
              <div
                className={`p-3 rounded-2xl border flex flex-wrap items-center justify-between gap-2 transition-colors ${
                  darkMode
                    ? 'bg-slate-900 border-slate-800'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handlePrevTrack}
                    className={`p-2 rounded-xl border cursor-pointer transition-colors ${
                      darkMode
                        ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                        : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                    title="Canción anterior"
                  >
                    <SkipBack className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={handleTogglePlayPause}
                    className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    {playing ? (
                      <>
                        <Pause className="w-4 h-4" /> Pausar
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" /> Reproducir
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleNextTrack}
                    className={`p-2 rounded-xl border cursor-pointer transition-colors ${
                      darkMode
                        ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                        : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                    title="Siguiente canción"
                  >
                    <SkipForward className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleToggleMute}
                    className={`p-1.5 rounded-lg cursor-pointer ${
                      darkMode ? 'text-slate-300 hover:bg-slate-800' : 'text-slate-600 hover:bg-slate-200'
                    }`}
                    title={muted ? 'Activar sonido' : 'Silenciar'}
                  >
                    {muted || volume === 0 ? (
                      <VolumeX className="w-4 h-4 text-rose-500" />
                    ) : (
                      <Volume2 className={`w-4 h-4 ${darkMode ? 'text-sky-400' : 'text-sky-600'}`} />
                    )}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={muted ? 0 : volume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="w-20 accent-sky-500 cursor-pointer"
                    aria-label="Volumen"
                  />
                </div>

                {active && (
                  <button
                    type="button"
                    onClick={handleCancelMusic}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-bold inline-flex items-center gap-1 cursor-pointer ${
                      darkMode
                        ? 'bg-rose-950/60 hover:bg-rose-900/60 border-rose-800 text-rose-300'
                        : 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700'
                    }`}
                    title="Detener y cancelar reproducción por completo"
                  >
                    <Square className="w-3 h-3 fill-current" /> Cancelar Música
                  </button>
                )}
              </div>

              {/* Search Results Playlist (Audio Tracks) */}
              <div
                className={`max-h-56 overflow-y-auto divide-y border rounded-2xl transition-colors ${
                  darkMode
                    ? 'divide-slate-800 border-slate-800 bg-slate-900/90'
                    : 'divide-slate-100 border-slate-200 bg-white'
                }`}
              >
                {tracks.map((t, i) => {
                  const isSelected = active && currentTrack?.id === t.id;
                  const isBlocked = Boolean(blockedIds[t.id]);
                  return (
                    <button
                      key={`${t.id}_${i}`}
                      type="button"
                      onClick={() => {
                        consecutiveErrorsRef.current = 0;
                        setPlayerNotice('');
                        setCurrentIdx(i);
                        setSelectedTrack(t);
                        setActive(true);
                        setPlaying(true);
                      }}
                      className={`w-full px-3 py-2 text-left text-xs flex items-center gap-2.5 cursor-pointer transition-colors ${
                        darkMode
                          ? isSelected
                            ? 'bg-sky-950/80 text-sky-100'
                            : 'hover:bg-slate-800/80 text-slate-200'
                          : isSelected
                          ? 'bg-sky-50 text-sky-950'
                          : 'hover:bg-slate-50 text-slate-800'
                      } ${isBlocked ? 'opacity-60' : ''}`}
                    >
                      <img
                        src={t.thumbnail || `https://i.ytimg.com/vi/${t.id}/mqdefault.jpg`}
                        alt=""
                        className={`w-10 h-10 rounded-xl object-cover shrink-0 ${
                          darkMode ? 'bg-slate-800' : 'bg-slate-200'
                        }`}
                        loading="lazy"
                      />
                      <div className="min-w-0 flex-1">
                        <p
                          className={`truncate ${
                            isSelected
                              ? darkMode
                                ? 'font-extrabold text-sky-300'
                                : 'font-extrabold text-sky-900'
                              : 'font-semibold'
                          }`}
                        >
                          {t.title}
                        </p>
                        <p className={`text-[10px] truncate ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {t.channel}
                        </p>
                      </div>
                      <span
                        className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-md shrink-0 ${
                          isBlocked
                            ? darkMode
                              ? 'bg-amber-950 text-amber-300'
                              : 'bg-amber-100 text-amber-800'
                            : isSelected && playing
                            ? 'bg-sky-600 text-white'
                            : darkMode
                            ? 'bg-slate-800 text-slate-300'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {isBlocked ? 'RESTRINGIDO' : isSelected && playing ? 'SONANDO' : t.duration || 'AUDIO'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div
              className={`px-5 py-3 border-t flex flex-wrap items-center justify-between gap-2 text-xs transition-colors ${
                darkMode
                  ? 'border-slate-800 bg-slate-900/90'
                  : 'border-slate-200 bg-slate-50'
              }`}
            >
              <span className={`text-[11px] ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {active
                  ? 'Usa "Ocultar" para seguir escuchando desde el ícono musical superior.'
                  : 'Selecciona o busca una canción para escuchar solo audio.'}
              </span>
              <div className="flex items-center gap-2">
                {active && (
                  <button
                    type="button"
                    onClick={() => {
                      handleCancelMusic();
                      onClose();
                    }}
                    className={`px-3.5 py-2 rounded-xl border font-semibold cursor-pointer ${
                      darkMode
                        ? 'border-rose-800 bg-rose-950/60 hover:bg-rose-900/60 text-rose-300'
                        : 'border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700'
                    }`}
                  >
                    Detener y Cerrar
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold cursor-pointer"
                >
                  {active ? 'Ocultar en 2do Plano' : 'Cerrar'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

/* ================= KEYBOARD SHORTCUTS MODAL ================= */
export const ShortcutsModal: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => {
  if (!open) return null;
  const rows = [
    ['F1', 'Ayuda y atajos rápidos'],
    ['F2', 'Enfocar buscador / lector de código'],
    ['F3', 'Abrir cámara escáner'],
    ['F4', 'Abrir control de Fiados'],
    ['F5', 'Alternar IVA 16%'],
    ['F6', 'Registrar reparación de motor'],
    ['F7', 'Abrir control de Taller'],
    ['F8', 'Cobrar carrito actual'],
    ['F9', 'Cerrar Turno / Caja'],
    ['F10', 'Abrir Administración'],
    ['F12', 'Cerrar sesión'],
  ];

  return (
    <div className="fixed inset-0 z-[155] bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Keyboard className="w-4 h-4 text-sky-600" />
            <h3 className="text-sm font-bold text-slate-900">Atajos de Teclado del POS</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 divide-y divide-slate-100 text-xs">
          {rows.map(([k, desc]) => (
            <div key={k} className="py-2 flex items-center justify-between">
              <span className="text-slate-700">{desc}</span>
              <kbd className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 font-mono font-bold text-slate-800">
                {k}
              </kbd>
            </div>
          ))}
        </div>
        <div className="px-4 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};

/* ================= SUPPORT MODAL (AI ASSISTANT + HUMAN ESCALATION + TICKETS) ================= */
interface SupportChatMessage {
  role: 'user' | 'assistant';
  text: string;
  escalated?: boolean;
  category?: string;
}

const QUICK_SUPPORT_PROMPTS = [
  'La impresora térmica no imprime',
  '¿Cómo actualizo la tasa BCV?',
  'Problema con fiados o abonos',
  '¿Cómo renuevo mi membresía por Pago Móvil?',
  'Error al cerrar la caja del turno',
];

export const SupportModal: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => {
  const {
    activeTenantId,
    activeTenant,
    authUser,
    localName,
    operatorName,
    operatorEmail,
    role,
    tickets,
    config,
    bcvRate,
    activePrinter,
    membershipDaysLeft,
    notifyToast,
    playBeep,
  } = usePos();

  const [tab, setTab] = useState<'ai' | 'ticket'>('ai');
  const [chatInput, setChatInput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [needsHumanAgent, setNeedsHumanAgent] = useState(false);
  const INITIAL_SUPPORT_GREETING: SupportChatMessage = {
    role: 'assistant',
    text: '¡Hola! Soy Innova Grup, tu Asistente Virtual de Soporte IA. Cuéntame qué error o duda tienes en el sistema y te guiaré paso a paso para solucionarlo. Si el caso requiere atención humana, te conectaré con un agente por WhatsApp o chat de soporte.',
  };
  const [chatMessages, setChatMessages] = useState<SupportChatMessage[]>([INITIAL_SUPPORT_GREETING]);

  const handleResetSupportChat = () => {
    setChatMessages([INITIAL_SUPPORT_GREETING]);
    setNeedsHumanAgent(false);
    setChatInput('');
    notifyToast('Conversación con Innova Grup restablecida.', 'info');
  };

  const handleClearSupportChat = () => {
    setChatMessages([]);
    setNeedsHumanAgent(false);
    setChatInput('');
    notifyToast('Historial de chat borrado.', 'info');
  };

  const [tipo, setTipo] = useState('Falla técnica');
  const [msg, setMsg] = useState('');
  const [sending, setSending] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, aiLoading, needsHumanAgent]);

  if (!open) return null;

  const myTickets = tickets.slice(0, 8);
  const primaryWa = (config.whatsapp_soporte || config.whatsapp_membresia || '584245655395').replace(
    /\D/g,
    ''
  );
  const secondaryWa = (config.whatsapp_soporte_secundario || '').replace(/\D/g, '');
  const scheduleNote = config.soporte_horario || 'Lun–Sáb 8:00 a.m. – 8:00 p.m.';

  const sendAiMessage = async (textOverride?: string) => {
    const clean = (textOverride ?? chatInput).trim();
    if (!clean || aiLoading) return;
    const nextHistory = [...chatMessages, { role: 'user' as const, text: clean }];
    setChatMessages(nextHistory);
    setChatInput('');
    setAiLoading(true);
    try {
      const res = await fetch('/api/support-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: clean,
          history: chatMessages.slice(-8).map((m) => ({ role: m.role, text: m.text })),
          context: {
            localName,
            role,
            bcvRate,
            activePrinter: activePrinter?.name || 'Ninguna',
            membershipDaysLeft,
          },
        }),
      });
      const data = (await res.json()) as {
        reply?: string;
        escalate_to_human?: boolean;
        suggested_category?: string;
      };
      const replyText =
        data.reply ||
        'En este momento no puedo continuar resolviendo este caso automáticamente. Un agente de soporte te contactará por WhatsApp o por el chat de soporte.';
      const escalate = Boolean(data.escalate_to_human);
      if (data.suggested_category) {
        setTipo(data.suggested_category);
      }
      if (escalate) {
        setNeedsHumanAgent(true);
      }
      setChatMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: replyText,
          escalated: escalate,
          category: data.suggested_category,
        },
      ]);
    } catch {
      setNeedsHumanAgent(true);
      setChatMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'No pude conectar con el asistente automático en este momento. Un agente de soporte te contactará por WhatsApp o por el chat de soporte.',
          escalated: true,
        },
      ]);
    } finally {
      setAiLoading(false);
    }
  };

  const submitTicketMessage = async (ticketBody: string, ticketType: string) => {
    if (!activeTenantId || !authUser) {
      notifyToast('Inicia sesión en un comercio para enviar un ticket.', 'warning');
      return false;
    }
    if (!ticketBody.trim()) {
      notifyToast('Describe el problema o consulta antes de enviar.', 'warning');
      return false;
    }
    setSending(true);
    try {
      const now = Date.now();
      const ticketId = `tk_${now}_${Math.random().toString(36).slice(2, 6)}`;
      const ownerUid = activeTenant?.ownerUid || authUser.uid;
      const payload = {
        tenantId: activeTenantId,
        tenantName: localName,
        ownerUid,
        t: now,
        usuario: operatorName || operatorEmail || authUser.email || 'Usuario POS',
        rol: role || 'cashier',
        tipo: ticketType,
        msg: ticketBody.trim().slice(0, 2000),
        err: null,
        estado: 'nuevo' as const,
      };
      const batch = writeBatch(db);
      batch.set(doc(db, 'tenants', activeTenantId, 'tickets', ticketId), payload);
      batch.set(doc(db, 'platform_tickets', ticketId), payload);
      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `platform_tickets/${ticketId}`);
      }
      playBeep('ok');
      notifyToast('Conversación enviada al Chat de Soporte. Un agente te atenderá pronto.', 'success');
      return true;
    } finally {
      setSending(false);
    }
  };

  const handleSubmitManual = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await submitTicketMessage(msg, tipo);
    if (ok) setMsg('');
  };

  const handleEscalateToChatTicket = async () => {
    const transcript = chatMessages
      .slice(-6)
      .map((m) => `${m.role === 'user' ? 'Cliente' : 'Asistente IA'}: ${m.text}`)
      .join('\n');
    const ok = await submitTicketMessage(
      `[Escalado desde Asistente IA]\n${transcript}`,
      tipo || 'Soporte Técnico'
    );
    if (ok) setTab('ticket');
  };

  const waSummaryText = encodeURIComponent(
    `Hola Soporte Innova Grup, necesito ayuda de un agente.\nComercio: ${localName}\nUsuario: ${
      operatorName || operatorEmail || 'Local'
    }\nConsulta: ${
      chatMessages
        .filter((m) => m.role === 'user')
        .slice(-2)
        .map((m) => m.text)
        .join(' | ') || 'Soporte técnico POS'
    }`
  );

  return (
    <div className="fixed inset-0 z-[155] bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full max-h-[88vh] flex flex-col overflow-hidden shadow-2xl">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-gradient-to-r from-sky-50 to-cyan-50 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs">
              <Headphones className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Soporte Inteligente Innova Grup</h3>
              <p className="text-[11px] text-slate-500">
                Asistente IA 24/7 + Escalamiento directo a Agente por WhatsApp y Chat
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher + Reset & Clear Chat Buttons */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-100 bg-white flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs">
            <button
              type="button"
              onClick={() => setTab('ai')}
              className={`px-3 py-1.5 rounded-lg font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
                tab === 'ai' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bot className="w-3.5 h-3.5" /> Innova Grup IA
            </button>
            <button
              type="button"
              onClick={() => setTab('ticket')}
              className={`px-3 py-1.5 rounded-lg font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
                tab === 'ticket'
                  ? 'bg-white text-sky-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageCircle className="w-3.5 h-3.5" /> Chat / Tickets ({myTickets.length})
            </button>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {tab === 'ai' && (
              <>
                <button
                  type="button"
                  onClick={handleResetSupportChat}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                  title="Restablecer conversación"
                >
                  <RotateCcw className="w-3 h-3" /> Restablecer
                </button>
                <button
                  type="button"
                  onClick={handleClearSupportChat}
                  className="px-2.5 py-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                  title="Borrar chat"
                >
                  <Trash2 className="w-3 h-3" /> Borrar chat
                </button>
              </>
            )}
            <button
              type="button"
              onClick={() => setNeedsHumanAgent(true)}
              className="px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" /> Hablar con Agente
            </button>
          </div>
        </div>

        {tab === 'ai' ? (
          <div className="flex-1 flex flex-col min-h-0">
            {/* Quick Prompts */}
            <div className="px-5 py-2.5 bg-slate-50/70 border-b border-slate-100 flex flex-wrap gap-1.5">
              {QUICK_SUPPORT_PROMPTS.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  disabled={aiLoading}
                  onClick={() => void sendAiMessage(prompt)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-sky-300 hover:bg-sky-50 text-[11px] font-medium text-slate-700 cursor-pointer"
                >
                  {prompt}
                </button>
              ))}
            </div>

            {/* Chat stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/40 text-xs">
              {chatMessages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 shadow-xs whitespace-pre-wrap leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-sky-600 text-white rounded-br-sm'
                        : 'bg-white border border-slate-200 text-slate-800 rounded-bl-sm'
                    }`}
                  >
                    {m.role === 'assistant' && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-sky-600 uppercase tracking-wider mb-1">
                        <Sparkles className="w-3 h-3" /> Asistente IA Innova
                      </span>
                    )}
                    <div>{m.text}</div>
                  </div>
                </div>
              ))}

              {aiLoading && (
                <div className="flex justify-start">
                  <div className="px-3.5 py-2.5 rounded-2xl bg-white border border-slate-200 text-slate-500 inline-flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-600" />
                    Analizando tu consulta...
                  </div>
                </div>
              )}

              {/* Human Escalation Card */}
              {needsHumanAgent && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-3">
                  <div className="flex items-start gap-2.5">
                    <Headphones className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-emerald-950 text-xs">
                        Un agente de soporte te contactará por WhatsApp o por el chat de soporte
                      </p>
                      <p className="text-[11px] text-emerald-800 mt-0.5">
                        Horario de atención humana: <b>{scheduleNote}</b>
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {primaryWa && (
                      <a
                        href={`https://wa.me/${primaryWa}?text=${waSummaryText}`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1.5"
                      >
                        <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Soporte Principal (+
                        {primaryWa})
                      </a>
                    )}
                    {secondaryWa && (
                      <a
                        href={`https://wa.me/${secondaryWa}?text=${waSummaryText}`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-2 rounded-xl bg-white border border-emerald-300 hover:bg-emerald-100 text-emerald-800 text-xs font-bold inline-flex items-center gap-1.5"
                      >
                        <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Alterno (+{secondaryWa})
                      </a>
                    )}
                    <button
                      type="button"
                      disabled={sending}
                      onClick={() => void handleEscalateToChatTicket()}
                      className="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      {sending ? 'Enviando...' : 'Enviar conversación al Chat de Soporte'}
                    </button>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Chat input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void sendAiMessage();
              }}
              className="p-3 border-t border-slate-200 bg-white flex items-center gap-2"
            >
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Describe el error o problema que tienes en el sistema..."
                className="flex-1 px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-400"
              />
              <button
                type="submit"
                disabled={aiLoading || !chatInput.trim()}
                className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" /> Enviar
              </button>
            </form>
          </div>
        ) : (
          <div className="p-5 space-y-4 overflow-y-auto text-xs flex-1">
            <form onSubmit={handleSubmitManual} className="space-y-3">
              <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              >
                <option value="Falla técnica">Falla técnica / Error en caja</option>
                <option value="Impresora / Escáner">Impresora térmica / Lector de barras</option>
                <option value="Tasas e inventario">Consulta de tasas / inventario</option>
                <option value="Membresía y pagos">Membresía y facturación</option>
                <option value="Sugerencia">Mejora o solicitud</option>
              </select>
              <textarea
                rows={3}
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                placeholder="Escribe directamente al Chat de Soporte de Innova Grup..."
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl"
              />
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-3">
                  {primaryWa && (
                    <a
                      href={`https://wa.me/${primaryWa}?text=${waSummaryText}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-emerald-700 font-bold hover:underline inline-flex items-center gap-1"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp (+{primaryWa})
                    </a>
                  )}
                  {secondaryWa && (
                    <a
                      href={`https://wa.me/${secondaryWa}?text=${waSummaryText}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-emerald-700 font-semibold hover:underline"
                    >
                      Alterno (+{secondaryWa})
                    </a>
                  )}
                </div>
                <button
                  type="submit"
                  disabled={sending}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold cursor-pointer"
                >
                  {sending ? 'Enviando...' : 'Enviar al Chat de Soporte'}
                </button>
              </div>
            </form>

            {myTickets.length > 0 && (
              <div className="border-t border-slate-200 pt-3 space-y-2">
                <p className="font-bold text-slate-600">Historial de Chat / Tickets</p>
                {myTickets.map((t) => (
                  <div
                    key={t.key}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5"
                  >
                    <div className="flex justify-between font-bold text-slate-800">
                      <span>{t.tipo}</span>
                      <span className="uppercase text-sky-700">{t.estado}</span>
                    </div>
                    <p className="text-slate-600 whitespace-pre-wrap">{t.msg}</p>
                    {t.resp &&
                      Object.values(t.resp).map((r, idx) => (
                        <p key={idx} className="text-emerald-700 font-semibold pt-1 border-t border-slate-200/70">
                          Respuesta ({r.de}): {r.msg}
                        </p>
                      ))}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
          <span className="text-[11px] text-slate-500">Horario agente: {scheduleNote}</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};

/* ================= MEMBERSHIP PAYMENT & LOCKSCREEN ================= */
interface MembershipModalProps {
  open: boolean;
  forcedLock?: boolean;
  onClose: () => void;
}

export const MembershipModal: React.FC<MembershipModalProps> = ({
  open,
  forcedLock = false,
  onClose,
}) => {
  const {
    activeTenantId,
    activeTenant,
    authUser,
    localName,
    config,
    plans,
    planLinks,
    promos,
    pagoMovil,
    membership,
    membershipDaysLeft,
    membershipExpired,
    membershipPayments,
    metodosPagoMembresia,
    operatorName,
    operatorEmail,
    notifyToast,
    playBeep,
    logout,
  } = usePos();

  const [selectedPlanKey, setSelectedPlanKey] = useState<string>(Object.keys(plans)[0] || 'p1');
  const [refNumber, setRefNumber] = useState('');
  const [captura, setCaptura] = useState<string>('');
  const [verifyingCapture, setVerifyingCapture] = useState(false);
  const [aiVerification, setAiVerification] = useState<PagoMovilVerificationResult | null>(null);
  const [sending, setSending] = useState(false);
  const [showPrePayWarning, setShowPrePayWarning] = useState(false);
  const [redirectedNotice, setRedirectedNotice] = useState(false);

  if (!open && !forcedLock) return null;

  const plan = plans[selectedPlanKey] || Object.values(plans)[0];
  const effPct = plan ? effectiveDiscountWithPromos(plan, promos) : 0;
  const bonus = plan ? bonusMonthsWithPromos(plan, promos) : 0;
  // Memberships are priced strictly in USD — NEVER calculated with the system BCV rate
  const finalUsd = plan ? round2(plan.precio * (1 - effPct / 100)) : 0;
  const waNumber = (config.whatsapp_membresia || '584245655395').replace(/\D/g, '');
  const rawPaymentLink = (planLinks[selectedPlanKey] || '').trim();
  const safePaymentLink = /^https?:\/\//i.test(rawPaymentLink) ? rawPaymentLink : '';

  const isPagoMovilActive = Boolean(
    pagoMovil &&
      pagoMovil.activo !== false &&
      (pagoMovil.tel || pagoMovil.banco || pagoMovil.ci || pagoMovil.titular)
  );
  const activeCustomMethods = metodosPagoMembresia.filter((m) => m.activo !== false);
  const hasManualPaymentOptions = isPagoMovilActive || activeCustomMethods.length > 0;

  const pmFields: Array<[string, string | undefined]> = isPagoMovilActive && pagoMovil
    ? [
        ['Banco', pagoMovil.banco],
        ['Teléfono', pagoMovil.tel],
        ['Cédula / RIF', pagoMovil.ci],
        ['Titular', pagoMovil.titular],
      ]
    : [];

  const runPagoMovilAiCheck = async (imgData: string, currentRef?: string) => {
    if (!imgData) return;
    setVerifyingCapture(true);
    try {
      const res = await fetch('/api/verify-pago-movil', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageDataUrl: imgData,
          expectedBs: 0,
          expectedUsd: finalUsd,
          expectedRef: (currentRef ?? refNumber).trim(),
          expectedBank: isPagoMovilActive ? pagoMovil?.banco || '' : '',
          expectedTel: isPagoMovilActive ? pagoMovil?.tel || '' : '',
          expectedCi: isPagoMovilActive ? pagoMovil?.ci || '' : '',
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as PagoMovilVerificationResult;
        setAiVerification(data);
        if (!refNumber.trim() && data.referencia_detectada) {
          setRefNumber(data.referencia_detectada);
        }
        if (data.es_comprobante_valido) {
          playBeep('ok');
          notifyToast('Comprobante pre-verificado correctamente.', 'success');
        } else {
          notifyToast(
            data.resumen || 'Comprobante leído. Será validado por el propietario.',
            'info'
          );
        }
      }
    } catch {
      setAiVerification({
        es_comprobante_valido: false,
        confianza: 0,
        coincide_monto: false,
        coincide_referencia: false,
        estado_sugerido: 'en_revision',
        resumen: 'Verificación automática no disponible. El propietario revisará tu captura manualmente.',
        verificado_en: Date.now(),
      });
    } finally {
      setVerifyingCapture(false);
    }
  };

  const buildWaConfirmUrl = (customRef?: string) => {
    if (!plan) return '#';
    const msg =
      `Hola Innova Grup, confirmo mi pago de membresía.\n` +
      `Comercio: ${localName}\n` +
      `Plan: ${plan.nombre}${bonus > 0 ? ` (+${bonus} mes(es) de regalo)` : ''}\n` +
      `Monto: $${finalUsd.toFixed(2)} USD\n` +
      (customRef ? `Referencia: ${customRef}\n` : '') +
      `Usuario: ${operatorName || operatorEmail || 'Local'}`;
    return `https://wa.me/${waNumber}?text=${encodeURIComponent(msg)}`;
  };

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanRef = refNumber.trim();
    if (!plan || cleanRef.length < 4) {
      notifyToast('Ingresa el número de referencia del pago (mínimo 4 caracteres).', 'warning');
      return;
    }
    if (!captura || captura.length < 20) {
      notifyToast('Debes subir la captura del comprobante de pago (Obligatorio).', 'error');
      playBeep('err');
      return;
    }
    if (!activeTenantId || !authUser) {
      notifyToast('No hay comercio activo vinculado.', 'warning');
      return;
    }
    setSending(true);
    try {
      const now = Date.now();
      const paymentId = `pay_${now}_${Math.random().toString(36).slice(2, 6)}`;
      const ownerUid = activeTenant?.ownerUid || authUser.uid;
      const payload: Record<string, unknown> = {
        tenantId: activeTenantId,
        tenantName: localName,
        ownerUid,
        t: now,
        plan: selectedPlanKey,
        nombre: plan.nombre,
        meses: plan.meses,
        bonus,
        usd: finalUsd,
        bs: 0,
        tasa: 0,
        ref: cleanRef,
        captura,
        usuario: operatorName || operatorEmail || authUser.email || 'Local',
        estado: 'pendiente' as const,
      };
      if (aiVerification) {
        payload.verificacion_ia = aiVerification;
      }
      const batch = writeBatch(db);
      batch.set(doc(db, 'tenants', activeTenantId, 'membership_payments', paymentId), payload);
      batch.set(doc(db, 'platform_payments', paymentId), payload);
      await batch.commit();

      setRefNumber('');
      setCaptura('');
      setAiVerification(null);
      playBeep('ok');
      notifyToast('Comprobante enviado. El propietario lo revisará y aprobará en breve.', 'success');
      if (!forcedLock) onClose();
    } catch {
      playBeep('err');
      notifyToast(
        'No se pudo guardar el reporte en la nube. Verifica tu conexión o confirma por WhatsApp.',
        'error'
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[190] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl border border-slate-200 max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <Crown className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="min-w-0">
              <h3 className="text-sm font-bold truncate">
                {membershipExpired ? 'Membresía Vencida · Renovar Licencia' : 'Membresía Innova Grup'}
              </h3>
              <p className="text-[11px] text-slate-300 truncate">
                {membership?.vence
                  ? `Plan: ${membership.nombre || 'Activo'} · Días disponibles: ${membershipDaysLeft} · Vence: ${new Date(
                      membership.vence
                    ).toLocaleDateString('es-VE')}`
                  : `Días disponibles: ${membershipDaysLeft} · Selecciona un plan para contratar`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
              title="Recargar y verificar estado"
            >
              <RotateCw className="w-3 h-3" /> Recargar
            </button>
            {!forcedLock ? (
              <button
                type="button"
                onClick={onClose}
                className="text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void logout()}
                className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-semibold cursor-pointer"
              >
                Salir
              </button>
            )}
          </div>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {membershipExpired && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2 font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              El acceso de caja está pausado hasta confirmar la renovación de la licencia.
            </div>
          )}

          {promos.filter((p) => p.activo).length > 0 && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900">
              <b>Promociones vigentes:</b>{' '}
              {promos
                .filter((p) => p.activo)
                .map((p) => `${p.nombre} (${describePromo(p)})`)
                .join(' · ')}
            </div>
          )}

          {/* Plan Selection Grid (USD only — no BCV calculation) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {Object.entries(plans).map(([k, pl]) => {
              const eff = effectiveDiscountWithPromos(pl, promos);
              const usd = round2(pl.precio * (1 - eff / 100));
              const b = bonusMonthsWithPromos(pl, promos);
              const hasLink = /^https?:\/\//i.test((planLinks[k] || '').trim());
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => {
                    setSelectedPlanKey(k);
                    setRedirectedNotice(false);
                  }}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                    selectedPlanKey === k
                      ? 'border-sky-600 bg-sky-50 ring-2 ring-sky-200'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <p className="font-bold text-slate-900 truncate">{pl.nombre}</p>
                  <p className="font-mono tabular-nums font-extrabold text-sky-700 text-base mt-0.5">
                    ${usd.toFixed(2)} <span className="text-[10px] font-semibold">USD</span>
                  </p>
                  <p className="text-[10px] text-slate-500">
                    {pl.meses} {pl.meses === 1 ? 'mes' : 'meses'}
                    {b > 0 ? ` + ${b} gratis` : ''}
                  </p>
                  {hasLink && (
                    <p className="text-[10px] text-emerald-700 font-bold mt-1">
                      Pago directo en línea
                    </p>
                  )}
                </button>
              );
            })}
          </div>

          {/* Selected Plan Summary + Direct Payment Link CTA */}
          {plan && (
            <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-sky-300">
                    Plan Seleccionado
                  </p>
                  <p className="text-sm font-extrabold text-white">
                    {plan.nombre} · {plan.meses} {plan.meses === 1 ? 'mes' : 'meses'}
                    {bonus > 0 ? ` (+${bonus} mes gratis)` : ''}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-400">Monto del plan</p>
                  <p className="text-lg font-extrabold font-mono tabular-nums text-emerald-400">
                    ${finalUsd.toFixed(2)} USD
                  </p>
                </div>
              </div>

              {safePaymentLink ? (
                <button
                  type="button"
                  onClick={() => setShowPrePayWarning(true)}
                  className="w-full py-3 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-xs sm:text-sm inline-flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  Pagar Plan ahora (${finalUsd.toFixed(2)} USD)
                </button>
              ) : (
                <p className="text-[11px] text-slate-300">
                  Este plan no tiene un enlace de pago directo configurado todavía. Usa los métodos
                  habilitados abajo o confirma por WhatsApp.
                </p>
              )}

              {redirectedNotice && safePaymentLink && (
                <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-400/40 text-amber-100 text-[11px] flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-bold text-white">
                      Pasarela de pago abierta — No salgas de la pantalla de pago hasta que tu pago
                      sea confirmado.
                    </p>
                    <a
                      href={safePaymentLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-sky-300 hover:text-sky-200 font-bold underline"
                    >
                      <ExternalLink className="w-3 h-3" /> Reabrir enlace de pago
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Pago Móvil Data — ONLY visible when activated by Owner */}
          {isPagoMovilActive && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <p className="font-bold text-slate-900">
                  Datos Bancarios y Pago Móvil del Propietario
                </p>
                <span className="font-mono tabular-nums font-bold text-emerald-700">
                  ${finalUsd.toFixed(2)} USD
                </span>
              </div>

              <div className="space-y-1.5">
                {pmFields.map(([label, val]) =>
                  val ? (
                    <div
                      key={label}
                      className="flex items-center justify-between gap-2 bg-white border border-slate-200 rounded-lg px-3 py-2"
                    >
                      <span className="text-slate-500 w-24 shrink-0">{label}</span>
                      <span className="font-mono font-bold text-slate-900 flex-1 break-all">
                        {val}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard?.writeText(val);
                          notifyToast(`${label} copiado: ${val}`, 'info');
                        }}
                        className="px-2 py-1 rounded bg-sky-50 hover:bg-sky-100 text-sky-700 font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                        title={`Copiar ${label}`}
                      >
                        <Copy className="w-3 h-3" /> Copiar
                      </button>
                    </div>
                  ) : null
                )}
              </div>
            </div>
          )}

          {/* Additional Owner Payment Methods — ONLY active ones */}
          {activeCustomMethods.length > 0 && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <p className="font-bold text-slate-900">Otros Métodos de Pago Disponibles</p>
              <div className="space-y-2">
                {activeCustomMethods.map((m) => (
                  <div
                    key={m.id}
                    className="p-2.5 rounded-lg bg-white border border-slate-200 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 text-white text-[10px] font-bold uppercase shrink-0">
                          {m.tipo.replace('_', ' ')}
                        </span>
                        <span className="font-bold text-slate-900 truncate">{m.titulo}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const full = [m.titulo, m.detalle, m.titular, m.documento]
                            .filter(Boolean)
                            .join(' | ');
                          navigator.clipboard?.writeText(full);
                          notifyToast(`Datos de ${m.titulo} copiados.`, 'info');
                        }}
                        className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <Copy className="w-3 h-3" /> Copiar todo
                      </button>
                    </div>
                    <div className="flex items-center justify-between gap-2 bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5">
                      <span className="font-mono font-bold text-slate-900 break-all">
                        {m.detalle}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard?.writeText(m.detalle);
                          notifyToast(`Copiado: ${m.detalle}`, 'info');
                        }}
                        className="px-2 py-0.5 rounded bg-sky-50 hover:bg-sky-100 text-sky-700 font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <Copy className="w-3 h-3" /> Copiar
                      </button>
                    </div>
                    {(m.titular || m.documento) && (
                      <p className="text-[11px] text-slate-500">
                        {m.titular ? `Titular: ${m.titular}` : ''}{' '}
                        {m.documento ? `· ${m.documento}` : ''}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Manual Proof Upload Form (only when Pago Móvil or another manual payment method is enabled) */}
          {hasManualPaymentOptions && (
            <form onSubmit={handleSubmitPayment} className="space-y-3">
              <div className="p-3 rounded-xl bg-sky-50/70 border border-sky-200 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-sky-950 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-sky-600" />
                    Reportar Comprobante de Pago Manual
                  </p>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-100 text-rose-700">
                    Captura obligatoria *
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    inputMode="numeric"
                    value={refNumber}
                    onChange={(e) => setRefNumber(e.target.value)}
                    placeholder="Número de referencia *"
                    className="px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono font-bold"
                  />
                  <label
                    className={`px-3 py-2 rounded-xl border-2 border-dashed flex items-center gap-2 cursor-pointer transition-colors ${
                      captura
                        ? 'border-emerald-400 bg-emerald-50 text-emerald-800'
                        : 'border-rose-300 bg-white hover:bg-rose-50/40 text-slate-700'
                    }`}
                  >
                    <Upload className={`w-4 h-4 ${captura ? 'text-emerald-600' : 'text-rose-500'}`} />
                    <span className="font-semibold truncate">
                      {captura ? 'Captura cargada ✓ (Cambiar)' : 'Subir captura del pago *'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={async (e) => {
                        const f = e.target.files?.[0];
                        if (f) {
                          const compressed = await compressImageFile(f);
                          setCaptura(compressed);
                          setAiVerification(null);
                          void runPagoMovilAiCheck(compressed);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                </div>

                {captura && (
                  <div className="space-y-2 pt-1">
                    <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                      <img
                        src={captura}
                        alt="Vista previa comprobante"
                        className="h-28 w-28 rounded-lg border border-slate-200 object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0 space-y-1.5 text-[11px]">
                        {verifyingCapture ? (
                          <div className="flex items-center gap-2 text-sky-700 font-bold">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Verificando comprobante...
                          </div>
                        ) : aiVerification ? (
                          <>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span
                                className={`px-2 py-0.5 rounded-md font-bold inline-flex items-center gap-1 ${
                                  aiVerification.es_comprobante_valido
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {aiVerification.es_comprobante_valido ? (
                                  <CheckCircle2 className="w-3 h-3" />
                                ) : (
                                  <AlertTriangle className="w-3 h-3" />
                                )}
                                {aiVerification.es_comprobante_valido
                                  ? `Verificado (${Math.round(aiVerification.confianza)}%)`
                                  : 'Pendiente validación manual'}
                              </span>
                              {aiVerification.referencia_detectada && (
                                <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">
                                  Ref: {aiVerification.referencia_detectada}
                                </span>
                              )}
                            </div>
                            <p className="text-slate-600">{aiVerification.resumen}</p>
                          </>
                        ) : (
                          <p className="text-slate-500">
                            Captura lista. Puedes re-verificar o enviar directamente al propietario.
                          </p>
                        )}
                        <button
                          type="button"
                          disabled={verifyingCapture}
                          onClick={() => void runPagoMovilAiCheck(captura, refNumber)}
                          className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3" /> Re-verificar comprobante
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={sending || verifyingCapture || !captura}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer"
              >
                {sending
                  ? 'Enviando comprobante...'
                  : !captura
                  ? 'Sube la captura del pago para enviar'
                  : 'Enviar Comprobante de Pago al Propietario'}
              </button>
            </form>
          )}

          {membershipPayments.length > 0 && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <p className="font-bold text-slate-700">Mis Pagos Enviados</p>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {membershipPayments.slice(0, 5).map((p) => (
                  <div
                    key={p.key}
                    className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-[11px]"
                  >
                    <div className="min-w-0">
                      <span className="font-bold text-slate-800">{p.nombre}</span>{' '}
                      <span className="font-mono text-slate-500">· Ref {p.ref}</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-md font-bold uppercase text-[10px] shrink-0 ${
                        p.estado === 'aprobado'
                          ? 'bg-emerald-100 text-emerald-800'
                          : p.estado === 'en_revision'
                          ? 'bg-sky-100 text-sky-800'
                          : p.estado === 'rechazado'
                          ? 'bg-rose-100 text-rose-700'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {p.estado === 'en_revision' ? 'En Revisión' : p.estado}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="pt-1">
            <a
              href={buildWaConfirmUrl(refNumber.trim() || undefined)}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold inline-flex items-center justify-center gap-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5" /> Ya pagué · Confirmar por WhatsApp
            </a>
          </div>

          {!forcedLock && (
            <div className="pt-2 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cerrar / Atrás
              </button>
            </div>
          )}
        </div>

        {/* Pre-Payment Mandatory Warning Overlay before redirecting to Owner's Payment Link */}
        {showPrePayWarning && plan && safePaymentLink && (
          <div className="absolute inset-0 z-20 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-5">
            <div className="w-full max-w-md rounded-2xl bg-white border border-amber-300 shadow-2xl overflow-hidden">
              <div className="bg-amber-500 text-slate-950 px-5 py-3.5 flex items-center gap-2.5">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h4 className="text-sm font-extrabold">
                  Aviso Importante Antes de Continuar a Pagar
                </h4>
              </div>

              <div className="p-5 space-y-4 text-xs">
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 space-y-1.5">
                  <p className="text-sm font-extrabold text-slate-950 leading-snug">
                    No salgas de la pantalla de pago hasta que tu pago sea confirmado.
                  </p>
                  <p className="text-xs text-amber-900 leading-relaxed">
                    Al presionar continuar serás redirigido automáticamente al enlace de pago oficial
                    del plan <b>{plan.nombre}</b> (
                    <span className="font-mono font-bold">${finalUsd.toFixed(2)} USD</span>). Mantén
                    abierta la pantalla hasta ver la confirmación completa del pago.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <button
                    type="button"
                    onClick={() => setShowPrePayWarning(false)}
                    className="sm:flex-1 py-2.5 px-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <a
                    href={safePaymentLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      setShowPrePayWarning(false);
                      setRedirectedNotice(true);
                      playBeep('ok');
                    }}
                    className="sm:flex-1 py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs inline-flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Continuar a pagar
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
