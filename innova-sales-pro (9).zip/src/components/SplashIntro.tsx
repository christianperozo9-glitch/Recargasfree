import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Sparkles } from 'lucide-react';
import { InnovaLogo } from './InnovaLogo';

interface SplashIntroProps {
  ready: boolean;
  onFinish: () => void;
}

export const SplashIntro: React.FC<SplashIntroProps> = ({ ready, onFinish }) => {
  const [stageReady, setStageReady] = useState(false);
  const [visible, setVisible] = useState(true);
  const [stalled, setStalled] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setStageReady(true), 550);
    const tSlow = setTimeout(() => setStalled(true), 10_000);
    return () => {
      clearTimeout(t1);
      clearTimeout(tSlow);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const t2 = setTimeout(() => {
      setVisible(false);
      setTimeout(onFinish, 360);
    }, 1350);
    return () => clearTimeout(t2);
  }, [ready, onFinish]);

  const handleSkip = () => {
    if (!ready) return;
    setVisible(false);
    setTimeout(onFinish, 240);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.015 }}
          transition={{ duration: 0.36, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-[200] flex flex-col items-center justify-center px-6 select-none overflow-hidden bg-[#f7fbff] text-slate-900"
        >
          {/* Luminous soft pastel ambient halos */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <motion.div
              animate={{ x: [0, 26, 0], y: [0, -18, 0], scale: [1, 1.08, 1] }}
              transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -top-28 -left-24 w-[420px] h-[420px] rounded-full bg-sky-200/55 blur-3xl"
            />
            <motion.div
              animate={{ x: [0, -24, 0], y: [0, 22, 0], scale: [1, 1.06, 1] }}
              transition={{ duration: 11, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -bottom-32 -right-24 w-[460px] h-[460px] rounded-full bg-cyan-100/75 blur-3xl"
            />
            <motion.div
              animate={{ scale: [1, 1.12, 1], opacity: [0.35, 0.55, 0.35] }}
              transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full bg-emerald-100/35 blur-3xl"
            />
          </div>

          <div className="relative z-10 flex flex-col items-center max-w-sm w-full text-center">
            {/* Floating glass emblem with soft expanding light ripples */}
            <motion.div
              initial={{ scale: 0.86, opacity: 0, y: 12 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
              className="relative mb-7 flex items-center justify-center"
            >
              <motion.div
                animate={{ scale: [1, 1.48], opacity: [0.55, 0] }}
                transition={{ duration: 2.4, repeat: Infinity, ease: [0.16, 1, 0.3, 1] }}
                className="absolute w-24 h-24 rounded-[28px] border border-sky-300/80"
              />
              <motion.div
                animate={{ scale: [1, 1.72], opacity: [0.35, 0] }}
                transition={{ duration: 2.4, delay: 0.65, repeat: Infinity, ease: [0.16, 1, 0.3, 1] }}
                className="absolute w-24 h-24 rounded-[28px] border border-cyan-300/60"
              />
              <motion.div
                animate={{ y: [0, -4, 0] }}
                transition={{ duration: 3.6, repeat: Infinity, ease: 'easeInOut' }}
                className="relative p-3 rounded-[26px] bg-white/95 border border-sky-100 shadow-[0_20px_50px_-18px_rgba(14,165,233,0.32)]"
              >
                <InnovaLogo size={64} />
              </motion.div>
            </motion.div>

            {/* Brand Title */}
            <motion.div
              initial={{ y: 14, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
              className="mb-7"
            >
              <div className="text-[26px] font-extrabold tracking-[0.2em] text-slate-900">
                INNOVA <span className="text-sky-600">GRUP</span>
              </div>
              <p className="text-xs text-slate-500 mt-1.5 font-medium tracking-wide">
                Plataforma Comercial & Punto de Venta Inteligente
              </p>
            </motion.div>

            {/* Sleek Glass Status Card */}
            <motion.div
              initial={{ y: 16, opacity: 0, scale: 0.98 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-[300px] bg-white/85 backdrop-blur-xl rounded-2xl border border-sky-100/90 shadow-[0_14px_34px_-16px_rgba(15,23,42,0.12)] px-5 py-4 space-y-3"
            >
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="inline-flex items-center gap-1.5 text-slate-700">
                  {ready && stageReady ? (
                    <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-600 inline-flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </span>
                  ) : (
                    <Sparkles className="w-3.5 h-3.5 text-sky-500" />
                  )}
                  {ready
                    ? stageReady
                      ? 'Sistema sincronizado'
                      : 'Preparando entorno'
                    : 'Conectando en la nube'}
                </span>
                <span className="font-mono tabular-nums text-[11px] text-sky-600 font-bold">
                  {ready && stageReady ? '100%' : stageReady ? '78%' : '45%'}
                </span>
              </div>

              {/* Luminous Progress Ribbon */}
              <div className="w-full h-2 bg-sky-100/80 rounded-full overflow-hidden relative">
                <motion.div
                  initial={{ scaleX: 0.15 }}
                  animate={{ scaleX: ready && stageReady ? 1 : stageReady ? 0.78 : 0.45 }}
                  transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
                  style={{ transformOrigin: 'left center' }}
                  className="w-full h-full bg-gradient-to-r from-sky-400 via-sky-500 to-cyan-400 rounded-full relative overflow-hidden"
                >
                  <div className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-shimmer" />
                </motion.div>
              </div>

              <p className="text-[11px] text-slate-500">
                {ready
                  ? stageReady
                    ? 'Todo listo · Iniciando tu espacio comercial...'
                    : 'Verificando catálogo, tasas y permisos...'
                  : 'Estableciendo conexión segura en tiempo real...'}
              </p>
            </motion.div>

            {ready ? (
              <motion.button
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35, duration: 0.3 }}
                type="button"
                onClick={handleSkip}
                className="mt-6 px-5 py-2 rounded-xl bg-white hover:bg-sky-50 border border-sky-200/80 text-xs font-semibold text-sky-700 shadow-xs transition-all cursor-pointer btn-press"
              >
                Entrar ahora
              </motion.button>
            ) : (
              stalled && (
                <button
                  type="button"
                  onClick={() => window.location.reload()}
                  className="mt-6 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                >
                  Tardó en conectar · Recargar página
                </button>
              )
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
