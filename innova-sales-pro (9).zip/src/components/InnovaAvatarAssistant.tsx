import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import {
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  Lock,
  Mail,
  MessageSquare,
  RotateCcw,
  Send,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { db, hashPin, loginWithEmail } from '../lib/firebase';
import type { TenantRecord } from '../types/pos';
import innovaAvatarImg from '../assets/images/innova_assistant_avatar_1795489643576.jpg';

interface AssistantMessage {
  id: string;
  role: 'assistant' | 'user';
  text: string;
  ts: number;
  suggestVerification?: boolean;
}

interface VerifiedAccountSummary {
  nombre_local: string;
  razon_social: string;
  email: string;
  rif: string;
  contacto_nombre: string;
  telefono: string;
  estado_cuenta: string;
  membresia_plan: string;
  membresia_estado: string;
  dias_restantes: number | null;
  verificacion_pendiente: boolean;
  documentos_pendientes: string[];
  seniat_modo_fiscal: boolean;
}

interface InnovaAvatarAssistantProps {
  contextMode?: 'portal' | 'pos';
  activeTenant?: TenantRecord | null;
  seniatActive?: boolean;
  externalOpen?: boolean;
  onExternalOpen?: () => void;
  onExternalClose?: () => void;
  hideFloatingButton?: boolean;
}

const WELCOME_PORTAL =
  '¡Hola! Soy el Asistente Virtual de Innova Grup. Puedo guiarte sobre cómo iniciar sesión, registrar tu negocio o responder tus dudas. Para asesoría rápida solo ingresa tu correo (sin Google), y si necesitas consultar datos privados de tu cuenta validaremos tu contraseña y PIN de Administrador. ¿En qué te ayudo hoy?';

const WELCOME_POS =
  '¡Hola! Soy Innova Grup, tu Asistente Virtual IA. Puedo ayudarte con facturación SENIAT, impresoras térmicas, tasas BCV, inventario o cierre de caja. Si deseas consultar datos privados de tu comercio, desbloquéalos con tu contraseña y PIN de Administrador. ¿Qué necesitas?';

function isValidEmailFormat(raw: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw.trim().toLowerCase());
}

function buildSanitizedAccount(
  tenant: TenantRecord,
  seniatActive = false
): VerifiedAccountSummary {
  const now = Date.now();
  const vence = Number(tenant.membresia?.vence || 0);
  const diasRestantes =
    vence > 0 ? Math.ceil((vence - now) / (1000 * 60 * 60 * 24)) : null;
  const estadoCuenta = !tenant.activo
    ? 'Inactiva'
    : tenant.congelado
    ? 'Congelada / Restringida'
    : tenant.mantenimiento
    ? 'En mantenimiento'
    : 'Activa y operativa';

  const verifCfg = tenant.verificacion_datos;
  const pendingDocs: string[] = [];
  if (verifCfg?.activo) {
    Object.entries(verifCfg.requisitos || {}).forEach(([k, enabled]) => {
      if (enabled) pendingDocs.push(k.replace(/_/g, ' '));
    });
    (verifCfg.requisitos_personalizados || []).forEach((c) => {
      if (c.activo) pendingDocs.push(c.label);
    });
  }

  return {
    nombre_local: tenant.nombre_local || 'Comercio',
    razon_social: tenant.razon_social || tenant.nombre_local || '',
    email: tenant.email || '',
    rif: tenant.rif || '',
    contacto_nombre: tenant.contacto_nombre || '',
    telefono: tenant.telefono || '',
    estado_cuenta: estadoCuenta,
    membresia_plan: tenant.membresia?.nombre || tenant.membresia?.plan || 'Estándar',
    membresia_estado: tenant.membresia?.estado === 'suspendida' ? 'Suspendida' : 'Activa',
    dias_restantes: diasRestantes,
    verificacion_pendiente: Boolean(verifCfg?.activo),
    documentos_pendientes: pendingDocs.slice(0, 8),
    seniat_modo_fiscal: seniatActive,
  };
}

export const InnovaAvatarAssistant: React.FC<InnovaAvatarAssistantProps> = ({
  contextMode = 'portal',
  activeTenant = null,
  seniatActive = false,
  externalOpen,
  onExternalOpen,
  onExternalClose,
  hideFloatingButton = false,
}) => {
  const [internalOpen, setInternalOpen] = useState(false);
  const isOpen = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = (next: boolean) => {
    if (externalOpen !== undefined) {
      if (next) onExternalOpen?.();
      else onExternalClose?.();
    } else {
      setInternalOpen(next);
    }
  };

  const makeGreeting = (): AssistantMessage => ({
    id: `greet_${Date.now()}`,
    role: 'assistant',
    text: contextMode === 'portal' ? WELCOME_PORTAL : WELCOME_POS,
    ts: Date.now(),
  });

  const [messages, setMessages] = useState<AssistantMessage[]>(() => [makeGreeting()]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [avatarBroken, setAvatarBroken] = useState(false);

  // 2-Tier Verification (NO Google Sign-In):
  // Tier 1: Email-only confirmation for general personalized advisory (private data remains locked)
  // Tier 2: Account Password + Admin PIN to unlock private tenant details
  const [showVerifyBox, setShowVerifyBox] = useState(false);
  const [verifyMode, setVerifyMode] = useState<'email_only' | 'private_gate'>('email_only');
  const [emailInput, setEmailInput] = useState('');
  const [confirmedEmail, setConfirmedEmail] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [adminPinInput, setAdminPinInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [verifyLoading, setVerifyLoading] = useState(false);
  const [verifyError, setVerifyError] = useState('');
  const [verifiedAccount, setVerifiedAccount] = useState<VerifiedAccountSummary | null>(null);

  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading, showVerifyBox, isOpen]);

  // If already in POS with an activeTenant, pre-fill their email for convenience
  // while keeping private account data locked until Password + Admin PIN are confirmed.
  useEffect(() => {
    if (contextMode === 'pos' && activeTenant?.email && !emailInput) {
      setEmailInput(activeTenant.email);
      setConfirmedEmail(activeTenant.email.toLowerCase());
    }
  }, [activeTenant?.email, contextMode, emailInput]);

  const handleResetConversation = () => {
    setMessages([makeGreeting()]);
    setInput('');
    setVerifyError('');
  };

  const handleClearChat = () => {
    setMessages([]);
    setInput('');
    setVerifyError('');
  };

  const handleLockVerification = () => {
    setVerifiedAccount(null);
    setPasswordInput('');
    setAdminPinInput('');
    setVerifyMode('email_only');
    setVerifyError('');
  };

  // Tier 1: Email-only verification (NO Google Sign-In popup)
  const handleConfirmEmailOnly = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = emailInput.trim().toLowerCase();
    if (!isValidEmailFormat(cleanEmail)) {
      setVerifyError('Ingresa un correo electrónico válido (ej. tucomercio@ejemplo.com).');
      return;
    }
    setConfirmedEmail(cleanEmail);
    setVerifyError('');
    setShowVerifyBox(false);
    setMessages((prev) => [
      ...prev,
      {
        id: `email_ok_${Date.now()}`,
        role: 'assistant',
        text: `¡Listo! He vinculado tu correo (${cleanEmail}) sin necesidad de Google para asesorarte. Recuerda que tus datos privados (membresía, RIF, días restantes o documentos) permanecen protegidos: cuando desees consultarlos, solo presiona "Desbloquear datos privados" e ingresa tu contraseña y PIN de Administrador.`,
        ts: Date.now(),
      },
    ]);
  };

  // Tier 2: Unlock Private Account Data with Email + Account Password + Admin PIN
  const handleUnlockPrivateData = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = (emailInput || confirmedEmail).trim().toLowerCase();
    const cleanPassword = passwordInput;
    const cleanPin = adminPinInput.trim();

    if (!isValidEmailFormat(cleanEmail)) {
      setVerifyError('Ingresa el correo electrónico afiliado a tu negocio.');
      return;
    }
    if (!cleanPassword || cleanPassword.length < 4) {
      setVerifyError('Ingresa la contraseña de tu cuenta para validar el acceso.');
      return;
    }
    if (!cleanPin || cleanPin.length < 4) {
      setVerifyError('Ingresa tu PIN de Administrador (mínimo 4 dígitos).');
      return;
    }

    setVerifyError('');
    setVerifyLoading(true);
    try {
      // Authenticate via Email/Password (no Google Sign-In) so Firestore rules authorize reading ONLY this owner's tenant
      const signedUser = await loginWithEmail(cleanEmail, cleanPassword);

      let foundTenant: TenantRecord | null = null;
      if (activeTenant && activeTenant.email?.toLowerCase() === cleanEmail) {
        foundTenant = activeTenant;
      } else {
        // Query by ownerUid first (works even if email_verified is false on Firebase Auth)
        const snapByUid = await getDocs(
          query(collection(db, 'tenants'), where('ownerUid', '==', signedUser.uid))
        );
        if (!snapByUid.empty) {
          const d = snapByUid.docs[0];
          foundTenant = { ...(d.data() as TenantRecord), id: d.id };
        } else if (signedUser.emailVerified) {
          const snapByEmail = await getDocs(
            query(collection(db, 'tenants'), where('email', '==', cleanEmail))
          );
          if (!snapByEmail.empty) {
            const d = snapByEmail.docs[0];
            foundTenant = { ...(d.data() as TenantRecord), id: d.id };
          }
        }
      }

      if (!foundTenant) {
        setVerifyError(
          'Credenciales válidas, pero no encontramos un comercio asociado a este correo todavía.'
        );
        return;
      }

      // Strictly validate Admin PIN against salted SHA-256 hash stored in tenant record
      if (foundTenant.admin_pin_salt && foundTenant.admin_pin_hash) {
        const computedAdminHash = await hashPin(foundTenant.admin_pin_salt, cleanPin);
        if (computedAdminHash !== foundTenant.admin_pin_hash) {
          setVerifyError(
            'PIN de Administrador incorrecto. El acceso a datos privados exige el PIN Administrativo del comercio.'
          );
          return;
        }
      } else if (foundTenant.caja_pin_salt && foundTenant.caja_pin_hash) {
        // Fallback only for legacy tenants that haven't set a dedicated Admin PIN yet
        const computedLegacyHash = await hashPin(foundTenant.caja_pin_salt, cleanPin);
        if (computedLegacyHash !== foundTenant.caja_pin_hash) {
          setVerifyError(
            'PIN incorrecto. Verifica el PIN configurado en tu comercio o configúralo desde el Panel de Administrador.'
          );
          return;
        }
      } else {
        setVerifyError(
          'Tu comercio aún no tiene un PIN de Administrador configurado. Configúralo en el Panel de Administrador para habilitar consultas privadas.'
        );
        return;
      }

      const summary = buildSanitizedAccount(foundTenant, seniatActive);
      setConfirmedEmail(cleanEmail);
      setVerifiedAccount(summary);
      // Clear secrets immediately from client state
      setPasswordInput('');
      setAdminPinInput('');
      setVerifyError('');
      setShowVerifyBox(false);

      setMessages((prev) => [
        ...prev,
        {
          id: `verified_${Date.now()}`,
          role: 'assistant',
          text: `¡Verificación de datos privados completada! Hola ${
            summary.contacto_nombre || summary.nombre_local
          }, validé tu contraseña y PIN de Administrador para "${
            summary.nombre_local
          }". Ya puedes consultarme sobre tu membresía, RIF, días restantes, estado de cuenta o requisitos pendientes.`,
          ts: Date.now(),
        },
      ]);
    } catch (err) {
      const fbErr = err as { code?: string; message?: string };
      if (
        fbErr?.code === 'auth/invalid-credential' ||
        fbErr?.code === 'auth/wrong-password' ||
        fbErr?.code === 'auth/user-not-found'
      ) {
        setVerifyError('Correo o contraseña incorrectos. Verifica tus datos e intenta nuevamente.');
      } else if (fbErr?.code === 'auth/too-many-requests') {
        setVerifyError('Demasiados intentos fallidos. Espera unos minutos antes de intentar de nuevo.');
      } else if (fbErr?.code === 'auth/operation-not-allowed') {
        setVerifyError(
          'El método de Correo y Contraseña debe estar habilitado en Firebase Authentication para validar tu clave.'
        );
      } else {
        setVerifyError('No se pudo validar tu contraseña en este momento. Intenta de nuevo.');
      }
    } finally {
      setVerifyLoading(false);
    }
  };

  const openPrivateGate = () => {
    setVerifyMode('private_gate');
    setShowVerifyBox(true);
    setVerifyError('');
  };

  const sendMessage = async (textOverride?: string) => {
    const clean = (textOverride ?? input).trim();
    if (!clean || loading) return;

    const userMsg: AssistantMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: clean,
      ts: Date.now(),
    };
    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    if (!textOverride) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/innova-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: clean,
          mode: contextMode === 'portal' ? 'portal_advisor' : 'client_chat',
          email: confirmedEmail || undefined,
          verified: Boolean(verifiedAccount),
          verifiedAccount: verifiedAccount || null,
          history: nextHistory.slice(-10).map((m) => ({ role: m.role, text: m.text })),
        }),
      });
      const data = (await res.json()) as {
        reply?: string;
        suggestVerification?: boolean;
        error?: string;
      };
      const replyText =
        data.reply ||
        data.error ||
        'Soy Innova Grup. No pude responder en este momento, intenta de nuevo.';
      setMessages((prev) => [
        ...prev,
        {
          id: `a_${Date.now()}`,
          role: 'assistant',
          text: replyText,
          ts: Date.now(),
          suggestVerification: !verifiedAccount && Boolean(data.suggestVerification),
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          text: 'Hubo un problema de conexión con el Asistente Virtual Innova Grup. Intenta nuevamente en unos segundos.',
          ts: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts =
    contextMode === 'portal'
      ? [
          '¿Cómo iniciar sesión?',
          '¿Cómo registrar mi negocio?',
          'Consultar mi cuenta y membresía',
          'Olvidé mi PIN o contraseña',
        ]
      : [
          '¿Cómo funciona el Modo Fiscal SENIAT?',
          '¿Cómo configurar mi impresora térmica?',
          'Consultar estado de mi cuenta',
          '¿Cómo hacer el cierre de caja?',
        ];

  return (
    <>
      {/* Animated Floating Avatar Launcher */}
      {!hideFloatingButton && !isOpen && (
        <div className="fixed bottom-5 right-5 z-[95] flex flex-col items-end gap-2">
          <motion.button
            type="button"
            onClick={() => setOpen(true)}
            initial={{ opacity: 0, scale: 0.85, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            className="group flex items-center gap-3 pr-4 pl-2 py-2 rounded-full bg-slate-900/95 hover:bg-slate-950 text-white border border-sky-400/40 shadow-2xl shadow-slate-950/35 backdrop-blur-md cursor-pointer"
            title="Abrir Asistente Virtual Innova Grup"
          >
            <div className="relative">
              <motion.span
                aria-hidden="true"
                animate={{ scale: [1, 1.14, 1], opacity: [0.35, 0.7, 0.35] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -inset-1 rounded-full bg-gradient-to-tr from-sky-500 via-cyan-400 to-blue-600 blur-[4px]"
              />
              <motion.div
                animate={{ y: [0, -3, 0] }}
                transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
                className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-sky-300 bg-slate-800 flex items-center justify-center shadow-lg"
              >
                {!avatarBroken ? (
                  <img
                    src={innovaAvatarImg}
                    alt="Asistente Virtual Innova Grup"
                    referrerPolicy="no-referrer"
                    onError={() => setAvatarBroken(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Sparkles className="w-6 h-6 text-sky-400" />
                )}
              </motion.div>
            </div>
            <div className="text-left hidden sm:block">
              <div className="text-xs font-extrabold tracking-tight text-white">
                Innova Grup IA
              </div>
              <div className="text-[11px] text-sky-200/85 font-medium">
                Asesor Virtual · ¿Necesitas ayuda?
              </div>
            </div>
          </motion.button>
        </div>
      )}

      {/* Interactive Virtual Assistant Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-4 right-4 z-[110] w-[calc(100vw-2rem)] sm:w-[420px] max-h-[86vh] bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden"
          >
            {/* Header with Animated Avatar + Reset & Clear Buttons */}
            <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-sky-950 text-white px-4 py-3.5 flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative shrink-0">
                  <motion.div
                    animate={{ y: [0, -2.5, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                    className="w-11 h-11 rounded-full overflow-hidden border-2 border-sky-400 bg-slate-800 flex items-center justify-center shadow-md"
                  >
                    {!avatarBroken ? (
                      <img
                        src={innovaAvatarImg}
                        alt="Innova Grup"
                        referrerPolicy="no-referrer"
                        onError={() => setAvatarBroken(true)}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Sparkles className="w-5 h-5 text-sky-300" />
                    )}
                  </motion.div>
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-extrabold tracking-tight truncate flex items-center gap-1.5">
                    Innova Grup
                    <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-sky-500/25 text-sky-200 border border-sky-400/30">
                      Asistente IA
                    </span>
                  </div>
                  <div className="text-[11px] text-sky-200/85 truncate">
                    {verifiedAccount
                      ? `Datos desbloqueados · ${verifiedAccount.nombre_local}`
                      : confirmedEmail
                      ? `Correo activo · ${confirmedEmail}`
                      : 'Asesor Virtual · Verificación solo por correo'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={handleResetConversation}
                  title="Restablecer conversación"
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-sky-100 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleClearChat}
                  title="Borrar chat"
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-rose-500/30 text-rose-200 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  title="Cerrar asistente"
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* 2-Tier Verification Status Bar */}
            <div
              className={`px-4 py-2.5 border-b flex items-center justify-between gap-2 text-[11px] shrink-0 ${
                verifiedAccount
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : confirmedEmail
                  ? 'bg-sky-50 border-sky-200 text-sky-900'
                  : 'bg-amber-50 border-amber-200 text-amber-900'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold min-w-0">
                {verifiedAccount ? (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="truncate">Datos privados desbloqueados</span>
                  </>
                ) : confirmedEmail ? (
                  <>
                    <Mail className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                    <span className="truncate">Solo correo · Datos privados bloqueados</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="truncate">Verificación por correo (sin Google)</span>
                  </>
                )}
              </div>

              {verifiedAccount ? (
                <button
                  type="button"
                  onClick={handleLockVerification}
                  className="text-[10px] font-bold uppercase px-2.5 py-1 rounded-lg bg-emerald-200/80 hover:bg-emerald-200 text-emerald-950 shrink-0 whitespace-nowrap cursor-pointer"
                >
                  Bloquear
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    if (!showVerifyBox) {
                      setVerifyMode(confirmedEmail ? 'private_gate' : 'email_only');
                    }
                    setShowVerifyBox((v) => !v);
                    setVerifyError('');
                  }}
                  className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-lg text-white shrink-0 whitespace-nowrap cursor-pointer ${
                    confirmedEmail
                      ? 'bg-sky-600 hover:bg-sky-700'
                      : 'bg-amber-600 hover:bg-amber-700'
                  }`}
                >
                  {showVerifyBox
                    ? 'Ocultar'
                    : confirmedEmail
                    ? 'Desbloquear privados'
                    : 'Verificar correo'}
                </button>
              )}
            </div>

            {/* Expandable 2-Tier Verification Box (Email Only vs Password + Admin PIN) */}
            <AnimatePresence>
              {showVerifyBox && !verifiedAccount && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden border-b border-slate-200 bg-slate-50 shrink-0"
                >
                  <div className="p-3.5 space-y-3">
                    {/* Mode Switcher Tabs */}
                    <div className="grid grid-cols-2 gap-1 p-1 bg-slate-200/70 rounded-xl text-[11px] font-bold">
                      <button
                        type="button"
                        onClick={() => {
                          setVerifyMode('email_only');
                          setVerifyError('');
                        }}
                        className={`py-1.5 px-2 rounded-lg transition cursor-pointer ${
                          verifyMode === 'email_only'
                            ? 'bg-white text-sky-700 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        1. Solo correo
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setVerifyMode('private_gate');
                          setVerifyError('');
                        }}
                        className={`py-1.5 px-2 rounded-lg transition cursor-pointer ${
                          verifyMode === 'private_gate'
                            ? 'bg-white text-emerald-700 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        2. Datos privados
                      </button>
                    </div>

                    {verifyMode === 'email_only' ? (
                      <form onSubmit={handleConfirmEmailOnly} className="space-y-2.5">
                        <div className="flex items-start gap-2">
                          <Mail className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                          <p className="text-[11px] text-slate-700 leading-snug">
                            <strong>Sin iniciar sesión con Google:</strong> ingresa únicamente tu
                            correo afiliado para recibir asesoría. Si pides datos privados, te
                            solicitaremos tu contraseña y PIN de Administrador.
                          </p>
                        </div>
                        <div className="relative">
                          <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="email"
                            required
                            value={emailInput}
                            onChange={(e) => setEmailInput(e.target.value)}
                            placeholder="correo.afiliado@ejemplo.com"
                            className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500"
                          />
                        </div>
                        <button
                          type="submit"
                          className="w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Confirmar solo mi correo
                        </button>
                      </form>
                    ) : (
                      <form onSubmit={handleUnlockPrivateData} className="space-y-2">
                        <div className="flex items-start gap-2">
                          <KeyRound className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <p className="text-[11px] text-slate-700 leading-snug">
                            <strong>Acceso a datos privados:</strong> confirma tu correo,{' '}
                            <strong>contraseña de cuenta</strong> y{' '}
                            <strong>PIN de Administrador</strong> (sin Google).
                          </p>
                        </div>

                        <div className="relative">
                          <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="email"
                            required
                            value={emailInput}
                            onChange={(e) => setEmailInput(e.target.value)}
                            placeholder="correo.afiliado@ejemplo.com"
                            className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>

                        <div className="relative">
                          <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type={showPassword ? 'text' : 'password'}
                            required
                            value={passwordInput}
                            onChange={(e) => setPasswordInput(e.target.value)}
                            placeholder="Contraseña de la cuenta"
                            autoComplete="current-password"
                            className="w-full pl-8 pr-9 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword((v) => !v)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                            aria-label="Mostrar contraseña"
                          >
                            {showPassword ? (
                              <EyeOff className="w-3.5 h-3.5" />
                            ) : (
                              <Eye className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>

                        <div className="relative">
                          <KeyRound className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type={showPin ? 'text' : 'password'}
                            inputMode="numeric"
                            required
                            maxLength={8}
                            value={adminPinInput}
                            onChange={(e) => setAdminPinInput(e.target.value.replace(/\D/g, ''))}
                            placeholder="PIN de Administrador (4-8 dígitos)"
                            className="w-full pl-8 pr-9 py-2 rounded-xl border border-slate-300 bg-white text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPin((v) => !v)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                            aria-label="Mostrar PIN"
                          >
                            {showPin ? (
                              <EyeOff className="w-3.5 h-3.5" />
                            ) : (
                              <Eye className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>

                        <button
                          type="submit"
                          disabled={verifyLoading}
                          className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                        >
                          {verifyLoading ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <ShieldCheck className="w-3.5 h-3.5" />
                          )}
                          Validar Contraseña + PIN Admin
                        </button>
                      </form>
                    )}

                    {verifyError && (
                      <div className="text-[11px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-2.5 py-1.5">
                        {verifyError}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Chat Messages Area */}
            <div
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-slate-50/70 min-h-[240px] max-h-[380px]"
            >
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-10 px-4">
                  <MessageSquare className="w-8 h-8 text-slate-300 mb-2" />
                  <p className="text-xs font-bold text-slate-600">Chat borrado</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Escribe tu pregunta abajo o pulsa Restablecer para iniciar con el saludo de
                    Innova Grup.
                  </p>
                </div>
              ) : (
                messages.map((m) => (
                  <div
                    key={m.id}
                    className={`flex flex-col ${
                      m.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[86%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-xs ${
                        m.role === 'user'
                          ? 'bg-sky-600 text-white rounded-br-sm font-medium'
                          : 'bg-white border border-slate-200 text-slate-800 rounded-bl-sm'
                      }`}
                    >
                      {m.role === 'assistant' && (
                        <div className="text-[10px] font-extrabold text-sky-700 uppercase tracking-wider mb-1">
                          Innova Grup · Asesor Virtual
                        </div>
                      )}
                      <div className="whitespace-pre-line">{m.text}</div>
                      {m.suggestVerification && !verifiedAccount && (
                        <button
                          type="button"
                          onClick={openPrivateGate}
                          className="mt-2 w-full py-1.5 px-2.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 font-bold text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                          Verificar con Contraseña y PIN Admin
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}

              {loading && (
                <div className="flex items-start">
                  <div className="bg-white border border-slate-200 rounded-2xl rounded-bl-sm px-3.5 py-2.5 text-xs text-slate-500 flex items-center gap-2 shadow-xs">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-600" />
                    Innova Grup está respondiendo...
                  </div>
                </div>
              )}
            </div>

            {/* Quick Advisor Suggestions */}
            <div className="px-3 py-2 bg-white border-t border-slate-100 flex flex-wrap gap-1.5 shrink-0">
              {quickPrompts.map((q) => (
                <button
                  key={q}
                  type="button"
                  disabled={loading}
                  onClick={() => void sendMessage(q)}
                  className="text-[10.5px] font-bold px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-sky-100 hover:text-sky-800 text-slate-700 transition cursor-pointer disabled:opacity-50"
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Message Input + Action Footer */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void sendMessage();
              }}
              className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Pregúntale a Innova Grup..."
                className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white"
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="p-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white transition cursor-pointer disabled:opacity-50"
                title="Enviar mensaje"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
