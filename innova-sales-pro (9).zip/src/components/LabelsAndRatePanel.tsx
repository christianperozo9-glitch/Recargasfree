import React, { useMemo, useState } from 'react';
import JsBarcode from 'jsbarcode';
import {
  CheckSquare,
  Download,
  FileText,
  Landmark,
  Printer,
  Search,
  Square,
  Tag,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import { formatMoney } from '../utils/format';
import {
  printLabelsHtml,
  printRateSignHtml,
  type PrintableLabelEntry,
} from '../utils/thermalPrinter';
import { generateLabelsPDF, generateRateSignPDF } from '../utils/pdfGenerator';

function renderBarcodeSvg(code: string): string {
  const clean = String(code || '').trim();
  if (!clean) return '';
  try {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    JsBarcode(svg, clean, {
      format: 'CODE128',
      displayValue: true,
      height: 26,
      width: 1.35,
      margin: 1,
      fontSize: 9,
      background: '#ffffff',
      lineColor: '#0f172a',
    });
    return svg.outerHTML;
  } catch {
    return '';
  }
}

export const LabelsAndRatePanel: React.FC = () => {
  const {
    products,
    localName,
    activeTenant,
    bcvRate,
    secondaryRate,
    tertiaryRate,
    notifyToast,
  } = usePos();

  const [mode, setMode] = useState<'labels' | 'rate'>('labels');

  // === Labels State ===
  const [labelSearch, setLabelSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [selectedKeys, setSelectedKeys] = useState<Record<string, number>>({});
  const [labelFormat, setLabelFormat] = useState<
    'gondola-50x30' | 'termica-58' | 'mini-40x20' | 'carta-grid'
  >('gondola-50x30');
  const [labelDesign, setLabelDesign] = useState<'clasica' | 'dual' | 'compacta' | 'oferta'>('dual');
  const [showStoreName, setShowStoreName] = useState(true);
  const [showCategory, setShowCategory] = useState(true);
  const [showUsd, setShowUsd] = useState(true);
  const [showBcvBs, setShowBcvBs] = useState(true);
  const [showBarcode, setShowBarcode] = useState(true);
  const [labelRateChoice, setLabelRateChoice] = useState<'bcv' | 'p1' | 'p2'>('bcv');

  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.categoria?.trim()) set.add(p.categoria.trim());
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [products]);

  const filteredProducts = useMemo(() => {
    const q = labelSearch.trim().toLowerCase();
    return products.filter((p) => {
      if (categoryFilter !== 'ALL') {
        const cat = (p.categoria || '').trim() || 'Sin categoría';
        if (cat !== categoryFilter) return false;
      }
      if (!q) return true;
      return (
        p.id.toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q) ||
        (p.categoria || '').toLowerCase().includes(q)
      );
    });
  }, [categoryFilter, labelSearch, products]);

  const effectiveLabelRate =
    labelRateChoice === 'p1' ? secondaryRate : labelRateChoice === 'p2' ? tertiaryRate : bcvRate;

  const selectedEntries: PrintableLabelEntry[] = useMemo(() => {
    const list: PrintableLabelEntry[] = [];
    products.forEach((p) => {
      const copies = selectedKeys[p.key] || 0;
      if (copies > 0) {
        const bc = (p.barcode || '').trim() || p.key.slice(0, 12);
        const svg = showBarcode ? renderBarcodeSvg(bc) : '';
        for (let c = 0; c < copies; c++) {
          list.push({
            nombre: p.id,
            barcode: bc,
            categoria: p.categoria || '',
            priceUsd: p.price,
            priceBs: p.price * effectiveLabelRate,
            svgBarcode: svg,
          });
        }
      }
    });
    return list;
  }, [effectiveLabelRate, products, selectedKeys, showBarcode]);

  const totalSelectedProducts = useMemo(
    () => Object.values(selectedKeys).filter((n) => n > 0).length,
    [selectedKeys]
  );

  const toggleSelectProduct = (key: string) => {
    setSelectedKeys((prev) => {
      if (prev[key]) {
        const next = { ...prev };
        delete next[key];
        return next;
      }
      return { ...prev, [key]: 1 };
    });
  };

  const setProductCopies = (key: string, copies: number) => {
    const c = Math.max(0, Math.min(200, Math.round(copies) || 0));
    setSelectedKeys((prev) => {
      const next = { ...prev };
      if (c <= 0) delete next[key];
      else next[key] = c;
      return next;
    });
  };

  const selectAllFiltered = () => {
    setSelectedKeys((prev) => {
      const next = { ...prev };
      filteredProducts.forEach((p) => {
        if (!next[p.key]) next[p.key] = 1;
      });
      return next;
    });
    notifyToast(`${filteredProducts.length} producto(s) seleccionados para etiquetas.`, 'success');
  };

  const clearSelection = () => setSelectedKeys({});

  const handlePrintLabels = () => {
    if (selectedEntries.length === 0) {
      notifyToast('Selecciona al menos un producto para imprimir etiquetas.', 'warning');
      return;
    }
    printLabelsHtml({
      localName,
      format: labelFormat,
      design: labelDesign,
      showStoreName,
      showCategory,
      showUsd,
      showBcvBs,
      showBarcode,
      labels: selectedEntries,
    });
  };

  const handleDownloadLabelsPdf = () => {
    if (selectedEntries.length === 0) {
      notifyToast('Selecciona al menos un producto para exportar el PDF.', 'warning');
      return;
    }
    generateLabelsPDF({
      localName,
      format: labelFormat,
      design: labelDesign,
      showStoreName,
      showCategory,
      showUsd,
      showBcvBs,
      showBarcode,
      labels: selectedEntries,
    });
    notifyToast('Archivo PDF de etiquetas generado.', 'success');
  };

  // === Rate Sign State ===
  const [signLocalName, setSignLocalName] = useState(localName);
  const [signRazon, setSignRazon] = useState(activeTenant?.razon_social || '');
  const [signRif, setSignRif] = useState(activeTenant?.rif || '');
  const [signDir, setSignDir] = useState(activeTenant?.direccion_fiscal || '');
  const [signTel, setSignTel] = useState(activeTenant?.telefono || '');
  const [signShowParalelo, setSignShowParalelo] = useState(false);
  const [signTheme, setSignTheme] = useState<'clasico' | 'moderno' | 'minimal'>('clasico');
  const [signNota, setSignNota] = useState('Precios calculados a la tasa oficial vigente.');

  const previewSample = useMemo(() => {
    const first = selectedEntries[0] || {
      nombre: products[0]?.id || 'Producto de Muestra',
      barcode: products[0]?.barcode || '759123456789',
      categoria: products[0]?.categoria || 'General',
      priceUsd: products[0]?.price || 12.5,
      priceBs: (products[0]?.price || 12.5) * effectiveLabelRate,
      svgBarcode: renderBarcodeSvg(products[0]?.barcode || '759123456789'),
    };
    return first;
  }, [effectiveLabelRate, products, selectedEntries]);

  return (
    <div className="space-y-4">
      {/* Sub-navigation */}
      <div className="flex flex-wrap gap-2 bg-white border border-slate-200 rounded-2xl p-2 shadow-sm">
        <button
          type="button"
          onClick={() => setMode('labels')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition ${
            mode === 'labels'
              ? 'bg-sky-600 text-white shadow'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Tag className="w-4 h-4" />
          Imprimir Etiquetas de Precios
        </button>
        <button
          type="button"
          onClick={() => setMode('rate')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition ${
            mode === 'rate'
              ? 'bg-sky-600 text-white shadow'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Landmark className="w-4 h-4" />
          Imprimir Cartel Tasa BCV del Local
        </button>
      </div>

      {mode === 'labels' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Product Search & Multi-Selection */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h4 className="font-extrabold text-slate-800 text-sm">
                Buscar y Seleccionar Productos ({totalSelectedProducts} elegidos ·{' '}
                {selectedEntries.length} etiquetas)
              </h4>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={selectAllFiltered}
                  className="px-3 py-1.5 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold hover:bg-sky-100 whitespace-nowrap"
                >
                  Seleccionar visibles ({filteredProducts.length})
                </button>
                {totalSelectedProducts > 0 && (
                  <button
                    type="button"
                    onClick={clearSelection}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-bold hover:bg-slate-200 whitespace-nowrap"
                  >
                    Limpiar
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  value={labelSearch}
                  onChange={(e) => setLabelSearch(e.target.value)}
                  placeholder="Buscar producto específico o código..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold outline-none focus:border-sky-500"
                />
              </div>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold outline-none focus:border-sky-500"
              >
                <option value="ALL">Todas las categorías ({products.length})</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    Categoría: {cat}
                  </option>
                ))}
                <option value="Sin categoría">Sin categoría</option>
              </select>
            </div>

            <div className="max-h-[420px] overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-xl">
              {filteredProducts.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400">
                  No se encontraron productos con ese criterio.
                </div>
              ) : (
                filteredProducts.map((p) => {
                  const copies = selectedKeys[p.key] || 0;
                  const checked = copies > 0;
                  return (
                    <div
                      key={p.key}
                      className={`flex items-center justify-between gap-2 px-3 py-2 text-xs transition ${
                        checked ? 'bg-sky-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => toggleSelectProduct(p.key)}
                        className="flex items-center gap-2.5 text-left min-w-0 flex-1"
                      >
                        {checked ? (
                          <CheckSquare className="w-4 h-4 text-sky-600 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-300 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <div className="font-bold text-slate-800 truncate">{p.id}</div>
                          <div className="text-[11px] text-slate-400 font-mono truncate">
                            {p.barcode || 'Sin código'}
                            {p.categoria ? ` · ${p.categoria}` : ''}
                          </div>
                        </div>
                      </button>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-right font-mono tabular-nums">
                          <div className="font-extrabold text-slate-900">
                            ${p.price.toFixed(2)}
                          </div>
                          <div className="text-[10px] text-sky-700">
                            {formatMoney(p.price * effectiveLabelRate)} Bs
                          </div>
                        </div>
                        {checked && (
                          <input
                            type="number"
                            min={1}
                            max={200}
                            value={copies}
                            onChange={(e) => setProductCopies(p.key, Number(e.target.value))}
                            title="Cantidad de copias"
                            className="w-14 px-2 py-1 rounded-lg border border-sky-300 bg-white text-center font-mono text-xs font-bold"
                          />
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right: Label Format, Design & Preview */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-4">
            <h4 className="font-extrabold text-slate-800 text-sm">
              Formato, Diseño y Vista Previa
            </h4>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  Formato de Etiqueta
                </label>
                <select
                  value={labelFormat}
                  onChange={(e) =>
                    setLabelFormat(e.target.value as typeof labelFormat)
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold"
                >
                  <option value="gondola-50x30">Góndola Estantería 50×30mm</option>
                  <option value="termica-58">Rollo Térmico 58mm</option>
                  <option value="mini-40x20">Mini Adhesiva 40×20mm</option>
                  <option value="carta-grid">Hoja Carta (3×8)</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  Estilo Visual
                </label>
                <select
                  value={labelDesign}
                  onChange={(e) => setLabelDesign(e.target.value as typeof labelDesign)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold"
                >
                  <option value="dual">Dual Moderno (Azul)</option>
                  <option value="clasica">Clásica Minimalista</option>
                  <option value="compacta">Compacta Código</option>
                  <option value="oferta">Destacada Oferta (Rojo)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Tasa para Bolívares
              </label>
              <select
                value={labelRateChoice}
                onChange={(e) => setLabelRateChoice(e.target.value as 'bcv' | 'p1' | 'p2')}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold"
              >
                <option value="bcv">Tasa Oficial BCV ({bcvRate.toFixed(2)} Bs)</option>
                <option value="p1">Paralelo 1 ({secondaryRate.toFixed(2)} Bs)</option>
                <option value="p2">Paralelo 2 ({tertiaryRate.toFixed(2)} Bs)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-semibold text-slate-700">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showStoreName}
                  onChange={(e) => setShowStoreName(e.target.checked)}
                />
                Nombre del local
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showCategory}
                  onChange={(e) => setShowCategory(e.target.checked)}
                />
                Categoría
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showUsd}
                  onChange={(e) => setShowUsd(e.target.checked)}
                />
                Precio en USD ($)
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showBcvBs}
                  onChange={(e) => setShowBcvBs(e.target.checked)}
                />
                Precio en Bs
              </label>
              <label className="flex items-center gap-2 cursor-pointer col-span-2">
                <input
                  type="checkbox"
                  checked={showBarcode}
                  onChange={(e) => setShowBarcode(e.target.checked)}
                />
                Incluir código de barras 1D (CODE128)
              </label>
            </div>

            {/* Live label preview */}
            <div className="p-4 rounded-2xl bg-slate-100 border border-slate-200 flex justify-center">
              <div
                className={`w-60 bg-white rounded-lg p-2.5 flex flex-col justify-between text-center shadow-sm ${
                  labelDesign === 'oferta'
                    ? 'border-2 border-red-600'
                    : labelDesign === 'dual'
                    ? 'border-2 border-sky-600'
                    : 'border border-slate-400'
                }`}
              >
                {showStoreName && (
                  <div
                    className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded mb-1 truncate ${
                      labelDesign === 'oferta'
                        ? 'bg-red-600 text-white'
                        : labelDesign === 'dual'
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600'
                    }`}
                  >
                    {localName}
                  </div>
                )}
                <div className="text-xs font-extrabold text-slate-900 leading-tight line-clamp-2">
                  {previewSample.nombre}
                </div>
                {showCategory && previewSample.categoria && (
                  <div className="text-[10px] text-slate-400">{previewSample.categoria}</div>
                )}
                <div className="flex items-baseline justify-center gap-2 my-1 font-mono tabular-nums">
                  {showUsd && (
                    <span className="text-lg font-black text-slate-900">
                      ${previewSample.priceUsd.toFixed(2)}
                    </span>
                  )}
                  {showBcvBs && (
                    <span className="text-xs font-extrabold text-sky-700">
                      {formatMoney(previewSample.priceBs)} Bs
                    </span>
                  )}
                </div>
                {showBarcode && previewSample.svgBarcode && (
                  <div
                    className="flex justify-center overflow-hidden [&>svg]:max-w-full [&>svg]:h-9"
                    dangerouslySetInnerHTML={{ __html: previewSample.svgBarcode }}
                  />
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handlePrintLabels}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-extrabold whitespace-nowrap"
              >
                <Printer className="w-4 h-4" />
                Imprimir Etiquetas
              </button>
              <button
                type="button"
                onClick={handleDownloadLabelsPdf}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                Descargar PDF
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Store details & rate config */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
            <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-2">
              <FileText className="w-4 h-4 text-sky-600" />
              Datos del Local y Cartel Tasa BCV
            </h4>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Nombre Comercial del Local
              </label>
              <input
                value={signLocalName}
                onChange={(e) => setSignLocalName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  Razón Social
                </label>
                <input
                  value={signRazon}
                  onChange={(e) => setSignRazon(e.target.value)}
                  placeholder="Opcional"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  RIF / Identificación
                </label>
                <input
                  value={signRif}
                  onChange={(e) => setSignRif(e.target.value)}
                  placeholder="J-00000000-0"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-mono"
                />
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Dirección del Local
              </label>
              <input
                value={signDir}
                onChange={(e) => setSignDir(e.target.value)}
                placeholder="Av / Calle / Sector"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  Teléfono
                </label>
                <input
                  value={signTel}
                  onChange={(e) => setSignTel(e.target.value)}
                  placeholder="0414-0000000"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  Estilo del Cartel
                </label>
                <select
                  value={signTheme}
                  onChange={(e) => setSignTheme(e.target.value as typeof signTheme)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold"
                >
                  <option value="clasico">Clásico Blanco</option>
                  <option value="moderno">Moderno Oscuro</option>
                  <option value="minimal">Minimalista</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Nota Informativa al Pie
              </label>
              <input
                value={signNota}
                onChange={(e) => setSignNota(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
            <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={signShowParalelo}
                onChange={(e) => setSignShowParalelo(e.target.checked)}
              />
              Incluir tasas de referencia secundarias (P1 / P2)
            </label>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() =>
                  printRateSignHtml({
                    localName: signLocalName,
                    razonSocial: signRazon,
                    rif: signRif,
                    direccion: signDir,
                    telefono: signTel,
                    tasaBcv: bcvRate,
                    tasaSecundaria: secondaryRate,
                    tasaTerciaria: tertiaryRate,
                    showParalelo: signShowParalelo,
                    nota: signNota,
                    theme: signTheme,
                  })
                }
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-extrabold whitespace-nowrap"
              >
                <Printer className="w-4 h-4" />
                Imprimir Cartel
              </button>
              <button
                type="button"
                onClick={() => {
                  generateRateSignPDF({
                    localName: signLocalName,
                    razonSocial: signRazon,
                    rif: signRif,
                    direccion: signDir,
                    telefono: signTel,
                    tasaBcv: bcvRate,
                    tasaSecundaria: secondaryRate,
                    tasaTerciaria: tertiaryRate,
                    showParalelo: signShowParalelo,
                    nota: signNota,
                    theme: signTheme,
                  });
                  notifyToast('Cartel Tasa BCV PDF descargado.', 'success');
                }}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                Descargar PDF
              </button>
            </div>
          </div>

          {/* Right: Live Poster Preview */}
          <div className="lg:col-span-7 bg-slate-100 border border-slate-200 rounded-2xl p-6 flex items-center justify-center">
            <div
              className={`w-full max-w-lg rounded-3xl p-8 text-center border-2 shadow-xl ${
                signTheme === 'moderno'
                  ? 'bg-slate-900 text-white border-slate-700'
                  : 'bg-white text-slate-900 border-slate-900'
              }`}
            >
              <div className="text-2xl font-black tracking-tight uppercase">
                {signLocalName || localName}
              </div>
              <div
                className={`text-xs mt-1 space-y-0.5 ${
                  signTheme === 'moderno' ? 'text-slate-300' : 'text-slate-600'
                }`}
              >
                {signRazon && <div className="font-bold">{signRazon}</div>}
                {signRif && <div>RIF: {signRif}</div>}
                {signDir && <div>{signDir}</div>}
                {signTel && <div>Tel: {signTel}</div>}
              </div>

              <div
                className={`my-6 rounded-2xl border-2 border-dashed p-6 ${
                  signTheme === 'moderno'
                    ? 'border-sky-400 bg-sky-950/50'
                    : 'border-sky-600 bg-sky-50'
                }`}
              >
                <div
                  className={`text-xs font-extrabold uppercase tracking-widest ${
                    signTheme === 'moderno' ? 'text-sky-300' : 'text-sky-700'
                  }`}
                >
                  Tasa Oficial BCV del Día
                </div>
                <div
                  className={`text-5xl font-black font-mono tabular-nums my-2 ${
                    signTheme === 'moderno' ? 'text-white' : 'text-sky-950'
                  }`}
                >
                  {bcvRate.toFixed(2)} Bs
                </div>
                <div className="text-xs font-semibold opacity-80">
                  1 USD ($) = {bcvRate.toFixed(2)} Bolívares
                </div>
              </div>

              {signShowParalelo && (
                <div className="flex justify-center gap-3 mb-4 text-xs font-mono">
                  <div className="px-3 py-2 rounded-xl border border-slate-300/40">
                    <div className="text-[10px] opacity-70 uppercase">Ref. 1</div>
                    <div className="font-extrabold">{secondaryRate.toFixed(2)} Bs</div>
                  </div>
                  <div className="px-3 py-2 rounded-xl border border-slate-300/40">
                    <div className="text-[10px] opacity-70 uppercase">Ref. 2</div>
                    <div className="font-extrabold">{tertiaryRate.toFixed(2)} Bs</div>
                  </div>
                </div>
              )}

              <div className="text-xs opacity-70">{signNota}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
