import React, { useMemo, useState } from 'react';
import { CloudUpload, KeyRound, Lock, MessageCircle, Printer, ShieldAlert, X } from 'lucide-react';
import { usePos } from '../context/PosContext';
import { formatMoney } from '../utils/format';

interface CloseShiftModalProps {
  open: boolean;
  onClose: () => void;
}

export const CloseShiftModal: React.FC<CloseShiftModalProps> = ({ open, onClose }) => {
  const {
    config,
    localName,
    activePrinter,
    updateTenantSettings,
    buildCurrentCierrePayload,
    verifyAdminAuthorization,
    executeShiftClose,
    notifyToast,
    playBeep,
  } = usePos();

  const [phonePromptOpen, setPhonePromptOpen] = useState(false);
  const [phoneInput, setPhoneInput] = useState('');
  const [authMode, setAuthMode] = useState<'pin' | 'password'>('pin');
  const [authSecret, setAuthSecret] = useState('');
  const [authError, setAuthError] = useState('');
  const [closing, setClosing] = useState(false);

  const cierre = useMemo(
    () => (open ? buildCurrentCierrePayload() : null),
    [open, buildCurrentCierrePayload]
  );

  if (!open || !cierre) return null;

  const sendWhatsApp = (targetPhone: string) => {
    let msg = `*CIERRE DE CAJA - ${localName}*\n`;
    msg += `Fecha: ${cierre.fecha} - ${cierre.hora}\n`;
    msg += `Cajero: ${cierre.cerrado_por}\n`;
    msg += `Transacciones: ${cierre.cantidad_ventas}\n\n`;
    msg += `*DESGLOSE POR MÉTODOS:*\n`;
    Object.keys(cierre.totales_metodos_ves).forEach((m) => {
      const label = m === 'Cashea' ? 'Cashea (Solo Inicial aprobada)' : m;
      msg += `- ${label}: ${cierre.totales_metodos_ves[m].toFixed(2)} Bs ($${cierre.totales_metodos_usd[
        m
      ].toFixed(2)})\n`;
    });
    if ((cierre.cashea_pendiente_usd || 0) > 0) {
      msg += `\n*PENDIENTE CASHEA (No sumado al cierre):* $${(cierre.cashea_pendiente_usd || 0).toFixed(2)} (${(cierre.cashea_pendiente_ves || 0).toFixed(2)} Bs)\n`;
    }
    msg += `\n*TOTAL RECAUDADO VES:* ${cierre.total_general_ves.toFixed(2)} Bs\n`;
    msg += `*EQUIV. TOTAL USD:* $${cierre.total_general_usd.toFixed(2)}\n`;
    window.open(`https://wa.me/${targetPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleWhatsAppClick = () => {
    const saved = config.whatsapp_close_phone;
    if (!saved) {
      setPhonePromptOpen(true);
      return;
    }
    sendWhatsApp(saved);
  };

  const handleSavePhone = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = phoneInput.replace(/\D/g, '');
    if (clean.length < 8) {
      notifyToast('Ingresa un número WhatsApp válido con código de país.', 'warning');
      return;
    }
    await updateTenantSettings({ whatsapp_close_phone: clean });
    setPhonePromptOpen(false);
    sendWhatsApp(clean);
  };

  const handleFinalClose = async () => {
    setAuthError('');
    if (!authSecret.trim()) {
      setAuthError(
        authMode === 'pin'
          ? 'Ingresa el PIN Administrativo para autorizar el cierre.'
          : 'Ingresa la Contraseña de Administrador para autorizar el cierre.'
      );
      playBeep('err');
      return;
    }

    setClosing(true);
    try {
      const check = await verifyAdminAuthorization(authSecret, authMode);
      if (!check.ok) {
        setAuthError(check.error || 'Autorización denegada.');
        playBeep('err');
        return;
      }
      await executeShiftClose(check.label);
      setAuthSecret('');
      onClose();
    } finally {
      setClosing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[150] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full flex flex-col max-h-[92vh] overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <h3 className="font-bold text-base text-slate-900">Comprobante de Cierre de Caja</h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 font-mono text-xs">
          <div className="text-center border-b border-dashed border-slate-300 pb-3">
            <h4 className="font-bold text-base text-slate-900 uppercase">{localName}</h4>
            <p className="text-slate-500">
              Resumen de Turno · {cierre.fecha} {cierre.hora}
            </p>
            <p className="text-slate-500">Operador: {cierre.cerrado_por}</p>
          </div>

          <div className="flex justify-between font-bold border-b border-slate-200 pb-2">
            <span>Transacciones realizadas:</span>
            <span>{cierre.cantidad_ventas}</span>
          </div>

          <div className="space-y-1">
            <p className="font-bold text-slate-500 uppercase text-[10px]">Desglose por método</p>
            {Object.keys(cierre.totales_metodos_ves || {}).map((m) => (
              <div key={m} className="flex justify-between">
                <span>{m === 'Cashea' ? 'Cashea (Solo Inicial aprobada)' : m}</span>
                <span className="font-bold">
                  {formatMoney(cierre.totales_metodos_ves?.[m] || 0)} Bs ($
                  {Number(cierre.totales_metodos_usd?.[m] || 0).toFixed(2)})
                </span>
              </div>
            ))}
          </div>

          {(cierre.cashea_pendiente_usd || 0) > 0 && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 space-y-1.5 text-[11px]">
              <div className="flex items-center justify-between font-bold text-amber-900">
                <span>RESUMEN CASHEA (SOLO INICIAL EN CIERRE)</span>
                <span className="px-1.5 py-0.5 rounded bg-[#FFDD00] text-slate-900 text-[10px] font-black">
                  CASHEA
                </span>
              </div>
              <div className="flex justify-between text-slate-700">
                <span>Inicial aprobada en cierre:</span>
                <span className="font-bold text-emerald-700">
                  ${Number(cierre.cashea_inicial_total_usd || 0).toFixed(2)} (
                  {formatMoney(cierre.cashea_inicial_total_ves || 0)} Bs)
                </span>
              </div>
              <div className="flex justify-between text-amber-900 font-bold">
                <span>Restante pendiente (no sumado al cierre):</span>
                <span>
                  ${Number(cierre.cashea_pendiente_usd || 0).toFixed(2)} (
                  {formatMoney(cierre.cashea_pendiente_ves || 0)} Bs)
                </span>
              </div>
              {(cierre.detalle_ventas || [])
                .filter((v) => (v.cashea_restante_usd || 0) > 0)
                .map((v, idx) => (
                  <div
                    key={`${v.hora}_${idx}`}
                    className="pt-1 border-t border-amber-200/70 flex flex-wrap justify-between gap-1 text-[10px] text-slate-600"
                  >
                    <span>
                      {v.hora} · Venta {formatMoney(v.cashea_total_venta_ves || 0)} Bs
                    </span>
                    <span>
                      Aprobado: <b>{formatMoney(v.total_ves)} Bs</b> · Pend:{' '}
                      <b>${Number(v.cashea_restante_usd || 0).toFixed(2)}</b> ({v.cashea_cuotas || 3} cuotas)
                    </span>
                  </div>
                ))}
            </div>
          )}

          {(cierre.productos_vendidos || []).length > 0 && (
            <div className="space-y-1 pt-2 border-t border-dashed border-slate-300">
              <p className="font-bold text-slate-500 uppercase text-[10px]">Productos vendidos</p>
              {(cierre.productos_vendidos || []).map((p) => (
                <div key={p.nombre} className="flex justify-between">
                  <span className="truncate pr-2">
                    {p.nombre} × {p.cantidad}
                  </span>
                  <span className="font-semibold shrink-0">{formatMoney(p.total_ves)} Bs</span>
                </div>
              ))}
            </div>
          )}

          <div className="pt-3 border-t border-dashed border-slate-300 space-y-1">
            {cierre.total_iva_ves > 0 && (
              <div className="flex justify-between text-slate-500">
                <span>IVA cobrado:</span>
                <span>{formatMoney(cierre.total_iva_ves)} Bs</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-bold text-slate-900">
              <span>TOTAL VES RECAUDADO:</span>
              <span className="text-emerald-700">{formatMoney(cierre.total_general_ves)} Bs</span>
            </div>
            <div className="flex justify-between text-xs font-bold text-sky-700">
              <span>EQUIV. TOTAL USD (BCV):</span>
              <span>${cierre.total_general_usd.toFixed(2)}</span>
            </div>
          </div>

          {/* Printer + Automatic PDF info */}
          <div className="font-sans p-3 rounded-xl bg-sky-50 border border-sky-200 text-[11px] text-sky-900">
            <strong>Salida automática al cerrar:</strong>{' '}
            {activePrinter
              ? `Impresora conectada (${activePrinter.name}) — se imprimirá ticket detallado + descarga automática de PDF.`
              : 'Se descargará automáticamente el comprobante detallado en PDF.'}
          </div>

          {/* Admin-only Authorization Gate */}
          <div className="font-sans p-3.5 rounded-xl bg-slate-50 border border-slate-300 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-rose-600" />
                Autorización de Administrador
              </span>
              <div className="flex rounded-lg bg-slate-200 p-0.5 text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('pin');
                    setAuthSecret('');
                    setAuthError('');
                  }}
                  className={`px-2.5 py-1 rounded-md transition ${
                    authMode === 'pin' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  PIN Admin
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('password');
                    setAuthSecret('');
                    setAuthError('');
                  }}
                  className={`px-2.5 py-1 rounded-md transition ${
                    authMode === 'password'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  Contraseña
                </button>
              </div>
            </div>

            <div className="relative">
              {authMode === 'pin' ? (
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              ) : (
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              )}
              <input
                type="password"
                inputMode={authMode === 'pin' ? 'numeric' : 'text'}
                value={authSecret}
                onChange={(e) => {
                  setAuthSecret(
                    authMode === 'pin' ? e.target.value.replace(/\D/g, '') : e.target.value
                  );
                  if (authError) setAuthError('');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    void handleFinalClose();
                  }
                }}
                placeholder={
                  authMode === 'pin'
                    ? 'Ingresa el PIN Administrativo (4-8 dígitos)'
                    : 'Ingresa la Contraseña del Administrador'
                }
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 bg-white text-xs font-semibold outline-none focus:border-sky-500"
              />
            </div>

            <p className="text-[10px] text-slate-500">
              Solo la contraseña o PIN de Administración autorizan el cierre de turno (los PIN de cajeros no aplican).
            </p>

            {authError && (
              <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-[11px] font-bold text-rose-700">
                {authError}
              </div>
            )}
          </div>
        </div>

        <div className="p-4 border-t border-slate-200 bg-slate-50 grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleWhatsAppClick}
            className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" /> WhatsApp
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" /> Imprimir
          </button>
          <button
            type="button"
            disabled={closing}
            onClick={() => void handleFinalClose()}
            className="py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <CloudUpload className="w-4 h-4" /> {closing ? 'Autorizando...' : 'Autorizar y Cerrar'}
          </button>
        </div>
      </div>

      {phonePromptOpen && (
        <div className="fixed inset-0 z-[170] bg-slate-950/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleSavePhone}
            className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4 relative"
          >
            <button
              type="button"
              onClick={() => setPhonePromptOpen(false)}
              className="absolute top-3.5 right-3.5 p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
            <h4 className="font-bold text-sm text-slate-900 pr-7">Registrar WhatsApp de Cierres</h4>
            <input
              type="tel"
              value={phoneInput}
              onChange={(e) => setPhoneInput(e.target.value)}
              placeholder="Ej: 584121234567"
              className="w-full px-3 py-2.5 text-center font-mono bg-slate-50 border border-slate-200 rounded-xl"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPhonePromptOpen(false)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-semibold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
              >
                Guardar y Enviar
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
