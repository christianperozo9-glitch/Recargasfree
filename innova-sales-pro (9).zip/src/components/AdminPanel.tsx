import React, { useEffect, useMemo, useState } from 'react';
import { deleteDoc, doc, setDoc, updateDoc, writeBatch } from 'firebase/firestore';
import {
  AlertTriangle,
  Archive,
  Ban,
  BarChart3,
  Barcode,
  Bell,
  BellRing,
  BookOpen,
  Boxes,
  Building2,
  Camera,
  Check,
  CheckSquare,
  Clock,
  Copy,
  CreditCard,
  Crown,
  Download,
  Edit3,
  ExternalLink,
  Eye,
  FileJson,
  FileSpreadsheet,
  FileText,
  Globe,
  Headphones,
  Image as ImageIcon,
  Loader2,
  Lock,
  Minus,
  Package,
  Palette,
  Percent,
  Plus,
  PlusCircle,
  Printer,
  RefreshCw,
  RotateCw,
  Search,
  Settings2,
  Shield,
  SlidersHorizontal,
  Square,
  Store,
  Tag,
  Trash2,
  TrendingUp,
  Upload,
  UserCheck,
  Users,
  Wrench,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType, stripUndefined } from '../lib/firebase';
import { IG_THEMES, IVA_RATE, usePos } from '../context/PosContext';
import type { CierreRecord, CustomerRecord, Product } from '../types/pos';
import { compressImageFile, downloadCSV, formatMoney, round2 } from '../utils/format';
import { generateCierrePDF } from '../utils/pdfGenerator';
import { AnalyticsView } from './AnalyticsView';
import { BulkImportModal } from './BulkImportModal';
import { CurrencyRateManager } from './CurrencyRateManager';
import { FiadosModal } from './FiadosModal';
import { LabelsAndRatePanel } from './LabelsAndRatePanel';
import { ProductThumb } from './ProductThumb';
import { PWAInstallButton } from './PWAInstallButton';
import { UserManagementTab } from './UserManagementTab';
import { ViewModeToggle } from './ViewModeToggle';
import { VoidInvoiceModal } from './VoidInvoiceModal';

interface AdminPanelProps {
  open: boolean;
  onClose: () => void;
  onOpenSecurity: () => void;
  onOpenScanner: (target: 'sale' | 'register', onScanned?: (code: string) => void) => void;
  onOpenFiados?: () => void;
  onOpenCloseShift?: () => void;
  onOpenTaller?: () => void;
  onOpenMotor?: () => void;
  onOpenSupport?: () => void;
  onOpenMembership?: () => void;
  onOpenPriceChecker?: (tenantId: string) => void;
}

type AdminTab =
  | 'inventory'
  | 'new'
  | 'fiados'
  | 'labels'
  | 'closures'
  | 'customers'
  | 'checker'
  | 'systems'
  | 'fiscal'
  | 'reports'
  | 'cashiers'
  | 'membership'
  | 'theme';
type StockFilter = 'all' | 'low' | 'out' | 'iva' | 'nobarcode' | 'frac';
type SortOption = 'name' | 'stock_asc' | 'stock_desc' | 'price_desc' | 'margin_asc';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  open,
  onClose,
  onOpenSecurity,
  onOpenScanner,
  onOpenFiados,
  onOpenCloseShift,
  onOpenTaller,
  onOpenMotor,
  onOpenSupport,
  onOpenMembership,
  onOpenPriceChecker,
}) => {
  const {
    activeTenantId,
    activeTenant,
    invoiceConfig,
    products,
    liveSales,
    savedCierres,
    config,
    bcvRate,
    secondaryRate,
    tertiaryRate,
    syncAllRates,
    syncBcvRate,
    syncUsdtRate,
    updateRate,
    updateTenantSettings,
    syncPublicPriceChecker,
    reprintSavedCierre,
    deleteSavedCierre,
    activePrinter,
    ivaActive,
    toggleIva,
    adminAccessBlocked,
    activeTheme,
    setLocalTheme,
    isMobileLayout,
    viewMode,
    isWideViewport,
    localName,
    mechanics,
    updateMechanics,
    membership,
    membershipDaysLeft,
    membershipExpired,
    membershipPayments,
    customers,
    saveCustomer,
    deleteCustomer,
    fiados,
    pushSupported,
    pushPermission,
    pushEnabled,
    togglePushNotifications,
    sendTestPushNotification,
    notifyToast,
    playBeep,
  } = usePos();

  const [tab, setTab] = useState<AdminTab>('inventory');
  const [query, setQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [stockFilter, setStockFilter] = useState<StockFilter>('all');
  const [sortBy, setSortBy] = useState<SortOption>('name');
  const [visibleLimit, setVisibleLimit] = useState(40);
  const [bulkPct, setBulkPct] = useState('10');
  const [bulkStockDelta, setBulkStockDelta] = useState('5');
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());
  const [bulkImportOpen, setBulkImportOpen] = useState(false);
  const [voidModalOpen, setVoidModalOpen] = useState(false);

  // Google Real Image Search with explicit confirmation modal + simultaneous name sync
  type GoogleImageCandidate = {
    dataUrl: string;
    title: string;
    sourceUrl: string;
    sourceDomain: string;
    matchScore?: number;
    engine?: string;
  };
  const [imgSearchTarget, setImgSearchTarget] = useState<'new' | 'edit' | null>(null);
  const [imgSearchQuery, setImgSearchQuery] = useState('');
  const [imgSearching, setImgSearching] = useState(false);
  const [imgSearchResults, setImgSearchResults] = useState<GoogleImageCandidate[]>([]);
  const [imgSearchSelectedIdx, setImgSearchSelectedIdx] = useState<number>(0);
  const [imgSearchNotice, setImgSearchNotice] = useState('');

  // Live simultaneous Google image sync tied to product name (requires explicit user confirmation)
  const [autoSyncGoogleImg, setAutoSyncGoogleImg] = useState(true);
  const [liveNewImgLoading, setLiveNewImgLoading] = useState(false);
  const [liveNewImgQuery, setLiveNewImgQuery] = useState('');
  const [liveNewImgResults, setLiveNewImgResults] = useState<GoogleImageCandidate[]>([]);
  const [liveNewImgDismissedFor, setLiveNewImgDismissedFor] = useState('');

  const [liveEditImgLoading, setLiveEditImgLoading] = useState(false);
  const [liveEditImgQuery, setLiveEditImgQuery] = useState('');
  const [liveEditImgResults, setLiveEditImgResults] = useState<GoogleImageCandidate[]>([]);
  const [liveEditImgDismissedFor, setLiveEditImgDismissedFor] = useState('');

  // Billing Customers (Clientes para Facturación) CRUD state
  const [custQuery, setCustQuery] = useState('');
  const [editingCustKey, setEditingCustKey] = useState<string | null>(null);
  const [custCedula, setCustCedula] = useState('');
  const [custNombre, setCustNombre] = useState('');
  const [custTelefono, setCustTelefono] = useState('');
  const [custDireccion, setCustDireccion] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custNota, setCustNota] = useState('');
  const [savingCust, setSavingCust] = useState(false);
  const [custToDelete, setCustToDelete] = useState<CustomerRecord | null>(null);

  // Hosted Closures Viewer state
  const [cierreSearch, setCierreSearch] = useState('');
  const [selectedCierre, setSelectedCierre] = useState<CierreRecord | null>(null);
  const [cierreToDelete, setCierreToDelete] = useState<CierreRecord | null>(null);
  const [deletingCierre, setDeletingCierre] = useState(false);

  // Price Checker Configurator state
  const [checkerMsgDraft, setCheckerMsgDraft] = useState(config.consultor_mensaje || '');
  const [savingChecker, setSavingChecker] = useState(false);

  useEffect(() => {
    setCheckerMsgDraft(config.consultor_mensaje || '');
  }, [config.consultor_mensaje]);

  // System Rates Draft inside Systems Tab
  const [rate1Draft, setRate1Draft] = useState(bcvRate.toFixed(2));
  const [rate2Draft, setRate2Draft] = useState(secondaryRate.toFixed(2));
  const [rate3Draft, setRate3Draft] = useState(tertiaryRate.toFixed(2));
  const [syncingRates, setSyncingRates] = useState(false);

  useEffect(() => {
    setRate1Draft(bcvRate.toFixed(2));
    setRate2Draft(secondaryRate.toFixed(2));
    setRate3Draft(tertiaryRate.toFixed(2));
  }, [bcvRate, secondaryRate, tertiaryRate]);

  // Mechanics Manager for Motor button
  const [mechanicsModalOpen, setMechanicsModalOpen] = useState(false);
  const [newMechanicName, setNewMechanicName] = useState('');
  const [savingMechanic, setSavingMechanic] = useState(false);

  const handleAddMechanic = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = newMechanicName.trim();
    if (!clean) {
      notifyToast('Escribe el nombre del mecánico.', 'warning');
      return;
    }
    if (mechanics.some((m) => m.toLowerCase() === clean.toLowerCase())) {
      notifyToast(`"${clean}" ya está en la lista de mecánicos.`, 'info');
      return;
    }
    setSavingMechanic(true);
    try {
      await updateMechanics([...mechanics, clean]);
      setNewMechanicName('');
      playBeep('ok');
      notifyToast(`Mecánico "${clean}" agregado al botón Motor.`, 'success');
    } finally {
      setSavingMechanic(false);
    }
  };

  const handleRemoveMechanic = async (name: string) => {
    setSavingMechanic(true);
    try {
      await updateMechanics(mechanics.filter((m) => m !== name));
      playBeep('tick');
      notifyToast(`"${name}" eliminado de la lista de mecánicos.`, 'info');
    } finally {
      setSavingMechanic(false);
    }
  };

  // Edit Product Modal
  const [editing, setEditing] = useState<Product | null>(null);
  const [editName, setEditName] = useState('');
  const [editBarcode, setEditBarcode] = useState('');
  const [editCat, setEditCat] = useState('');
  const [editCost, setEditCost] = useState('');
  const [editMargin, setEditMargin] = useState('');
  const [editStock, setEditStock] = useState('');
  const [editPrice1, setEditPrice1] = useState('');
  const [editImage, setEditImage] = useState('');
  const [editFrac, setEditFrac] = useState(false);
  const [editVentaBulto, setEditVentaBulto] = useState(false);
  const [editUnidadesBulto, setEditUnidadesBulto] = useState('12');
  const [editPrecioBulto, setEditPrecioBulto] = useState('');
  const [editStockMode, setEditStockMode] = useState<'detal' | 'bulto'>('detal');

  // In-app Confirmation Modals (replaces unreliable browser confirm())
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState(false);
  const [confirmBulkAction, setConfirmBulkAction] = useState<
    | { type: 'delete'; count: number }
    | { type: 'iva'; add: boolean; count: number; scopeLabel: string; targets: Product[] }
    | { type: 'percent'; sign: 1 | -1; pct: number; scopeLabel: string }
    | null
  >(null);
  const [runningBulkAction, setRunningBulkAction] = useState(false);

  // New Product Form
  const [newName, setNewName] = useState('');
  const [newBarcode, setNewBarcode] = useState('');
  const [newCat, setNewCat] = useState('');
  const [newStock, setNewStock] = useState('');
  const [newStockMode, setNewStockMode] = useState<'detal' | 'bulto'>('detal');
  const [newCost, setNewCost] = useState('');
  const [newMargin, setNewMargin] = useState('35');
  const [newPrice1, setNewPrice1] = useState('');
  const [newImage, setNewImage] = useState('');
  const [newFrac, setNewFrac] = useState(false);
  const [newVentaBulto, setNewVentaBulto] = useState(false);
  const [newUnidadesBulto, setNewUnidadesBulto] = useState('12');
  const [newPrecioBulto, setNewPrecioBulto] = useState('');
  const [savingNew, setSavingNew] = useState(false);

  const downscaleDataUrl = (dataUrl: string, maxDim = 480): Promise<string> =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width || 1, img.height || 1));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        try {
          const out = canvas.toDataURL('image/jpeg', 0.82);
          resolve(out.length < 700000 ? out : dataUrl.slice(0, 700000));
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });

  // Simultaneous live Google web product image search synced with newName
  useEffect(() => {
    if (!open || tab !== 'new' || !autoSyncGoogleImg) return;
    const clean = newName.trim();
    if (clean.length < 3) {
      setLiveNewImgResults([]);
      setLiveNewImgQuery('');
      setLiveNewImgLoading(false);
      return;
    }
    if (liveNewImgDismissedFor === clean) return;

    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setLiveNewImgLoading(true);
      setLiveNewImgQuery(clean);
      try {
        const res = await fetch('/api/product-image-search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: clean }),
          signal: controller.signal,
        });
        if (!res.ok) {
          setLiveNewImgResults([]);
          return;
        }
        const data = (await res.json()) as {
          results?: GoogleImageCandidate[];
          candidates?: GoogleImageCandidate[];
        };
        const list = Array.isArray(data.results)
          ? data.results
          : Array.isArray(data.candidates)
          ? data.candidates
          : [];
        if (!controller.signal.aborted) {
          setLiveNewImgResults(list.slice(0, 4));
        }
      } catch {
        if (!controller.signal.aborted) {
          setLiveNewImgResults([]);
        }
      } finally {
        if (!controller.signal.aborted) {
          setLiveNewImgLoading(false);
        }
      }
    }, 900);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [autoSyncGoogleImg, liveNewImgDismissedFor, newName, open, tab]);

  // Simultaneous live Google web product image search synced with editName
  useEffect(() => {
    if (!open || !editing || !autoSyncGoogleImg) return;
    const clean = editName.trim();
    if (clean.length < 3) {
      setLiveEditImgResults([]);
      setLiveEditImgQuery('');
      setLiveEditImgLoading(false);
      return;
    }
    if (liveEditImgDismissedFor === clean) return;

    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setLiveEditImgLoading(true);
      setLiveEditImgQuery(clean);
      try {
        const res = await fetch('/api/product-image-search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: clean }),
          signal: controller.signal,
        });
        if (!res.ok) {
          setLiveEditImgResults([]);
          return;
        }
        const data = (await res.json()) as {
          results?: GoogleImageCandidate[];
          candidates?: GoogleImageCandidate[];
        };
        const list = Array.isArray(data.results)
          ? data.results
          : Array.isArray(data.candidates)
          ? data.candidates
          : [];
        if (!controller.signal.aborted) {
          setLiveEditImgResults(list.slice(0, 4));
        }
      } catch {
        if (!controller.signal.aborted) {
          setLiveEditImgResults([]);
        }
      } finally {
        if (!controller.signal.aborted) {
          setLiveEditImgLoading(false);
        }
      }
    }, 900);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [autoSyncGoogleImg, editName, editing, liveEditImgDismissedFor, open]);

  const handleApplyLiveGoogleImage = async (target: 'new' | 'edit', item: GoogleImageCandidate) => {
    const compressed = await downscaleDataUrl(item.dataUrl);
    if (target === 'new') {
      setNewImage(compressed);
      setLiveNewImgDismissedFor(newName.trim());
    } else {
      setEditImage(compressed);
      setLiveEditImgDismissedFor(editName.trim());
    }
    playBeep('ok');
    notifyToast(`Imagen confirmada de "${item.title.slice(0, 42)}" aplicada al producto.`, 'success');
  };

  const handleSearchGoogleImage = async (target: 'new' | 'edit', customQuery?: string) => {
    const productName = (customQuery !== undefined ? customQuery : target === 'new' ? newName : editName).trim();
    if (productName.length < 2) {
      notifyToast('Primero escribe el nombre exacto del producto para buscar su imagen real en Google.', 'warning');
      return;
    }
    setImgSearchTarget(target);
    setImgSearchQuery(productName);
    setImgSearchResults([]);
    setImgSearchSelectedIdx(0);
    setImgSearchNotice('');
    setImgSearching(true);
    try {
      const res = await fetch('/api/product-image-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: productName }),
      });
      const data = (await res.json()) as {
        results?: GoogleImageCandidate[];
        candidates?: GoogleImageCandidate[];
        message?: string;
        error?: string;
      };
      if (!res.ok) {
        setImgSearchNotice(data.error || 'Error consultando imágenes.');
        return;
      }
      const list = Array.isArray(data.results)
        ? data.results
        : Array.isArray(data.candidates)
        ? data.candidates
        : [];
      setImgSearchResults(list);
      setImgSearchSelectedIdx(0);
      if (list.length === 0) {
        setImgSearchNotice(
          data.message ||
            'No se encontró ninguna imagen real verificada que coincida con el nombre de este producto.'
        );
      }
    } catch {
      setImgSearchNotice('No se pudo conectar con el buscador de imágenes. Verifica tu conexión.');
    } finally {
      setImgSearching(false);
    }
  };

  const handleConfirmSelectedGoogleImage = async () => {
    const picked = imgSearchResults[imgSearchSelectedIdx];
    if (!picked || !imgSearchTarget) return;
    const compressed = await downscaleDataUrl(picked.dataUrl);
    if (imgSearchTarget === 'new') {
      setNewImage(compressed);
      setLiveNewImgDismissedFor(newName.trim());
    } else {
      setEditImage(compressed);
      setLiveEditImgDismissedFor(editName.trim());
    }
    playBeep('ok');
    notifyToast('Imagen real verificada añadida al producto.', 'success');
    setImgSearchTarget(null);
    setImgSearchResults([]);
  };

  const resetCustomerForm = () => {
    setEditingCustKey(null);
    setCustCedula('');
    setCustNombre('');
    setCustTelefono('');
    setCustDireccion('');
    setCustEmail('');
    setCustNota('');
  };

  const handleSaveCustomerForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!custCedula.trim() || !custNombre.trim()) {
      notifyToast('Ingresa la cédula/RIF y el nombre del cliente.', 'warning');
      return;
    }
    setSavingCust(true);
    try {
      await saveCustomer(
        {
          cedula: custCedula,
          nombre: custNombre,
          telefono: custTelefono,
          direccion: custDireccion,
          email: custEmail,
          nota: custNota,
        },
        editingCustKey || undefined
      );
      resetCustomerForm();
    } finally {
      setSavingCust(false);
    }
  };

  const filteredCustomers = useMemo(() => {
    const q = custQuery.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      (c) =>
        (c.nombre || '').toLowerCase().includes(q) ||
        (c.cedula || '').toLowerCase().includes(q) ||
        (c.telefono || '').toLowerCase().includes(q)
    );
  }, [customers, custQuery]);

  const categoriesList = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      const c = (p.categoria || '').trim();
      if (c) set.add(c);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'es'));
  }, [products]);

  const inventoryStats = useMemo(() => {
    let low = 0;
    let out = 0;
    let ivaCount = 0;
    let noBarcode = 0;
    let totalCostUsd = 0;
    let totalRetailUsd = 0;
    products.forEach((p) => {
      const stk = Math.max(0, Number(p.stock) || 0);
      if (p.stock <= 0) out++;
      else if (p.stock <= 5) low++;
      if (p.ivaIncluded) ivaCount++;
      if (!p.barcode?.trim()) noBarcode++;
      totalCostUsd += (Number(p.cost) || 0) * stk;
      totalRetailUsd += (Number(p.price) || 0) * stk;
    });
    const estMarginPct =
      totalRetailUsd > 0 ? ((totalRetailUsd - totalCostUsd) / totalRetailUsd) * 100 : 0;
    return {
      total: products.length,
      low,
      out,
      ivaCount,
      noBarcode,
      totalCostUsd: round2(totalCostUsd),
      totalRetailUsd: round2(totalRetailUsd),
      estMarginPct: round2(estMarginPct),
    };
  }, [products]);

  const liveShiftTotals = useMemo(() => {
    let ves = 0;
    let usd = 0;
    liveSales.forEach((s) => {
      ves += Number(s.monto_total_ves) || 0;
      usd += Number(s.monto_total_usd_bcv) || 0;
    });
    return { count: liveSales.length, ves: round2(ves), usd: round2(usd) };
  }, [liveSales]);

  const filteredProducts = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = products.filter((p) => {
      if (categoryFilter !== 'ALL') {
        const cat = (p.categoria || '').trim();
        if (categoryFilter === 'UNCAT') {
          if (cat) return false;
        } else if (cat !== categoryFilter) {
          return false;
        }
      }
      if (stockFilter === 'low' && !(p.stock > 0 && p.stock <= 5)) return false;
      if (stockFilter === 'out' && p.stock > 0) return false;
      if (stockFilter === 'iva' && !p.ivaIncluded) return false;
      if (stockFilter === 'nobarcode' && Boolean(p.barcode?.trim())) return false;
      if (stockFilter === 'frac' && !p.fraccionable) return false;
      if (!q) return true;
      return (
        (p.id || '').toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q) ||
        (p.categoria || '').toLowerCase().includes(q)
      );
    });

    const calcMargin = (p: Product) => {
      if (!p.price || p.price <= 0) return -999;
      return ((p.price - p.cost) / p.price) * 100;
    };

    return [...list].sort((a, b) => {
      if (sortBy === 'stock_asc') return a.stock - b.stock;
      if (sortBy === 'stock_desc') return b.stock - a.stock;
      if (sortBy === 'price_desc') return b.price - a.price;
      if (sortBy === 'margin_asc') return calcMargin(a) - calcMargin(b);
      return String(a.id || '').localeCompare(String(b.id || ''), 'es');
    });
  }, [categoryFilter, products, query, stockFilter, sortBy]);

  const filteredCierres = useMemo(() => {
    const q = cierreSearch.trim().toLowerCase();
    return [...savedCierres]
      .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))
      .filter(
        (c) =>
          !q ||
          (c.fecha || '').toLowerCase().includes(q) ||
          (c.cerrado_por || '').toLowerCase().includes(q)
      );
  }, [cierreSearch, savedCierres]);

  if (!open) return null;

  if (adminAccessBlocked) {
    return (
      <div className="fixed inset-0 z-[140] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
          <Lock className="w-10 h-10 text-rose-600 mx-auto" />
          <h3 className="text-lg font-bold text-slate-900">Panel Administrativo Bloqueado</h3>
          <p className="text-sm text-slate-500">
            El propietario ha restringido temporalmente el acceso a la administración de inventario.
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-sm font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCw className="w-4 h-4" /> Recargar
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-semibold cursor-pointer"
            >
              Volver al Punto de Venta
            </button>
          </div>
        </div>
      </div>
    );
  }

  const visibleProducts = filteredProducts.slice(0, visibleLimit);
  const selectedList = products.filter((p) => selectedKeys.has(p.key));
  const targetList = selectedList.length > 0 ? selectedList : products;

  const toggleSelectOne = (key: string) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const toggleSelectVisible = () => {
    const allVisibleSelected =
      visibleProducts.length > 0 && visibleProducts.every((p) => selectedKeys.has(p.key));
    if (allVisibleSelected) {
      setSelectedKeys(new Set());
    } else {
      setSelectedKeys(new Set(visibleProducts.map((p) => p.key)));
    }
  };

  const startEdit = (p: Product) => {
    setEditing(p);
    setEditName(p.id);
    setEditBarcode(p.barcode);
    setEditCat(p.categoria || '');
    const costNum = Number(p.cost) || 0;
    const priceNum = Number(p.price) || 0;
    setEditCost(String(costNum));
    setEditMargin(costNum > 0 && priceNum > 0 ? String(round2(((priceNum - costNum) / costNum) * 100)) : '');
    setEditStock(String(p.stock || 0));
    setEditStockMode('detal');
    setEditPrice1(String(priceNum));
    setEditImage(p.image || '');
    setEditFrac(p.fraccionable);
    setEditVentaBulto(p.ventaPorBulto === true);
    setEditUnidadesBulto(String(p.unidadesPorBulto && p.unidadesPorBulto > 1 ? p.unidadesPorBulto : 12));
    setEditPrecioBulto(
      p.precioBulto && p.precioBulto > 0
        ? String(p.precioBulto)
        : p.ventaPorBulto && p.unidadesPorBulto && p.unidadesPorBulto > 1
        ? String(round2(p.price * p.unidadesPorBulto))
        : ''
    );
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing || !activeTenantId) return;
    const cleanName = editName.trim();
    if (!cleanName) {
      notifyToast('El nombre no puede estar vacío.', 'warning');
      return;
    }
    const priceNum = round2(Number(editPrice1) || 0);
    const upb = Math.max(0, Math.round(Number(editUnidadesBulto) || 0));
    if (editVentaBulto && upb < 2) {
      notifyToast('Para venta por bulto, indica al menos 2 unidades por bulto.', 'warning');
      return;
    }
    const rawStockNum = Number(editStock) || 0;
    const finalStockUnits =
      editVentaBulto && editStockMode === 'bulto'
        ? round2(rawStockNum * upb)
        : round2(rawStockNum);
    const parsedBultoPrice = Number(editPrecioBulto) || 0;
    const finalBultoPrice = editVentaBulto
      ? parsedBultoPrice > 0
        ? round2(parsedBultoPrice)
        : round2(priceNum * upb)
      : null;

    const payload: Record<string, unknown> = stripUndefined({
      nombre: cleanName,
      barcode: editBarcode.trim(),
      categoria: editCat.trim() || undefined,
      costo: round2(Number(editCost) || 0),
      stock: finalStockUnits,
      precio: priceNum,
      precio2: null,
      precio3: null,
      imagen: editImage || '',
      fraccionable: editFrac,
      venta_por_bulto: editVentaBulto,
      unidades_por_bulto: editVentaBulto ? upb : null,
      precio_bulto: finalBultoPrice,
      updatedAt: Date.now(),
    });
    const path = `tenants/${activeTenantId}/products/${editing.key}`;
    try {
      await updateDoc(doc(db, 'tenants', activeTenantId, 'products', editing.key), payload);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
    setEditing(null);
    playBeep('ok');
    notifyToast(`Producto "${cleanName}" actualizado.`, 'success');
  };

  const handleQuickStock = async (p: Product, delta: number) => {
    if (!activeTenantId) return;
    const next = Math.max(0, round2(p.stock + delta));
    const path = `tenants/${activeTenantId}/products/${p.key}`;
    try {
      await updateDoc(doc(db, 'tenants', activeTenantId, 'products', p.key), {
        stock: next,
        updatedAt: Date.now(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
    playBeep('tick');
  };

  const handleBulkStockAdjust = async (sign: 1 | -1) => {
    if (!activeTenantId) return;
    const delta = Math.abs(Number(bulkStockDelta) || 0);
    if (delta <= 0) {
      notifyToast('Ingresa una cantidad válida para ajustar stock.', 'warning');
      return;
    }
    if (selectedList.length === 0) {
      notifyToast('Selecciona al menos un producto para ajustar stock por lote.', 'warning');
      return;
    }
    const batch = writeBatch(db);
    const now = Date.now();
    selectedList.forEach((p) => {
      batch.update(doc(db, 'tenants', activeTenantId, 'products', p.key), {
        stock: Math.max(0, round2(p.stock + sign * delta)),
        updatedAt: now,
      });
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tenants/${activeTenantId}/products`);
    }
    playBeep('ok');
    notifyToast(
      `Stock ${sign > 0 ? '+' : '-'}${delta} aplicado a ${selectedList.length} producto(s).`,
      'success'
    );
  };

  const handleBulkDeleteSelected = () => {
    if (!activeTenantId || selectedList.length === 0) return;
    setConfirmBulkAction({ type: 'delete', count: selectedList.length });
  };

  const handleToggleItemIva = async (p: Product) => {
    if (!activeTenantId) return;
    const factor = 1 + IVA_RATE;
    const adding = !p.ivaIncluded;
    const nextPrice = round2(adding ? p.price * factor : p.price / factor);
    const path = `tenants/${activeTenantId}/products/${p.key}`;
    try {
      await updateDoc(doc(db, 'tenants', activeTenantId, 'products', p.key), {
        precio: nextPrice,
        precio2: null,
        precio3: null,
        iva_incluido: adding,
        iva_pct: adding ? Math.round(IVA_RATE * 100) : 0,
        updatedAt: Date.now(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
    notifyToast(`${adding ? 'IVA aplicado' : 'IVA removido'} en ${p.id}`, 'info');
  };

  const handleBulkIva = (add: boolean) => {
    if (!activeTenantId) return;
    const scopeLabel = selectedList.length > 0 ? `${selectedList.length} seleccionados` : 'todo el catálogo';
    const targets = targetList.filter((p) => (add ? !p.ivaIncluded : p.ivaIncluded));
    if (targets.length === 0) {
      notifyToast(
        add ? 'Los productos indicados ya tienen IVA incluido.' : 'Ningún producto indicado tiene IVA marcado.',
        'info'
      );
      return;
    }
    setConfirmBulkAction({
      type: 'iva',
      add,
      count: targets.length,
      scopeLabel,
      targets,
    });
  };

  const handleBulkPercent = (sign: 1 | -1) => {
    if (!activeTenantId) return;
    const pct = Math.abs(Number(bulkPct) || 0);
    if (pct <= 0 || pct > 95) {
      notifyToast('Ingresa un porcentaje entre 1 y 95.', 'warning');
      return;
    }
    const scopeLabel =
      selectedList.length > 0 ? `${selectedList.length} seleccionados` : `todos (${products.length})`;
    setConfirmBulkAction({
      type: 'percent',
      sign,
      pct,
      scopeLabel,
    });
  };

  const executeConfirmedBulkAction = async () => {
    if (!activeTenantId || !confirmBulkAction) return;
    setRunningBulkAction(true);
    const now = Date.now();
    try {
      if (confirmBulkAction.type === 'delete') {
        const toDelete = products.filter((p) => selectedKeys.has(p.key));
        if (toDelete.length === 0) {
          setConfirmBulkAction(null);
          return;
        }
        const batch = writeBatch(db);
        toDelete.forEach((p) => {
          batch.delete(doc(db, 'tenants', activeTenantId, 'products', p.key));
        });
        await batch.commit();
        setSelectedKeys(new Set());
        playBeep('ok');
        notifyToast(`${toDelete.length} producto(s) eliminados del inventario.`, 'success');
      } else if (confirmBulkAction.type === 'iva') {
        const { add, targets } = confirmBulkAction;
        const factor = 1 + IVA_RATE;
        const batch = writeBatch(db);
        targets.forEach((p) => {
          batch.update(doc(db, 'tenants', activeTenantId, 'products', p.key), {
            precio: round2(add ? p.price * factor : p.price / factor),
            precio2: null,
            precio3: null,
            iva_incluido: add,
            iva_pct: add ? Math.round(IVA_RATE * 100) : 0,
            updatedAt: now,
          });
        });
        await batch.commit();
        playBeep('ok');
        notifyToast(`IVA actualizado en ${targets.length} productos.`, 'success');
      } else if (confirmBulkAction.type === 'percent') {
        const { sign, pct } = confirmBulkAction;
        const mult = 1 + (sign * pct) / 100;
        const batch = writeBatch(db);
        targetList.forEach((p) => {
          batch.update(doc(db, 'tenants', activeTenantId, 'products', p.key), {
            precio: round2(p.price * mult),
            precio2: null,
            precio3: null,
            updatedAt: now,
          });
        });
        await batch.commit();
        playBeep('ok');
        notifyToast(
          `Precios ajustados (${sign > 0 ? '+' : '-'}${pct}%) en ${targetList.length} productos.`,
          'success'
        );
      }
      setConfirmBulkAction(null);
    } catch (err) {
      playBeep('err');
      const msg = err instanceof Error ? err.message : 'No se pudo completar la operación en Firestore.';
      notifyToast(`Error: ${msg}`, 'error');
    } finally {
      setRunningBulkAction(false);
    }
  };

  const requestDeleteProduct = (p: Product) => {
    setProductToDelete(p);
  };

  const confirmDeleteSingleProduct = async () => {
    if (!activeTenantId || !productToDelete) return;
    const target = productToDelete;
    setDeletingProduct(true);
    try {
      await deleteDoc(doc(db, 'tenants', activeTenantId, 'products', target.key));
      setSelectedKeys((prev) => {
        const next = new Set(prev);
        next.delete(target.key);
        return next;
      });
      setProductToDelete(null);
      playBeep('ok');
      notifyToast(`"${target.id}" eliminado del inventario.`, 'success');
    } catch (err) {
      playBeep('err');
      const msg = err instanceof Error ? err.message : 'Error de permisos o conexión.';
      notifyToast(`No se pudo eliminar "${target.id}": ${msg}`, 'error');
    } finally {
      setDeletingProduct(false);
    }
  };

  const handleAutoMargin = (costStr: string, marginStr: string) => {
    const c = Number(costStr) || 0;
    const m = Number(marginStr);
    if (c > 0 && marginStr.trim() !== '' && Number.isFinite(m) && m >= 0) {
      const p1 = round2(c * (1 + m / 100));
      setNewPrice1(String(p1));
    }
  };

  const handleEditAutoMargin = (costStr: string, marginStr: string) => {
    const c = Number(costStr) || 0;
    const m = Number(marginStr);
    if (c > 0 && marginStr.trim() !== '' && Number.isFinite(m) && m >= 0) {
      const prevPrice = Number(editPrice1) || 0;
      const nextPrice = round2(c * (1 + m / 100));
      setEditPrice1(String(nextPrice));
      // Keep bulto price synced if it was matching exact detal * units
      if (editVentaBulto) {
        const upb = Math.max(2, Math.round(Number(editUnidadesBulto) || 12));
        const curBulto = Number(editPrecioBulto) || 0;
        if (curBulto <= 0 || Math.abs(curBulto - round2(prevPrice * upb)) < 0.05) {
          setEditPrecioBulto(String(round2(nextPrice * upb)));
        }
      }
    }
  };

  const handleImagePick = async (file: File | undefined, target: 'new' | 'edit') => {
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file);
      if (target === 'new') setNewImage(dataUrl);
      else setEditImage(dataUrl);
    } catch (err) {
      notifyToast(err instanceof Error ? err.message : 'Error procesando imagen', 'error');
    }
  };

  const handleCreateProduct = async (e: React.FormEvent, stayOnTab = false) => {
    e.preventDefault();
    if (!activeTenantId) {
      notifyToast('No hay un nodo de comercio activo.', 'warning');
      return;
    }
    const cleanName = newName.trim();
    const priceNum = Number(newPrice1) || 0;
    if (!cleanName || priceNum <= 0) {
      notifyToast('Nombre del producto y Precio de venta (USD) son obligatorios.', 'warning');
      return;
    }
    const upb = Math.max(0, Math.round(Number(newUnidadesBulto) || 0));
    if (newVentaBulto && upb < 2) {
      notifyToast('Para venta por bulto, indica al menos 2 unidades por bulto.', 'warning');
      return;
    }
    const rawStockNum = Number(newStock) || 0;
    const finalStockUnits =
      newVentaBulto && newStockMode === 'bulto'
        ? round2(rawStockNum * upb)
        : round2(rawStockNum);
    const parsedBultoPrice = Number(newPrecioBulto) || 0;
    const finalBultoPrice = newVentaBulto
      ? parsedBultoPrice > 0
        ? round2(parsedBultoPrice)
        : round2(priceNum * upb)
      : null;

    setSavingNew(true);
    try {
      const key = `${Date.now()}`;
      const path = `tenants/${activeTenantId}/products/${key}`;
      try {
        await setDoc(
          doc(db, 'tenants', activeTenantId, 'products', key),
          stripUndefined({
            nombre: cleanName,
            barcode: newBarcode.trim(),
            categoria: newCat.trim() || undefined,
            stock: finalStockUnits,
            costo: round2(Number(newCost) || 0),
            precio: round2(priceNum),
            precio2: null,
            precio3: null,
            imagen: newImage || '',
            fraccionable: newFrac,
            venta_por_bulto: newVentaBulto,
            unidades_por_bulto: newVentaBulto ? upb : null,
            precio_bulto: finalBultoPrice,
            iva_incluido: false,
            iva_pct: 0,
            updatedAt: Date.now(),
          })
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
      setNewName('');
      setNewBarcode('');
      setNewCat('');
      setNewStock('');
      setNewStockMode('detal');
      setNewCost('');
      setNewPrice1('');
      setNewImage('');
      setNewFrac(false);
      setNewVentaBulto(false);
      setNewUnidadesBulto('12');
      setNewPrecioBulto('');
      playBeep('ok');
      notifyToast(
        newVentaBulto
          ? `"${cleanName}" registrado (${finalStockUnits} uds · Bulto ×${upb}).`
          : `Repuesto "${cleanName}" añadido al inventario.`,
        'success'
      );
      if (!stayOnTab) setTab('inventory');
    } finally {
      setSavingNew(false);
    }
  };

  const handleExportInventoryCSV = (onlyLow = false) => {
    const source = onlyLow ? products.filter((p) => p.stock <= 5) : products;
    downloadCSV(
      `${onlyLow ? 'Reposicion_Stock_Bajo' : 'Inventario'}_${localName.replace(/\s+/g, '_')}_${new Date()
        .toISOString()
        .slice(0, 10)}.csv`,
      ['Nombre', 'Codigo_Barra', 'Stock', 'Costo_USD', 'Precio_USD', 'Bs_BCV', 'Bs_Paralelo1', 'Bs_Paralelo2', 'IVA'],
      source.map((p) => [
        p.id,
        p.barcode,
        p.stock,
        p.cost,
        p.price,
        round2(p.price * bcvRate),
        round2(p.price * secondaryRate),
        round2(p.price * tertiaryRate),
        p.ivaIncluded ? 'SI' : 'NO',
      ])
    );
  };

  const handleExportBackupJSON = () => {
    const payload = {
      exportado: new Date().toISOString(),
      comercio: localName,
      tasas: { bcv: bcvRate, paralela1: secondaryRate, paralela2: tertiaryRate },
      productos: products.map((p) => ({
        key: p.key,
        nombre: p.id,
        barcode: p.barcode,
        stock: p.stock,
        costo: p.cost,
        precio: p.price,
        fraccionable: p.fraccionable,
        iva_incluido: p.ivaIncluded,
      })),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Respaldo_Sistema_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    notifyToast('Respaldo JSON descargado.', 'success');
  };

  const handleSaveRatesInAdmin = async () => {
    const r1 = Number(rate1Draft);
    const r2 = Number(rate2Draft);
    const r3 = Number(rate3Draft);
    if (!Number.isFinite(r1) || !Number.isFinite(r2) || !Number.isFinite(r3) || r1 <= 0 || r2 <= 0 || r3 <= 0) {
      notifyToast('Todas las tasas deben ser números mayores a 0.', 'warning');
      return;
    }
    try {
      await updateTenantSettings({
        tasa_bcv: round2(r1),
        tasa_secundaria: round2(r2),
        tasa_terciaria: round2(r3),
      });
      playBeep('ok');
      notifyToast('Tasas de cambio actualizadas en todo el sistema.', 'success');
    } catch (err) {
      playBeep('err');
      console.error('Error guardando tasas manuales:', err);
      notifyToast('No se pudieron guardar las tasas en la nube. Verifica tu conexión e intenta nuevamente.', 'error');
    }
  };

  const handleSyncAllRates = async () => {
    setSyncingRates(true);
    try {
      await syncAllRates(false);
    } finally {
      setSyncingRates(false);
    }
  };

  // Live profit summary for New Product
  const newCostVal = Number(newCost) || 0;
  const newPrice1Val = Number(newPrice1) || 0;
  const newProfitUsd = round2(newPrice1Val - newCostVal);
  const newRealMarginPct =
    newPrice1Val > 0 ? round2(((newPrice1Val - newCostVal) / newPrice1Val) * 100) : 0;

  // Live profit summary for Edit Product
  const editCostVal = Number(editCost) || 0;
  const editPrice1Val = Number(editPrice1) || 0;
  const editProfitUsd = round2(editPrice1Val - editCostVal);
  const editRealMarginPct =
    editCostVal > 0 && editPrice1Val > 0
      ? round2(((editPrice1Val - editCostVal) / editCostVal) * 100)
      : editPrice1Val > 0
      ? round2(((editPrice1Val - editCostVal) / editPrice1Val) * 100)
      : 0;

  const modalShellClass =
    viewMode === 'mobile' && isWideViewport
      ? 'max-w-[460px] w-full h-[94vh]'
      : isMobileLayout
      ? 'w-full h-[96vh]'
      : 'max-w-7xl w-full h-[92vh]';

  return (
    <div className="fixed inset-0 z-[140] bg-slate-900/25 backdrop-blur-sm flex items-center justify-center p-1.5 sm:p-4">
      <div
        className={`bg-[#f7faff] rounded-3xl border border-sky-100 shadow-[0_28px_70px_-24px_rgba(14,116,144,0.22)] flex flex-col overflow-hidden animate-panel-in ${modalShellClass}`}
      >
        <div className="h-[3px] w-full bg-gradient-to-r from-sky-400 via-cyan-400 to-emerald-400 shrink-0" />
        {/* Top Bar */}
        <div className="px-4 sm:px-5 py-3 bg-white/95 backdrop-blur-md border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 flex items-center justify-center shrink-0">
              <Package className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-900 truncate">
                Panel de Administración · Productos y Sistemas
              </h2>
              <p className="text-xs text-slate-500 font-mono truncate">
                {inventoryStats.total} productos · {inventoryStats.low} bajo · {inventoryStats.out} agotados · Costo $
                {inventoryStats.totalCostUsd.toFixed(2)}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <ViewModeToggle compact />
            <button
              type="button"
              onClick={() => setVoidModalOpen(true)}
              className="px-3 py-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-xs font-semibold text-rose-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              title="Anular factura y restablecer stock (requiere autorización Admin)"
            >
              <Ban className="w-3.5 h-3.5 text-rose-600" />
              <span>Anular Factura</span>
            </button>
            <button
              type="button"
              onClick={() => setMechanicsModalOpen(true)}
              className="px-3 py-1.5 rounded-xl border border-amber-200 bg-amber-50 hover:bg-amber-100 text-xs font-semibold text-amber-900 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              title="Agregar o quitar mecánicos del botón Motor"
            >
              <Wrench className="w-3.5 h-3.5 text-amber-600" />
              <span>Mecánicos ({mechanics.length})</span>
            </button>
            <button
              type="button"
              onClick={onOpenSecurity}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5 text-sky-600" />
              <span className={isMobileLayout ? 'hidden sm:inline' : ''}>Seguridad</span>
            </button>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              title="Recargar página"
            >
              <RotateCw className="w-3.5 h-3.5 text-sky-600" />
              <span>Recargar</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer shrink-0"
              aria-label="Cerrar panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-4 sm:px-5 py-2.5 bg-white border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          {(
            [
              { id: 'inventory', label: 'Inventario y Productos', Icon: Package },
              { id: 'new', label: 'Nuevo Producto / Excel', Icon: PlusCircle },
              {
                id: 'fiados',
                label: `Fiados y Cuentas (${Object.keys(fiados || {}).length})`,
                Icon: BookOpen,
              },
              { id: 'labels', label: 'Etiquetas y Tasa BCV', Icon: Tag },
              { id: 'closures', label: `Cierres Guardados (${savedCierres.length})`, Icon: Archive },
              { id: 'customers', label: `Clientes Facturación (${customers.length})`, Icon: UserCheck },
              { id: 'checker', label: 'Consultor de Precios', Icon: Barcode },
              { id: 'systems', label: 'Sistemas y Tasas', Icon: Settings2 },
              { id: 'fiscal', label: 'Datos Fiscales', Icon: Building2 },
              { id: 'reports', label: 'Dashboard y Ventas', Icon: BarChart3 },
              { id: 'cashiers', label: 'Usuarios, Proveedores y Compras', Icon: Users },
              { id: 'membership', label: 'Membresía', Icon: Crown },
              { id: 'theme', label: 'Apariencia POS', Icon: Palette },
            ] as const
          ).map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition-all btn-press ${
                tab === id
                  ? 'bg-gradient-to-r from-sky-500 to-cyan-500 text-white shadow-xs'
                  : 'bg-sky-50/70 text-slate-700 hover:bg-sky-100/80 hover:text-sky-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" /> {label}
            </button>
          ))}
        </div>

        {/* Visible Casilla de Membresía Actual */}
        <div
          className={`px-4 sm:px-5 py-2 border-b flex flex-wrap items-center justify-between gap-2 text-xs ${
            membershipExpired || membershipDaysLeft === 0
              ? 'bg-rose-50 border-rose-200 text-rose-900'
              : membershipDaysLeft <= 5
              ? 'bg-amber-50 border-amber-200 text-amber-900'
              : 'bg-emerald-50/70 border-emerald-200/80 text-emerald-950'
          }`}
        >
          <div className="flex flex-wrap items-center gap-2 min-w-0">
            <Crown
              className={`w-4 h-4 shrink-0 ${
                membershipExpired || membershipDaysLeft === 0
                  ? 'text-rose-600'
                  : membershipDaysLeft <= 5
                  ? 'text-amber-600'
                  : 'text-emerald-600'
              }`}
            />
            <span className="font-bold">
              Membresía actual: {membership?.nombre || 'Sin plan'}
            </span>
            <span className="font-mono tabular-nums font-extrabold px-2 py-0.5 rounded-md bg-white/80 border border-current/15">
              {membershipDaysLeft} {membershipDaysLeft === 1 ? 'día disponible' : 'días disponibles'}
            </span>
            {membership?.vence && (
              <span className="text-[11px] opacity-80 font-mono">
                Vence: {new Date(membership.vence).toLocaleDateString('es-VE')}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setTab('membership')}
              className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-800 hover:bg-slate-100 font-semibold cursor-pointer whitespace-nowrap"
            >
              Ver Casilla
            </button>
            {onOpenMembership && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenMembership();
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold cursor-pointer whitespace-nowrap"
              >
                Renovar / Pagar
              </button>
            )}
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-3.5 sm:p-5">
          {tab === 'inventory' && (
            <div className="space-y-4">
              {/* KPI Summary Strip */}
              <div
                className={`grid gap-3 ${
                  isMobileLayout ? 'grid-cols-2' : 'grid-cols-2 lg:grid-cols-4'
                }`}
              >
                <div className="bg-white rounded-xl border border-slate-200 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    Total en Catálogo
                  </span>
                  <span className="text-lg font-mono font-bold text-slate-900 mt-0.5 block">
                    {inventoryStats.total}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    {inventoryStats.ivaCount} con IVA · {inventoryStats.noBarcode} sin código
                  </span>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    Capital en Costo
                  </span>
                  <span className="text-lg font-mono font-bold text-slate-900 mt-0.5 block">
                    ${inventoryStats.totalCostUsd.toFixed(2)}
                  </span>
                  <span className="text-[11px] font-mono text-slate-500">
                    {formatMoney(inventoryStats.totalCostUsd * bcvRate)} Bs
                  </span>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    Valor Venta BCV
                  </span>
                  <span className="text-lg font-mono font-bold text-emerald-700 mt-0.5 block">
                    ${inventoryStats.totalRetailUsd.toFixed(2)}
                  </span>
                  <span className="text-[11px] font-mono text-emerald-700">
                    Margen prom: {inventoryStats.estMarginPct.toFixed(1)}%
                  </span>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    Alertas de Stock
                  </span>
                  <span className="text-lg font-mono font-bold text-rose-600 mt-0.5 block">
                    {inventoryStats.low + inventoryStats.out}
                  </span>
                  <span className="text-[11px] text-amber-700 font-medium">
                    {inventoryStats.low} críticos · {inventoryStats.out} agotados
                  </span>
                </div>
              </div>

              {/* Search, Filters & Sort Toolbar */}
              <div className="bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-4 space-y-3">
                <div className="flex flex-wrap items-center gap-2.5">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Buscar producto o código de barras..."
                      className="w-full pl-9 pr-8 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                    />
                    {query && (
                      <button
                        type="button"
                        onClick={() => setQuery('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                        aria-label="Limpiar búsqueda"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onOpenScanner('register', (code) => {
                        setQuery(code);
                        notifyToast(`Buscando código: ${code}`, 'info');
                      })
                    }
                    className="px-3 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                    title="Escanear código de barra"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Escanear</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBulkImportOpen(true)}
                    className="px-3 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                    title="Importar productos masivamente desde Excel, CSV o documentos"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Importar Excel / Doc</span>
                  </button>

                  {categoriesList.length > 0 && (
                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="px-3 py-2.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl text-slate-700 cursor-pointer"
                      aria-label="Filtrar por categoría"
                    >
                      <option value="ALL">Todas las categorías</option>
                      {categoriesList.map((cat) => (
                        <option key={cat} value={cat}>
                          Cat: {cat}
                        </option>
                      ))}
                      <option value="UNCAT">Sin categoría</option>
                    </select>
                  )}

                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="px-3 py-2.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl text-slate-700 cursor-pointer"
                    aria-label="Ordenar productos"
                  >
                    <option value="name">Orden: Nombre (A-Z)</option>
                    <option value="stock_asc">Orden: Menor stock</option>
                    <option value="stock_desc">Orden: Mayor stock</option>
                    <option value="price_desc">Orden: Mayor precio</option>
                    <option value="margin_asc">Orden: Menor margen</option>
                  </select>
                </div>

                {/* Filter Segmented Strip */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 scrollbar-thin">
                  {(
                    [
                      { id: 'all', label: `Todos (${inventoryStats.total})` },
                      { id: 'low', label: `Crítico ≤5 (${inventoryStats.low})` },
                      { id: 'out', label: `Agotado (${inventoryStats.out})` },
                      { id: 'iva', label: `Con IVA (${inventoryStats.ivaCount})` },
                      { id: 'nobarcode', label: `Sin código (${inventoryStats.noBarcode})` },
                      { id: 'frac', label: 'Fraccionables' },
                    ] as const
                  ).map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setStockFilter(f.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                        stockFilter === f.id
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                {/* Bulk Selection & Batch Operations */}
                <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2.5 border-t border-slate-100 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={toggleSelectVisible}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      {visibleProducts.length > 0 &&
                      visibleProducts.every((p) => selectedKeys.has(p.key)) ? (
                        <CheckSquare className="w-3.5 h-3.5 text-sky-600" />
                      ) : (
                        <Square className="w-3.5 h-3.5 text-slate-400" />
                      )}
                      {selectedKeys.size > 0
                        ? `${selectedKeys.size} sel. (limpiar)`
                        : 'Seleccionar visibles'}
                    </button>

                    {selectedKeys.size > 0 && (
                      <>
                        <div className="inline-flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                          <input
                            type="number"
                            value={bulkStockDelta}
                            onChange={(e) => setBulkStockDelta(e.target.value)}
                            className="w-12 px-1.5 py-1 text-xs font-mono text-center bg-transparent"
                            min={1}
                          />
                          <button
                            type="button"
                            onClick={() => handleBulkStockAdjust(1)}
                            className="px-2 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-semibold cursor-pointer"
                          >
                            +Stock
                          </button>
                          <button
                            type="button"
                            onClick={() => handleBulkStockAdjust(-1)}
                            className="px-2 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold cursor-pointer"
                          >
                            -Stock
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={handleBulkDeleteSelected}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Eliminar ({selectedKeys.size})
                        </button>
                      </>
                    )}

                    <button
                      type="button"
                      onClick={() => handleBulkIva(true)}
                      className="px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 font-semibold cursor-pointer"
                    >
                      + IVA 16% {selectedKeys.size > 0 ? '(sel.)' : '(todos)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleBulkIva(false)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                    >
                      - Quitar IVA
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="inline-flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                      <input
                        type="number"
                        value={bulkPct}
                        onChange={(e) => setBulkPct(e.target.value)}
                        className="w-12 px-1.5 py-1 text-xs font-mono bg-transparent text-center"
                        min={1}
                        max={95}
                      />
                      <span className="pr-1.5 text-slate-500">%</span>
                      <button
                        type="button"
                        onClick={() => handleBulkPercent(1)}
                        className="px-2.5 py-1.5 bg-emerald-600 text-white font-semibold hover:bg-emerald-700 cursor-pointer"
                      >
                        + Subir
                      </button>
                      <button
                        type="button"
                        onClick={() => handleBulkPercent(-1)}
                        className="px-2.5 py-1.5 bg-rose-600 text-white font-semibold hover:bg-rose-700 cursor-pointer"
                      >
                        - Bajar
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleExportInventoryCSV(false)}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 font-semibold text-slate-700 inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-600" /> CSV
                    </button>
                  </div>
                </div>
              </div>

              {/* Adaptive Inventory Listing: Mobile Cards vs Desktop Data Table */}
              {isMobileLayout ? (
                <div className="space-y-2.5">
                  {filteredProducts.length === 0 ? (
                    <div className="bg-white rounded-2xl border border-slate-200 py-10 px-4 text-center text-xs text-slate-400">
                      No se encontraron productos que coincidan con el filtro.
                    </div>
                  ) : (
                    visibleProducts.map((p) => {
                      const margin =
                        p.price > 0 ? round2(((p.price - p.cost) / p.price) * 100) : 0;
                      const isSelected = selectedKeys.has(p.key);
                      return (
                        <div
                          key={p.key}
                          className={`bg-white rounded-2xl border p-3.5 space-y-3 ${
                            isSelected ? 'border-sky-400 ring-1 ring-sky-200' : 'border-slate-200'
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <button
                              type="button"
                              onClick={() => toggleSelectOne(p.key)}
                              className="mt-1 text-slate-500 cursor-pointer shrink-0"
                              aria-label={`Seleccionar ${p.id}`}
                            >
                              {isSelected ? (
                                <CheckSquare className="w-5 h-5 text-sky-600" />
                              ) : (
                                <Square className="w-5 h-5 text-slate-300" />
                              )}
                            </button>
                            <ProductThumb
                              name={p.id}
                              image={p.image}
                              className="w-11 h-11 text-xs shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-slate-900 leading-snug">
                                {p.id}
                              </p>
                              <p className="text-[11px] font-mono text-slate-500 truncate mt-0.5">
                                {p.barcode || 'Sin código'}
                                {p.fraccionable ? ' · Fracc.' : ''}
                                {p.ventaPorBulto && (p.unidadesPorBulto || 0) > 1
                                  ? ` · Bulto ×${p.unidadesPorBulto} ($${(
                                      p.precioBulto && p.precioBulto > 0
                                        ? p.precioBulto
                                        : round2(p.price * (p.unidadesPorBulto || 1))
                                    ).toFixed(2)})`
                                  : ''}
                                {' · '}Margen {margin.toFixed(0)}%
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleToggleItemIva(p)}
                              className={`px-2 py-1 rounded-lg text-[11px] font-mono font-semibold shrink-0 cursor-pointer ${
                                p.ivaIncluded
                                  ? 'bg-sky-50 text-sky-700 border border-sky-200'
                                  : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {p.ivaIncluded ? 'IVA 16%' : 'Exento'}
                            </button>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono bg-slate-50 rounded-xl p-2.5">
                            <div>
                              <span className="text-[10px] text-slate-500 block font-sans">Costo</span>
                              <span className="font-semibold text-slate-700">${p.cost.toFixed(2)}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-500 block font-sans">Precio USD</span>
                              <span className="font-bold text-emerald-700">${p.price.toFixed(2)}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-500 block font-sans">Bs BCV</span>
                              <span className="font-semibold text-slate-900">
                                {(p.price * bcvRate).toFixed(2)}
                              </span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-500 block font-sans">Bs P1 / P2</span>
                              <span className="font-semibold text-sky-700">
                                {(p.price * secondaryRate).toFixed(2)} / {(p.price * tertiaryRate).toFixed(2)}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-1">
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleQuickStock(p, -1)}
                                className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
                                aria-label="Restar 1"
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <span
                                className={`min-w-[42px] text-center font-mono text-sm font-bold ${
                                  p.stock <= 0
                                    ? 'text-rose-600'
                                    : p.stock <= 5
                                    ? 'text-amber-600'
                                    : 'text-emerald-700'
                                }`}
                              >
                                {p.stock}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleQuickStock(p, 1)}
                                className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
                                aria-label="Sumar 1"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleQuickStock(p, 5)}
                                className="min-h-[40px] px-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-mono font-bold cursor-pointer"
                              >
                                +5
                              </button>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => startEdit(p)}
                                className="min-h-[40px] min-w-[40px] rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 flex items-center justify-center cursor-pointer"
                                title="Editar producto"
                                aria-label={`Editar ${p.id}`}
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => requestDeleteProduct(p)}
                                className="min-h-[40px] min-w-[40px] rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center cursor-pointer"
                                title="Eliminar producto"
                                aria-label={`Eliminar ${p.id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 pl-4 pr-2 w-8">
                            <button
                              type="button"
                              onClick={toggleSelectVisible}
                              className="text-slate-500 cursor-pointer"
                              title="Seleccionar todos los visibles"
                            >
                              {visibleProducts.length > 0 &&
                              visibleProducts.every((p) => selectedKeys.has(p.key)) ? (
                                <CheckSquare className="w-4 h-4 text-sky-600" />
                              ) : (
                                <Square className="w-4 h-4" />
                              )}
                            </button>
                          </th>
                          <th className="py-2.5 px-3 font-semibold">Producto</th>
                          <th className="py-2.5 px-3 font-semibold text-right">Costo</th>
                          <th className="py-2.5 px-3 font-semibold text-right">Precio USD / Bolívares</th>
                          <th className="py-2.5 px-3 font-semibold text-right">Margen</th>
                          <th className="py-2.5 px-3 font-semibold text-center">Stock</th>
                          <th className="py-2.5 px-3 font-semibold text-center">IVA</th>
                          <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredProducts.length === 0 ? (
                          <tr>
                            <td colSpan={8} className="py-10 text-center text-slate-400">
                              No se encontraron productos que coincidan con el filtro.
                            </td>
                          </tr>
                        ) : (
                          visibleProducts.map((p) => {
                            const margin =
                              p.price > 0 ? round2(((p.price - p.cost) / p.price) * 100) : 0;
                            const isSelected = selectedKeys.has(p.key);
                            return (
                              <tr
                                key={p.key}
                                className={`hover:bg-slate-50/80 ${isSelected ? 'bg-sky-50/40' : ''}`}
                              >
                                <td className="py-2.5 pl-4 pr-2">
                                  <button
                                    type="button"
                                    onClick={() => toggleSelectOne(p.key)}
                                    className="text-slate-400 hover:text-sky-600 cursor-pointer"
                                  >
                                    {isSelected ? (
                                      <CheckSquare className="w-4 h-4 text-sky-600" />
                                    ) : (
                                      <Square className="w-4 h-4" />
                                    )}
                                  </button>
                                </td>
                                <td className="py-2.5 px-3">
                                  <div className="flex items-center gap-3">
                                    <ProductThumb
                                      name={p.id}
                                      image={p.image}
                                      className="w-9 h-9 text-[11px]"
                                    />
                                    <div>
                                      <p className="font-bold text-slate-900 leading-tight">{p.id}</p>
                                      <p className="text-[11px] font-mono text-slate-500">
                                        {p.barcode || 'Sin código'}
                                        {p.categoria ? ` · ${p.categoria}` : ''}
                                        {p.fraccionable ? ' · Fraccionable' : ''}
                                        {p.ventaPorBulto && (p.unidadesPorBulto || 0) > 1
                                          ? ` · Bulto ×${p.unidadesPorBulto}`
                                          : ''}
                                      </p>
                                    </div>
                                  </div>
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                                  ${p.cost.toFixed(2)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono">
                                  <span className="font-bold text-slate-900 block">
                                    Detal: ${p.price.toFixed(2)}
                                    {p.ventaPorBulto && (p.unidadesPorBulto || 0) > 1 && (
                                      <span className="text-indigo-700 ml-1.5">
                                        · Bulto: $
                                        {(p.precioBulto && p.precioBulto > 0
                                          ? p.precioBulto
                                          : round2(p.price * (p.unidadesPorBulto || 1))
                                        ).toFixed(2)}
                                      </span>
                                    )}
                                  </span>
                                  <span className="text-[10px] text-slate-500 block">
                                    BCV {(p.price * bcvRate).toFixed(2)} · P1 {(p.price * secondaryRate).toFixed(2)} · P2{' '}
                                    {(p.price * tertiaryRate).toFixed(2)} Bs
                                  </span>
                                </td>
                                <td
                                  className={`py-2.5 px-3 text-right font-mono font-semibold ${
                                    p.cost <= 0
                                      ? 'text-slate-400'
                                      : margin < 12
                                      ? 'text-rose-600'
                                      : 'text-emerald-700'
                                  }`}
                                >
                                  {p.cost > 0 ? `${margin.toFixed(0)}%` : '—'}
                                </td>
                                <td className="py-2.5 px-3">
                                  <div className="flex items-center justify-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleQuickStock(p, -1)}
                                      className="w-6 h-6 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
                                    >
                                      <Minus className="w-3 h-3" />
                                    </button>
                                    <span
                                      className={`min-w-[34px] text-center font-mono font-bold ${
                                        p.stock <= 0
                                          ? 'text-rose-600'
                                          : p.stock <= 5
                                          ? 'text-amber-600'
                                          : 'text-emerald-700'
                                      }`}
                                    >
                                      {p.stock}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleQuickStock(p, 1)}
                                      className="w-6 h-6 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
                                    >
                                      <Plus className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleQuickStock(p, 5)}
                                      className="px-1.5 h-6 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-mono text-[10px] font-bold cursor-pointer"
                                      title="Sumar 5 unidades"
                                    >
                                      +5
                                    </button>
                                  </div>
                                </td>
                                <td className="py-2.5 px-3 text-center">
                                  <button
                                    type="button"
                                    onClick={() => handleToggleItemIva(p)}
                                    className={`px-2 py-1 rounded-lg font-mono font-semibold cursor-pointer ${
                                      p.ivaIncluded
                                        ? 'bg-sky-50 text-sky-700 border border-sky-200'
                                        : 'bg-slate-100 text-slate-500'
                                    }`}
                                  >
                                    {p.ivaIncluded ? '16%' : 'Exento'}
                                  </button>
                                </td>
                                <td className="py-2.5 px-4 text-right">
                                  <div className="inline-flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => startEdit(p)}
                                      className="p-1.5 rounded-lg hover:bg-sky-50 text-sky-700 cursor-pointer"
                                      title="Editar producto"
                                      aria-label={`Editar ${p.id}`}
                                    >
                                      <Edit3 className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => requestDeleteProduct(p)}
                                      className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                                      title="Eliminar producto"
                                      aria-label={`Eliminar ${p.id}`}
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {filteredProducts.length > visibleLimit && (
                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={() => setVisibleLimit((v) => v + 40)}
                    className="px-4 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
                  >
                    Mostrar 40 más ({filteredProducts.length - visibleLimit} restantes)
                  </button>
                </div>
              )}
            </div>
          )}

          {tab === 'new' && (
            <form
              onSubmit={(e) => handleCreateProduct(e, false)}
              className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 max-w-2xl mx-auto space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Registrar Nuevo Repuesto o Artículo</h3>
                  {newPrice1Val > 0 && (
                    <span className="text-xs font-mono font-bold text-emerald-700">
                      Ganancia: ${newProfitUsd.toFixed(2)} ({newRealMarginPct.toFixed(0)}%)
                    </span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setBulkImportOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" /> Carga Masiva desde Excel / Documento
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nombre / Descripción *
                  </label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Ej. Kit de Empacadura 150cc"
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Código de Barras
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={newBarcode}
                      onChange={(e) => setNewBarcode(e.target.value)}
                      placeholder="Escanear o escribir"
                      className="flex-1 px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => onOpenScanner('register', (code) => setNewBarcode(code))}
                      className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                      title="Escanear con cámara"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Categoría (opcional)
                  </label>
                  <input
                    type="text"
                    list="admin-categories-list"
                    value={newCat}
                    onChange={(e) => setNewCat(e.target.value)}
                    placeholder="Ej. Motor, Frenos, Lubricantes..."
                    maxLength={80}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <datalist id="admin-categories-list">
                    {categoriesList.map((cat) => (
                      <option key={cat} value={cat} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      Stock Inicial {newVentaBulto && newStockMode === 'bulto' ? '(en Bultos)' : '(en Unidades)'}
                    </label>
                    {newVentaBulto && (
                      <div className="inline-flex rounded-lg border border-indigo-200 bg-indigo-50 p-0.5 text-[10px] font-bold">
                        <button
                          type="button"
                          onClick={() => setNewStockMode('detal')}
                          className={`px-2 py-0.5 rounded-md cursor-pointer ${
                            newStockMode === 'detal'
                              ? 'bg-indigo-600 text-white'
                              : 'text-indigo-700 hover:bg-indigo-100'
                          }`}
                        >
                          Al Detal
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewStockMode('bulto')}
                          className={`px-2 py-0.5 rounded-md cursor-pointer ${
                            newStockMode === 'bulto'
                              ? 'bg-indigo-600 text-white'
                              : 'text-indigo-700 hover:bg-indigo-100'
                          }`}
                        >
                          Por Bultos
                        </button>
                      </div>
                    )}
                  </div>
                  <input
                    type="number"
                    step={newVentaBulto && newStockMode === 'bulto' ? '1' : '0.01'}
                    value={newStock}
                    onChange={(e) => setNewStock(e.target.value)}
                    placeholder="0"
                    className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  {newVentaBulto && newStockMode === 'bulto' && (Number(newStock) || 0) > 0 && (
                    <span className="text-[11px] font-mono text-indigo-700 font-semibold mt-1 block">
                      = {round2((Number(newStock) || 0) * Math.max(1, Math.round(Number(newUnidadesBulto) || 1)))} unidades totales en inventario
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Costo Unitario (USD)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newCost}
                    onChange={(e) => {
                      setNewCost(e.target.value);
                      handleAutoMargin(e.target.value, newMargin);
                    }}
                    placeholder="0.00"
                    className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Margen de Ganancia Automático (%)
                  </label>
                  <div className="relative">
                    <Percent className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="number"
                      step="1"
                      value={newMargin}
                      onChange={(e) => {
                        setNewMargin(e.target.value);
                        handleAutoMargin(newCost, e.target.value);
                      }}
                      className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Precio de Venta (USD) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newPrice1}
                    onChange={(e) => {
                      const val = e.target.value;
                      setNewPrice1(val);
                      const c = Number(newCost) || 0;
                      const p = Number(val) || 0;
                      if (c > 0 && p > 0) {
                        setNewMargin(String(round2(((p - c) / c) * 100)));
                      }
                    }}
                    placeholder="0.00"
                    className="w-full px-3 py-2 text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    El precio en USD se mantiene igual; en Bs varía según la tasa aplicada.
                  </span>
                </div>

                <div className="sm:col-span-2 p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-3 gap-2 text-xs font-mono">
                  <div>
                    <span className="text-[10px] font-sans font-semibold text-emerald-700 block">
                      BCV ({bcvRate.toFixed(2)})
                    </span>
                    <span className="font-bold text-slate-900">
                      {formatMoney(newPrice1Val * bcvRate)} Bs
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-sans font-semibold text-sky-700 block">
                      Paralelo 1 ({secondaryRate.toFixed(2)})
                    </span>
                    <span className="font-bold text-slate-900">
                      {formatMoney(newPrice1Val * secondaryRate)} Bs
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-sans font-semibold text-indigo-700 block">
                      Paralelo 2 ({tertiaryRate.toFixed(2)})
                    </span>
                    <span className="font-bold text-slate-900">
                      {formatMoney(newPrice1Val * tertiaryRate)} Bs
                    </span>
                  </div>
                </div>

                <div className="sm:col-span-2 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="block text-xs font-semibold text-slate-700">
                      Imagen del producto (Sincronizada con Google)
                    </label>
                    <label className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-indigo-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={autoSyncGoogleImg}
                        onChange={(e) => {
                          setAutoSyncGoogleImg(e.target.checked);
                          if (e.target.checked) setLiveNewImgDismissedFor('');
                        }}
                        className="rounded border-indigo-300 accent-indigo-600"
                      />
                      Sincronizar en vivo con el nombre
                    </label>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="flex-1 min-w-[180px] flex items-center gap-2 px-3 py-2 rounded-xl border border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 text-xs text-slate-600 cursor-pointer">
                      <ImageIcon className="w-4 h-4 text-sky-600 shrink-0" />
                      <span className="truncate">
                        {newImage ? 'Imagen lista (cambiar)' : 'Subir foto (auto-compresión)'}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImagePick(e.target.files?.[0], 'new')}
                        className="hidden"
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => void handleSearchGoogleImage('new')}
                      className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                      title="Buscar imagen real en Google según el nombre del producto"
                    >
                      <Globe className="w-3.5 h-3.5" /> Buscar en Google
                    </button>
                    {newImage && (
                      <div className="flex items-center gap-2">
                        <img
                          src={newImage}
                          alt="Vista previa"
                          className="w-9 h-9 rounded-lg object-cover border border-slate-200"
                        />
                        <button
                          type="button"
                          onClick={() => setNewImage('')}
                          className="px-2.5 py-2 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold cursor-pointer"
                        >
                          Quitar
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Live simultaneous Google image match strip (explicit confirmation before attaching) */}
                  {autoSyncGoogleImg && newName.trim().length >= 3 && liveNewImgDismissedFor !== newName.trim() && (
                    <div className="p-3 rounded-xl bg-indigo-50/60 border border-indigo-200/80 space-y-2">
                      <div className="flex items-center justify-between gap-2 text-[11px]">
                        <span className="font-bold text-indigo-900 inline-flex items-center gap-1.5 truncate">
                          {liveNewImgLoading ? (
                            <Loader2 className="w-3.5 h-3.5 text-indigo-600 animate-spin shrink-0" />
                          ) : (
                            <Globe className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          )}
                          {liveNewImgLoading
                            ? `Buscando en Google coincidencias exactas para “${newName.trim()}”...`
                            : liveNewImgResults.length > 0
                            ? `Coincidencias reales en Google para “${liveNewImgQuery}” · Toca una para confirmar:`
                            : `Sin coincidencias exactas en Google para “${liveNewImgQuery}” (agrega marca o modelo)`}
                        </span>
                        <button
                          type="button"
                          onClick={() => setLiveNewImgDismissedFor(newName.trim())}
                          className="text-slate-500 hover:text-slate-800 font-semibold whitespace-nowrap cursor-pointer"
                        >
                          Ocultar
                        </button>
                      </div>

                      {liveNewImgResults.length > 0 && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {liveNewImgResults.map((cand, idx) => (
                            <button
                              key={cand.sourceUrl + idx}
                              type="button"
                              onClick={() => void handleApplyLiveGoogleImage('new', cand)}
                              className="group rounded-xl bg-white border border-indigo-200/80 hover:border-emerald-500 hover:ring-2 hover:ring-emerald-200 p-1.5 text-left transition cursor-pointer flex flex-col gap-1"
                              title={`Confirmar y usar: ${cand.title}`}
                            >
                              <div className="aspect-square w-full rounded-lg bg-slate-50 overflow-hidden flex items-center justify-center relative">
                                <img
                                  src={cand.dataUrl}
                                  alt={cand.title}
                                  className="w-full h-full object-contain"
                                />
                                {typeof cand.matchScore === 'number' && cand.matchScore > 0 && (
                                  <span className="absolute top-1 right-1 px-1.5 py-0.5 rounded bg-emerald-600/90 text-white font-mono text-[9px] font-bold">
                                    {cand.matchScore}%
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] font-semibold text-slate-800 line-clamp-1 leading-tight">
                                {cand.title}
                              </p>
                              <span className="text-[10px] font-bold text-emerald-700 group-hover:text-emerald-800 inline-flex items-center gap-0.5">
                                <Check className="w-3 h-3" /> Usar foto
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Dedicated Venta por Bultos & Al Detal Configuration Section */}
              <div className="rounded-2xl border border-indigo-200/90 bg-indigo-50/40 p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="inline-flex items-center gap-2 text-xs font-bold text-indigo-950 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newVentaBulto}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setNewVentaBulto(checked);
                        if (!checked) setNewStockMode('detal');
                        if (checked && !newPrecioBulto && newPrice1Val > 0) {
                          const upb = Math.max(2, Math.round(Number(newUnidadesBulto) || 12));
                          setNewPrecioBulto(String(round2(newPrice1Val * upb)));
                        }
                      }}
                      className="rounded border-indigo-300 accent-indigo-600"
                    />
                    <Boxes className="w-4 h-4 text-indigo-600" />
                    Activar venta por Bultos / Cajas (y Al Detal)
                  </label>
                  <span className="text-[11px] text-indigo-700 font-medium">
                    Permite vender tanto por bulto completo como al detal en caja
                  </span>
                </div>

                {newVentaBulto && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Unidades que trae el bulto *
                      </label>
                      <input
                        type="number"
                        min={2}
                        step="1"
                        value={newUnidadesBulto}
                        onChange={(e) => {
                          setNewUnidadesBulto(e.target.value);
                          const upb = Math.max(2, Math.round(Number(e.target.value) || 0));
                          if (newPrice1Val > 0 && upb >= 2) {
                            setNewPrecioBulto(String(round2(newPrice1Val * upb)));
                          }
                        }}
                        placeholder="Ej. 12, 24, 36"
                        className="w-full px-3 py-2 text-sm font-mono font-bold bg-white border border-indigo-200 rounded-xl"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="block text-xs font-semibold text-slate-700">
                          Precio por Bulto (USD)
                        </label>
                        {newPrice1Val > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              const upb = Math.max(2, Math.round(Number(newUnidadesBulto) || 12));
                              setNewPrecioBulto(String(round2(newPrice1Val * upb)));
                            }}
                            className="text-[10px] font-bold text-indigo-700 hover:underline cursor-pointer"
                          >
                            = ×{Math.max(2, Math.round(Number(newUnidadesBulto) || 12))} detal
                          </button>
                        )}
                      </div>
                      <input
                        type="number"
                        step="0.01"
                        value={newPrecioBulto}
                        onChange={(e) => setNewPrecioBulto(e.target.value)}
                        placeholder={
                          newPrice1Val > 0
                            ? String(round2(newPrice1Val * Math.max(2, Math.round(Number(newUnidadesBulto) || 12))))
                            : '0.00'
                        }
                        className="w-full px-3 py-2 text-sm font-mono font-bold bg-white border border-indigo-200 rounded-xl text-indigo-900"
                      />
                    </div>
                    {(() => {
                      const upb = Math.max(2, Math.round(Number(newUnidadesBulto) || 12));
                      const bUsd =
                        Number(newPrecioBulto) > 0
                          ? Number(newPrecioBulto)
                          : round2(newPrice1Val * upb);
                      if (bUsd <= 0) return null;
                      return (
                        <div className="sm:col-span-2 p-2.5 rounded-xl bg-white border border-indigo-200/80 grid grid-cols-3 gap-2 text-[11px] font-mono">
                          <div>
                            <span className="text-[10px] font-sans font-semibold text-emerald-700 block">
                              Bulto BCV
                            </span>
                            <span className="font-bold text-slate-900">
                              {formatMoney(bUsd * bcvRate)} Bs
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] font-sans font-semibold text-sky-700 block">
                              Bulto P1
                            </span>
                            <span className="font-bold text-slate-900">
                              {formatMoney(bUsd * secondaryRate)} Bs
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] font-sans font-semibold text-indigo-700 block">
                              C/u en bulto
                            </span>
                            <span className="font-bold text-indigo-800">
                              ${(bUsd / upb).toFixed(2)} USD
                            </span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>

              <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newFrac}
                  onChange={(e) => setNewFrac(e.target.checked)}
                  className="rounded border-slate-300"
                />
                Producto fraccionable (acepta decimales como 0.50 metros / litros al detal)
              </label>

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="submit"
                  disabled={savingNew}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs sm:text-sm font-semibold cursor-pointer"
                >
                  {savingNew ? 'Guardando en la nube...' : 'Guardar Producto'}
                </button>
                <button
                  type="button"
                  disabled={savingNew}
                  onClick={(e) => handleCreateProduct(e, true)}
                  className="py-2.5 px-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-semibold cursor-pointer"
                >
                  Guardar y añadir otro
                </button>
              </div>
            </form>
          )}

          {tab === 'systems' && (
            <div className="space-y-4 max-w-5xl mx-auto">
              {/* Multi-Currency & Live Daily Exchange Rates Manager */}
              <CurrencyRateManager mode="admin" />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

                {/* Display Mode & System Reload */}
                <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <SlidersHorizontal className="w-4 h-4 text-sky-600" />
                      Modo de Pantalla y Adaptación
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Cambia entre vista Escritorio o Móvil en cualquier dispositivo, o usa Auto para adaptarse al tamaño de pantalla.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <span className="text-xs font-bold text-slate-800 block">
                        Vista activa: {isMobileLayout ? 'Modo Móvil (Táctil)' : 'Modo Escritorio (Expandido)'}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Preferencia guardada: {viewMode === 'auto' ? 'Automático' : viewMode === 'mobile' ? 'Móvil fijo' : 'Escritorio fijo'}
                      </span>
                    </div>
                    <ViewModeToggle />
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={toggleIva}
                      className={`flex-1 py-2.5 px-3 rounded-xl border text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer ${
                        ivaActive
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Percent className="w-3.5 h-3.5" />
                      {ivaActive ? 'IVA 16% Activo en Caja' : 'IVA en Caja: Desactivado'}
                    </button>
                    <button
                      type="button"
                      onClick={() => window.location.reload()}
                      className="py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCw className="w-3.5 h-3.5" /> Recargar Sistema
                    </button>
                  </div>
                </div>
              </div>

              {/* Mechanics Manager Card inside Systems */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-amber-600" />
                      Mecánicos Responsables (Botón Motor)
                    </h3>
                    <p className="text-xs text-slate-500">
                      Agrega los nombres de los mecánicos que aparecerán al abrir Reparación de Motor.
                    </p>
                  </div>
                  {onOpenMotor && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenMotor();
                      }}
                      className="px-3 py-1.5 rounded-xl border border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Wrench className="w-3.5 h-3.5" /> Abrir Motor
                    </button>
                  )}
                </div>

                <form onSubmit={handleAddMechanic} className="flex gap-2">
                  <input
                    type="text"
                    value={newMechanicName}
                    onChange={(e) => setNewMechanicName(e.target.value)}
                    placeholder="Nombre del mecánico (ej: Carlos Pérez)"
                    maxLength={60}
                    className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <button
                    type="submit"
                    disabled={savingMechanic}
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Agregar Mecánico
                  </button>
                </form>

                {mechanics.length === 0 ? (
                  <div className="p-3 rounded-xl bg-slate-50 border border-dashed border-slate-300 text-xs text-slate-500 flex items-center justify-between gap-2">
                    <span>No hay mecánicos registrados. Se mostrará solo la opción "Otro".</span>
                    <button
                      type="button"
                      onClick={() => void updateMechanics(['José', 'Jesús'])}
                      className="text-sky-700 font-semibold hover:underline cursor-pointer shrink-0"
                    >
                      Restaurar base
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {mechanics.map((m) => (
                      <div
                        key={m}
                        className="inline-flex items-center gap-2 pl-3 pr-1.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-800"
                      >
                        <Wrench className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>{m}</span>
                        <button
                          type="button"
                          disabled={savingMechanic}
                          onClick={() => void handleRemoveMechanic(m)}
                          className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                          title={`Quitar a ${m}`}
                          aria-label={`Quitar a ${m}`}
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Operational Launchers */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Accesos Directos de Operaciones ({liveShiftTotals.count} ventas en turno)
                    </h3>
                    <p className="text-xs text-slate-500 font-mono">
                      Turno activo: {formatMoney(liveShiftTotals.ves)} Bs · ${liveShiftTotals.usd.toFixed(2)} USD
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
                  {onOpenFiados && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenFiados();
                      }}
                      className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-left flex items-center gap-3 cursor-pointer transition-colors"
                    >
                      <BookOpen className="w-5 h-5 text-rose-600 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-900 block">Cuentas por Cobrar (Fiados)</span>
                        <span className="text-[11px] text-slate-500">Abonos, cuotas y clientes</span>
                      </div>
                    </button>
                  )}

                  {onOpenCloseShift && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenCloseShift();
                      }}
                      className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-left flex items-center gap-3 cursor-pointer transition-colors"
                    >
                      <TrendingUp className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-900 block">Cierre de Turno y PDF</span>
                        <span className="text-[11px] text-slate-500">Consolidar caja del día</span>
                      </div>
                    </button>
                  )}

                  {onOpenTaller && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenTaller();
                      }}
                      className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-left flex items-center gap-3 cursor-pointer transition-colors"
                    >
                      <Store className="w-5 h-5 text-sky-600 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-900 block">Control de Taller</span>
                        <span className="text-[11px] text-slate-500">Trabajos y liquidaciones</span>
                      </div>
                    </button>
                  )}

                  {onOpenMotor && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenMotor();
                      }}
                      className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-left flex items-center gap-3 cursor-pointer transition-colors"
                    >
                      <Wrench className="w-5 h-5 text-amber-600 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-900 block">Reparación de Motor</span>
                        <span className="text-[11px] text-slate-500">Registrar mano de obra</span>
                      </div>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={onOpenSecurity}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-left flex items-center gap-3 cursor-pointer transition-colors"
                  >
                    <Shield className="w-5 h-5 text-indigo-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-900 block">Seguridad y MFA</span>
                      <span className="text-[11px] text-slate-500">Clave y verificación 2FA</span>
                    </div>
                  </button>

                  {onOpenSupport && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenSupport();
                      }}
                      className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-left flex items-center gap-3 cursor-pointer transition-colors"
                    >
                      <Headphones className="w-5 h-5 text-sky-600 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-900 block">Soporte Técnico</span>
                        <span className="text-[11px] text-slate-500">Enviar ticket al propietario</span>
                      </div>
                    </button>
                  )}
                </div>
              </div>

              {/* Export & Backup */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3">
                <h3 className="text-sm font-bold text-slate-900">Respaldo y Exportación de Inventario</h3>
                <div className="flex flex-wrap gap-2.5 text-xs">
                  <button
                    type="button"
                    onClick={() => handleExportInventoryCSV(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 font-semibold text-slate-800 inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-600" />
                    Exportar Catálogo Completo (CSV)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleExportInventoryCSV(true)}
                    className="px-4 py-2.5 rounded-xl border border-amber-200 bg-amber-50 hover:bg-amber-100 font-semibold text-amber-900 inline-flex items-center gap-2 cursor-pointer"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    Orden de Reposición Stock ≤5 (CSV)
                  </button>
                  <button
                    type="button"
                    onClick={handleExportBackupJSON}
                    className="px-4 py-2.5 rounded-xl border border-sky-200 bg-sky-50 hover:bg-sky-100 font-semibold text-sky-900 inline-flex items-center gap-2 cursor-pointer"
                  >
                    <FileJson className="w-4 h-4 text-sky-600" />
                    Respaldo JSON de Productos y Tasas
                  </button>
                </div>
              </div>

              {/* Push Notifications & Android/Web App Installation */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <BellRing className="w-4 h-4 text-sky-600" />
                      Notificaciones Push (Android y Web) e Instalación App
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Recibe alertas instantáneas en tu teléfono Android o navegador cuando se apruebe una membresía, llegue un aviso de gerencia o respondan tu soporte.
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                      pushEnabled && pushPermission === 'granted'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {pushEnabled && pushPermission === 'granted' ? 'Push Activo' : 'Push Inactivo'}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2.5 text-xs">
                  {pushSupported ? (
                    <>
                      <button
                        type="button"
                        onClick={() => void togglePushNotifications()}
                        className={`px-4 py-2.5 rounded-xl font-semibold inline-flex items-center gap-2 cursor-pointer ${
                          pushEnabled && pushPermission === 'granted'
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'bg-sky-600 hover:bg-sky-700 text-white'
                        }`}
                      >
                        {pushEnabled && pushPermission === 'granted' ? (
                          <>
                            <BellRing className="w-4 h-4" /> Silenciar Notificaciones Push
                          </>
                        ) : (
                          <>
                            <Bell className="w-4 h-4" /> Activar Notificaciones Push
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => void sendTestPushNotification()}
                        className="px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 font-semibold text-slate-800 inline-flex items-center gap-2 cursor-pointer"
                      >
                        <Bell className="w-4 h-4 text-sky-600" /> Enviar Notificación de Prueba
                      </button>
                    </>
                  ) : (
                    <span className="text-slate-500">
                      Este navegador no soporta notificaciones push nativas.
                    </span>
                  )}
                  <PWAInstallButton />
                </div>
              </div>
            </div>
          )}

          {tab === 'fiados' && (
            <div className="max-w-6xl mx-auto">
              <FiadosModal open embedded onClose={() => {}} />
            </div>
          )}

          {tab === 'labels' && <LabelsAndRatePanel />}

          {tab === 'closures' && (
            <div className="space-y-4 max-w-6xl mx-auto">
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Archive className="w-4 h-4 text-sky-600" />
                    Cierres Hospedados en la Nube ({savedCierres.length})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Reimprime copias en {activePrinter ? `impresora (${activePrinter.name})` : 'navegador / PDF'} o elimina registros antiguos.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setVoidModalOpen(true)}
                    className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Ban className="w-3.5 h-3.5" /> Anular Factura de Cierre
                  </button>
                  <div className="relative min-w-[220px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={cierreSearch}
                      onChange={(e) => setCierreSearch(e.target.value)}
                      placeholder="Buscar por fecha o usuario..."
                      className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                {filteredCierres.length === 0 ? (
                  <div className="py-12 text-center text-xs text-slate-400">
                    No hay cierres guardados que coincidan con la búsqueda.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                        <tr>
                          <th className="py-3 px-4 font-semibold">Fecha y Hora</th>
                          <th className="py-3 px-3 font-semibold text-center">Ventas</th>
                          <th className="py-3 px-3 font-semibold text-right">Total Bs</th>
                          <th className="py-3 px-3 font-semibold text-right">Total USD</th>
                          <th className="py-3 px-3 font-semibold">Autorizado / Cerrado Por</th>
                          <th className="py-3 px-4 font-semibold text-right">Acciones</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredCierres.map((c) => (
                          <tr key={c.key || c.timestamp} className="hover:bg-slate-50/70">
                            <td className="py-3 px-4 font-mono">
                              <span className="font-bold text-slate-900 block">{c.fecha}</span>
                              <span className="text-[11px] text-slate-500">{c.hora}</span>
                            </td>
                            <td className="py-3 px-3 text-center font-mono font-bold text-slate-700">
                              {c.cantidad_ventas}
                            </td>
                            <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                              {formatMoney(c.total_general_ves)} Bs
                            </td>
                            <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-emerald-700">
                              ${(Number(c.total_general_usd) || 0).toFixed(2)}
                            </td>
                            <td className="py-3 px-3 text-slate-600 max-w-[220px] truncate">
                              {c.cerrado_por || '—'}
                            </td>
                            <td className="py-3 px-4 text-right">
                              <div className="inline-flex items-center gap-1.5 flex-wrap justify-end">
                                <button
                                  type="button"
                                  onClick={() => setSelectedCierre(c)}
                                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
                                >
                                  <Eye className="w-3.5 h-3.5" /> Detalle
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void reprintSavedCierre(c, 'auto')}
                                  className="px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 font-semibold inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
                                  title="Reimprimir copia en impresora conectada o navegador"
                                >
                                  <Printer className="w-3.5 h-3.5" /> Reimprimir Copia
                                </button>
                                <button
                                  type="button"
                                  onClick={() => generateCierrePDF(c, localName)}
                                  className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
                                  title="Descargar copia en PDF"
                                >
                                  <FileText className="w-3.5 h-3.5" /> PDF
                                </button>
                                {c.key && (
                                  <button
                                    type="button"
                                    onClick={() => setCierreToDelete(c)}
                                    className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
                                    title="Eliminar cierre hospedado"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" /> Borrar
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {tab === 'customers' && (
            <div className="space-y-4 max-w-5xl mx-auto">
              <form
                onSubmit={handleSaveCustomerForm}
                className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <UserCheck className="w-4 h-4 text-sky-600" />
                      {editingCustKey
                        ? 'Editar Cliente de Facturación'
                        : 'Registrar Cliente para Facturación'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Directorio de clientes para emisión de facturas opcionales desde caja (también se registran automáticamente al facturar con cédula y nombre).
                    </p>
                  </div>
                  {editingCustKey && (
                    <button
                      type="button"
                      onClick={resetCustomerForm}
                      className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Cancelar edición
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  <input
                    type="text"
                    value={custCedula}
                    onChange={(e) => setCustCedula(e.target.value)}
                    placeholder="Cédula o RIF (Ej: V-12345678) *"
                    maxLength={40}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-semibold"
                  />
                  <input
                    type="text"
                    value={custNombre}
                    onChange={(e) => setCustNombre(e.target.value)}
                    placeholder="Nombre o Razón Social *"
                    maxLength={140}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                  <input
                    type="tel"
                    value={custTelefono}
                    onChange={(e) => setCustTelefono(e.target.value)}
                    placeholder="Teléfono / WhatsApp (opcional)"
                    maxLength={40}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                  <input
                    type="email"
                    value={custEmail}
                    onChange={(e) => setCustEmail(e.target.value)}
                    placeholder="Correo electrónico (opcional)"
                    maxLength={180}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <input
                    type="text"
                    value={custDireccion}
                    onChange={(e) => setCustDireccion(e.target.value)}
                    placeholder="Dirección fiscal (opcional)"
                    maxLength={240}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <input
                    type="text"
                    value={custNota}
                    onChange={(e) => setCustNota(e.target.value)}
                    placeholder="Nota interna (opcional)"
                    maxLength={240}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={savingCust}
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    {savingCust
                      ? 'Guardando...'
                      : editingCustKey
                      ? 'Actualizar Cliente'
                      : 'Guardar Cliente'}
                  </button>
                </div>
              </form>

              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-bold text-slate-800">
                    Clientes Registrados ({filteredCustomers.length})
                  </h4>
                  <div className="relative min-w-[220px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={custQuery}
                      onChange={(e) => setCustQuery(e.target.value)}
                      placeholder="Buscar cédula, nombre o tel..."
                      className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                      <tr>
                        <th className="py-2.5 px-4 font-semibold">Cédula / RIF</th>
                        <th className="py-2.5 px-4 font-semibold">Nombre / Razón Social</th>
                        <th className="py-2.5 px-4 font-semibold">Contacto</th>
                        <th className="py-2.5 px-4 font-semibold text-center">Facturas</th>
                        <th className="py-2.5 px-4 font-semibold text-right">Facturado USD</th>
                        <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredCustomers.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-400">
                            No hay clientes registrados para facturación todavía.
                          </td>
                        </tr>
                      ) : (
                        filteredCustomers.map((c) => (
                          <tr key={c.key} className="hover:bg-slate-50">
                            <td className="py-2.5 px-4 font-mono font-bold text-slate-800">
                              {c.cedula}
                            </td>
                            <td className="py-2.5 px-4 font-bold text-slate-900">
                              <div>{c.nombre}</div>
                              {c.direccion && (
                                <div className="text-[10px] font-normal text-slate-500 truncate max-w-[240px]">
                                  {c.direccion}
                                </div>
                              )}
                            </td>
                            <td className="py-2.5 px-4 text-slate-600 font-mono">
                              {c.telefono || c.email || '—'}
                            </td>
                            <td className="py-2.5 px-4 text-center font-mono font-semibold text-slate-700">
                              {c.compras_count || 0}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums font-bold text-emerald-700">
                              ${(Number(c.total_comprado_usd) || 0).toFixed(2)}
                            </td>
                            <td className="py-2.5 px-4 text-right">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingCustKey(c.key);
                                    setCustCedula(c.cedula);
                                    setCustNombre(c.nombre);
                                    setCustTelefono(c.telefono || '');
                                    setCustDireccion(c.direccion || '');
                                    setCustEmail(c.email || '');
                                    setCustNota(c.nota || '');
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                                >
                                  Editar
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setCustToDelete(c)}
                                  className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                                  title="Eliminar cliente"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {tab === 'checker' && (() => {
            const checkerActive = config.consultor_precios_activo === true;
            const showParallel = config.consultor_mostrar_paralelo !== false;
            const showStock = config.consultor_mostrar_stock !== false;
            const shareUrl = activeTenantId
              ? `${window.location.origin}/?consultor=${encodeURIComponent(activeTenantId)}`
              : '';

            const handleToggleChecker = async (nextActive: boolean) => {
              if (!activeTenantId) return;
              setSavingChecker(true);
              try {
                await updateTenantSettings({
                  consultor_precios_activo: nextActive,
                  consultor_mostrar_paralelo: showParallel,
                  consultor_mostrar_stock: showStock,
                  consultor_mensaje: checkerMsgDraft.trim(),
                });
                await syncPublicPriceChecker({
                  activo: nextActive,
                  mostrar_paralelo: showParallel,
                  mostrar_stock: showStock,
                  mensaje: checkerMsgDraft.trim(),
                });
                playBeep('ok');
                notifyToast(
                  nextActive
                    ? 'Consultor de Precios activado y catálogo publicado en la nube.'
                    : 'Consultor de Precios desactivado.',
                  nextActive ? 'success' : 'info'
                );
              } finally {
                setSavingChecker(false);
              }
            };

            const handleSaveCheckerOpts = async (
              patch?: Partial<{ paralelo: boolean; stock: boolean; msg: string }>
            ) => {
              if (!activeTenantId) return;
              setSavingChecker(true);
              const nextParallel = patch?.paralelo !== undefined ? patch.paralelo : showParallel;
              const nextStock = patch?.stock !== undefined ? patch.stock : showStock;
              const nextMsg = patch?.msg !== undefined ? patch.msg : checkerMsgDraft.trim();
              try {
                await updateTenantSettings({
                  consultor_mostrar_paralelo: nextParallel,
                  consultor_mostrar_stock: nextStock,
                  consultor_mensaje: nextMsg,
                });
                await syncPublicPriceChecker({
                  activo: checkerActive,
                  mostrar_paralelo: nextParallel,
                  mostrar_stock: nextStock,
                  mensaje: nextMsg,
                });
                notifyToast('Configuración del Consultor de Precios sincronizada.', 'success');
              } finally {
                setSavingChecker(false);
              }
            };

            return (
              <div className="max-w-3xl mx-auto space-y-4">
                <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 ${
                          checkerActive
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-600'
                            : 'bg-slate-100 border-slate-200 text-slate-500'
                        }`}
                      >
                        <Barcode className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-slate-900">
                          Consultor de Precios y Lector de Autoservicio
                        </h3>
                        <p className="text-xs text-slate-500">
                          Permite a tus clientes verificar precios escaneando con lector USB/inalámbrico, cámara o teclado en una pantalla o teléfono.
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={savingChecker}
                      onClick={() => void handleToggleChecker(!checkerActive)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer ${
                        checkerActive
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                          : 'bg-slate-900 hover:bg-slate-800 text-white'
                      }`}
                    >
                      {checkerActive ? 'Consultor Activo (Desactivar)' : 'Activar Consultor de Precios'}
                    </button>
                  </div>

                  {shareUrl && (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Enlace directo del Consultor de Precios para tu tienda
                      </span>
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          type="text"
                          readOnly
                          value={shareUrl}
                          onFocus={(e) => e.currentTarget.select()}
                          className="flex-1 min-w-[200px] px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-xl text-slate-800"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(shareUrl);
                            notifyToast('Enlace del Consultor de Precios copiado.', 'success');
                          }}
                          className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                        >
                          <Copy className="w-3.5 h-3.5" /> Copiar Enlace
                        </button>
                        {onOpenPriceChecker && activeTenantId && (
                          <button
                            type="button"
                            onClick={() => {
                              if (!checkerActive) {
                                void handleToggleChecker(true).then(() =>
                                  onOpenPriceChecker(activeTenantId)
                                );
                              } else {
                                onOpenPriceChecker(activeTenantId);
                              }
                            }}
                            className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5 text-sky-600" /> Abrir Vista Consultor
                          </button>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Solo publica nombres, códigos, precios, tasas y stock (sin datos financieros, ventas ni usuarios). Se actualiza automáticamente al modificar productos o tasas.
                      </p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <label className="flex items-center justify-between gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                      <span>
                        <strong className="block text-slate-900">Mostrar Tasas Paralelas</strong>
                        <span className="text-[11px] text-slate-500">Muestra conversión a Paralelo 1 además de USD y BCV.</span>
                      </span>
                      <input
                        type="checkbox"
                        checked={showParallel}
                        disabled={savingChecker}
                        onChange={(e) => void handleSaveCheckerOpts({ paralelo: e.target.checked })}
                        className="w-4 h-4 accent-sky-600"
                      />
                    </label>
                    <label className="flex items-center justify-between gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                      <span>
                        <strong className="block text-slate-900">Mostrar Disponibilidad (Stock)</strong>
                        <span className="text-[11px] text-slate-500">Indica si el artículo está disponible o cuántas unidades hay.</span>
                      </span>
                      <input
                        type="checkbox"
                        checked={showStock}
                        disabled={savingChecker}
                        onChange={(e) => void handleSaveCheckerOpts({ stock: e.target.checked })}
                        className="w-4 h-4 accent-sky-600"
                      />
                    </label>
                  </div>

                  <div className="space-y-2 text-xs">
                    <label className="font-semibold text-slate-700 block">
                      Mensaje de bienvenida / aviso en pantalla del Consultor (opcional)
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={checkerMsgDraft}
                        onChange={(e) => setCheckerMsgDraft(e.target.value)}
                        placeholder="Ej: ¡Escanea el código de barras para consultar el precio al instante!"
                        maxLength={140}
                        className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                      />
                      <button
                        type="button"
                        disabled={savingChecker}
                        onClick={() => void handleSaveCheckerOpts()}
                        className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold whitespace-nowrap cursor-pointer"
                      >
                        Guardar y Sincronizar
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {tab === 'fiscal' && (() => {
            const fiscalLogo =
              invoiceConfig?.logo_data_url || activeTenant?.logo_url || config.logo_url || '';
            const printerTypeLabels: Record<string, string> = {
              navegador: 'Impresión del Navegador',
              usb: 'Impresora Térmica USB',
              serial: 'Impresora Térmica Serial / Bluetooth',
              pdf: 'Generación Automática en PDF',
            };
            const modelLabels: Record<string, string> = {
              clasico: 'Clásico',
              moderno: 'Moderno',
              compacto: 'Compacto',
              detallado: 'Detallado',
            };
            const fontLabels: Record<string, string> = {
              mono: 'Monoespaciada (Térmica)',
              sans: 'Sans-Serif Moderna',
              serif: 'Serif Editorial',
              condensada: 'Condensada',
            };
            const sizeLabels: Record<string, string> = {
              pequena: 'Pequeña',
              normal: 'Normal',
              grande: 'Grande',
            };
            const fiscalRows = [
              { label: 'Nombre Comercial', value: activeTenant?.nombre_local || localName || 'No registrado', mono: false },
              { label: 'Razón Social', value: activeTenant?.razon_social || 'No registrada', mono: false },
              { label: 'RIF / Identificación Fiscal', value: activeTenant?.rif || 'No registrado', mono: true },
              { label: 'Dirección Fiscal', value: activeTenant?.direccion_fiscal || 'No registrada', mono: false },
              { label: 'Teléfono de Contacto', value: activeTenant?.telefono || 'No registrado', mono: true },
              { label: 'Representante / Contacto', value: activeTenant?.contacto_nombre || 'No registrado', mono: false },
              { label: 'Correo Electrónico Registrado', value: activeTenant?.email || 'No registrado', mono: true },
              { label: 'ID de Comercio / Nodo', value: activeTenant?.id || activeTenantId || '—', mono: true },
            ];
            return (
              <div className="max-w-5xl mx-auto space-y-4">
                {/* Read-Only Protection Banner */}
                <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5 min-w-0">
                    {fiscalLogo ? (
                      <div className="w-14 h-14 rounded-xl border border-slate-200 bg-slate-50 p-1.5 flex items-center justify-center shrink-0 overflow-hidden">
                        <img
                          src={fiscalLogo}
                          alt={`Logotipo de ${activeTenant?.nombre_local || localName}`}
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 flex items-center justify-center shrink-0">
                        <Building2 className="w-6 h-6" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <h3 className="text-base font-bold text-slate-900 truncate">
                        Datos Fiscales y de Facturación
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>Vista de solo lectura · Protegido sin permiso de edición para administradores</span>
                      </p>
                    </div>
                  </div>
                  {onOpenSupport && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenSupport();
                      }}
                      className="px-3.5 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <Headphones className="w-3.5 h-3.5 text-sky-600" />
                      Solicitar actualización al Propietario
                    </button>
                  )}
                </div>

                {/* Fiscal Information Grid (Strictly Read-Only) */}
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between gap-2">
                    <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-sky-600" />
                      Identificación Fiscal del Comercio
                    </h4>
                    <span className="text-[11px] font-medium text-slate-500 inline-flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Solo lectura
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:gap-px bg-slate-100">
                    {fiscalRows.map((row) => (
                      <div key={row.label} className="bg-white px-4 sm:px-5 py-3.5">
                        <span className="text-[11px] font-medium text-slate-500 block">
                          {row.label}
                        </span>
                        <span
                          className={`text-sm font-semibold text-slate-900 mt-0.5 block break-words ${
                            row.mono ? 'font-mono tabular-nums' : ''
                          }`}
                        >
                          {row.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Billing & Thermal Printer Profile (Strictly Read-Only) */}
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between gap-2">
                    <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Printer className="w-4 h-4 text-sky-600" />
                      Parámetros de Facturación e Impresión Asignados
                    </h4>
                    <span className="text-[11px] font-medium text-slate-500 inline-flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Configurado por el Propietario
                    </span>
                  </div>
                  <div className="p-4 sm:p-5 space-y-4">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-[11px] text-slate-500 block">Ancho de Papel</span>
                        <span className="font-mono font-bold text-slate-900 mt-0.5 block">
                          {invoiceConfig?.ancho_papel || '80mm'}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-[11px] text-slate-500 block">Modelo de Factura</span>
                        <span className="font-semibold text-slate-900 mt-0.5 block">
                          {modelLabels[invoiceConfig?.modelo || 'moderno'] || invoiceConfig?.modelo}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-[11px] text-slate-500 block">Tipografía y Tamaño</span>
                        <span className="font-semibold text-slate-900 mt-0.5 block">
                          {fontLabels[invoiceConfig?.fuente || 'mono'] || invoiceConfig?.fuente} ·{' '}
                          {sizeLabels[invoiceConfig?.tamano_letra || 'normal'] || invoiceConfig?.tamano_letra}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-[11px] text-slate-500 block">Impresora Asignada</span>
                        <span className="font-semibold text-slate-900 mt-0.5 block truncate">
                          {invoiceConfig?.impresora_nombre ||
                            printerTypeLabels[invoiceConfig?.impresora_predeterminada || 'navegador'] ||
                            'Navegador / PDF'}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-100">
                      <div>
                        <span className="text-[11px] font-medium text-slate-500 block mb-1">
                          Elementos visibles en comprobante
                        </span>
                        <p className="text-slate-800 font-medium leading-relaxed">
                          {[
                            invoiceConfig?.mostrar_logo ? 'Logotipo' : null,
                            invoiceConfig?.mostrar_rif ? 'RIF' : null,
                            invoiceConfig?.mostrar_direccion ? 'Dirección fiscal' : null,
                            invoiceConfig?.mostrar_telefono ? 'Teléfono' : null,
                            invoiceConfig?.mostrar_tasa ? 'Tasa de cambio' : null,
                            invoiceConfig?.mostrar_cajero ? 'Operador / Cajero' : null,
                          ]
                            .filter(Boolean)
                            .join(' · ') || 'Configuración estándar'}
                        </p>
                      </div>
                      <div>
                        <span className="text-[11px] font-medium text-slate-500 block mb-1">
                          Copias y automatización
                        </span>
                        <p className="text-slate-800 font-mono tabular-nums font-medium">
                          {invoiceConfig?.copias || 1} {invoiceConfig?.copias === 2 ? 'copias' : 'copia'} ·{' '}
                          {invoiceConfig?.auto_imprimir ? 'Auto-impresión activa' : 'Impresión manual'} ·{' '}
                          {invoiceConfig?.corte_automatico ? 'Corte automático' : 'Sin corte automático'}
                        </p>
                      </div>
                    </div>

                    {(invoiceConfig?.encabezado_extra || invoiceConfig?.pie_pagina) && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-100">
                        {invoiceConfig?.encabezado_extra && (
                          <div>
                            <span className="text-[11px] font-medium text-slate-500 block">
                              Encabezado adicional
                            </span>
                            <p className="text-slate-800 mt-0.5 whitespace-pre-wrap">
                              {invoiceConfig.encabezado_extra}
                            </p>
                          </div>
                        )}
                        {invoiceConfig?.pie_pagina && (
                          <div>
                            <span className="text-[11px] font-medium text-slate-500 block">
                              Pie de página en factura
                            </span>
                            <p className="text-slate-800 mt-0.5 whitespace-pre-wrap">
                              {invoiceConfig.pie_pagina}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {tab === 'reports' && <AnalyticsView compact={false} />}

          {tab === 'cashiers' && <UserManagementTab isOwnerView={false} />}

          {tab === 'theme' && (
            <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 max-w-3xl mx-auto space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Paleta Visual del Punto de Venta</h4>
                  <p className="text-xs text-slate-500">
                    Personaliza la identidad cromática de esta terminal de caja.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setLocalTheme(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Restablecer predeterminado
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {IG_THEMES.map((t) => {
                  const selected = activeTheme === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setLocalTheme(t.id)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        selected
                          ? 'border-sky-500 ring-2 ring-sky-200 bg-sky-50/40'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div
                        className="h-8 rounded-lg mb-2 flex items-center justify-end px-2"
                        style={{ background: `linear-gradient(135deg, ${t.c1}, ${t.c2})` }}
                      >
                        {selected && <Check className="w-4 h-4 text-white" />}
                      </div>
                      <span className="text-xs font-bold text-slate-800">{t.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {tab === 'membership' && (
            <div className="max-w-3xl mx-auto space-y-4">
              {/* Casilla principal de Membresía */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 ${
                        membershipExpired || membershipDaysLeft === 0
                          ? 'bg-rose-50 border-rose-200 text-rose-600'
                          : membershipDaysLeft <= 5
                          ? 'bg-amber-50 border-amber-200 text-amber-600'
                          : 'bg-emerald-50 border-emerald-200 text-emerald-600'
                      }`}
                    >
                      <Crown className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                        Casilla de Membresía Contratada · {localName}
                      </p>
                      <h4 className="text-base font-extrabold text-slate-900">
                        {membership?.nombre || 'Sin plan contratado'}
                      </h4>
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-lg text-xs font-bold uppercase ${
                      membership?.estado === 'suspendida'
                        ? 'bg-rose-100 text-rose-700'
                        : membershipExpired || membershipDaysLeft === 0
                        ? 'bg-rose-100 text-rose-700'
                        : membershipDaysLeft <= 5
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {membership?.estado === 'suspendida'
                      ? 'Suspendida'
                      : membershipExpired || membershipDaysLeft === 0
                      ? 'Vencida · Bloqueada'
                      : membershipDaysLeft <= 5
                      ? 'Por Vencer'
                      : 'Activa'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-sky-600" /> Días Disponibles
                    </span>
                    <p
                      className={`text-2xl font-mono tabular-nums font-extrabold mt-1 ${
                        membershipDaysLeft === 0
                          ? 'text-rose-600'
                          : membershipDaysLeft <= 5
                          ? 'text-amber-600'
                          : 'text-emerald-700'
                      }`}
                    >
                      {membershipDaysLeft} {membershipDaysLeft === 1 ? 'día' : 'días'}
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-semibold text-slate-500 block">
                      Plan Contratado
                    </span>
                    <p className="text-sm font-bold text-slate-900 mt-1">
                      {membership?.nombre || 'Sin plan'}
                    </p>
                    <p className="text-[11px] font-mono text-slate-500">
                      Código: {membership?.plan || 'N/A'}
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-semibold text-slate-500 block">
                      Fecha de Vencimiento
                    </span>
                    <p className="text-sm font-mono font-bold text-slate-900 mt-1">
                      {membership?.vence
                        ? new Date(membership.vence).toLocaleDateString('es-VE')
                        : 'Sin fecha'}
                    </p>
                    <p className="text-[11px] font-mono text-slate-500">
                      {membership?.vence
                        ? new Date(membership.vence).toLocaleTimeString('es-VE', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : ''}
                    </p>
                  </div>
                </div>

                <div
                  className={`p-3 rounded-xl border text-xs ${
                    membershipDaysLeft === 0 || membershipExpired
                      ? 'bg-rose-50 border-rose-200 text-rose-800 font-semibold'
                      : 'bg-sky-50 border-sky-200 text-sky-900'
                  }`}
                >
                  {membershipDaysLeft === 0 || membershipExpired
                    ? 'Tu membresía llegó a 0 días disponibles. Todas las acciones de venta, caja y administración están bloqueadas hasta reportar y aprobar tu renovación.'
                    : 'Los días disponibles se descuentan automáticamente a medida que transcurren los días. Si llegan a 0, el sistema bloqueará las acciones automáticamente hasta realizar el pago.'}
                </div>

                {onOpenMembership && (
                  <div className="flex flex-wrap justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenMembership();
                      }}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <CreditCard className="w-4 h-4" /> Pagar / Renovar Membresía
                    </button>
                  </div>
                )}
              </div>

              {/* Comprobantes de pago reportados por este local */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-sky-600" />
                  Mis Comprobantes de Membresía ({membershipPayments.length})
                </h4>
                {membershipPayments.length === 0 ? (
                  <p className="text-xs text-slate-400">
                    Aún no has enviado reportes de pago de membresía.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {membershipPayments.map((p) => (
                      <div
                        key={p.key}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2 text-xs"
                      >
                        <div>
                          <p className="font-bold text-slate-900">
                            {p.nombre} · Ref: <span className="font-mono">{p.ref}</span>
                          </p>
                          <p className="text-slate-500">
                            ${Number(p.usd).toFixed(2)} ({formatMoney(p.bs)} Bs) ·{' '}
                            {p.t ? new Date(p.t).toLocaleString('es-VE') : ''}
                          </p>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase ${
                            p.estado === 'aprobado'
                              ? 'bg-emerald-100 text-emerald-800'
                              : p.estado === 'rechazado'
                              ? 'bg-rose-100 text-rose-700'
                              : p.estado === 'en_revision'
                              ? 'bg-sky-100 text-sky-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {p.estado === 'en_revision' ? 'En Revisión' : p.estado}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Edit Product Modal */}
      {editing && (
        <div className="fixed inset-0 z-[165] bg-slate-950/60 flex items-center justify-center p-3 sm:p-4">
          <form
            onSubmit={handleSaveEdit}
            className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full max-h-[92vh] overflow-y-auto p-5 space-y-3.5 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">Editar Producto</h4>
                {editPrice1Val > 0 && (
                  <p className="text-[11px] font-mono text-emerald-700">
                    Ganancia: ${editProfitUsd.toFixed(2)} ({editCostVal > 0 ? `+${editRealMarginPct.toFixed(1)}% s/costo` : `${editRealMarginPct.toFixed(0)}%`}) ·{' '}
                    {formatMoney(editPrice1Val * bcvRate)} Bs
                  </p>
                )}
              </div>
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="font-semibold text-slate-700 block mb-1">Nombre</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-semibold"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Código de barras</label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    value={editBarcode}
                    onChange={(e) => setEditBarcode(e.target.value)}
                    className="flex-1 min-w-0 px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => onOpenScanner('register', (code) => setEditBarcode(code))}
                    className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer shrink-0"
                    title="Escanear código con cámara"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Categoría</label>
                <input
                  type="text"
                  list="admin-categories-list-edit"
                  value={editCat}
                  onChange={(e) => setEditCat(e.target.value)}
                  placeholder="Opcional"
                  maxLength={80}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50"
                />
                <datalist id="admin-categories-list-edit">
                  {categoriesList.map((cat) => (
                    <option key={cat} value={cat} />
                  ))}
                </datalist>
              </div>
              <div>
                <div className="flex items-center justify-between gap-1 mb-1">
                  <label className="font-semibold text-slate-700 block">
                    Stock {editVentaBulto && editStockMode === 'bulto' ? '(Bultos)' : '(Unidades)'}
                  </label>
                  {editVentaBulto && (
                    <div className="inline-flex rounded-md border border-indigo-200 bg-indigo-50 p-0.5 text-[10px] font-bold">
                      <button
                        type="button"
                        onClick={() => setEditStockMode('detal')}
                        className={`px-1.5 py-0.5 rounded cursor-pointer ${
                          editStockMode === 'detal' ? 'bg-indigo-600 text-white' : 'text-indigo-700'
                        }`}
                      >
                        Uds
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditStockMode('bulto')}
                        className={`px-1.5 py-0.5 rounded cursor-pointer ${
                          editStockMode === 'bulto' ? 'bg-indigo-600 text-white' : 'text-indigo-700'
                        }`}
                      >
                        Bultos
                      </button>
                    </div>
                  )}
                </div>
                <input
                  type="number"
                  step={editVentaBulto && editStockMode === 'bulto' ? '1' : '0.01'}
                  value={editStock}
                  onChange={(e) => setEditStock(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-mono"
                />
                {editVentaBulto && editStockMode === 'bulto' && (Number(editStock) || 0) > 0 && (
                  <span className="text-[10px] font-mono text-indigo-700 font-semibold mt-0.5 block">
                    = {round2((Number(editStock) || 0) * Math.max(1, Math.round(Number(editUnidadesBulto) || 1)))} uds
                  </span>
                )}
              </div>
              <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Costo USD</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={editCost}
                    onChange={(e) => {
                      const val = e.target.value;
                      setEditCost(val);
                      handleEditAutoMargin(val, editMargin);
                    }}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Porcentaje a Ganar (%)
                  </label>
                  <div className="relative">
                    <Percent className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="number"
                      step="0.5"
                      min="0"
                      value={editMargin}
                      onChange={(e) => {
                        const val = e.target.value;
                        setEditMargin(val);
                        handleEditAutoMargin(editCost, val);
                      }}
                      placeholder="Ej. 35"
                      className="w-full px-3 pr-8 py-2 border border-emerald-300 rounded-xl bg-emerald-50/40 font-mono font-bold text-emerald-900"
                    />
                  </div>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Precio Venta (USD)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={editPrice1}
                    onChange={(e) => {
                      const val = e.target.value;
                      setEditPrice1(val);
                      const c = Number(editCost) || 0;
                      const p = Number(val) || 0;
                      if (c > 0 && p > 0) {
                        setEditMargin(String(round2(((p - c) / c) * 100)));
                      } else if (c <= 0) {
                        setEditMargin('');
                      }
                    }}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-mono font-bold"
                  />
                </div>
                {editCostVal <= 0 && (
                  <p className="sm:col-span-3 text-[11px] text-amber-700">
                    Para calcular el precio automáticamente por porcentaje (%), ingresa primero un Costo USD mayor a 0.
                  </p>
                )}
              </div>
              <div className="sm:col-span-2 p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-3 gap-2 text-xs font-mono">
                <div>
                  <span className="text-[10px] font-sans font-semibold text-emerald-700 block">
                    BCV ({bcvRate.toFixed(2)})
                  </span>
                  <span className="font-bold text-slate-900">
                    {formatMoney(editPrice1Val * bcvRate)} Bs
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-sans font-semibold text-sky-700 block">
                    Paralelo 1 ({secondaryRate.toFixed(2)})
                  </span>
                  <span className="font-bold text-slate-900">
                    {formatMoney(editPrice1Val * secondaryRate)} Bs
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-sans font-semibold text-indigo-700 block">
                    Paralelo 2 ({tertiaryRate.toFixed(2)})
                  </span>
                  <span className="font-bold text-slate-900">
                    {formatMoney(editPrice1Val * tertiaryRate)} Bs
                  </span>
                </div>
              </div>

              {/* Bulk/Bulto Settings inside Edit Product Modal */}
              <div className="sm:col-span-2 rounded-xl border border-indigo-200 bg-indigo-50/40 p-3 space-y-2.5">
                <label className="inline-flex items-center gap-2 font-bold text-indigo-950 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editVentaBulto}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setEditVentaBulto(checked);
                      if (!checked) setEditStockMode('detal');
                      if (checked && !editPrecioBulto && editPrice1Val > 0) {
                        const upb = Math.max(2, Math.round(Number(editUnidadesBulto) || 12));
                        setEditPrecioBulto(String(round2(editPrice1Val * upb)));
                      }
                    }}
                    className="rounded border-indigo-300 accent-indigo-600"
                  />
                  <Boxes className="w-3.5 h-3.5 text-indigo-600" />
                  Venta por Bultos / Cajas (y Al Detal)
                </label>
                {editVentaBulto && (
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Unidades / bulto
                      </label>
                      <input
                        type="number"
                        min={2}
                        step="1"
                        value={editUnidadesBulto}
                        onChange={(e) => setEditUnidadesBulto(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-indigo-200 rounded-lg bg-white font-mono font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Precio Bulto (USD)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={editPrecioBulto}
                        onChange={(e) => setEditPrecioBulto(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-indigo-200 rounded-lg bg-white font-mono font-bold text-indigo-900"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="sm:col-span-2 flex flex-wrap items-center justify-between gap-2 pt-1">
                <label className="inline-flex items-center gap-2 font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editFrac}
                    onChange={(e) => setEditFrac(e.target.checked)}
                    className="rounded border-slate-300"
                  />
                  Fraccionable (decimales)
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <label className="px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 cursor-pointer font-semibold text-sky-700">
                    {editImage ? 'Cambiar imagen' : 'Subir imagen'}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImagePick(e.target.files?.[0], 'edit')}
                      className="hidden"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => void handleSearchGoogleImage('edit')}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Globe className="w-3.5 h-3.5" /> Buscar en Google
                  </button>
                  {editImage && (
                    <>
                      <img
                        src={editImage}
                        alt="Vista previa"
                        className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                      />
                      <button
                        type="button"
                        onClick={() => setEditImage('')}
                        className="px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-600 font-semibold cursor-pointer"
                      >
                        Quitar
                      </button>
                    </>
                  )}
                </div>

                {/* Live simultaneous Google image match strip inside Edit Product */}
                {autoSyncGoogleImg && editName.trim().length >= 3 && liveEditImgDismissedFor !== editName.trim() && (
                  <div className="w-full mt-2 p-2.5 rounded-xl bg-indigo-50/60 border border-indigo-200/80 space-y-2">
                    <div className="flex items-center justify-between gap-2 text-[11px]">
                      <span className="font-bold text-indigo-900 inline-flex items-center gap-1.5 truncate">
                        {liveEditImgLoading ? (
                          <Loader2 className="w-3.5 h-3.5 text-indigo-600 animate-spin shrink-0" />
                        ) : (
                          <Globe className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        )}
                        {liveEditImgLoading
                          ? `Sincronizando fotos en Google para “${editName.trim()}”...`
                          : liveEditImgResults.length > 0
                          ? `Sugerencias reales de Google para “${liveEditImgQuery}” · Toca para confirmar:`
                          : `Sin coincidencias exactas para “${liveEditImgQuery}”`}
                      </span>
                      <button
                        type="button"
                        onClick={() => setLiveEditImgDismissedFor(editName.trim())}
                        className="text-slate-500 hover:text-slate-800 font-semibold whitespace-nowrap cursor-pointer"
                      >
                        Ocultar
                      </button>
                    </div>
                    {liveEditImgResults.length > 0 && (
                      <div className="grid grid-cols-4 gap-2">
                        {liveEditImgResults.map((cand, idx) => (
                          <button
                            key={cand.sourceUrl + idx}
                            type="button"
                            onClick={() => void handleApplyLiveGoogleImage('edit', cand)}
                            className="group rounded-lg bg-white border border-indigo-200/80 hover:border-emerald-500 p-1 text-left transition cursor-pointer flex flex-col gap-1"
                          >
                            <div className="aspect-square w-full rounded bg-slate-50 overflow-hidden flex items-center justify-center relative">
                              <img
                                src={cand.dataUrl}
                                alt={cand.title}
                                className="w-full h-full object-contain"
                              />
                              {typeof cand.matchScore === 'number' && cand.matchScore > 0 && (
                                <span className="absolute top-0.5 right-0.5 px-1 py-0.5 rounded bg-emerald-600/90 text-white font-mono text-[8px] font-bold">
                                  {cand.matchScore}%
                                </span>
                              )}
                            </div>
                            <span className="text-[9px] font-bold text-emerald-700 inline-flex items-center gap-0.5">
                              <Check className="w-2.5 h-2.5" /> Usar
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {editing.stock <= 5 && (
              <p className="text-[11px] text-amber-700 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> Stock en nivel crítico o agotado.
              </p>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
              >
                Guardar Cambios
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Mechanics Manager Quick Modal (accessible from Admin Panel Top Bar) */}
      {mechanicsModalOpen && (
        <div className="fixed inset-0 z-[165] bg-slate-950/60 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-600" />
                <h4 className="font-bold text-slate-900 text-sm">Mecánicos del Botón Motor</h4>
              </div>
              <button
                type="button"
                onClick={() => setMechanicsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
                aria-label="Cerrar"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <p className="text-slate-500">
                Registra los nombres de los mecánicos responsables disponibles en el módulo de reparación de motor.
              </p>

              <form onSubmit={handleAddMechanic} className="flex gap-2">
                <input
                  type="text"
                  value={newMechanicName}
                  onChange={(e) => setNewMechanicName(e.target.value)}
                  placeholder="Nombre del mecánico..."
                  maxLength={60}
                  autoFocus
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
                <button
                  type="submit"
                  disabled={savingMechanic}
                  className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white font-semibold inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Agregar
                </button>
              </form>

              <div className="space-y-1.5 max-h-60 overflow-y-auto">
                {mechanics.length === 0 ? (
                  <p className="text-center py-4 text-slate-400">
                    Sin mecánicos registrados. Añade el primero arriba.
                  </p>
                ) : (
                  mechanics.map((m) => (
                    <div
                      key={m}
                      className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                    >
                      <span className="font-semibold text-slate-800 flex items-center gap-2">
                        <Wrench className="w-3.5 h-3.5 text-amber-600" />
                        {m}
                      </span>
                      <button
                        type="button"
                        disabled={savingMechanic}
                        onClick={() => void handleRemoveMechanic(m)}
                        className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer"
                        title={`Eliminar a ${m}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => void updateMechanics(['José', 'Jesús'])}
                className="text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Restaurar predeterminados
              </button>
              <button
                type="button"
                onClick={() => setMechanicsModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold cursor-pointer"
              >
                Listo
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Confirm Delete Single Product Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-[170] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl">
            <div className="px-5 py-4 border-b border-slate-200 bg-rose-50/70 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                  <Trash2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Confirmar Eliminación</h4>
                  <p className="text-[11px] text-rose-700">Esta acción eliminará el producto del inventario</p>
                </div>
              </div>
              <button
                type="button"
                disabled={deletingProduct}
                onClick={() => setProductToDelete(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-white cursor-pointer"
                aria-label="Cerrar confirmación"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 text-xs">
              <p className="text-slate-700">
                ¿Estás seguro de que deseas eliminar permanentemente este producto?
              </p>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-3">
                <ProductThumb
                  name={productToDelete.id}
                  image={productToDelete.image}
                  className="w-10 h-10 text-xs shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-slate-900 truncate">{productToDelete.id}</p>
                  <p className="text-[11px] font-mono text-slate-500">
                    {productToDelete.barcode || 'Sin código'} · Stock: {productToDelete.stock} · $
                    {productToDelete.price.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={deletingProduct}
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={deletingProduct}
                onClick={() => void confirmDeleteSingleProduct()}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                {deletingProduct ? 'Eliminando...' : 'Sí, eliminar producto'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Bulk Action Modal */}
      {confirmBulkAction && (
        <div className="fixed inset-0 z-[170] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl">
            <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <AlertTriangle
                  className={`w-4 h-4 ${
                    confirmBulkAction.type === 'delete' ? 'text-rose-600' : 'text-amber-600'
                  }`}
                />
                <h4 className="font-bold text-slate-900 text-sm">
                  {confirmBulkAction.type === 'delete'
                    ? 'Eliminar Productos Seleccionados'
                    : confirmBulkAction.type === 'iva'
                    ? `${confirmBulkAction.add ? 'Aplicar' : 'Quitar'} IVA 16% por Lote`
                    : `${confirmBulkAction.sign > 0 ? 'Aumentar' : 'Reducir'} Precios por Lote`}
                </h4>
              </div>
              <button
                type="button"
                disabled={runningBulkAction}
                onClick={() => setConfirmBulkAction(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
                aria-label="Cerrar confirmación"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 text-xs text-slate-700 space-y-2">
              {confirmBulkAction.type === 'delete' && (
                <p>
                  ¿Eliminar permanentemente <b>{confirmBulkAction.count} producto(s)</b> seleccionados del
                  inventario? Esta acción no se puede deshacer.
                </p>
              )}
              {confirmBulkAction.type === 'iva' && (
                <p>
                  ¿{confirmBulkAction.add ? 'Sumar' : 'Restar'} 16% de IVA a{' '}
                  <b>{confirmBulkAction.count} producto(s)</b> ({confirmBulkAction.scopeLabel})?
                </p>
              )}
              {confirmBulkAction.type === 'percent' && (
                <p>
                  ¿{confirmBulkAction.sign > 0 ? 'Aumentar' : 'Reducir'}{' '}
                  <b>{confirmBulkAction.pct}%</b> el precio de <b>{confirmBulkAction.scopeLabel}</b>?
                </p>
              )}
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={runningBulkAction}
                onClick={() => setConfirmBulkAction(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={runningBulkAction}
                onClick={() => void executeConfirmedBulkAction()}
                className={`px-4 py-2 rounded-xl text-white text-xs font-semibold disabled:opacity-60 cursor-pointer ${
                  confirmBulkAction.type === 'delete'
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-sky-600 hover:bg-sky-700'
                }`}
              >
                {runningBulkAction ? 'Procesando...' : 'Confirmar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hosted Cierre Detail Modal inside Admin Panel */}
      {selectedCierre && (
        <div className="fixed inset-0 z-[168] bg-slate-950/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  Detalle del Cierre · {selectedCierre.fecha} ({selectedCierre.hora})
                </h4>
                <p className="text-[11px] text-slate-500">
                  {selectedCierre.cantidad_ventas} venta(s) · {selectedCierre.cerrado_por}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCierre(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">Total Bs</span>
                  <span className="font-mono font-bold text-slate-900">
                    {formatMoney(selectedCierre.total_general_ves)} Bs
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[11px] text-emerald-700 block">Total USD</span>
                  <span className="font-mono font-bold text-emerald-900">
                    ${(Number(selectedCierre.total_general_usd) || 0).toFixed(2)}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">IVA Cobrado</span>
                  <span className="font-mono font-bold text-slate-900">
                    {formatMoney(selectedCierre.total_iva_ves)} Bs
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">Ventas</span>
                  <span className="font-mono font-bold text-slate-900">
                    {selectedCierre.cantidad_ventas}
                  </span>
                </div>
              </div>

              <div>
                <h5 className="font-bold text-slate-800 mb-2">Totales por Método de Pago</h5>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {Object.entries(selectedCierre.totales_metodos_ves || {}).map(([m, bs]) => (
                    <div key={m} className="p-2.5 rounded-xl border border-slate-200 bg-slate-50">
                      <span className="text-[11px] text-slate-500 block">{m}</span>
                      <span className="font-mono font-bold text-slate-900">{formatMoney(bs)} Bs</span>
                    </div>
                  ))}
                </div>
              </div>

              {selectedCierre.productos_vendidos?.length > 0 && (
                <div>
                  <h5 className="font-bold text-slate-800 mb-2">
                    Productos Vendidos ({selectedCierre.productos_vendidos.length})
                  </h5>
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                        <tr>
                          <th className="py-2 px-3">Producto</th>
                          <th className="py-2 px-3 text-center">Cant.</th>
                          <th className="py-2 px-3 text-right">Total Bs</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedCierre.productos_vendidos.map((p, idx) => (
                          <tr key={idx}>
                            <td className="py-2 px-3 font-medium text-slate-900">{p.nombre}</td>
                            <td className="py-2 px-3 text-center font-mono">{p.cantidad}</td>
                            <td className="py-2 px-3 text-right font-mono">{formatMoney(p.total_ves)} Bs</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-wrap justify-end gap-2">
              <button
                type="button"
                onClick={() => void reprintSavedCierre(selectedCierre, 'auto')}
                className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" /> Reimprimir Copia
              </button>
              <button
                type="button"
                onClick={() => generateCierrePDF(selectedCierre, localName)}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" /> Descargar PDF
              </button>
              <button
                type="button"
                onClick={() => setSelectedCierre(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Delete Hosted Cierre Modal */}
      {cierreToDelete && (
        <div className="fixed inset-0 z-[170] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl">
            <div className="px-5 py-4 border-b border-slate-200 bg-rose-50/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-rose-600" />
                <h4 className="font-bold text-slate-900 text-sm">Eliminar Cierre Guardado</h4>
              </div>
              <button
                type="button"
                disabled={deletingCierre}
                onClick={() => setCierreToDelete(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 text-xs text-slate-700 space-y-2">
              <p>
                ¿Deseas eliminar permanentemente el cierre del <b>{cierreToDelete.fecha}</b> ({cierreToDelete.hora}) por{' '}
                <b className="font-mono">{formatMoney(cierreToDelete.total_general_ves)} Bs</b>?
              </p>
              <p className="text-[11px] text-slate-500">Esta acción eliminará el respaldo de la nube.</p>
            </div>
            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex justify-end gap-2">
              <button
                type="button"
                disabled={deletingCierre}
                onClick={() => setCierreToDelete(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={deletingCierre}
                onClick={async () => {
                  if (!cierreToDelete.key) return;
                  setDeletingCierre(true);
                  try {
                    await deleteSavedCierre(cierreToDelete.key);
                    setCierreToDelete(null);
                  } finally {
                    setDeletingCierre(false);
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer"
              >
                {deletingCierre ? 'Eliminando...' : 'Sí, eliminar cierre'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Google Real Product Image Search Confirmation Modal */}
      {imgSearchTarget && (
        <div className="fixed inset-0 z-[175] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full max-h-[88vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-indigo-50/70 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <Globe className="w-5 h-5 text-indigo-600 shrink-0" />
                <div className="min-w-0">
                  <h4 className="font-bold text-slate-900 text-sm truncate">
                    Confirmar Imagen Real desde Google
                  </h4>
                  <p className="text-[11px] text-indigo-800 truncate">
                    Búsqueda exacta para: “{imgSearchQuery}”
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setImgSearchTarget(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (imgSearchTarget) void handleSearchGoogleImage(imgSearchTarget, imgSearchQuery);
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={imgSearchQuery}
                  onChange={(e) => setImgSearchQuery(e.target.value)}
                  placeholder="Nombre o modelo exacto del producto..."
                  className="flex-1 min-w-0 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
                <button
                  type="submit"
                  disabled={imgSearching || imgSearchQuery.trim().length < 2}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <Search className="w-3.5 h-3.5" /> Buscar
                </button>
              </form>

              {imgSearching ? (
                <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-600">
                  <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
                  <p className="text-xs font-semibold">
                    Buscando y verificando imágenes reales que coincidan con “{imgSearchQuery}”...
                  </p>
                </div>
              ) : imgSearchResults.length === 0 ? (
                <div className="p-6 rounded-2xl bg-amber-50 border border-amber-200 text-center space-y-2">
                  <AlertTriangle className="w-7 h-7 text-amber-600 mx-auto" />
                  <p className="text-xs font-bold text-amber-950">
                    Sin coincidencia real verificada
                  </p>
                  <p className="text-xs text-amber-800">
                    {imgSearchNotice ||
                      'No se encontraron imágenes reales exactas para este producto. No se añadirá ninguna imagen genérica.'}
                  </p>
                </div>
              ) : (
                <>
                  <p className="text-xs text-slate-600">
                    Selecciona la imagen que mejor corresponda al producto y confirma antes de añadirla:
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {imgSearchResults.map((item, idx) => {
                      const selected = idx === imgSearchSelectedIdx;
                      return (
                        <button
                          key={item.sourceUrl + idx}
                          type="button"
                          onClick={() => setImgSearchSelectedIdx(idx)}
                          className={`rounded-xl border p-2 text-left transition cursor-pointer flex flex-col gap-2 ${
                            selected
                              ? 'border-indigo-600 ring-2 ring-indigo-200 bg-indigo-50/40'
                              : 'border-slate-200 hover:border-slate-300 bg-white'
                          }`}
                        >
                          <div className="aspect-square w-full rounded-lg bg-slate-50 border border-slate-100 overflow-hidden flex items-center justify-center relative">
                            <img
                              src={item.dataUrl}
                              alt={item.title}
                              className="w-full h-full object-contain"
                            />
                            {typeof item.matchScore === 'number' && item.matchScore > 0 && (
                              <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-emerald-600 text-white font-mono text-[10px] font-bold">
                                {item.matchScore}%
                              </span>
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="text-[11px] font-bold text-slate-900 line-clamp-2 leading-tight">
                              {item.title}
                            </p>
                            <p className="text-[10px] font-mono text-slate-500 truncate mt-0.5">
                              {item.sourceDomain}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setImgSearchTarget(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                No añadir / Cerrar
              </button>
              {imgSearchResults.length > 0 && !imgSearching && (
                <button
                  type="button"
                  onClick={() => void handleConfirmSelectedGoogleImage()}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" /> Confirmar y Añadir Imagen
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Confirm Delete Customer Modal */}
      {custToDelete && (
        <div className="fixed inset-0 z-[175] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <h4 className="font-bold text-sm text-slate-900">Eliminar Cliente de Facturación</h4>
            <p className="text-xs text-slate-600">
              ¿Eliminar a <b>{custToDelete.nombre}</b> ({custToDelete.cedula}) del directorio?
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCustToDelete(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={async () => {
                  const target = custToDelete;
                  setCustToDelete(null);
                  await deleteCustomer(target.key);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Void Invoice Modal inside Admin Panel */}
      <VoidInvoiceModal open={voidModalOpen} onClose={() => setVoidModalOpen(false)} />

      {/* Bulk Product Import from Excel / Documents Modal */}
      <BulkImportModal open={bulkImportOpen} onClose={() => setBulkImportOpen(false)} />
    </div>
  );
};
