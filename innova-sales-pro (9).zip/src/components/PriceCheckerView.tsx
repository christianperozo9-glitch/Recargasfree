import React, { useEffect, useMemo, useRef, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import {
  Barcode,
  Camera,
  CheckCircle2,
  Package,
  Search,
  Store,
  AlertTriangle,
  ArrowLeft,
} from 'lucide-react';
import { db } from '../lib/firebase';
import type { PublicPriceCheckerCatalog, PublicPriceCheckerItem } from '../types/pos';
import { formatMoney } from '../utils/format';
import { attachUniversalWedgeDetector } from '../utils/barcodeScanner';
import { BarcodeScannerModal } from './UtilityModals';

interface PriceCheckerViewProps {
  tenantId: string;
  onExitPreview?: () => void;
}

export const PriceCheckerView: React.FC<PriceCheckerViewProps> = ({
  tenantId,
  onExitPreview,
}) => {
  const [catalog, setCatalog] = useState<PublicPriceCheckerCatalog | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [query, setQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<PublicPriceCheckerItem | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [lastScanSource, setLastScanSource] = useState<string>('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setLoading(true);
    setLoadError('');
    const unsub = onSnapshot(
      doc(db, 'tenants', tenantId, 'public_checker', 'catalog'),
      (snap) => {
        setLoading(false);
        if (!snap.exists()) {
          setCatalog(null);
          setLoadError('Este comercio aún no ha activado el Consultor de Precios.');
          return;
        }
        setCatalog(snap.data() as PublicPriceCheckerCatalog);
      },
      () => {
        setLoading(false);
        setCatalog(null);
        setLoadError('Consultor de precios desactivado o enlace no autorizado.');
      }
    );
    return () => unsub();
  }, [tenantId]);

  const handleCodeDetected = (rawCode: string, sourceLabel: string) => {
    const clean = rawCode.trim().toLowerCase();
    if (!clean || !catalog) return;
    setQuery(rawCode.trim());
    setLastScanSource(sourceLabel);
    const exact =
      catalog.items.find((it) => (it.barcode || '').trim().toLowerCase() === clean) ||
      catalog.items.find((it) => it.nombre.trim().toLowerCase() === clean) ||
      catalog.items.find(
        (it) =>
          (it.barcode || '').toLowerCase().includes(clean) ||
          it.nombre.toLowerCase().includes(clean)
      ) ||
      null;
    setSelectedItem(exact);
  };

  // Universal USB / Wireless HID barcode scanner auto-detection on kiosk
  useEffect(() => {
    return attachUniversalWedgeDetector(
      (ev) => {
        handleCodeDetected(ev.code, ev.deviceName || 'Lector USB / Inalámbrico');
      },
      { allowInsideInputs: true }
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catalog]);

  // Keep search input focused for seamless scanner kiosk operation
  useEffect(() => {
    if (!cameraOpen) {
      inputRef.current?.focus();
    }
  }, [cameraOpen, selectedItem]);

  const filteredItems = useMemo(() => {
    if (!catalog) return [];
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return catalog.items
      .filter(
        (it) =>
          it.nombre.toLowerCase().includes(q) ||
          (it.barcode || '').toLowerCase().includes(q) ||
          (it.categoria || '').toLowerCase().includes(q)
      )
      .slice(0, 12);
  }, [catalog, query]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center mx-auto animate-pulse">
            <Barcode className="w-6 h-6 text-sky-400" />
          </div>
          <div className="text-sm font-bold text-slate-300">Cargando Consultor de Precios...</div>
        </div>
      </div>
    );
  }

  if (loadError || !catalog || !catalog.activo) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-7 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center mx-auto text-amber-400">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-extrabold">Consultor de Precios No Disponible</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            {loadError ||
              'El administrador del local pausó temporalmente este consultor de precios.'}
          </p>
          {onExitPreview && (
            <button
              type="button"
              onClick={onExitPreview}
              className="px-4 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-extrabold"
            >
              Volver al Panel
            </button>
          )}
        </div>
      </div>
    );
  }

  const rateBcv = Number(catalog.tasa_bcv) || 1;
  const activeProduct = selectedItem || (filteredItems.length === 1 ? filteredItems[0] : null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950 text-white flex flex-col p-4 sm:p-8">
      {/* Header */}
      <header className="max-w-4xl w-full mx-auto flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight">
              {catalog.nombre_local}
            </h1>
            <p className="text-xs text-sky-300 font-semibold">
              {catalog.mensaje || 'Consultor de Precios · Escanea o escribe el nombre del artículo'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-4 py-2 rounded-2xl bg-white/10 border border-white/10 text-right">
            <div className="text-[10px] font-bold uppercase text-sky-300">Tasa BCV</div>
            <div className="text-sm font-black font-mono tabular-nums">
              {rateBcv.toFixed(2)} Bs
            </div>
          </div>
          {onExitPreview && (
            <button
              type="button"
              onClick={onExitPreview}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white text-slate-900 text-xs font-extrabold"
            >
              <ArrowLeft className="w-4 h-4" />
              Salir
            </button>
          )}
        </div>
      </header>

      {/* Main Scanner & Search Box */}
      <main className="max-w-4xl w-full mx-auto flex-1 flex flex-col justify-center py-6 space-y-6">
        <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-3xl p-4 sm:p-5 space-y-3 shadow-2xl">
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="w-5 h-5 text-sky-300 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                ref={inputRef}
                data-scanner-input="true"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedItem(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && query.trim()) {
                    e.preventDefault();
                    handleCodeDetected(query, 'Búsqueda / Lector');
                  }
                }}
                placeholder="Escanea el código de barras (USB / Inalámbrico) o escribe el producto..."
                className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-slate-950/70 border border-white/20 text-white placeholder-slate-400 text-base font-bold outline-none focus:border-sky-400"
              />
            </div>
            <button
              type="button"
              onClick={() => setCameraOpen(true)}
              className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-sm whitespace-nowrap transition"
            >
              <Camera className="w-5 h-5" />
              Escanear Cámara
            </button>
          </div>
          {lastScanSource && (
            <div className="text-[11px] text-emerald-300 flex items-center gap-1.5 px-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Última lectura detectada por: <strong>{lastScanSource}</strong>
            </div>
          )}
        </div>

        {/* Highlighted Product Result */}
        {activeProduct ? (
          <div className="bg-white text-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-white space-y-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                {activeProduct.categoria && (
                  <div className="text-xs font-extrabold uppercase tracking-wider text-sky-700 mb-1">
                    {activeProduct.categoria}
                  </div>
                )}
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 leading-tight">
                  {activeProduct.nombre}
                </h2>
                <div className="text-xs font-mono text-slate-500 mt-1">
                  Código: {activeProduct.barcode || activeProduct.id}
                  {activeProduct.iva_incluido ? ' · IVA 16% incluido' : ''}
                </div>
              </div>

              {catalog.mostrar_stock && (
                <div
                  className={`px-3.5 py-2 rounded-2xl text-xs font-extrabold flex items-center gap-1.5 ${
                    activeProduct.stock > 0
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  <Package className="w-4 h-4" />
                  {activeProduct.stock > 0
                    ? `Disponible: ${activeProduct.stock}`
                    : 'Sin existencia'}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-slate-900 text-white">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Precio en Divisas
                </div>
                <div className="text-4xl sm:text-5xl font-black font-mono tabular-nums mt-1">
                  ${activeProduct.precio.toFixed(2)}
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-sky-50 border border-sky-200 text-sky-950">
                <div className="text-xs font-bold uppercase tracking-wider text-sky-700">
                  Precio Tasa BCV ({rateBcv.toFixed(2)})
                </div>
                <div className="text-3xl sm:text-4xl font-black font-mono tabular-nums mt-1">
                  {formatMoney(activeProduct.precio * rateBcv)} Bs
                </div>
              </div>
            </div>

            {catalog.mostrar_paralelo &&
              ((catalog.tasa_secundaria || 0) > 0 || (catalog.tasa_terciaria || 0) > 0) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {(catalog.tasa_secundaria || 0) > 0 && (
                    <div className="px-4 py-3 rounded-xl bg-slate-100 flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-600">
                        Ref. P1 ({Number(catalog.tasa_secundaria).toFixed(2)}):
                      </span>
                      <span className="font-black font-mono tabular-nums text-slate-900">
                        {formatMoney(activeProduct.precio * Number(catalog.tasa_secundaria))} Bs
                      </span>
                    </div>
                  )}
                  {(catalog.tasa_terciaria || 0) > 0 && (
                    <div className="px-4 py-3 rounded-xl bg-slate-100 flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-600">
                        Ref. P2 ({Number(catalog.tasa_terciaria).toFixed(2)}):
                      </span>
                      <span className="font-black font-mono tabular-nums text-slate-900">
                        {formatMoney(activeProduct.precio * Number(catalog.tasa_terciaria))} Bs
                      </span>
                    </div>
                  )}
                </div>
              )}

            <button
              type="button"
              onClick={() => {
                setQuery('');
                setSelectedItem(null);
                inputRef.current?.focus();
              }}
              className="w-full py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-extrabold"
            >
              Consultar Otro Artículo
            </button>
          </div>
        ) : query.trim() && filteredItems.length > 0 ? (
          <div className="bg-white text-slate-900 rounded-3xl p-4 shadow-2xl space-y-2">
            <div className="text-xs font-extrabold text-slate-500 uppercase px-2">
              Resultados coincidentes ({filteredItems.length})
            </div>
            <div className="divide-y divide-slate-100">
              {filteredItems.map((it) => (
                <button
                  key={it.id}
                  type="button"
                  onClick={() => setSelectedItem(it)}
                  className="w-full flex items-center justify-between gap-3 px-3 py-3 hover:bg-sky-50 rounded-xl text-left transition"
                >
                  <div>
                    <div className="font-extrabold text-sm text-slate-900">{it.nombre}</div>
                    <div className="text-[11px] font-mono text-slate-400">
                      {it.barcode || it.id}
                    </div>
                  </div>
                  <div className="text-right font-mono tabular-nums">
                    <div className="font-black text-slate-900">${it.precio.toFixed(2)}</div>
                    <div className="text-xs font-bold text-sky-700">
                      {formatMoney(it.precio * rateBcv)} Bs
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : query.trim() ? (
          <div className="bg-white/10 border border-white/15 rounded-3xl p-8 text-center text-sm font-bold text-slate-300">
            No se encontró ningún artículo para &ldquo;{query}&rdquo;.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
              <Barcode className="w-7 h-7 text-sky-400 mx-auto mb-2" />
              <div className="text-sm font-extrabold">Lector USB / Inalámbrico</div>
              <div className="text-xs text-slate-400 mt-1">
                Apunta el lector físico directo a cualquier etiqueta del local.
              </div>
            </div>
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
              <Camera className="w-7 h-7 text-emerald-400 mx-auto mb-2" />
              <div className="text-sm font-extrabold">Cámara Integrada</div>
              <div className="text-xs text-slate-400 mt-1">
                Ideal para tablets o celulares en pasillos.
              </div>
            </div>
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
              <Search className="w-7 h-7 text-amber-400 mx-auto mb-2" />
              <div className="text-sm font-extrabold">Búsqueda Instantánea</div>
              <div className="text-xs text-slate-400 mt-1">
                {catalog.items.length} artículo(s) sincronizados en tiempo real.
              </div>
            </div>
          </div>
        )}
      </main>

      <BarcodeScannerModal
        open={cameraOpen}
        onClose={() => setCameraOpen(false)}
        onDetected={(code) => {
          setCameraOpen(false);
          handleCodeDetected(code, 'Cámara Consultor');
        }}
      />
    </div>
  );
};
