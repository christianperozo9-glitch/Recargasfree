export type UserRole = 'cashier' | 'admin' | 'owner' | '';

export interface Product {
  key: string;
  id: string;
  barcode: string;
  categoria?: string;
  price: number;
  price2: number | null;
  price3: number | null;
  stock: number;
  cost: number;
  image: string;
  ivaIncluded: boolean;
  ivaPct: number;
  fraccionable: boolean;
  ventaPorBulto?: boolean;
  unidadesPorBulto?: number;
  precioBulto?: number | null;
}

export interface CartItem {
  product: Product;
  quantity: number;
  customDiscountVes: number | null;
  saleUnit?: 'detal' | 'bulto';
  cartKey?: string;
}

export interface SaleItem {
  id: string;
  key?: string;
  cantidad: number;
  precio_unitario_bs: number;
  precio_unitario_usd: number;
  costo_unitario_usd?: number;
  es_bulto?: boolean;
  unidades_por_bulto?: number;
  unidades_descontadas?: number;
}

export interface SplitPaymentLeg {
  metodo: string;
  monto_ves: number;
  monto_usd: number;
  referencia?: string;
}

export interface CustomerRecord {
  key: string;
  cedula: string;
  nombre: string;
  telefono?: string;
  direccion?: string;
  email?: string;
  nota?: string;
  compras_count?: number;
  total_comprado_usd?: number;
  ultima_compra?: number;
  createdAt?: number;
  updatedAt?: number;
}

export interface SaleTransaction {
  key?: string;
  fecha: string;
  hora: string;
  timestamp: number;
  metodo_pago: string;
  monto_total_ves: number;
  monto_total_usd_bcv: number;
  tasa_bcv_momento: number;
  iva_aplicado?: boolean;
  iva_porcentaje?: number;
  monto_iva_ves?: number;
  monto_iva_usd?: number;
  mecanico?: string;
  cashea_nivel?: string;
  cashea_inicial_usd?: number;
  cashea_inicial_ves?: number;
  cashea_restante_usd?: number;
  cashea_restante_ves?: number;
  cashea_cuotas?: number;
  cashea_cuota_usd?: number;
  cashea_total_venta_usd?: number;
  cashea_total_venta_ves?: number;
  pagos_mixtos?: SplitPaymentLeg[];
  referencia_pago?: string;
  cliente_nombre?: string;
  cliente_cedula?: string;
  numero_factura?: string;
  numero_control?: string;
  items: SaleItem[];
  usuario: string;
  cajero_nombre?: string | null;
}

export interface CierreProductoSummary {
  nombre: string;
  cantidad: number;
  total_ves: number;
  total_usd: number;
}

export interface CierreDetalleItem {
  nombre: string;
  cantidad: number;
  precio_ves: number;
  subtotal_ves: number;
}

export interface CierreDetalleVenta {
  hora: string;
  metodo: string;
  productos: string;
  items: CierreDetalleItem[];
  iva_ves: number;
  ajuste_ves: number;
  total_ves: number;
  usuario: string;
  cashea_inicial_usd?: number;
  cashea_restante_usd?: number;
  cashea_restante_ves?: number;
  cashea_cuotas?: number;
  cashea_total_venta_ves?: number;
  pagos_mixtos?: SplitPaymentLeg[];
  cliente_nombre?: string;
  cliente_cedula?: string;
}

export interface CierreRecord {
  key?: string;
  fecha: string;
  hora: string;
  timestamp: number;
  total_general_ves: number;
  total_general_usd: number;
  totales_metodos_ves: Record<string, number>;
  totales_metodos_usd: Record<string, number>;
  cantidad_ventas: number;
  productos_vendidos: CierreProductoSummary[];
  detalle_ventas: CierreDetalleVenta[];
  subtotal_productos_ves: number;
  ajuste_ves: number;
  total_iva_ves: number;
  total_iva_usd: number;
  cashea_inicial_total_usd?: number;
  cashea_inicial_total_ves?: number;
  cashea_pendiente_usd?: number;
  cashea_pendiente_ves?: number;
  cerrado_por: string;
}

export interface FiadoItem {
  key: string;
  nombre: string;
  cant: number;
  usd: number;
  base: number;
  es_bulto?: boolean;
  unidades_por_bulto?: number;
  unidades_descontadas?: number;
}

export interface FiadoAbono {
  usd: number;
  bs?: number;
  tasa?: number;
  tipo: 'abono' | 'cuota' | 'inicial';
  metodo?: string;
  referencia?: string;
  fecha?: string;
  ts?: number;
  cobrado_por?: string;
  nota?: string;
}

export interface FiadoRecord {
  docKey?: string;
  cedula: string;
  ts: string;
  numero_factura?: string;
  modalidad?: 'credito' | 'contado_pendiente';
  cliente: string;
  telefono?: string;
  direccion?: string;
  nota?: string;
  cuotas: number;
  fecha_vencimiento?: string;
  limite_credito?: number;
  items: Record<string, FiadoItem> | FiadoItem[];
  abonos?: Record<string, FiadoAbono>;
  iva: number;
  fecha: string;
  estado: 'abierto' | 'pagado';
  creado_por?: string;
}

export interface TallerRepair {
  key?: string;
  fecha: string;
  hora: string;
  timestamp: number;
  mecanico: string;
  metodo_pago: string;
  usd: number;
  bs: number;
  tasa: number;
  descripcion?: string;
}

export interface CashierPermissions {
  aplicar_rebajas?: boolean;
  fiados?: boolean;
  motor?: boolean;
  taller?: boolean;
  editar_tasas?: boolean;
  cerrar_caja?: boolean;
  anular_factura?: boolean;
  herramientas?: boolean;
}

export interface CashierRecord {
  key: string;
  nombre: string;
  email: string;
  telefono?: string;
  turno?: string;
  activo: boolean;
  salt: string;
  hash: string;
  creado: number;
  ultimo_acceso?: number;
  permisos?: CashierPermissions;
}

export interface SystemUserRecord {
  key: string;
  nombre: string;
  email: string;
  rol: 'admin' | 'owner' | 'cashier';
  activo: boolean;
  congelado?: boolean;
  ultimo_acceso?: number;
  creado?: number;
}

export interface BroadcastConfig {
  id?: number;
  titulo: string;
  texto: string;
  tipo: 'info' | 'warning' | 'critical' | 'update';
  audiencia?: 'all' | 'cashier' | 'admin';
  con_voz?: boolean;
  timestamp?: number;
  enviado_por?: string;
}

export interface ScheduledNotice {
  hora: string;
  msg: string;
  activo: boolean;
}

export interface VoiceSettings {
  activa: boolean;
  vel: number;
  voz: string;
  sonidos: boolean;
}

export interface MembershipPlan {
  nombre: string;
  meses: number;
  precio: number;
  oferta: number;
}

export interface MembershipState {
  plan: string | null;
  nombre: string;
  vence: number;
  estado: 'activa' | 'suspendida';
}

export interface PromoRecord {
  id: string;
  nombre: string;
  tipo: 'pct' | 'menos' | 'regalo' | 'xy';
  valor?: number;
  x?: number;
  y?: number;
  repetir?: boolean;
  activo: boolean;
  aplica: 'all' | number[];
  desde?: string;
  hasta?: string;
  creado?: number;
}

export interface SupportTicket {
  key: string;
  tenantId?: string;
  tenantName?: string;
  ownerUid?: string;
  t: number;
  usuario: string;
  rol: string;
  tipo: string;
  msg: string;
  err?: string | null;
  ua?: string;
  estado: 'nuevo' | 'respondido' | 'resuelto';
  resp?: Record<string, { de: string; msg: string; t: number }>;
}

export interface PagoMovilVerificationResult {
  es_comprobante_valido: boolean;
  coincide_monto: boolean;
  coincide_referencia: boolean;
  referencia_detectada?: string;
  monto_detectado_bs?: number | null;
  banco_detectado?: string;
  fecha_detectada?: string;
  confianza: number;
  estado_sugerido: 'aprobado' | 'en_revision' | 'rechazado';
  resumen: string;
  verificado_en: number;
}

export interface MembershipPayment {
  key: string;
  tenantId?: string;
  tenantName?: string;
  ownerUid?: string;
  t: number;
  plan: string;
  nombre: string;
  meses: number;
  bonus: number;
  usd: number;
  bs: number;
  tasa: number;
  ref: string;
  captura?: string | null;
  usuario: string;
  estado: 'pendiente' | 'en_revision' | 'aprobado' | 'rechazado';
  verificacion_ia?: PagoMovilVerificationResult | null;
  nota_propietario?: string;
}

export interface TenantInvoiceConfig {
  ancho_papel: '58mm' | '80mm';
  modelo: 'clasico' | 'moderno' | 'compacto' | 'detallado';
  fuente: 'mono' | 'sans' | 'serif' | 'condensada';
  tamano_letra: 'pequena' | 'normal' | 'grande';
  color_factura?: string;
  intensidad_impresion?: 'suave' | 'normal' | 'oscura' | 'extra_oscura';
  mostrar_logo: boolean;
  logo_data_url?: string;
  encabezado_extra?: string;
  pie_pagina?: string;
  mostrar_rif: boolean;
  mostrar_direccion: boolean;
  mostrar_telefono: boolean;
  mostrar_tasa: boolean;
  mostrar_cajero: boolean;
  impresora_predeterminada: 'navegador' | 'usb' | 'serial' | 'pdf';
  impresora_nombre?: string;
  auto_imprimir: boolean;
  corte_automatico: boolean;
  abrir_gaveta: boolean;
  copias: 1 | 2;
}

export interface SeniatFiscalConfig {
  prefijo_factura?: string;
  factura_actual?: number;
  prefijo_control?: string;
  control_actual?: number;
  maquina_fiscal?: string;
  iva_porcentaje?: number;
  providencia?: string;
  pie_legal?: string;
}

export type VerificationRequirementKey =
  | 'datos_fiscales'
  | 'datos_domiciliarios'
  | 'verificacion_rif'
  | 'comprobacion_vida'
  | 'certificacion_ingresos'
  | 'certificacion_gastos'
  | 'verificacion_seniat'
  | 'comprobacion_seniat'
  | 'registro_mercantil';

export type VerificationDocStatus = 'pendiente' | 'en_revision' | 'verificado' | 'rechazado';

export interface CustomVerificationRequirement {
  id: string;
  label: string;
  description?: string;
  requiere_foto: boolean;
  activo: boolean;
}

export interface VerificationRequestConfig {
  activo: boolean;
  mensaje?: string;
  requisitos: Partial<Record<VerificationRequirementKey, boolean>>;
  requisitos_foto?: Record<string, boolean>;
  requisitos_personalizados?: CustomVerificationRequirement[];
  activado_en?: number;
  updatedAt?: number;
}

export interface VerificationDocRecord {
  key: string;
  req_id: string;
  label: string;
  imagen?: string;
  detalle?: string;
  estado: VerificationDocStatus;
  nota_propietario?: string;
  subido_por?: string;
  subido_en?: number;
  revisado_en?: number;
  revisado_por?: string;
}

export type PreRegistrationStatus = 'pendiente' | 'aprobado' | 'rechazado';

export interface PreRegistrationRecord {
  id: string;
  applicantUid: string;
  email: string;
  nombre_local: string;
  razon_social: string;
  rif: string;
  direccion_fiscal: string;
  telefono: string;
  contacto_nombre: string;
  cedula_representante?: string;
  rubro?: string;
  registro_mercantil?: string;
  foto_rif?: string;
  notas?: string;
  estado: PreRegistrationStatus;
  tenantIdAprobado?: string;
  nota_propietario?: string;
  createdAt: number;
  reviewedAt?: number;
  reviewedBy?: string;
}

export interface OwnerChatMessage {
  id: string;
  senderRole: 'owner' | 'client' | 'ai_bot';
  senderName: string;
  senderEmail?: string;
  text: string;
  aiGenerated?: boolean;
  timestamp: number;
}

export type NetworkHealthStatus = 'online' | 'unstable' | 'offline';

export interface PagoMovilConfig {
  banco: string;
  tel: string;
  ci: string;
  titular: string;
  activo?: boolean;
}

export interface MembershipPaymentMethod {
  id: string;
  tipo: string;
  titulo: string;
  detalle: string;
  titular?: string;
  documento?: string;
  activo: boolean;
}

export interface PlatformConfig {
  nombre_plataforma?: string;
  propietario_email?: string;
  whatsapp_membresia?: string;
  whatsapp_soporte?: string;
  whatsapp_soporte_secundario?: string;
  soporte_horario?: string;
  pago_movil?: PagoMovilConfig | null;
  metodos_pago_membresia?: MembershipPaymentMethod[];
  planes?: Record<string, MembershipPlan>;
  planes_links?: Record<string, string>;
  promos?: Record<string, PromoRecord>;
  aviso_membresia?: {
    dias: number;
    activo: boolean;
    titulo: string;
    msg: string;
  };
  voz?: VoiceSettings;
  mantenimiento_global?: boolean;
  mantenimiento_mensaje?: string;
  seniat_legal_activo?: boolean;
  seniat_providencia?: string;
  seniat_pie_legal?: string;
  seniat_prefijo_factura?: string;
  seniat_prefijo_control?: string;
  seniat_iva_porcentaje?: number;
  updatedAt?: number;
}

export interface TenantRecord {
  id: string;
  ownerUid: string;
  email: string;
  nombre_local: string;
  razon_social?: string;
  rif?: string;
  direccion_fiscal?: string;
  telefono?: string;
  contacto_nombre?: string;
  admin_pin_salt?: string;
  admin_pin_hash?: string;
  caja_pin_salt?: string;
  caja_pin_hash?: string;
  membresia?: MembershipState | null;
  logo_url?: string;
  invoice_config?: TenantInvoiceConfig | null;
  seniat_config?: SeniatFiscalConfig | null;
  verificacion_datos?: VerificationRequestConfig | null;
  activo: boolean;
  congelado?: boolean;
  admin_bloqueado?: boolean;
  mantenimiento?: boolean;
  ultimo_acceso?: number;
  createdAt?: number;
  updatedAt?: number;
  createdBy?: string;
}

export interface AppConfig {
  nombre_local: string;
  tasa_bcv: number;
  tasa_secundaria: number;
  tasa_terciaria: number;
  moneda_local?: string;
  tasa_editable?: boolean;
  whatsapp_close_phone: string;
  whatsapp_membresia: string;
  whatsapp_soporte: string;
  whatsapp_soporte_secundario?: string;
  soporte_horario?: string;
  propietario_email: string;
  caja_abierta: boolean;
  admin_bloqueado: boolean;
  usuario_congelado: boolean;
  mantenimiento: boolean;
  mantenimiento_global?: boolean;
  mantenimiento_mensaje?: string;
  seniat_legal_activo?: boolean;
  seniat_providencia?: string;
  seniat_pie_legal?: string;
  seniat_prefijo_factura?: string;
  seniat_prefijo_control?: string;
  seniat_iva_porcentaje?: number;
  seniat_config?: SeniatFiscalConfig | null;
  consultor_precios_activo?: boolean;
  consultor_mostrar_paralelo?: boolean;
  consultor_mostrar_stock?: boolean;
  consultor_mensaje?: string;
  logo_url?: string;
  invoice_config?: TenantInvoiceConfig | null;
  verificacion_datos?: VerificationRequestConfig | null;
  tema: string;
  meta_usd: number;
  broadcast: BroadcastConfig | null;
  avisos: Record<string, ScheduledNotice>;
  voz: VoiceSettings;
  mecanicos?: string[];
  membresia: MembershipState | null;
  planes: Record<string, MembershipPlan>;
  planes_links: Record<string, string>;
  promos: Record<string, PromoRecord>;
  pago_movil: PagoMovilConfig | null;
  metodos_pago_membresia: MembershipPaymentMethod[];
  aviso_membresia: {
    dias: number;
    activo: boolean;
    titulo: string;
    msg: string;
  };
}

export interface ProviderRecord {
  key: string;
  nombre: string;
  rif?: string;
  contacto?: string;
  telefono?: string;
  email?: string;
  direccion?: string;
  categoria?: string;
  nota?: string;
  activo: boolean;
  createdAt?: number;
  updatedAt?: number;
}

export interface SupplierPurchaseItem {
  productKey?: string;
  nombre: string;
  barcode?: string;
  cantidad: number;
  costo_unitario_usd: number;
  subtotal_usd: number;
}

export interface SupplierPurchaseRecord {
  key: string;
  numero_factura: string;
  providerId: string;
  providerNombre: string;
  providerRif?: string;
  fecha: string;
  items: SupplierPurchaseItem[];
  total_usd: number;
  total_bs: number;
  tasa: number;
  estado_pago: 'pagada' | 'pendiente';
  metodo_pago?: string;
  actualizar_stock: boolean;
  nota?: string;
  registrado_por?: string;
  createdAt: number;
}

export interface PublicPriceCheckerItem {
  id: string;
  nombre: string;
  barcode: string;
  categoria?: string;
  precio: number;
  stock: number;
  iva_incluido: boolean;
  iva_pct: number;
  fraccionable: boolean;
}

export interface PublicPriceCheckerCatalog {
  activo: boolean;
  nombre_local: string;
  tasa_bcv: number;
  tasa_secundaria: number;
  tasa_terciaria: number;
  mostrar_paralelo: boolean;
  mostrar_stock: boolean;
  mensaje?: string;
  updatedAt: number;
  items: PublicPriceCheckerItem[];
}

