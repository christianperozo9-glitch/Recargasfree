import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import dns from 'dns/promises';
import net from 'net';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

// Prevent transient upstream fetch / socket errors from crashing the Node server
process.on('unhandledRejection', (reason) => {
  console.warn('[server] Unhandled rejection prevented crash:', reason instanceof Error ? reason.message : String(reason));
});
process.on('uncaughtException', (err) => {
  console.error('[server] Uncaught exception prevented crash:', err?.message || err);
});

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const rateCache = new Map<string, CacheEntry<{ rate: number; source: string; updatedAt: number }>>();
const pendingFetches = new Map<string, Promise<{ rate: number; source: string; updatedAt: number }>>();
const CACHE_TTL_MS = 120_000; // 2 minutes TTL cache to eliminate redundant upstream calls

interface ProductImageCandidate {
  id: string;
  title: string;
  sourceDomain: string;
  sourceUrl: string;
  dataUrl: string;
  matchScore: number;
  engine: string;
}

const imageSearchCache = new Map<string, CacheEntry<ProductImageCandidate[]>>();
const IMAGE_SEARCH_CACHE_TTL_MS = 15 * 60_000; // 15 minutes
let geminiQuotaCooldownUntil = 0;
let ddgCooldownUntil = 0;

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

function isQuotaError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err ?? '');
  return msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.toLowerCase().includes('quota');
}

async function fetchWithTimeout(url: string, init: RequestInit = {}, timeoutMs = 6000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function isPrivateOrReservedIp(ip: string): boolean {
  const clean = ip.replace(/^::ffff:/i, '');
  if (net.isIPv4(clean)) {
    const parts = clean.split('.').map(Number);
    const [a, b] = parts;
    if (a === 10 || a === 127 || a === 0) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a >= 224) return true;
    return false;
  }
  const lower = ip.toLowerCase();
  return (
    lower === '::1' ||
    lower === '::' ||
    lower.startsWith('fc') ||
    lower.startsWith('fd') ||
    lower.startsWith('fe80:')
  );
}

async function assertSafePublicUrl(rawUrl: string): Promise<URL | null> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return null;
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
  const host = parsed.hostname.toLowerCase();
  if (
    !host ||
    host === 'localhost' ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host === 'metadata.google.internal'
  ) {
    return null;
  }
  if (net.isIP(host)) {
    return isPrivateOrReservedIp(host) ? null : parsed;
  }
  try {
    const records = await dns.lookup(host, { all: true });
    if (!records.length) return null;
    for (const r of records) {
      if (isPrivateOrReservedIp(r.address)) return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

async function safePublicFetch(
  rawUrl: string,
  init: RequestInit = {},
  timeoutMs = 5000,
  maxRedirects = 3
): Promise<Response | null> {
  let currentUrl = rawUrl;
  for (let i = 0; i <= maxRedirects; i++) {
    const safeUrl = await assertSafePublicUrl(currentUrl);
    if (!safeUrl) return null;
    try {
      const resp = await fetchWithTimeout(
        safeUrl.toString(),
        {
          ...init,
          redirect: 'manual',
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            Accept: 'image/avif,image/webp,image/apng,image/png,image/jpeg,text/html,application/xhtml+xml,*/*;q=0.8',
            'Accept-Language': 'es-VE,es;q=0.9,en;q=0.8',
            ...(init.headers || {}),
          },
        },
        timeoutMs
      );
      if (resp.status >= 300 && resp.status < 400) {
        const loc = resp.headers.get('location');
        if (!loc) return null;
        currentUrl = new URL(loc, safeUrl.toString()).toString();
        continue;
      }
      return resp;
    } catch {
      return null;
    }
  }
  return null;
}

const BAD_IMAGE_HINTS = [
  'favicon',
  'sprite',
  'placeholder',
  'no-image',
  'noimage',
  'default-avatar',
  'avatar',
  'blank.gif',
  'pixel.gif',
  '1x1',
  'logo',
  'brand-mark',
  'icon-',
  '/icons/',
  'gstatic.com/images/branding',
];

function looksLikeJunkImageUrl(u: string): boolean {
  const lower = u.toLowerCase();
  if (lower.endsWith('.svg') || lower.includes('.svg?')) return true;
  if (lower.endsWith('.ico') || lower.includes('.ico?')) return true;
  return BAD_IMAGE_HINTS.some((hint) => lower.includes(hint));
}

function extractProductImageUrlsFromHtml(html: string, pageUrl: string): string[] {
  const found: string[] = [];
  const pushUrl = (raw: string | undefined) => {
    if (!raw || typeof raw !== 'string') return;
    const cleaned = raw.trim().replace(/&amp;/g, '&');
    if (!cleaned || cleaned.startsWith('data:')) return;
    try {
      const resolved = new URL(cleaned, pageUrl).toString();
      if (!looksLikeJunkImageUrl(resolved) && !found.includes(resolved)) {
        found.push(resolved);
      }
    } catch {
      // ignore invalid url
    }
  };

  // 1. JSON-LD Product schema images (highest accuracy for real product photos)
  const ldRegex = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let ldMatch: RegExpExecArray | null;
  while ((ldMatch = ldRegex.exec(html)) !== null) {
    try {
      const parsed = JSON.parse(ldMatch[1].trim());
      const nodes = Array.isArray(parsed)
        ? parsed
        : Array.isArray(parsed?.['@graph'])
        ? parsed['@graph']
        : [parsed];
      for (const node of nodes) {
        const typeVal = String(node?.['@type'] || '').toLowerCase();
        if (typeVal.includes('product') || typeVal.includes('offer') || typeVal.includes('itempage')) {
          const img = node?.image;
          if (typeof img === 'string') pushUrl(img);
          else if (Array.isArray(img)) {
            img.slice(0, 3).forEach((entry) => {
              if (typeof entry === 'string') pushUrl(entry);
              else if (entry && typeof entry.url === 'string') pushUrl(entry.url);
            });
          } else if (img && typeof img === 'object' && typeof img.url === 'string') {
            pushUrl(img.url);
          }
        }
      }
    } catch {
      // ignore malformed JSON-LD
    }
  }

  // 2. OpenGraph / Twitter image meta tags
  const metaPatterns = [
    /<meta[^>]+(?:property|name)=["']og:image(?::secure_url)?["'][^>]+content=["']([^"']+)["']/gi,
    /<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']og:image(?::secure_url)?["']/gi,
    /<meta[^>]+(?:property|name)=["']twitter:image(?::src)?["'][^>]+content=["']([^"']+)["']/gi,
    /<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']twitter:image(?::src)?["']/gi,
  ];
  for (const re of metaPatterns) {
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) !== null) {
      pushUrl(m[1]);
    }
  }

  return found.slice(0, 4);
}

async function fetchVerifiedImageDataUrl(imageUrl: string): Promise<{ dataUrl: string; mime: string } | null> {
  if (looksLikeJunkImageUrl(imageUrl)) return null;
  const resp = await safePublicFetch(imageUrl, { method: 'GET' }, 5500, 3);
  if (!resp || !resp.ok) return null;
  const ct = (resp.headers.get('content-type') || '').toLowerCase().split(';')[0].trim();
  const allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];
  if (!allowedMimes.includes(ct)) return null;

  const contentLen = Number(resp.headers.get('content-length') || 0);
  if (contentLen > 2_500_000) return null;

  const buf = Buffer.from(await resp.arrayBuffer());
  // Skip tiny tracking pixels / micro icons (< 1.5 KB) or huge blobs (> 2.5 MB)
  if (buf.byteLength < 1500 || buf.byteLength > 2_500_000) return null;

  const normalizedMime = ct === 'image/jpg' ? 'image/jpeg' : ct;
  return {
    dataUrl: `data:${normalizedMime};base64,${buf.toString('base64')}`,
    mime: normalizedMime,
  };
}

function tokenizeProductQuery(q: string): string[] {
  const stopWords = new Set([
    'de', 'del', 'la', 'las', 'el', 'los', 'un', 'una', 'para', 'con', 'sin', 'por',
    'en', 'y', 'o', 'the', 'and', 'for', 'with', 'x', 'und', 'uni', 'unidad', 'pza',
  ]);
  return q
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 2 && !stopWords.has(w));
}

const NON_PRODUCT_TITLE_HINTS = [
  'tabla de equivalencias',
  'equivalencias',
  'infografia',
  'diagrama',
  'esquema electrico',
  'manual de usuario',
  'plano ',
  'banner ',
  'flyer ',
  'wallpaper',
];

function singularizeEsToken(tok: string): string {
  if (tok.length >= 6 && tok.endsWith('es') && !/[aeiou]es$/.test(tok)) {
    return tok.slice(0, -2);
  }
  if (tok.length >= 5 && tok.endsWith('s') && !tok.endsWith('ss')) {
    return tok.slice(0, -1);
  }
  return tok;
}

function computeTitleMatchScore(candidateTitle: string, queryTokens: string[], rawQuery: string): number {
  const norm = candidateTitle
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
  if (NON_PRODUCT_TITLE_HINTS.some((bad) => norm.includes(bad))) return 0;
  if (queryTokens.length === 0) return 60;

  let hits = 0;
  let exactWordHits = 0;
  const titleWordsList = norm.split(/[^a-z0-9]+/).filter(Boolean);
  const titleWords = new Set(titleWordsList);
  const titleSingularWords = new Set(titleWordsList.map(singularizeEsToken));
  const normCompact = norm.replace(/[^a-z0-9]/g, '');

  for (const tok of queryTokens) {
    const sing = singularizeEsToken(tok);
    if (titleWords.has(tok) || titleSingularWords.has(sing)) {
      hits++;
      exactWordHits++;
    } else if (
      norm.includes(tok) ||
      (sing.length >= 4 && norm.includes(sing)) ||
      (tok.length >= 3 && normCompact.includes(tok))
    ) {
      hits++;
    }
  }
  const required = queryTokens.length === 1 ? 1 : Math.max(1, Math.ceil(queryTokens.length * 0.5));
  if (hits < required) return 0;

  const ratio = hits / queryTokens.length;
  const exactBonus = (exactWordHits / queryTokens.length) * 18;
  const normQuery = rawQuery
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
  const phraseBonus = normQuery.length >= 4 && norm.includes(normQuery) ? 15 : 0;
  return Math.min(100, Math.round(ratio * 72 + exactBonus + phraseBonus));
}

function titleMatchesQuery(candidateTitle: string, queryTokens: string[], rawQuery = ''): boolean {
  return computeTitleMatchScore(candidateTitle, queryTokens, rawQuery) > 0;
}

async function getCachedRate(
  key: string,
  fetcher: () => Promise<{ rate: number; source: string; updatedAt: number }>
) {
  const now = Date.now();
  const cached = rateCache.get(key);
  if (cached && cached.expiresAt > now) {
    return { ...cached.value, cached: true };
  }

  const inflight = pendingFetches.get(key);
  if (inflight) {
    const val = await inflight;
    return { ...val, cached: true };
  }

  const promise = fetcher().then((val) => {
    rateCache.set(key, { value: val, expiresAt: Date.now() + CACHE_TTL_MS });
    pendingFetches.delete(key);
    return val;
  }).catch((err) => {
    pendingFetches.delete(key);
    throw err;
  });

  pendingFetches.set(key, promise);
  const val = await promise;
  return { ...val, cached: false };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // Health endpoint (fast, uncached, never hangs)
  app.get('/api/health', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.json({ ok: true, timestamp: Date.now() });
  });

  // Pago Móvil Capture AI Verifier (Server-side Gemini multimodal)
  app.post('/api/verify-pago-movil', async (req, res) => {
    const rawDataUrl = String(req.body?.imageDataUrl || '').trim();
    const expectedBs = Number(req.body?.expectedBs || 0);
    const expectedUsd = Number(req.body?.expectedUsd || 0);
    const expectedRef = String(req.body?.expectedRef || '').trim().slice(0, 80);
    const expectedBank = String(req.body?.expectedBank || '').trim().slice(0, 80);
    const expectedTel = String(req.body?.expectedTel || '').trim().slice(0, 40);
    const expectedCi = String(req.body?.expectedCi || '').trim().slice(0, 40);

    const dataUrlMatch = rawDataUrl.match(/^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=]+)$/);
    if (!dataUrlMatch) {
      res.status(400).json({ error: 'Adjunta una imagen válida del comprobante de Pago Móvil (PNG, JPG o WEBP).' });
      return;
    }

    const mimeType = dataUrlMatch[1] === 'image/jpg' ? 'image/jpeg' : dataUrlMatch[1];
    const base64Data = dataUrlMatch[2];
    if (base64Data.length > 2_200_000) {
      res.status(400).json({ error: 'La imagen del comprobante excede el tamaño máximo permitido.' });
      return;
    }

    const fallbackVerification = (reason: string) => ({
      es_comprobante_valido: true,
      coincide_monto: false,
      coincide_referencia: false,
      referencia_detectada: expectedRef || '',
      monto_detectado_bs: null,
      banco_detectado: '',
      fecha_detectada: '',
      confianza: 0,
      estado_sugerido: 'en_revision' as const,
      resumen: reason,
      verificado_en: Date.now(),
    });

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || Date.now() < geminiQuotaCooldownUntil) {
      res.json({
        verification: fallbackVerification(
          'Captura recibida correctamente. Pendiente de verificación manual por el propietario.'
        ),
      });
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const prompt = [
        'Eres un auditor experto en comprobantes bancarios de Pago Móvil venezolano.',
        'Analiza estrictamente la imagen adjunta y extrae los datos reales visibles.',
        `Datos esperados por el sistema:`,
        `- Monto esperado: ${expectedBs.toFixed(2)} Bs (equiv. $${expectedUsd.toFixed(2)} USD)`,
        expectedRef ? `- Referencia ingresada por el cliente: ${expectedRef}` : '- Referencia: aún no escrita por el cliente',
        expectedBank ? `- Banco destino esperado: ${expectedBank}` : '',
        expectedTel ? `- Teléfono destino esperado: ${expectedTel}` : '',
        expectedCi ? `- Cédula/RIF destino esperado: ${expectedCi}` : '',
        'Reglas:',
        '1. Si la imagen NO es un comprobante bancario / transferencia / Pago Móvil real (por ejemplo, es una foto cualquiera, meme, pantalla en blanco), marca es_comprobante_valido=false y estado_sugerido="rechazado".',
        '2. Compara el monto en Bolívares visible en la captura con el monto esperado (tolerancia ±2% por redondeo de tasa).',
        '3. Compara los últimos dígitos o referencia completa visible con la referencia ingresada (si el cliente ya la escribió).',
        '4. Extrae referencia_detectada (solo dígitos/código real visible), monto_detectado_bs (número), banco_detectado y fecha_detectada.',
        '5. Devuelve estado_sugerido="aprobado" solo si es un comprobante válido y coinciden monto y referencia; "en_revision" si es un comprobante real pero requiere chequeo humano; "rechazado" si no es un comprobante válido o los datos no corresponden.',
        '6. Escribe un resumen claro y conciso en español (máx 180 caracteres).',
      ]
        .filter(Boolean)
        .join('\n');

      const schema = {
        type: Type.OBJECT,
        properties: {
          es_comprobante_valido: { type: Type.BOOLEAN },
          coincide_monto: { type: Type.BOOLEAN },
          coincide_referencia: { type: Type.BOOLEAN },
          referencia_detectada: { type: Type.STRING },
          monto_detectado_bs: { type: Type.NUMBER, nullable: true },
          banco_detectado: { type: Type.STRING },
          fecha_detectada: { type: Type.STRING },
          confianza: { type: Type.NUMBER },
          estado_sugerido: { type: Type.STRING },
          resumen: { type: Type.STRING },
        },
        required: [
          'es_comprobante_valido',
          'coincide_monto',
          'coincide_referencia',
          'confianza',
          'estado_sugerido',
          'resumen',
        ],
      };

      const callModel = async (model: string, useLowThinking: boolean) =>
        ai.models.generateContent({
          model,
          contents: [
            {
              role: 'user',
              parts: [
                { inlineData: { mimeType, data: base64Data } },
                { text: prompt },
              ],
            },
          ],
          config: {
            responseMimeType: 'application/json',
            responseSchema: schema,
            ...(useLowThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          },
        });

      let response = null;
      try {
        response = await callModel('gemini-4-hydrogen', true);
      } catch (err) {
        if (isQuotaError(err)) {
          try {
            response = await callModel('gemini-3.1-flash-lite', false);
          } catch (liteErr) {
            if (isQuotaError(liteErr)) {
              geminiQuotaCooldownUntil = Date.now() + 5 * 60_000;
            }
          }
        }
      }

      const rawText = response?.text?.trim();
      if (!rawText) {
        res.json({
          verification: fallbackVerification(
            'Comprobante adjuntado. El propietario lo validará manualmente.'
          ),
        });
        return;
      }

      const parsed = JSON.parse(rawText) as Record<string, unknown>;
      const rawSuggested = String(parsed.estado_sugerido || 'en_revision').toLowerCase();
      const estado_sugerido =
        rawSuggested === 'aprobado' || rawSuggested === 'rechazado' || rawSuggested === 'en_revision'
          ? rawSuggested
          : 'en_revision';

      res.json({
        verification: {
          es_comprobante_valido: Boolean(parsed.es_comprobante_valido),
          coincide_monto: Boolean(parsed.coincide_monto),
          coincide_referencia: Boolean(parsed.coincide_referencia),
          referencia_detectada: String(parsed.referencia_detectada || '').slice(0, 60),
          monto_detectado_bs:
            typeof parsed.monto_detectado_bs === 'number' && Number.isFinite(parsed.monto_detectado_bs)
              ? Number(parsed.monto_detectado_bs.toFixed(2))
              : null,
          banco_detectado: String(parsed.banco_detectado || '').slice(0, 60),
          fecha_detectada: String(parsed.fecha_detectada || '').slice(0, 40),
          confianza: Math.max(0, Math.min(100, Math.round(Number(parsed.confianza) || 0))),
          estado_sugerido,
          resumen: String(parsed.resumen || 'Verificación completada.').slice(0, 240),
          verificado_en: Date.now(),
        },
      });
    } catch {
      res.json({
        verification: fallbackVerification(
          'Comprobante cargado. Queda en revisión para aprobación del propietario.'
        ),
      });
    }
  });

  // Owner Panel -> Google Gemini AI Bot for automated client chat messages
  app.post('/api/owner/ai-chat-draft', async (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(500).json({
        error:
          'Clave de IA no configurada en el servidor. Configura GEMINI_API_KEY en Settings > Secrets para activar el Bot de IA.',
      });
      return;
    }

    const clientName = String(req.body?.clientName || 'Cliente').trim().slice(0, 140);
    const contactName = String(req.body?.contactName || '').trim().slice(0, 120);
    const rif = String(req.body?.rif || req.body?.clientRif || '').trim().slice(0, 40);
    const membershipStatus = String(req.body?.membershipStatus || 'Activa').trim().slice(0, 80);
    const daysLeft =
      typeof req.body?.daysLeft === 'number' && Number.isFinite(req.body.daysLeft)
        ? Math.round(req.body.daysLeft)
        : null;
    const pendingDocs = Array.isArray(req.body?.pendingDocs)
      ? req.body.pendingDocs.map((d: unknown) => String(d || '').slice(0, 80)).filter(Boolean).slice(0, 12)
      : [];
    const intent = String(req.body?.intent || 'seguimiento').trim().slice(0, 80);
    const customPrompt = String(req.body?.customPrompt || req.body?.instruction || '').trim().slice(0, 1000);
    const recentMessages = Array.isArray(req.body?.recentMessages)
      ? req.body.recentMessages
          .slice(-8)
          .map((m: { senderRole?: string; text?: string }) => {
            const who = m?.senderRole === 'client' ? 'Cliente' : 'Propietario';
            return `${who}: ${String(m?.text || '').slice(0, 350)}`;
          })
          .join('\n')
      : '';

    const intentMap: Record<string, string> = {
      bienvenida: 'Dar una cálida bienvenida oficial al sistema Innova Grup POS y ofrecer apoyo inicial.',
      renovacion: 'Recordar amablemente el estado de su membresía e invitarlo a renovar a tiempo.',
      verificacion: 'Solicitar cordialmente la actualización y carga de fotos de sus documentos fiscales pendientes.',
      seguimiento: 'Hacer un seguimiento amable para preguntar cómo va su experiencia y ofrecer soporte técnico.',
      promocion: 'Informar sobre beneficios o promociones de renovación anual/semestral disponibles.',
      respuesta_automatica: 'Responder de manera útil, empática y profesional al último mensaje enviado por el cliente.',
      personalizado: 'Redactar el mensaje exacto siguiendo la instrucción del propietario.',
    };

    const goalDesc = intentMap[intent] || intentMap.seguimiento;

    const prompt = [
      'Eres Innova Grup, el Asistente Virtual IA oficial de atención y comunicación del Propietario de Innova Grup POS (sistema punto de venta en Venezuela).',
      'Redacta UN solo mensaje directo en español claro, cordial, profesional y listo para enviar al cliente (sin comillas envolventes, sin asunto de correo, sin explicaciones previas).',
      'Longitud ideal: entre 2 y 5 líneas cortas, fácil de leer en chat o WhatsApp.',
      '',
      'DATOS DEL CLIENTE:',
      `- Comercio: ${clientName}`,
      contactName ? `- Representante / Contacto: ${contactName}` : '',
      rif ? `- RIF: ${rif}` : '',
      `- Estado de membresía: ${membershipStatus}${daysLeft !== null ? ` (${daysLeft} día(s) restantes)` : ''}`,
      pendingDocs.length > 0 ? `- Documentos pendientes por verificar: ${pendingDocs.join(', ')}` : '',
      '',
      `OBJETIVO DEL MENSAJE: ${goalDesc}`,
      customPrompt ? `INSTRUCCIÓN ESPECÍFICA DEL PROPIETARIO: ${customPrompt}` : '',
      recentMessages ? `\nHISTORIAL RECIENTE DEL CHAT:\n${recentMessages}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const callModel = async (model: string, lowThink: boolean) =>
        ai.models.generateContent({
          model,
          contents: prompt,
          config: lowThink ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : undefined,
        });

      let response = null;
      try {
        response = await callModel('gemini-4-hydrogen', true);
      } catch (err) {
        const errStr = String(err || '').toLowerCase();
        const isTransientUnavailable =
          errStr.includes('503') ||
          errStr.includes('unavailable') ||
          errStr.includes('overloaded') ||
          errStr.includes('high demand');
        if (isQuotaError(err) || isTransientUnavailable) {
          response = await callModel('gemini-3.1-flash-lite', false);
        } else {
          throw err;
        }
      }

      const generated = (response?.text || '').trim().slice(0, 1800);
      if (!generated) {
        res.status(502).json({ error: 'El modelo de IA no devolvió texto. Intenta nuevamente.' });
        return;
      }

      res.json({ text: generated, message: generated });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Error consultando el servicio de IA.';
      res.status(502).json({ error: `No se pudo generar el mensaje con IA: ${msg.slice(0, 220)}` });
    }
  });

  // Unified Interactive Virtual Assistant ("Innova Grup") for Portal Advisor, Client Chat & Support
  app.post('/api/innova-assistant', async (req, res) => {
    const userMessage = String(req.body?.message || '').trim().slice(0, 1200);
    if (!userMessage) {
      res.status(400).json({ error: 'Escribe un mensaje para el Asistente Virtual Innova Grup.' });
      return;
    }

    const mode = String(req.body?.mode || 'portal_advisor').trim();
    const rawEmail = String(req.body?.email || '').trim().toLowerCase().slice(0, 160);
    const verifiedEmailContext = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawEmail) ? rawEmail : '';
    const verified = req.body?.verified === true;
    const rawAccount =
      verified && req.body?.verifiedAccount && typeof req.body.verifiedAccount === 'object'
        ? req.body.verifiedAccount
        : null;

    // Sanitize only non-sensitive account summary fields when verified === true (never passwords or PIN hashes)
    const safeAccount = rawAccount
      ? {
          nombre_local: String(rawAccount.nombre_local || '').slice(0, 120),
          razon_social: String(rawAccount.razon_social || '').slice(0, 140),
          email: String(rawAccount.email || '').slice(0, 160),
          rif: String(rawAccount.rif || '').slice(0, 40),
          contacto_nombre: String(rawAccount.contacto_nombre || '').slice(0, 100),
          telefono: String(rawAccount.telefono || '').slice(0, 40),
          estado_cuenta: String(rawAccount.estado_cuenta || 'Activa').slice(0, 60),
          membresia_plan: String(rawAccount.membresia_plan || 'Sin plan').slice(0, 80),
          membresia_estado: String(rawAccount.membresia_estado || 'Activa').slice(0, 40),
          dias_restantes:
            typeof rawAccount.dias_restantes === 'number' && Number.isFinite(rawAccount.dias_restantes)
              ? Math.round(rawAccount.dias_restantes)
              : null,
          verificacion_pendiente: Boolean(rawAccount.verificacion_pendiente),
          documentos_pendientes: Array.isArray(rawAccount.documentos_pendientes)
            ? rawAccount.documentos_pendientes.map((x: unknown) => String(x || '').slice(0, 80)).filter(Boolean).slice(0, 10)
            : [],
          seniat_modo_fiscal: Boolean(rawAccount.seniat_modo_fiscal),
        }
      : null;

    const rawHistory = Array.isArray(req.body?.history) ? req.body.history.slice(-10) : [];
    const historyLines = rawHistory
      .map((m: { role?: string; text?: string }) => {
        const who = m?.role === 'assistant' ? 'Innova Grup' : 'Usuario';
        return `${who}: ${String(m?.text || '').slice(0, 400)}`;
      })
      .join('\n');

    const lowerMsg = userMessage.toLowerCase();
    const asksPrivateData =
      /mi cuenta|mis datos|mi membres|vencim|dias restantes|d[ií]as restantes|mi rif|mi negocio|mi correo|mi local|mi verificaci|estatus|estado de mi|cu[aá]nto me queda|bloquead|congelad|mi plan|mi factura|datos privados/i.test(
        lowerMsg
      );

    const buildFallback = () => {
      if (!verified && asksPrivateData) {
        return {
          reply: verifiedEmailContext
            ? `Tengo registrado tu correo (${verifiedEmailContext}) para orientarte, pero para consultar o mostrar datos privados de tu cuenta (membresía, RIF, días restantes o documentos) Innova Grup requiere validar tu contraseña de cuenta y tu PIN de Administrador. Pulsa el botón "Desbloquear datos privados" aquí arriba para completar esa verificación.`
            : '¡Hola! Soy el Asistente Virtual de Innova Grup. Para consultas generales solo necesitas indicar tu correo electrónico (sin iniciar sesión con Google), pero para consultar datos privados de tu cuenta, membresía o comercio debes validar tu contraseña de cuenta y tu PIN de Administrador. Pulsa "Verificar correo / datos" aquí arriba para continuar.',
          suggestVerification: true,
          escalate_to_human: false,
        };
      }
      if (verified && safeAccount && asksPrivateData) {
        const daysStr =
          safeAccount.dias_restantes !== null
            ? `${safeAccount.dias_restantes} día(s) restantes`
            : 'sin fecha de vencimiento definida';
        return {
          reply: `Hola ${safeAccount.contacto_nombre || safeAccount.nombre_local}, ya confirmé tu contraseña y PIN de Administrador. Tu comercio "${safeAccount.nombre_local}" (RIF: ${safeAccount.rif || 'No registrado'}) se encuentra en estado ${safeAccount.estado_cuenta}. Membresía: ${safeAccount.membresia_plan} (${safeAccount.membresia_estado}, ${daysStr}).${safeAccount.verificacion_pendiente ? ' Tienes una actualización de datos pendiente por completar.' : ''} ¿En qué más puedo ayudarte hoy?`,
          suggestVerification: false,
          escalate_to_human: false,
        };
      }
      if (/iniciar sesi[oó]n|entrar|login|como entro|c[oó]mo entro|pin|clave|cajero|admin/i.test(lowerMsg)) {
        return {
          reply:
            'Para iniciar sesión en Innova Grup POS: 1) Elige tu perfil (Cajero o Administrador) en la pantalla principal. 2) Ingresa el correo afiliado de tu comercio. 3) Si eres Administrador, coloca tu contraseña; si eres Cajero, ingresa tu PIN numérico de caja (la primera vez en una terminal nueva necesitarás vincularla con la contraseña del comercio). ¿Necesitas verificar el estado de tu cuenta?',
          suggestVerification: !verified && mode === 'portal_advisor',
          escalate_to_human: false,
        };
      }
      if (/registr|crear cuenta|nuevo negocio|pre-?registro|afiliar|solicitar/i.test(lowerMsg)) {
        return {
          reply:
            'Para registrar tu negocio en Innova Grup POS, pulsa "¿Eres un negocio nuevo? Regístrate aquí" en la pantalla de inicio y completa tus datos fiscales y legales (Nombre comercial, Razón Social, RIF, Domicilio y WhatsApp). El Propietario revisará tu solicitud y al aprobarla recibirás tus credenciales con 5 días de regalo por WhatsApp.',
          suggestVerification: false,
          escalate_to_human: false,
        };
      }
      if (/seniat|fiscal|factura|impresora|tasa|bcv/i.test(lowerMsg)) {
        return {
          reply:
            'Soy Innova Grup, tu asistente virtual. Nuestro sistema soporta impresión térmica 58mm/80mm, PDF A4 y Modo Fiscal SENIAT con correlativos de factura y control, tasa BCV actualizada y respaldo legal venezolano. Si necesitas ayuda con un paso específico, indícame qué módulo estás usando.',
          suggestVerification: false,
          escalate_to_human: false,
        };
      }
      return {
        reply: verifiedEmailContext
          ? `¡Hola! Soy el Asistente Virtual de Innova Grup y ya vinculé tu correo (${verifiedEmailContext}) para asesorarte. Puedo ayudarte con el inicio de sesión, pre-registro, facturación SENIAT o impresoras; y si necesitas ver datos privados de tu comercio, puedes desbloquearlos con tu contraseña y PIN de Administrador. ¿Qué necesitas hacer ahora?`
          : '¡Hola! Soy el Asistente Virtual de Innova Grup. Puedes verificar solo tu correo para recibir orientación rápida (sin iniciar sesión con Google), o desbloquear datos privados de tu cuenta con tu contraseña y PIN de Administrador. ¿En qué puedo ayudarte hoy?',
        suggestVerification: !verified && mode === 'portal_advisor',
        escalate_to_human: false,
      };
    };

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || Date.now() < geminiQuotaCooldownUntil) {
      res.json(buildFallback());
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const systemInstruction = `Eres "Innova Grup", el Asistente Virtual IA oficial de C.C. INNOVA GRUP POS (sistema punto de venta comercial en Venezuela).
Actúas como un asesor cálido, profesional, claro, proactivo e interactivo en español.

CONOCIMIENTO DEL SISTEMA INNOVA GRUP:
- Acceso: Los clientes eligen perfil (Cajero o Administrador), ingresan el correo electrónico afiliado a su comercio y colocan su contraseña (Administrador) o PIN numérico de caja (Cajero).
- Verificación en el Asistente Virtual (SIN iniciar sesión con Google):
  * Nivel 1 (Solo correo): El usuario solo escribe su correo electrónico para recibir orientación personalizada sin usar Google Sign-In.
  * Nivel 2 (Datos privados): Si el usuario solicita datos privados de su cuenta (membresía, RIF, días restantes, estado de cuenta, documentos pendientes), debe validar obligatoriamente su Contraseña de cuenta y su PIN de Administrador desde el panel seguro del asistente.
- Pre-registro: En la pantalla principal pueden pulsar "¿Eres un negocio nuevo? Regístrate aquí", ingresar datos fiscales/legales (Razón Social, RIF, Domicilio, Registro Mercantil) y esperar aprobación del Propietario (incluye 5 días de regalo).
- POS: Ventas en USD/Bs a tasa BCV/Secundaria/Terciaria, lector de códigos de barras, Pago Móvil, Cashea, Pago Mixto, Fiados, Cierre de Caja, Inventario con búsqueda de imágenes, Impresoras térmicas 58mm/80mm, Modo Fiscal SENIAT (RIF, correlativos de factura y control, IVA 16%, Providencia SNAT/2011/00071), y Actualización/Verificación de Documentos.

REGLAS DE SEGURIDAD CRÍTICAS (INQUEBRANTABLES):
1. Tu nombre SIEMPRE es "Innova Grup" (nunca digas "Bot IA de Google" ni menciones modelos internos).
2. NUNCA pidas al usuario iniciar sesión con Google para verificarse en este asistente. La verificación básica es solo con correo electrónico, y para datos privados se solicita Contraseña de cuenta + PIN de Administrador dentro del formulario seguro del asistente (NUNCA pidas que escriban su contraseña o PIN directamente en el texto del chat).
3. Si "verified" es FALSE: TIENES PROHIBIDO ABSOLUTAMENTE revelar, adivinar o inventar cualquier información privada de una cuenta, RIF, membresía, pagos o estado de verificación. Si el usuario pregunta por sus datos privados, cuenta, membresía o negocio, indícale amablemente que para proteger su privacidad debe completar la verificación de datos privados con su Contraseña de cuenta y PIN de Administrador pulsando el botón seguro de verificación, y establece suggestVerification = true.
4. Si "verified" es TRUE: tienes acceso a los datos sanitizados de la cuenta verificada provistos abajo. Puedes responder con precisión sobre su comercio, RIF, estado de membresía, días restantes, verificación de datos o Modo Fiscal, pero NUNCA muestres ni solicites contraseñas ni PINs.
5. Responde de forma concisa y útil (máximo 4-5 frases) y termina ofreciendo el siguiente paso útil.`;

      const accountContextBlock =
        verified && safeAccount
          ? `ESTADO DE SEGURIDAD: DATOS PRIVADOS DESBLOQUEADOS (verificado con correo + contraseña + PIN de Administrador).
DATOS DE LA CUENTA VERIFICADA:
- Comercio: ${safeAccount.nombre_local}
- Razón Social: ${safeAccount.razon_social || 'No registrada'}
- Correo afiliado: ${safeAccount.email}
- RIF: ${safeAccount.rif || 'No registrado'}
- Contacto: ${safeAccount.contacto_nombre || 'No registrado'}
- Estado de cuenta: ${safeAccount.estado_cuenta}
- Membresía: ${safeAccount.membresia_plan} (${safeAccount.membresia_estado}${safeAccount.dias_restantes !== null ? `, ${safeAccount.dias_restantes} días restantes` : ''})
- Actualización de datos pendiente: ${safeAccount.verificacion_pendiente ? 'Sí' : 'No'}${safeAccount.documentos_pendientes.length > 0 ? ` (${safeAccount.documentos_pendientes.join(', ')})` : ''}
- Modo Fiscal SENIAT activo: ${safeAccount.seniat_modo_fiscal ? 'Sí' : 'No'}`
          : verifiedEmailContext
          ? `ESTADO DE SEGURIDAD: SOLO CORREO VERIFICADO (${verifiedEmailContext}) — DATOS PRIVADOS BLOQUEADOS. Puedes dar asesoría general, pero NO tienes acceso a datos privados hasta que el usuario valide su Contraseña de cuenta y PIN de Administrador.`
          : 'ESTADO DE SEGURIDAD: SIN VERIFICAR. NO TIENES PERMISO PARA DAR DATOS PRIVADOS DE CUENTA. Para asesoría solo requiere su correo; para datos privados requiere Contraseña de cuenta + PIN de Administrador.';

      const userPrompt = [
        `MODO: ${mode}`,
        accountContextBlock,
        historyLines ? `CONVERSACIÓN RECIENTE:\n${historyLines}` : '',
        `MENSAJE DEL USUARIO: ${userMessage}`,
      ]
        .filter(Boolean)
        .join('\n\n');

      const schema = {
        type: Type.OBJECT,
        properties: {
          reply: { type: Type.STRING },
          suggestVerification: { type: Type.BOOLEAN },
          escalate_to_human: { type: Type.BOOLEAN },
        },
        required: ['reply', 'suggestVerification', 'escalate_to_human'],
      };

      const callModel = async (model: string, lowThink: boolean) =>
        ai.models.generateContent({
          model,
          contents: userPrompt,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: schema,
            ...(lowThink ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          },
        });

      let response = null;
      try {
        response = await callModel('gemini-4-hydrogen', true);
      } catch (err) {
        const errStr = String(err || '').toLowerCase();
        const isTransient =
          errStr.includes('503') ||
          errStr.includes('unavailable') ||
          errStr.includes('overloaded') ||
          errStr.includes('high demand');
        if (isQuotaError(err) || isTransient) {
          try {
            response = await callModel('gemini-3.1-flash-lite', false);
          } catch (liteErr) {
            if (isQuotaError(liteErr)) {
              geminiQuotaCooldownUntil = Date.now() + 5 * 60_000;
            }
          }
        }
      }

      const rawText = response?.text?.trim();
      if (rawText) {
        const parsed = JSON.parse(rawText) as {
          reply?: string;
          suggestVerification?: boolean;
          escalate_to_human?: boolean;
        };
        if (parsed.reply) {
          res.json({
            reply: String(parsed.reply).trim().slice(0, 1800),
            suggestVerification: !verified && Boolean(parsed.suggestVerification || asksPrivateData),
            escalate_to_human: Boolean(parsed.escalate_to_human),
          });
          return;
        }
      }
    } catch {
      // Fall back gracefully
    }

    res.json(buildFallback());
  });

  // AI Technical Support Assistant with Automatic Human Escalation
  app.post('/api/support-ai', async (req, res) => {
    const userMessage = String(req.body?.message || '').trim().slice(0, 1200);
    if (!userMessage) {
      res.status(400).json({ error: 'Escribe tu consulta o el error que presentas.' });
      return;
    }

    const rawHistory = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
    const historyLines = rawHistory
      .map((m: { role?: string; text?: string }) => {
        const who = m?.role === 'assistant' ? 'Asistente' : 'Cliente';
        return `${who}: ${String(m?.text || '').slice(0, 400)}`;
      })
      .join('\n');

    const ctx = (req.body?.context || {}) as {
      localName?: string;
      role?: string;
      lastError?: string;
    };

    const lowerMsg = userMessage.toLowerCase();
    const wantsHuman =
      /humano|agente|persona|whatsapp|llamar|propietario|soporte real|no me ayud|no funcion|reembolso|desbloquear cuenta|cambiar correo|activar membres/i.test(
        lowerMsg
      );

    const buildLocalFallback = () => {
      if (wantsHuman) {
        return {
          reply:
            'Entiendo que necesitas atención directa. En este momento no puedo resolver este caso de forma automática, pero un agente de soporte se pondrá en contacto contigo por WhatsApp o mediante el chat de soporte para ayudarte de inmediato.',
          escalate_to_human: true,
          suggested_category: 'Atención de Agente',
        };
      }
      if (/impresor|ticket|factura|termic|térmic|usb|serial/i.test(lowerMsg)) {
        return {
          reply:
            'Para problemas con la impresora térmica: 1) Abre el menú ☰ → "Periféricos USB / Serial" y pulsa "Conectar USB" o "Conectar Serial" (en Chrome/Edge). 2) Si usas impresora del sistema operativo, elige modo "Impresora" al cobrar para imprimir por el navegador con tu formato térmico configurado. 3) Si tu logo o tamaño de papel (58mm/80mm) necesita ajuste, un agente del propietario puede actualizarlo desde el Panel Maestro. ¿Se solucionó o deseas que te contacte un agente?',
          escalate_to_human: false,
          suggested_category: 'Falla técnica',
        };
      }
      if (/tasa|bcv|paralel|dolar|dólar|usdt|bolivar/i.test(lowerMsg)) {
        return {
          reply:
            'Para actualizar las tasas: pulsa el botón "Tasas" en la barra superior o entra en Administración → "Sistemas y Tasas" para sincronizar BCV/USDT o editar manualmente la tasa. Recuerda que los precios en dólares se mantienen y los bolívares se recalculan automáticamente según la tasa seleccionada.',
          escalate_to_human: false,
          suggested_category: 'Tasas e inventario',
        };
      }
      if (/fiado|credito|crédito|cuota|abono|borrar/i.test(lowerMsg)) {
        return {
          reply:
            'En el módulo de Fiados puedes elegir entre "A Crédito (Por Cuotas)" o "Fiado / Factura Pendiente (Pago Único)". Para registrar abonos o buscar deudores entra a Fiados o Administración → "Fiados y Cuentas". Para borrar una factura fiada el sistema solicitará el PIN o contraseña del Administrador para autorizar.',
          escalate_to_human: false,
          suggested_category: 'Fiados y cuentas',
        };
      }
      if (/membres|pago m[oó]vil|captura|renovar|vencid|bloquead/i.test(lowerMsg)) {
        return {
          reply:
            'Para renovar tu membresía: abre "Membresía", selecciona el plan, realiza el Pago Móvil a los datos indicados, escribe la referencia y adjunta obligatoriamente la captura del comprobante. El propietario revisará tu pago y al aprobarlo se extenderán tus días y se generará tu recibo PDF. Si ya pagaste y necesitas validación urgente, un agente puede atenderte por WhatsApp o chat de soporte.',
          escalate_to_human: true,
          suggested_category: 'Membresía y pagos',
        };
      }
      return {
        reply:
          'No pude identificar con certeza una solución automática para tu caso. Un agente técnico de Innova Grup se pondrá en contacto contigo por medio de WhatsApp o el chat de soporte para revisarlo contigo paso a paso.',
        escalate_to_human: true,
        suggested_category: 'Falla técnica',
      };
    };

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || Date.now() < geminiQuotaCooldownUntil) {
      res.json(buildLocalFallback());
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const systemPrompt = `Eres el Asistente de Soporte Técnico IA oficial de Innova Grup POS (sistema punto de venta comercial en Venezuela).
Conoces al detalle el sistema:
- POS de ventas: búsqueda de productos, lector de código de barras (USB/inalámbrico/cámara F3), IVA 16% (F5), tasas BCV/Secundaria/Terciaria, Pago Móvil (con referencia opcional), Efectivo Dólar, Efectivo Bs, Débito, Biopago, Cashea (inicial entra al cierre), Pago Fraccionado/Mixto, Fiados (A Crédito por cuotas o Factura Pendiente pago único).
- Fiados: gestión desde botón Fiados (F4) y desde Administración -> Fiados y Cuentas; borrar factura fiada requiere PIN o contraseña del Administrador.
- Cierre de caja (F9): requiere autorización con PIN o contraseña del Administrador; imprime ticket térmico o PDF automático; cierres guardados visibles en Administración -> Cierres Guardados.
- Anulación de facturas: devuelve stock y descuenta del cierre, requiere clave/PIN de Administrador.
- Impresoras térmicas y logotipo: configurables por el propietario (58mm/80mm, fuente, tamaño, logo del local, impresora predeterminada USB/Serial/Navegador/PDF).
- Inventario: registro manual, carga masiva desde Excel/CSV, búsqueda automática de foto real, etiquetas de precios y cartel de tasa BCV.
- Permisos de cajeros: el administrador los configura en Administración -> Usuarios, Proveedores y Compras.
- Membresía: se renueva subiendo obligatoriamente captura de Pago Móvil; el propietario aprueba, pone en revisión o rechaza y genera recibo PDF.
- Notificaciones Push: compatibles con Android y Web al instalar la app (PWA) y activar permisos de notificación.

REGLAS ESTRICTAS:
1. Responde en español claro, amable, directo y paso a paso (máx 4-5 frases).
2. Si el problema requiere intervención humana (ej: desbloquear cuenta, aprobar pago móvil, cambiar logo/formato térmico, cambiar correo, error persistente tras intentar soluciones, o el cliente pide hablar con una persona/agente/WhatsApp), DEBES establecer escalate_to_human = true y decirle amablemente en tu respuesta que un agente de soporte se pondrá en contacto con él por medio de WhatsApp o el chat de soporte.
3. Si la conversación ya lleva 3 o más intercambios sin resolverse, establece escalate_to_human = true y ofrece el contacto por WhatsApp o chat de soporte.
4. No inventes funciones inexistentes ni pidas contraseñas o PINs al cliente.`;

      const userPrompt = [
        ctx.localName ? `Comercio: ${ctx.localName}` : '',
        ctx.role ? `Rol del usuario: ${ctx.role}` : '',
        ctx.lastError ? `Último error detectado en pantalla: ${ctx.lastError}` : '',
        historyLines ? `Historial reciente:\n${historyLines}` : '',
        `Mensaje actual del cliente: ${userMessage}`,
      ]
        .filter(Boolean)
        .join('\n\n');

      const schema = {
        type: Type.OBJECT,
        properties: {
          reply: { type: Type.STRING },
          escalate_to_human: { type: Type.BOOLEAN },
          suggested_category: { type: Type.STRING },
        },
        required: ['reply', 'escalate_to_human', 'suggested_category'],
      };

      const callModel = async (model: string, useLowThinking: boolean) =>
        ai.models.generateContent({
          model,
          contents: userPrompt,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: 'application/json',
            responseSchema: schema,
            ...(useLowThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          },
        });

      let response = null;
      try {
        response = await callModel('gemini-4-hydrogen', true);
      } catch (err) {
        if (isQuotaError(err)) {
          try {
            response = await callModel('gemini-3.1-flash-lite', false);
          } catch (liteErr) {
            if (isQuotaError(liteErr)) {
              geminiQuotaCooldownUntil = Date.now() + 5 * 60_000;
            }
          }
        }
      }

      const rawText = response?.text?.trim();
      if (!rawText) {
        res.json(buildLocalFallback());
        return;
      }

      const parsed = JSON.parse(rawText) as {
        reply?: string;
        escalate_to_human?: boolean;
        suggested_category?: string;
      };

      res.json({
        reply: String(parsed.reply || '').trim() || buildLocalFallback().reply,
        escalate_to_human: Boolean(parsed.escalate_to_human || wantsHuman),
        suggested_category: String(parsed.suggested_category || 'Falla técnica').slice(0, 80),
      });
    } catch {
      res.json(buildLocalFallback());
    }
  });

  // Real Web & Google Product Image Search with Verified Image Extraction
  const normalizePhoneticProductQuery = (raw: string): string | null => {
    const cleaned = raw.trim().replace(/\s+/g, ' ');
    let alt = cleaned;
    // Common Spanish voice-dictation corrections (e.g. "quita empacadura" -> "kit empacadura")
    alt = alt.replace(/^quita\s+/i, 'kit ');
    alt = alt.replace(/\bquita\s+(empacadura|empaque|junta|arrastre|cadena|clutch|embrague|freno|cilindro|piston|pist[oó]n|biela|carburador)/gi, 'kit $1');
    alt = alt.replace(/\bempacaduras\b/gi, 'empacadura');
    alt = alt.replace(/\bkit\s+de\s+/gi, 'kit ');
    return alt.toLowerCase() !== cleaned.toLowerCase() ? alt : null;
  };

  const searchBingWebImages = async (
    q: string
  ): Promise<Array<{ title: string; image: string; thumbnail?: string; url: string }>> => {
    const resp = await fetchWithTimeout(
      `https://www.bing.com/images/search?q=${encodeURIComponent(q)}&mkt=es-VE&setlang=es&FORM=IRFLTR`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
          'Accept-Language': 'es-VE,es;q=0.9,en;q=0.8',
        },
      },
      5500
    );
    if (!resp.ok) return [];
    const html = await resp.text();
    const out: Array<{ title: string; image: string; thumbnail?: string; url: string }> = [];
    const regex = /m="(\{[^"]+\})"/g;
    let match: RegExpExecArray | null;
    while ((match = regex.exec(html)) !== null && out.length < 24) {
      try {
        const obj = JSON.parse(decodeHtmlEntities(match[1])) as {
          t?: string;
          murl?: string;
          purl?: string;
          turl?: string;
        };
        const title = String(obj.t || '').trim();
        const murl = String(obj.murl || '').trim();
        const purl = String(obj.purl || murl).trim();
        const turl = obj.turl ? String(obj.turl).trim() : undefined;
        if (murl || turl) {
          out.push({ title, image: murl || turl || '', thumbnail: turl, url: purl });
        }
      } catch {
        // ignore malformed block
      }
    }
    return out;
  };

  const searchYandexImages = async (
    q: string
  ): Promise<Array<{ title: string; image: string; thumbnail?: string; url: string }>> => {
    const resp = await fetchWithTimeout(
      `https://yandex.com/images/search?text=${encodeURIComponent(q)}`,
      {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          'Accept-Language': 'es-VE,es;q=0.9,en;q=0.8',
        },
      },
      5500
    );
    if (!resp.ok) return [];
    const html = decodeHtmlEntities(await resp.text());
    const out: Array<{ title: string; image: string; thumbnail?: string; url: string }> = [];
    const seen = new Set<string>();
    const re =
      /"thumb":\{"url":"(\/\/avatars\.mds\.yandex\.net\/i\?id=[^"]+)"[\s\S]{0,600}?"img_url=([^"&]+)[\s\S]{0,400}?"alt":"([^"]{2,160})"/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) !== null && out.length < 18) {
      const thumb = `https:${m[1]}`;
      let orig = thumb;
      try {
        orig = decodeURIComponent(m[2]);
      } catch {
        orig = thumb;
      }
      const title = String(m[3] || '').trim();
      if (!seen.has(thumb)) {
        seen.add(thumb);
        out.push({ title, image: orig, thumbnail: thumb, url: orig });
      }
    }
    return out;
  };

  const searchDuckDuckGoImages = async (
    q: string
  ): Promise<Array<{ title: string; image: string; thumbnail?: string; url: string }>> => {
    if (Date.now() < ddgCooldownUntil) return [];
    const ua =
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
    const tokenResp = await fetchWithTimeout(
      `https://duckduckgo.com/?q=${encodeURIComponent(q)}&iax=images&ia=images`,
      {
        headers: {
          'User-Agent': ua,
          'Accept-Language': 'es-VE,es;q=0.9,en;q=0.8',
        },
      },
      4500
    );
    if (!tokenResp.ok) {
      if (tokenResp.status === 403 || tokenResp.status === 418 || tokenResp.status === 429) {
        ddgCooldownUntil = Date.now() + 3 * 60_000;
      }
      return [];
    }
    const html = await tokenResp.text();
    const vqdMatch =
      html.match(/vqd=["']([^"']+)["']/) ||
      html.match(/vqd=([0-9a-zA-Z_-]+)&/) ||
      html.match(/vqd%3D([0-9a-zA-Z_-]+)/);
    if (!vqdMatch?.[1]) return [];
    const vqd = vqdMatch[1];

    const imgResp = await fetchWithTimeout(
      `https://duckduckgo.com/i.js?l=es-ve&o=json&q=${encodeURIComponent(q)}&vqd=${encodeURIComponent(
        vqd
      )}&f=,,,,,&p=1`,
      {
        headers: {
          'User-Agent': ua,
          Referer: 'https://duckduckgo.com/',
          Accept: 'application/json, text/javascript, */*; q=0.01',
        },
      },
      5000
    );
    if (!imgResp.ok) {
      if (imgResp.status === 403 || imgResp.status === 418 || imgResp.status === 429) {
        ddgCooldownUntil = Date.now() + 3 * 60_000;
      }
      return [];
    }
    const json = (await imgResp.json()) as {
      results?: Array<{
        title?: string;
        image?: string;
        thumbnail?: string;
        url?: string;
      }>;
    };
    return (json.results || [])
      .filter((r) => Boolean(r.image || r.thumbnail))
      .map((r) => ({
        title: String(r.title || '').trim(),
        image: String(r.image || r.thumbnail || '').trim(),
        thumbnail: r.thumbnail ? String(r.thumbnail).trim() : undefined,
        url: String(r.url || r.image || '').trim(),
      }));
  };

  app.post('/api/product-image-search', async (req, res) => {
    const rawQuery = String(req.body?.query || req.body?.name || '').trim().slice(0, 140);
    if (rawQuery.length < 2) {
      res.status(400).json({ error: 'Escribe el nombre del producto antes de buscar la imagen.' });
      return;
    }

    const cacheKey = rawQuery
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ');
    const cachedHit = imageSearchCache.get(cacheKey);
    if (cachedHit && cachedHit.expiresAt > Date.now() && cachedHit.value.length > 0) {
      res.json({
        query: rawQuery,
        results: cachedHit.value,
        candidates: cachedHit.value,
        cached: true,
      });
      return;
    }

    const seenImageUrls = new Set<string>();
    const seenTitleKeys = new Set<string>();
    const results: ProductImageCandidate[] = [];

    const makeTryAdd =
      (activeQuery: string, activeTokens: string[]) =>
      async (
        imageUrl: string,
        title: string,
        sourceUrl: string,
        fallbackThumbUrl?: string,
        engine = 'Google / Web'
      ): Promise<boolean> => {
        if (results.length >= 6 || !imageUrl || seenImageUrls.has(imageUrl)) return false;
        const score = computeTitleMatchScore(title || activeQuery, activeTokens, activeQuery);
        if (score <= 0) return false;

        const normTitleKey = (title || '')
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]+/g, ' ')
          .trim()
          .slice(0, 48);
        if (normTitleKey && seenTitleKeys.has(normTitleKey)) return false;

        seenImageUrls.add(imageUrl);
        let verified = await fetchVerifiedImageDataUrl(imageUrl);
        if (!verified && fallbackThumbUrl && !seenImageUrls.has(fallbackThumbUrl)) {
          seenImageUrls.add(fallbackThumbUrl);
          verified = await fetchVerifiedImageDataUrl(fallbackThumbUrl);
        }
        if (!verified) return false;
        if (results.length >= 6) return false;
        if (normTitleKey) seenTitleKeys.add(normTitleKey);

        let domain = 'web';
        try {
          domain = new URL(sourceUrl || imageUrl).hostname.replace(/^www\./, '');
        } catch {
          // ignore
        }
        results.push({
          id: `img_${results.length + 1}_${Date.now()}`,
          title: (title || activeQuery).slice(0, 120),
          sourceDomain: domain,
          sourceUrl: sourceUrl || imageUrl,
          dataUrl: verified.dataUrl,
          matchScore: score,
          engine,
        });
        return true;
      };

    const runEnginePass = async (
      fetcher: (q: string) => Promise<Array<{ title: string; image: string; thumbnail?: string; url: string }>>,
      searchQuery: string,
      engineLabel: string,
      targetCount = 4
    ) => {
      if (results.length >= targetCount) return;
      const activeTokens = tokenizeProductQuery(searchQuery);
      const tryAdd = makeTryAdd(searchQuery, activeTokens);
      try {
        const rawItems = await fetcher(searchQuery);
        const scored = rawItems
          .map((item) => ({
            ...item,
            score: computeTitleMatchScore(item.title, activeTokens, searchQuery),
          }))
          .filter((item) => item.score > 0 && item.title.length > 0)
          .sort((a, b) => b.score - a.score)
          .slice(0, 16);

        for (let i = 0; i < scored.length && results.length < targetCount; i += 4) {
          const batch = scored.slice(i, i + 4);
          await Promise.all(
            batch.map((c) => tryAdd(c.image, c.title, c.url, c.thumbnail, engineLabel))
          );
        }
      } catch {
        // continue to fallbacks
      }
    };

    try {
      const queryTokens = tokenizeProductQuery(rawQuery);
      const tryAddCandidate = makeTryAdd(rawQuery, queryTokens);
      const phoneticAlt = normalizePhoneticProductQuery(rawQuery);
      let resolvedQueryLabel = rawQuery;

      // 1. Primary Engine: Bing Web Images (fast, VE/LatAm localized, reliable merchant photos + CDN thumbs)
      await runEnginePass(searchBingWebImages, rawQuery, 'Google / Web', 4);

      // 1b. Smart phonetic expansion (e.g. "quita empacadura" -> "kit empacadura") if exact query found < 3 matches
      if (results.length < 3 && phoneticAlt) {
        const beforeCount = results.length;
        await runEnginePass(searchBingWebImages, phoneticAlt, 'Google / Web', 4);
        if (results.length > beforeCount && beforeCount === 0) {
          resolvedQueryLabel = phoneticAlt;
        }
      }

      // 2. Secondary Web Engine: Yandex Images (high coverage for spare parts & global brands)
      if (results.length < 3) {
        const yandexQuery = phoneticAlt && results.length === 0 ? phoneticAlt : rawQuery;
        await runEnginePass(searchYandexImages, yandexQuery, 'Búsqueda Web', 4);
      }

      // 3. Tertiary Web Engine: DuckDuckGo Images (auto-cooled on rate limits)
      if (results.length < 3) {
        const ddgQuery = phoneticAlt && results.length === 0 ? phoneticAlt : rawQuery;
        await runEnginePass(searchDuckDuckGoImages, ddgQuery, 'Búsqueda Web', 4);
      }

      // 3. Real product catalog lookup (OpenFoodFacts + Wikimedia Commons) strictly matching query tokens
      if (results.length < 3) {
        try {
          const offUrl = `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(
            rawQuery
          )}&search_simple=1&action=process&json=1&page_size=6`;
          const offResp = await fetchWithTimeout(offUrl, {}, 4000);
          if (offResp.ok) {
            const offJson = (await offResp.json()) as {
              products?: Array<{
                product_name?: string;
                brands?: string;
                image_front_url?: string;
                image_url?: string;
                url?: string;
              }>;
            };
            for (const prod of offJson.products || []) {
              if (results.length >= 4) break;
              const label = `${prod.product_name || ''} ${prod.brands || ''}`.trim();
              const imgUrl = prod.image_front_url || prod.image_url;
              if (imgUrl && label && titleMatchesQuery(label, queryTokens, rawQuery)) {
                await tryAddCandidate(
                  imgUrl,
                  label,
                  prod.url || 'https://world.openfoodfacts.org',
                  undefined,
                  'Catálogo Verificado'
                );
              }
            }
          }
        } catch {
          // optional fallback
        }
      }

      if (results.length < 3) {
        try {
          const wikiUrl = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=6&gsrsearch=${encodeURIComponent(
            rawQuery
          )}&prop=imageinfo&iiprop=url|mime&iiurlwidth=640&format=json`;
          const wikiResp = await fetchWithTimeout(wikiUrl, {}, 4000);
          if (wikiResp.ok) {
            const wikiJson = (await wikiResp.json()) as {
              query?: {
                pages?: Record<
                  string,
                  {
                    title?: string;
                    imageinfo?: Array<{ thumburl?: string; url?: string; descriptionurl?: string; mime?: string }>;
                  }
                >;
              };
            };
            for (const pg of Object.values(wikiJson.query?.pages || {})) {
              if (results.length >= 4) break;
              const cleanTitle = (pg.title || '').replace(/^File:/i, '').replace(/\.[a-z0-9]+$/i, '');
              const info = pg.imageinfo?.[0];
              const imgUrl = info?.thumburl || info?.url;
              if (imgUrl && cleanTitle && titleMatchesQuery(cleanTitle, queryTokens, rawQuery)) {
                await tryAddCandidate(
                  imgUrl,
                  cleanTitle,
                  info?.descriptionurl || 'https://commons.wikimedia.org',
                  undefined,
                  'Wikimedia'
                );
              }
            }
          }
        } catch {
          // optional fallback
        }
      }

      // 4. Google Search Grounding via Gemini SDK when fewer than 2 real matches were found
      const apiKey = process.env.GEMINI_API_KEY;
      let hitGeminiQuota = false;
      if (results.length < 2 && apiKey && Date.now() >= geminiQuotaCooldownUntil) {
        const groundingQuery = phoneticAlt || rawQuery;
        const groundingTokens = tokenizeProductQuery(groundingQuery);
        const tryAddGround = makeTryAdd(groundingQuery, groundingTokens);
        const groundingPages: Array<{ url: string; title: string }> = [];
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
        });
        const prompt = `Busca en Google páginas reales de tiendas, fabricantes o catálogos que vendan o muestren exactamente el producto "${groundingQuery}". Devuelve solo información factual del producto exacto encontrado.`;

        const runGrounding = async (model: string, useLowThinking: boolean) =>
          ai.models.generateContent({
            model,
            contents: prompt,
            config: {
              tools: [{ googleSearch: {} }],
              ...(useLowThinking ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
            },
          });

        let response = null;
        try {
          response = await runGrounding('gemini-4-hydrogen', true);
        } catch (err) {
          if (isQuotaError(err)) {
            try {
              response = await runGrounding('gemini-3.1-flash-lite', false);
            } catch (liteErr) {
              if (isQuotaError(liteErr)) {
                hitGeminiQuota = true;
                geminiQuotaCooldownUntil = Date.now() + 5 * 60_000;
              }
            }
          }
        }

        const chunks = response?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        const seenPages = new Set<string>();
        for (const chunk of chunks) {
          const uri = chunk?.web?.uri;
          const title = chunk?.web?.title || '';
          if (uri && !seenPages.has(uri)) {
            seenPages.add(uri);
            groundingPages.push({ url: uri, title });
          }
        }

        if (groundingPages.length > 0) {
          const pageTasks = groundingPages.slice(0, 6).map(async (pg) => {
            const resp = await safePublicFetch(pg.url, { method: 'GET' }, 4500, 4);
            if (!resp || !resp.ok) return null;
            const finalUrl = resp.url || pg.url;
            const ct = (resp.headers.get('content-type') || '').toLowerCase();
            if (!ct.includes('text/html') && !ct.includes('application/xhtml')) return null;
            const htmlText = (await resp.text()).slice(0, 350_000);
            const titleMatch = htmlText.match(/<title[^>]*>([^<]{2,180})<\/title>/i);
            const pageTitle = (titleMatch?.[1] || pg.title || '').replace(/\s+/g, ' ').trim();
            if (pageTitle && !titleMatchesQuery(`${pageTitle} ${pg.title}`, groundingTokens, groundingQuery)) {
              return null;
            }
            const imgs = extractProductImageUrlsFromHtml(htmlText, finalUrl);
            return { pageTitle: pageTitle || pg.title || groundingQuery, finalUrl, imgs };
          });

          const settled = await Promise.all(pageTasks);
          for (const item of settled) {
            if (!item || results.length >= 4) continue;
            for (const imgUrl of item.imgs) {
              if (results.length >= 4) break;
              const added = await tryAddGround(
                imgUrl,
                item.pageTitle,
                item.finalUrl,
                undefined,
                'Google Search'
              );
              if (added) break;
            }
          }
        }
      }

      // Rank final verified candidates by highest matchScore and cap at 4
      results.sort((a, b) => b.matchScore - a.matchScore);
      const topResults = results.slice(0, 4);

      if (topResults.length > 0) {
        if (imageSearchCache.size >= 200) {
          const oldestKey = imageSearchCache.keys().next().value;
          if (oldestKey) imageSearchCache.delete(oldestKey);
        }
        imageSearchCache.set(cacheKey, {
          value: topResults,
          expiresAt: Date.now() + IMAGE_SEARCH_CACHE_TTL_MS,
        });
      }

      res.json({
        query: resolvedQueryLabel,
        results: topResults,
        candidates: topResults,
        message:
          topResults.length === 0
            ? hitGeminiQuota
              ? `No se encontró ninguna imagen exacta para "${rawQuery}" y la cuota gratuita de búsqueda avanzada alcanzó su límite temporal. Prueba agregando la marca o modelo exacto.`
              : `No se encontró ninguna imagen real coincidente para "${rawQuery}". Prueba agregando la marca o modelo exacto.`
            : undefined,
      });
    } catch (error) {
      res.status(500).json({
        error:
          error instanceof Error
            ? error.message
            : 'No se pudo completar la búsqueda de imágenes.',
      });
    }
  });

  // Optimized BCV rate endpoint with TTL cache, multi-source fallback, and request coalescing
  app.get('/api/rates/bcv', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    try {
      const data = await getCachedRate('bcv', async () => {
        try {
          const resp = await fetchWithTimeout('https://ve.dolarapi.com/v1/dolares/oficial', {}, 6000);
          if (resp.ok) {
            const json = (await resp.json()) as { promedio?: number; venta?: number };
            const rate = Number(json.promedio || json.venta || 0);
            if (Number.isFinite(rate) && rate > 0) {
              return { rate: Number(rate.toFixed(2)), source: 'dolarapi-oficial', updatedAt: Date.now() };
            }
          }
        } catch {
          // fallback to full list endpoint
        }

        try {
          const listResp = await fetchWithTimeout('https://ve.dolarapi.com/v1/dolares', {}, 6000);
          if (listResp.ok) {
            const list = (await listResp.json()) as Array<{ fuente?: string; promedio?: number; venta?: number }>;
            const oficial = Array.isArray(list)
              ? list.find((item) => String(item.fuente || '').toLowerCase() === 'oficial')
              : null;
            const rate = Number(oficial?.promedio || oficial?.venta || 0);
            if (Number.isFinite(rate) && rate > 0) {
              return { rate: Number(rate.toFixed(2)), source: 'dolarapi-oficial-list', updatedAt: Date.now() };
            }
          }
        } catch {
          // fallback to open exchange rate API
        }

        const erResp = await fetchWithTimeout('https://open.er-api.com/v6/latest/USD', {}, 6000);
        if (!erResp.ok) throw new Error(`Upstream BCV error ${erResp.status}`);
        const erJson = (await erResp.json()) as { rates?: { VES?: number } };
        const rate = Number(erJson.rates?.VES || 0);
        if (!Number.isFinite(rate) || rate <= 0) throw new Error('Tasa BCV inválida');
        return { rate: Number(rate.toFixed(2)), source: 'open-er-ves', updatedAt: Date.now() };
      });
      res.json(data);
    } catch (error) {
      const stale = rateCache.get('bcv');
      if (stale) {
        res.json({ ...stale.value, cached: true, stale: true });
        return;
      }
      res.status(502).json({
        error: error instanceof Error ? error.message : 'No se pudo consultar la tasa BCV',
      });
    }
  });

  // Optimized USDT / Paralelo rate endpoint with Binance P2P + DolarAPI fallback
  app.get('/api/rates/usdt', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    try {
      const data = await getCachedRate('usdt', async () => {
        try {
          const binanceResp = await fetchWithTimeout(
            'https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                asset: 'USDT',
                fiat: 'VES',
                tradeType: 'BUY',
                page: 1,
                rows: 5,
                payTypes: [],
                publisherType: null,
              }),
            },
            5000
          );
          if (binanceResp.ok) {
            const bJson = (await binanceResp.json()) as { data?: Array<{ adv?: { price?: string } }> };
            const prices = (bJson.data || [])
              .map((d) => Number(d.adv?.price || 0))
              .filter((n) => Number.isFinite(n) && n > 0);
            if (prices.length > 0) {
              const avg = prices.reduce((s, v) => s + v, 0) / prices.length;
              return { rate: Number(avg.toFixed(2)), source: 'binance-p2p', updatedAt: Date.now() };
            }
          }
        } catch {
          // Fallback to DolarAPI paralelo
        }

        try {
          const fallback = await fetchWithTimeout('https://ve.dolarapi.com/v1/dolares/paralelo', {}, 6000);
          if (fallback.ok) {
            const fJson = (await fallback.json()) as { promedio?: number; venta?: number };
            const rate = Number(fJson.promedio || fJson.venta || 0);
            if (Number.isFinite(rate) && rate > 0) {
              return { rate: Number(rate.toFixed(2)), source: 'dolarapi-paralelo', updatedAt: Date.now() };
            }
          }
        } catch {
          // fallback to full list endpoint
        }

        const listResp = await fetchWithTimeout('https://ve.dolarapi.com/v1/dolares', {}, 6000);
        if (!listResp.ok) throw new Error(`Upstream Paralelo error ${listResp.status}`);
        const list = (await listResp.json()) as Array<{ fuente?: string; promedio?: number; venta?: number }>;
        const paralelo = Array.isArray(list)
          ? list.find((item) => String(item.fuente || '').toLowerCase() === 'paralelo')
          : null;
        const rate = Number(paralelo?.promedio || paralelo?.venta || 0);
        if (!Number.isFinite(rate) || rate <= 0) throw new Error('Tasa USDT inválida');
        return { rate: Number(rate.toFixed(2)), source: 'dolarapi-paralelo-list', updatedAt: Date.now() };
      });
      res.json(data);
    } catch (error) {
      const stale = rateCache.get('usdt');
      if (stale) {
        res.json({ ...stale.value, cached: true, stale: true });
        return;
      }
      res.status(502).json({
        error: error instanceof Error ? error.message : 'No se pudo consultar la tasa USDT',
      });
    }
  });

  // Multi-currency daily exchange rate endpoint (USD -> Selected Local Currency)
  const SUPPORTED_FX_CODES = new Set([
    'VES',
    'COP',
    'CLP',
    'EUR',
    'ARS',
    'MXN',
    'PEN',
    'BRL',
    'DOP',
    'PAB',
  ]);

  app.get('/api/rates/currency', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const rawCode = String(req.query.code || 'VES').trim().toUpperCase();
    if (!SUPPORTED_FX_CODES.has(rawCode)) {
      res.status(400).json({
        ok: false,
        error: `Moneda no soportada: ${rawCode}`,
      });
      return;
    }

    if (rawCode === 'PAB') {
      res.json({
        ok: true,
        currency: 'PAB',
        rate: 1,
        source: 'paridad-oficial-usd',
        updatedAt: Date.now(),
        cached: false,
      });
      return;
    }

    const formatFxPrecision = (val: number) =>
      rawCode === 'EUR' || (val < 5 && val !== 1)
        ? Number(val.toFixed(4))
        : Number(val.toFixed(2));

    const cacheKey = rawCode === 'VES' ? 'bcv' : `fx_${rawCode}`;

    try {
      const data = await getCachedRate(cacheKey, async () => {
        if (rawCode === 'VES') {
          try {
            const resp = await fetchWithTimeout('https://ve.dolarapi.com/v1/dolares/oficial', {}, 6000);
            if (resp.ok) {
              const json = (await resp.json()) as { promedio?: number; venta?: number };
              const rate = Number(json.promedio || json.venta || 0);
              if (Number.isFinite(rate) && rate > 0) {
                return { rate: Number(rate.toFixed(2)), source: 'dolarapi-oficial', updatedAt: Date.now() };
              }
            }
          } catch {
            // fallback to open.er-api
          }
        }

        // Source 1: Open Exchange Rate API (covers COP, CLP, EUR, ARS, MXN, PEN, BRL, DOP, VES)
        try {
          const erResp = await fetchWithTimeout('https://open.er-api.com/v6/latest/USD', {}, 7000);
          if (erResp.ok) {
            const erJson = (await erResp.json()) as { rates?: Record<string, number> };
            const rate = Number(erJson.rates?.[rawCode] || 0);
            if (Number.isFinite(rate) && rate > 0) {
              return {
                rate: formatFxPrecision(rate),
                source: 'open-er-api',
                updatedAt: Date.now(),
              };
            }
          }
        } catch {
          // fallback to Fawaz Ahmed CDN currency API
        }

        // Source 2: jsDelivr Fawaz Ahmed Daily Currency API
        try {
          const cdnResp = await fetchWithTimeout(
            'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json',
            {},
            7000
          );
          if (cdnResp.ok) {
            const cdnJson = (await cdnResp.json()) as { usd?: Record<string, number> };
            const rate = Number(cdnJson.usd?.[rawCode.toLowerCase()] || 0);
            if (Number.isFinite(rate) && rate > 0) {
              return {
                rate: formatFxPrecision(rate),
                source: 'jsdelivr-currency-api',
                updatedAt: Date.now(),
              };
            }
          }
        } catch {
          // fallback to Frankfurter (ECB) for supported currencies
        }

        // Source 3: Frankfurter ECB API (EUR, MXN, BRL, etc.)
        const frankfurterResp = await fetchWithTimeout(
          `https://api.frankfurter.app/latest?from=USD&to=${encodeURIComponent(rawCode)}`,
          {},
          7000
        );
        if (!frankfurterResp.ok) {
          throw new Error(`No se pudo obtener la tasa del día para ${rawCode}`);
        }
        const fJson = (await frankfurterResp.json()) as { rates?: Record<string, number> };
        const rate = Number(fJson.rates?.[rawCode] || 0);
        if (!Number.isFinite(rate) || rate <= 0) {
          throw new Error(`Tasa inválida recibida para ${rawCode}`);
        }
        return {
          rate: formatFxPrecision(rate),
          source: 'frankfurter-ecb',
          updatedAt: Date.now(),
        };
      });

      res.json({
        ok: true,
        currency: rawCode,
        ...data,
      });
    } catch (error) {
      const stale = rateCache.get(cacheKey);
      if (stale) {
        res.json({ ok: true, currency: rawCode, ...stale.value, cached: true, stale: true });
        return;
      }
      res.status(502).json({
        ok: false,
        currency: rawCode,
        error:
          error instanceof Error
            ? error.message
            : `No se pudo consultar la tasa del día para ${rawCode}`,
      });
    }
  });

  // Real YouTube Music Search Proxy (YouTube Data API v3 -> Live YouTube HTML ytInitialData -> Piped fallback -> Curated)
  interface YouTubeSearchItem {
    id: string;
    title: string;
    channel: string;
    duration?: string;
    thumbnail?: string;
    type: 'video' | 'playlist';
  }

  const CURATED_MUSIC: YouTubeSearchItem[] = [
    {
      id: 'jfKfPfyJRdk',
      title: 'Lofi Hip Hop Radio - Beats to Relax/Work',
      channel: 'Lofi Girl',
      duration: 'EN VIVO',
      thumbnail: 'https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg',
      type: 'video',
    },
    {
      id: '4xDzrJKXOOY',
      title: 'Synthwave Radio - Chill Synth / Retro',
      channel: 'Lofi Girl',
      duration: 'EN VIVO',
      thumbnail: 'https://i.ytimg.com/vi/4xDzrJKXOOY/mqdefault.jpg',
      type: 'video',
    },
    {
      id: 'Dx5qFachd3A',
      title: 'Smooth Jazz & Bossa Nova Instrumental',
      channel: 'Cafe Music BGM',
      duration: 'EN VIVO',
      thumbnail: 'https://i.ytimg.com/vi/Dx5qFachd3A/mqdefault.jpg',
      type: 'video',
    },
    {
      id: '36YnV9STBqc',
      title: 'Acoustic Instrumental Ambient Mix',
      channel: 'Ambient Worlds',
      duration: '2:00:00',
      thumbnail: 'https://i.ytimg.com/vi/36YnV9STBqc/mqdefault.jpg',
      type: 'video',
    },
    {
      id: 'lTRiuFIWV54',
      title: '1 A.M Study Session · Chill Lofi Beats',
      channel: 'Lofi Girl',
      duration: '1:01:28',
      thumbnail: 'https://i.ytimg.com/vi/lTRiuFIWV54/mqdefault.jpg',
      type: 'video',
    },
  ];

  function extractYouTubeVideoRenderers(node: unknown, out: YouTubeSearchItem[], seen: Set<string>): void {
    if (!node || typeof node !== 'object' || out.length >= 16) return;
    if (Array.isArray(node)) {
      for (const item of node) {
        if (out.length >= 16) break;
        extractYouTubeVideoRenderers(item, out, seen);
      }
      return;
    }
    const rec = node as Record<string, unknown>;
    if (rec.videoRenderer && typeof rec.videoRenderer === 'object') {
      const vr = rec.videoRenderer as Record<string, unknown>;
      const videoId = typeof vr.videoId === 'string' ? vr.videoId : '';
      if (videoId && /^[a-zA-Z0-9_-]{11}$/.test(videoId) && !seen.has(videoId)) {
        seen.add(videoId);
        const titleObj = vr.title as { runs?: Array<{ text?: string }>; simpleText?: string } | undefined;
        const title =
          titleObj?.runs?.map((r) => r.text || '').join('') ||
          titleObj?.simpleText ||
          'Video de YouTube';
        const ownerObj = (vr.ownerText || vr.longBylineText || vr.shortBylineText) as
          | { runs?: Array<{ text?: string }>; simpleText?: string }
          | undefined;
        const channel =
          ownerObj?.runs?.map((r) => r.text || '').join('') ||
          ownerObj?.simpleText ||
          'YouTube';
        const lenObj = vr.lengthText as { simpleText?: string; runs?: Array<{ text?: string }> } | undefined;
        const duration =
          lenObj?.simpleText ||
          lenObj?.runs?.map((r) => r.text || '').join('') ||
          '';
        const thumbs = (vr.thumbnail as { thumbnails?: Array<{ url?: string }> } | undefined)?.thumbnails;
        const thumbnail =
          (thumbs && thumbs.length > 0 ? thumbs[thumbs.length - 1]?.url : '') ||
          `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`;
        out.push({
          id: videoId,
          title: title.trim(),
          channel: channel.trim(),
          duration: duration || 'AUDIO',
          thumbnail,
          type: 'video',
        });
      }
      return;
    }
    for (const val of Object.values(rec)) {
      if (out.length >= 16) break;
      if (val && typeof val === 'object') {
        extractYouTubeVideoRenderers(val, out, seen);
      }
    }
  }

  async function searchYouTubeInnerTube(q: string): Promise<YouTubeSearchItem[]> {
    const resp = await fetchWithTimeout(
      'https://www.youtube.com/youtubei/v1/search?prettyPrint=false',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          'Accept-Language': 'es-VE,es;q=0.9,en;q=0.8',
          Origin: 'https://www.youtube.com',
          Referer: 'https://www.youtube.com/',
        },
        body: JSON.stringify({
          context: {
            client: {
              clientName: 'WEB',
              clientVersion: '2.20241101.00.00',
              hl: 'es',
              gl: 'VE',
            },
          },
          query: q,
          params: 'EgIQAQ%3D%3D', // Videos only
        }),
      },
      7500
    );
    if (!resp.ok) throw new Error(`InnerTube HTTP ${resp.status}`);
    const json = (await resp.json()) as unknown;
    const items: YouTubeSearchItem[] = [];
    const seen = new Set<string>();
    extractYouTubeVideoRenderers(json, items, seen);
    return items;
  }

  async function searchYouTubeLiveScrape(q: string): Promise<YouTubeSearchItem[]> {
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}&hl=es&gl=VE`;
    const resp = await fetchWithTimeout(
      searchUrl,
      {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          'Accept-Language': 'es-VE,es;q=0.9,en;q=0.8',
          Accept: 'text/html,application/xhtml+xml',
        },
      },
      7500
    );
    if (!resp.ok) throw new Error(`YouTube HTTP ${resp.status}`);
    const html = await resp.text();

    const items: YouTubeSearchItem[] = [];
    const seen = new Set<string>();

    const markerRegexes = [
      /var\s+ytInitialData\s*=\s*(\{[\s\S]*?\});\s*<\/script>/,
      /window\["ytInitialData"\]\s*=\s*(\{[\s\S]*?\});\s*/,
      /ytInitialData\s*=\s*(\{[\s\S]*?\});\s*(?:var|window|<\/script>)/,
    ];
    for (const rx of markerRegexes) {
      const m = html.match(rx);
      if (m?.[1]) {
        try {
          const parsed = JSON.parse(m[1]) as unknown;
          extractYouTubeVideoRenderers(parsed, items, seen);
          if (items.length > 0) return items;
        } catch {
          // try next marker
        }
      }
    }

    // Fallback lightweight regex extraction from embedded JSON blobs
    const fallbackRx = /"videoRenderer":\{"videoId":"([a-zA-Z0-9_-]{11})"[\s\S]{0,1200}?"title":\{"runs":\[\{"text":"([^"]{1,180})"/g;
    let match: RegExpExecArray | null;
    while ((match = fallbackRx.exec(html)) !== null && items.length < 14) {
      const id = match[1];
      if (!seen.has(id)) {
        seen.add(id);
        const title = match[2].replace(/\\u0026/g, '&').replace(/\\"/g, '"');
        items.push({
          id,
          title,
          channel: 'YouTube',
          duration: 'AUDIO',
          thumbnail: `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
          type: 'video',
        });
      }
    }
    return items;
  }

  async function searchYouTubePipedFallback(q: string): Promise<YouTubeSearchItem[]> {
    const pipedEndpoints = [
      `https://api.piped.private.coffee/search?q=${encodeURIComponent(q)}&filter=videos`,
      `https://pipedapi.kavin.rocks/search?q=${encodeURIComponent(q)}&filter=videos`,
    ];
    for (const ep of pipedEndpoints) {
      try {
        const resp = await fetchWithTimeout(ep, { headers: { Accept: 'application/json' } }, 4500);
        if (!resp.ok) continue;
        const json = (await resp.json()) as {
          items?: Array<{
            url?: string;
            title?: string;
            uploaderName?: string;
            thumbnail?: string;
            duration?: number;
          }>;
        };
        const out: YouTubeSearchItem[] = [];
        const seen = new Set<string>();
        for (const it of json.items || []) {
          const idMatch = String(it.url || '').match(/v=([a-zA-Z0-9_-]{11})/);
          const id = idMatch?.[1] || '';
          if (!id || seen.has(id)) continue;
          seen.add(id);
          const secs = Number(it.duration) || 0;
          const mins = Math.floor(secs / 60);
          const rem = secs % 60;
          out.push({
            id,
            title: String(it.title || 'YouTube Audio'),
            channel: String(it.uploaderName || 'YouTube'),
            duration: secs > 0 ? `${mins}:${String(rem).padStart(2, '0')}` : 'EN VIVO',
            thumbnail: it.thumbnail || `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
            type: 'video',
          });
          if (out.length >= 14) break;
        }
        if (out.length > 0) return out;
      } catch {
        // try next endpoint
      }
    }

    const invidiousEndpoints = [
      `https://inv.nadeko.net/api/v1/search?q=${encodeURIComponent(q)}&type=video`,
      `https://invidious.nerdvpn.de/api/v1/search?q=${encodeURIComponent(q)}&type=video`,
    ];
    for (const ep of invidiousEndpoints) {
      try {
        const resp = await fetchWithTimeout(ep, { headers: { Accept: 'application/json' } }, 4500);
        if (!resp.ok) continue;
        const rows = (await resp.json()) as Array<{
          videoId?: string;
          title?: string;
          author?: string;
          lengthSeconds?: number;
        }>;
        if (!Array.isArray(rows)) continue;
        const out: YouTubeSearchItem[] = [];
        const seen = new Set<string>();
        for (const it of rows) {
          const id = typeof it.videoId === 'string' ? it.videoId : '';
          if (!id || !/^[a-zA-Z0-9_-]{11}$/.test(id) || seen.has(id)) continue;
          seen.add(id);
          const secs = Number(it.lengthSeconds) || 0;
          const mins = Math.floor(secs / 60);
          const rem = secs % 60;
          out.push({
            id,
            title: String(it.title || 'YouTube Audio'),
            channel: String(it.author || 'YouTube'),
            duration: secs > 0 ? `${mins}:${String(rem).padStart(2, '0')}` : 'EN VIVO',
            thumbnail: `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
            type: 'video',
          });
          if (out.length >= 14) break;
        }
        if (out.length > 0) return out;
      } catch {
        // try next endpoint
      }
    }

    return [];
  }

  const musicSearchCache = new Map<
    string,
    CacheEntry<{ items: YouTubeSearchItem[]; curated: boolean; source: string }>
  >();
  const pendingMusicSearches = new Map<
    string,
    Promise<{ items: YouTubeSearchItem[]; curated: boolean; source: string }>
  >();
  const MUSIC_CACHE_TTL_MS = 5 * 60_000;

  async function resolveYouTubeMusicSearch(
    q: string,
    type: 'video' | 'playlist'
  ): Promise<{ items: YouTubeSearchItem[]; curated: boolean; source: string }> {
    const apiKey = process.env.YOUTUBE_API_KEY;

    // 1. Official YouTube Data API v3 if key configured
    if (apiKey) {
      try {
        const url = new URL('https://www.googleapis.com/youtube/v3/search');
        url.searchParams.set('part', 'snippet');
        url.searchParams.set('maxResults', '14');
        url.searchParams.set('type', type);
        if (type === 'video') {
          url.searchParams.set('videoEmbeddable', 'true');
        }
        url.searchParams.set('q', q);
        url.searchParams.set('key', apiKey);

        const ytResp = await fetchWithTimeout(url.toString(), {}, 6000);
        const json = (await ytResp.json()) as {
          error?: { message?: string };
          items?: Array<{
            id?: { videoId?: string; playlistId?: string };
            snippet?: {
              title?: string;
              channelTitle?: string;
              thumbnails?: { medium?: { url?: string }; default?: { url?: string } };
            };
          }>;
        };
        if (!json.error && Array.isArray(json.items) && json.items.length > 0) {
          const items: YouTubeSearchItem[] = json.items
            .map((it) => {
              const id = it.id?.videoId || it.id?.playlistId || '';
              return {
                id,
                title: it.snippet?.title || 'Sin título',
                channel: it.snippet?.channelTitle || 'YouTube',
                thumbnail:
                  it.snippet?.thumbnails?.medium?.url ||
                  it.snippet?.thumbnails?.default?.url ||
                  (id ? `https://i.ytimg.com/vi/${id}/mqdefault.jpg` : ''),
                duration: 'AUDIO',
                type,
              };
            })
            .filter((it) => Boolean(it.id));
          if (items.length > 0) {
            return { items, curated: false, source: 'youtube_api' };
          }
        }
      } catch {
        // fall through to InnerTube JSON API
      }
    }

    // 2. YouTube InnerTube JSON API (fast, reliable on Cloud Run & datacenter IPs)
    try {
      const innerTubeItems = await searchYouTubeInnerTube(q);
      if (innerTubeItems.length > 0) {
        return { items: innerTubeItems, curated: false, source: 'youtube_innertube' };
      }
    } catch {
      // fall through to live HTML scrape
    }

    // 3. Live YouTube HTML search fallback
    try {
      const liveItems = await searchYouTubeLiveScrape(q);
      if (liveItems.length > 0) {
        return { items: liveItems, curated: false, source: 'youtube_live' };
      }
    } catch {
      // fall through to Piped / Invidious
    }

    // 4. Piped / Invidious API fallback
    try {
      const pipedItems = await searchYouTubePipedFallback(q);
      if (pipedItems.length > 0) {
        return { items: pipedItems, curated: false, source: 'piped' };
      }
    } catch {
      // fall through to curated
    }

    const filtered = CURATED_MUSIC.filter(
      (m) =>
        m.title.toLowerCase().includes(q.toLowerCase()) ||
        m.channel.toLowerCase().includes(q.toLowerCase())
    );
    return { items: filtered.length ? filtered : CURATED_MUSIC, curated: true, source: 'curated' };
  }

  app.get('/api/music/search', async (req, res) => {
    const q = String(req.query.q || '').trim().slice(0, 140);
    const type: 'video' | 'playlist' = req.query.type === 'playlist' ? 'playlist' : 'video';

    if (!q) {
      res.json({ items: CURATED_MUSIC, curated: true, source: 'curated' });
      return;
    }

    const cacheKey = `${type}:${q.toLowerCase().replace(/\s+/g, ' ')}`;
    const now = Date.now();
    const cached = musicSearchCache.get(cacheKey);
    if (cached && cached.expiresAt > now) {
      res.json({ ...cached.value, cached: true });
      return;
    }

    try {
      let inflight = pendingMusicSearches.get(cacheKey);
      if (!inflight) {
        inflight = resolveYouTubeMusicSearch(q, type)
          .then((result) => {
            if (!result.curated && result.items.length > 0) {
              if (musicSearchCache.size > 150) {
                const oldestKey = musicSearchCache.keys().next().value;
                if (oldestKey) musicSearchCache.delete(oldestKey);
              }
              musicSearchCache.set(cacheKey, {
                value: result,
                expiresAt: Date.now() + MUSIC_CACHE_TTL_MS,
              });
            }
            pendingMusicSearches.delete(cacheKey);
            return result;
          })
          .catch((err) => {
            pendingMusicSearches.delete(cacheKey);
            throw err;
          });
        pendingMusicSearches.set(cacheKey, inflight);
      }

      const result = await inflight;
      res.json(result);
    } catch {
      res.json({ items: CURATED_MUSIC, curated: true, source: 'curated' });
    }
  });

  // Safe Express JSON error handler so API errors never drop connections
  app.use((err: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (res.headersSent) {
      next(err);
      return;
    }
    if (req.path.startsWith('/api/')) {
      res.status(500).json({ error: 'Error interno temporal. Intenta nuevamente.' });
      return;
    }
    next(err);
  });

  if (!IS_PROD) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.use((req, res, next) => {
      if (req.method !== 'GET' || req.path.startsWith('/api/')) {
        next();
        return;
      }
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Innova Grup POS server listening on http://localhost:${PORT}`);
  });
  // Align Node HTTP keep-alive above Cloud Run proxy timeout (60s) to prevent 502/connection-reset drops
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 66_000;
}

startServer();
