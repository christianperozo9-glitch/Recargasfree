export function round2(n: number): number {
  return Math.round(((Number(n) || 0) + Number.EPSILON) * 100) / 100;
}

export function formatMoney(n: number, decimals = 2): string {
  return (Number(n) || 0).toLocaleString('es-VE', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatDateVE(d: Date = new Date()): string {
  return d.toLocaleDateString('es-VE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
}

export function avatarHue(name: string): number {
  let h = 0;
  const s = String(name || '?');
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) % 360;
  }
  return h;
}

export function initialsOf(name: string): string {
  const parts = String(name || '?').trim().split(/\s+/).filter(Boolean);
  const a = parts[0] ? parts[0][0] : '?';
  const b = parts[1] ? parts[1][0] : '';
  return (a + b).toUpperCase();
}

const avatarCache = new Map<string, string>();
export function avatarDataUrl(name: string): string {
  const cached = avatarCache.get(name);
  if (cached) return cached;
  const canvas = document.createElement('canvas');
  canvas.width = 96;
  canvas.height = 96;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  const h = avatarHue(name);
  const grad = ctx.createLinearGradient(0, 0, 96, 96);
  grad.addColorStop(0, `hsl(${h}, 70%, 42%)`);
  grad.addColorStop(1, `hsl(${(h + 40) % 360}, 75%, 58%)`);
  ctx.fillStyle = grad;
  ctx.beginPath();
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(0, 0, 96, 96, 18);
  } else {
    ctx.rect(0, 0, 96, 96);
  }
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 40px Helvetica, Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(initialsOf(name), 48, 52);
  const url = canvas.toDataURL('image/png');
  avatarCache.set(name, url);
  return url;
}

export function compressImageFile(file: File, maxDim = 640, maxBytes = 160_000): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('No se pudo leer la imagen'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Archivo de imagen inválido'));
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas no disponible'));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        let quality = 0.78;
        let output = canvas.toDataURL('image/jpeg', quality);
        while (output.length > maxBytes && quality > 0.3) {
          quality -= 0.1;
          output = canvas.toDataURL('image/jpeg', quality);
        }
        resolve(output);
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  });
}

// Safe recursive-descent math expression evaluator (replaces unsafe eval)
export function evaluateMathExpression(expr: string): string {
  const sanitized = expr.replace(/\s+/g, '');
  if (!sanitized || !/^[0-9+\-*/().]+$/.test(sanitized)) return 'Error';
  let pos = 0;

  function parseExpression(): number {
    let val = parseTerm();
    while (pos < sanitized.length && (sanitized[pos] === '+' || sanitized[pos] === '-')) {
      const op = sanitized[pos++];
      const right = parseTerm();
      val = op === '+' ? val + right : val - right;
    }
    return val;
  }

  function parseTerm(): number {
    let val = parseFactor();
    while (pos < sanitized.length && (sanitized[pos] === '*' || sanitized[pos] === '/')) {
      const op = sanitized[pos++];
      const right = parseFactor();
      if (op === '/' && right === 0) throw new Error('División entre cero');
      val = op === '*' ? val * right : val / right;
    }
    return val;
  }

  function parseFactor(): number {
    if (sanitized[pos] === '-') {
      pos++;
      return -parseFactor();
    }
    if (sanitized[pos] === '+') {
      pos++;
      return parseFactor();
    }
    if (sanitized[pos] === '(') {
      pos++;
      const val = parseExpression();
      if (sanitized[pos] !== ')') throw new Error('Paréntesis sin cerrar');
      pos++;
      return val;
    }
    const start = pos;
    while (pos < sanitized.length && /[0-9.]/.test(sanitized[pos])) {
      pos++;
    }
    if (start === pos) throw new Error('Token inválido');
    const num = Number(sanitized.slice(start, pos));
    if (!Number.isFinite(num)) throw new Error('Número inválido');
    return num;
  }

  try {
    const result = parseExpression();
    if (pos !== sanitized.length || !Number.isFinite(result)) return 'Error';
    return String(Math.round((result + Number.EPSILON) * 1_000_000) / 1_000_000);
  } catch {
    return 'Error';
  }
}

export function downloadCSV(filename: string, headers: string[], rows: Array<Array<string | number>>): void {
  const quote = (v: string | number) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = [headers.map(quote).join(',')];
  rows.forEach((row) => lines.push(row.map(quote).join(',')));
  const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(a.href);
    a.remove();
  }, 1000);
}
