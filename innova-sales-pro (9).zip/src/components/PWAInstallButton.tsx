import React, { useState } from 'react';
import { Download, Share, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false, className = '' }) => {
  const { canInstall, isIOS, isInstalled, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled || (!canInstall && !isIOS)) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => {
          if (canInstall) {
            void install();
          } else if (isIOS) {
            setShowIOSGuide(true);
          }
        }}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200/80 text-sky-700 text-xs font-semibold cursor-pointer btn-press whitespace-nowrap shrink-0 ${className}`}
        title="Instalar Innova Grup POS como aplicación en Android / Escritorio"
      >
        {isIOS ? <Share className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
        {!compact && <span>Instalar App</span>}
      </button>

      {showIOSGuide && (
        <div
          className="fixed inset-0 z-[210] bg-slate-900/30 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowIOSGuide(false)}
        >
          <div
            className="bg-white rounded-2xl border border-slate-200 max-w-sm w-full p-5 space-y-3 shadow-2xl text-xs"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Smartphone className="w-4 h-4 text-sky-600" /> Instalar en iPhone / iPad
              </div>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-600">
              <li>Toca el botón <b>Compartir</b> en la barra inferior de Safari.</li>
              <li>Selecciona <b>Añadir a pantalla de inicio</b>.</li>
              <li>Toca <b>Añadir</b> para abrir Innova Grup POS a pantalla completa y recibir notificaciones.</li>
            </ol>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold cursor-pointer"
            >
              Entendido
            </button>
          </div>
        </div>
      )}
    </>
  );
};
