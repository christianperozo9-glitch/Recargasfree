import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import type { MultiFactorResolver, User } from 'firebase/auth';
import {
  KeyRound,
  Lock,
  Mail,
  ShieldCheck,
  Store,
  UserCog,
  Crown,
  Eye,
  EyeOff,
  ArrowLeft,
  CheckCircle2,
  RotateCw,
  LogOut,
  Building2,
  Upload,
  Clock,
  Sparkles,
  FileText,
  XCircle,
  AlertTriangle,
  ShieldAlert,
  Printer,
  Coins,
  ArrowRight,
  MessageSquare,
  ChevronDown,
  LogIn,
} from 'lucide-react';
import {
  db,
  extractMfaResolver,
  FIREBASE_PROJECT_ID,
  handleFirestoreError,
  loginWithEmail,
  loginWithGoogle,
  logoutFirebase,
  MASTER_OWNER_EMAIL,
  OperationType,
  resolveTotpMfaSignIn,
  sendPasswordRecoveryEmail,
} from '../lib/firebase';
import { usePos } from '../context/PosContext';
import { InnovaLogo } from './InnovaLogo';
import { InnovaAvatarAssistant } from './InnovaAvatarAssistant';
import { compressImageFile } from '../utils/format';
import type { PreRegistrationRecord, TenantRecord, UserRole } from '../types/pos';
import innovaAvatarImg from '../assets/images/innova_assistant_avatar_1795489643576.jpg';

type GateRole = Exclude<UserRole, ''>;

const PLATFORM_HIGHLIGHTS = [
  {
    icon: Coins,
    title: 'Multimoneda y Pagos Ágiles',
    desc: 'Cobros sincronizados en USD y Bolívares con soporte para Pago Móvil, Cashea, pago mixto y control de fiados.',
    accent: 'text-emerald-600 bg-emerald-50 border-emerald-200/80',
  },
  {
    icon: Printer,
    title: 'Impresión Térmica 58/80mm',
    desc: 'Comprobantes personalizados con logotipo de tu negocio, formato configurable y copia en PDF A4.',
    accent: 'text-sky-600 bg-sky-50 border-sky-200/80',
  },
  {
    icon: ShieldCheck,
    title: 'Control por Roles y PIN',
    desc: 'Sesiones independientes para Cajero y Administrador con protección por PIN, inventario y cierre de caja.',
    accent: 'text-amber-600 bg-amber-50 border-amber-200/80',
  },
];

export const AuthPortal: React.FC = () => {
  const {
    authUser,
    localName,
    activeTenantId,
    setActiveTenantId,
    ensurePlatformDefaults,
    loginCashierWithPin,
    setSessionRole,
    registerSystemUserSession,
    playBeep,
    notifyToast,
  } = usePos();

  const [selectedRole, setSelectedRole] = useState<GateRole>('cashier');
  const [email, setEmail] = useState(authUser?.email || '');
  const [secret, setSecret] = useState('');
  const [terminalPassword, setTerminalPassword] = useState('');
  const [showSecret, setShowSecret] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [avatarBroken, setAvatarBroken] = useState(false);

  // Password recovery state
  const [recoveryMode, setRecoveryMode] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoverySent, setRecoverySent] = useState(false);

  // Pre-registration (new business signup) state
  const [preRegMode, setPreRegMode] = useState(false);
  const [preRegSent, setPreRegSent] = useState(false);
  const [myPreRegs, setMyPreRegs] = useState<PreRegistrationRecord[]>([]);
  const [preForm, setPreForm] = useState({
    nombre_comercial: '',
    razon_social: '',
    rif: '',
    direccion_fiscal: '',
    telefono: '',
    representante_legal: '',
    cedula_representante: '',
    rubro: 'Comercio General / Minimarket',
    registro_mercantil: '',
    notas: '',
    foto_rif: '',
  });
  const [uploadingRif, setUploadingRif] = useState(false);

  // MFA challenge state
  const [mfaResolver, setMfaResolver] = useState<MultiFactorResolver | null>(null);
  const [mfaCode, setMfaCode] = useState('');
  const [mfaRoleTarget, setMfaRoleTarget] = useState<'admin' | 'owner'>('admin');

  // Listen to applicant's own pre-registrations when signed in on the Pre-Registro screen
  useEffect(() => {
    if (!preRegMode || !authUser?.uid) {
      setMyPreRegs([]);
      return;
    }
    const q = query(
      collection(db, 'platform_preregistrations'),
      where('applicantUid', '==', authUser.uid)
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: PreRegistrationRecord[] = snap.docs
          .map((d) => ({ ...(d.data() as PreRegistrationRecord), id: d.id }))
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setMyPreRegs(list);
      },
      () => {
        // ignore if no permissions yet
      }
    );
    return () => unsub();
  }, [preRegMode, authUser?.uid]);

  const [ownerWarningOpen, setOwnerWarningOpen] = useState(false);

  const applyRoleSwitch = (role: GateRole) => {
    setSelectedRole(role);
    setSecret('');
    setTerminalPassword('');
    setErrorMsg('');
    setRecoveryMode(false);
    setPreRegMode(false);
    setMfaResolver(null);
  };

  const handleRoleSwitch = (role: GateRole) => {
    if (role === 'owner' && selectedRole !== 'owner') {
      setOwnerWarningOpen(true);
      return;
    }
    applyRoleSwitch(role);
  };

  const resolveTenantForUser = async (
    userObj: User,
    targetEmail: string
  ): Promise<{ id: string; data: TenantRecord } | null> => {
    const cleanEmail = targetEmail.trim().toLowerCase();
    try {
      const byUid = await getDocs(
        query(collection(db, 'tenants'), where('ownerUid', '==', userObj.uid))
      );
      if (!byUid.empty) {
        const d = byUid.docs[0];
        return { id: d.id, data: { ...(d.data() as TenantRecord), id: d.id } };
      }

      if (cleanEmail) {
        const byEmail = await getDocs(
          query(collection(db, 'tenants'), where('email', '==', cleanEmail))
        );
        if (!byEmail.empty) {
          const d = byEmail.docs[0];
          const data = { ...(d.data() as TenantRecord), id: d.id };
          if (String(data.ownerUid || '').startsWith('pending_') && userObj.emailVerified) {
            await updateDoc(doc(db, 'tenants', d.id), {
              ownerUid: userObj.uid,
              ultimo_acceso: Date.now(),
              updatedAt: Date.now(),
            });
            data.ownerUid = userObj.uid;
          }
          return { id: d.id, data };
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'tenants');
    }
    return null;
  };

  const completeFirebaseSignIn = async (
    userEmail: string,
    targetRole: 'admin' | 'owner',
    userObj: User
  ) => {
    const cleanEmail = userEmail.trim().toLowerCase();

    if (targetRole === 'owner') {
      const isMaster = cleanEmail === MASTER_OWNER_EMAIL.toLowerCase();

      if (!isMaster) {
        await logoutFirebase();
        setErrorMsg(
          `Acceso denegado: la cuenta (${cleanEmail}) no está autorizada para el Panel del Propietario.`
        );
        playBeep('err');
        return;
      }

      let isAdminDoc = false;
      try {
        const adminSnap = await getDoc(doc(db, 'admins', userObj.uid));
        isAdminDoc = adminSnap.exists();
      } catch {
        isAdminDoc = false;
      }

      if (!isAdminDoc) {
        try {
          await setDoc(
            doc(db, 'admins', userObj.uid),
            {
              uid: userObj.uid,
              email: cleanEmail,
              role: 'owner',
              createdAt: Date.now(),
            },
            { merge: true }
          );
        } catch {
          // Will rely on email_verified token rule or prompt verification if needed
        }
      }

      await ensurePlatformDefaults().catch(() => {});

      const matchedTenant = await resolveTenantForUser(userObj, cleanEmail);
      if (matchedTenant) {
        setActiveTenantId(matchedTenant.id);
        await registerSystemUserSession(userObj, 'owner', matchedTenant.id);
      }

      setSessionRole('owner', userObj.displayName || 'Propietario', cleanEmail);
      playBeep('ok');
      notifyToast('Bienvenido al Panel Maestro del Propietario.', 'success');
      return;
    }

    // Admin login: locate client's isolated tenant node
    const tenantMatch = await resolveTenantForUser(userObj, cleanEmail);
    if (!tenantMatch) {
      await logoutFirebase();
      setErrorMsg(
        'Este correo no tiene un comercio registrado todavía. Puedes completar el Pre-Registro de negocio aquí abajo.'
      );
      playBeep('err');
      return;
    }

    const { id: tenantId, data: tenantData } = tenantMatch;
    if (tenantData.activo === false) {
      await logoutFirebase();
      setErrorMsg('Esta cuenta comercial está desactivada por administración.');
      playBeep('err');
      return;
    }

    setActiveTenantId(tenantId);

    try {
      await updateDoc(doc(db, 'tenants', tenantId), {
        ultimo_acceso: Date.now(),
        updatedAt: Date.now(),
      });
    } catch {
      // ignore non-critical timestamp error
    }

    try {
      const settingsRef = doc(db, 'tenants', tenantId, 'settings', 'config');
      const cajaSnap = await getDoc(settingsRef);
      if (!cajaSnap.exists() || cajaSnap.data()?.caja_abierta !== true) {
        const now = new Date();
        const ts = now.getTime();
        await setDoc(settingsRef, { caja_abierta: true, updatedAt: ts }, { merge: true });
        await setDoc(doc(db, 'tenants', tenantId, 'cash_openings', String(ts)), {
          tipo: 'APERTURA DE CAJA',
          usuario: cleanEmail,
          fecha: now.toLocaleDateString('es-VE'),
          hora: now.toLocaleTimeString('es-VE'),
          timestamp: ts,
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tenants/${tenantId}/settings/config`);
    }

    await registerSystemUserSession(userObj, 'admin', tenantId);
    setSessionRole(
      'admin',
      userObj.displayName || tenantData.nombre_local || 'Administrador',
      cleanEmail
    );
    playBeep('ok');
    notifyToast(`Sesión iniciada en ${tenantData.nombre_local}.`, 'success');
  };

  const mapAuthError = (err: unknown): string => {
    const fbErr = err as { code?: string; message?: string };
    if (fbErr.code === 'auth/invalid-credential' || fbErr.code === 'auth/wrong-password') {
      return 'Correo o contraseña incorrectos.';
    }
    if (fbErr.code === 'auth/user-not-found') {
      return 'No existe una cuenta registrada con ese correo.';
    }
    if (fbErr.code === 'auth/too-many-requests') {
      return 'Demasiados intentos. Intenta más tarde o recupera tu contraseña.';
    }
    if (fbErr.code === 'auth/operation-not-allowed') {
      return `El inicio con Correo/Contraseña aún no está habilitado en Firebase Console (${FIREBASE_PROJECT_ID} -> Authentication -> Sign-in method). Puedes usar "Continuar con Google" o habilitar Correo/Contraseña.`;
    }
    if (fbErr.code === 'auth/popup-closed-by-user') {
      return 'Ventana de Google cerrada antes de completar el acceso.';
    }
    return fbErr.message || 'No se pudo iniciar sesión.';
  };

  const handleGoogleAccess = async () => {
    setErrorMsg('');
    setLoading(true);
    try {
      const user = await loginWithGoogle();
      const userEmail = (user.email || '').toLowerCase();
      setEmail(userEmail);

      if (selectedRole === 'cashier') {
        const tenantMatch = await resolveTenantForUser(user, userEmail);
        if (tenantMatch) {
          setActiveTenantId(tenantMatch.id);
          notifyToast(
            `Terminal vinculada a "${tenantMatch.data.nombre_local}". Ahora ingresa tu PIN de cajero.`,
            'success'
          );
        } else {
          notifyToast(
            'Sesión Google vinculada. Si tienes PIN de cajero, ingrésalo ahora.',
            'info'
          );
        }
        return;
      }

      const targetRole = selectedRole === 'owner' ? 'owner' : 'admin';
      if (targetRole === 'owner' && userEmail !== MASTER_OWNER_EMAIL.toLowerCase()) {
        await logoutFirebase();
        setErrorMsg(
          `Acceso denegado: la cuenta (${userEmail}) no tiene permiso para ingresar al Panel del Propietario.`
        );
        playBeep('err');
        return;
      }
      await completeFirebaseSignIn(userEmail, targetRole, user);
    } catch (err) {
      const resolver = extractMfaResolver(err);
      if (resolver) {
        setMfaResolver(resolver);
        setMfaRoleTarget(selectedRole === 'owner' ? 'owner' : 'admin');
        setMfaCode('');
        notifyToast('Se requiere verificación de segundo factor (MFA).', 'info');
      } else {
        setErrorMsg(mapAuthError(err));
        playBeep('err');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const cleanEmail = (email || authUser?.email || '').trim().toLowerCase();

    if (!cleanEmail || !secret) {
      setErrorMsg(
        selectedRole === 'cashier'
          ? 'Ingresa el correo del comercio y el PIN del cajero.'
          : 'Ingresa tu correo y contraseña registrados.'
      );
      return;
    }

    setLoading(true);
    try {
      if (selectedRole === 'cashier') {
        let resolvedTid = activeTenantId || undefined;
        if (!authUser) {
          if (!terminalPassword) {
            setErrorMsg(
              'Para vincular esta terminal por primera vez, ingresa la contraseña del comercio o usa Google.'
            );
            setLoading(false);
            return;
          }
          const user = await loginWithEmail(cleanEmail, terminalPassword);
          const match = await resolveTenantForUser(user, cleanEmail);
          if (match) {
            resolvedTid = match.id;
            setActiveTenantId(match.id);
          }
        }
        const res = await loginCashierWithPin(cleanEmail, secret, resolvedTid);
        if (!res.ok) {
          setErrorMsg(res.error || 'Credenciales inválidas.');
        } else {
          notifyToast('Terminal operativo inicializado.', 'success');
        }
        return;
      }

      const targetRole = selectedRole === 'owner' ? 'owner' : 'admin';
      if (targetRole === 'owner' && cleanEmail !== MASTER_OWNER_EMAIL.toLowerCase()) {
        setErrorMsg(
          `Acceso denegado: solo el correo autorizado del Propietario puede acceder a este panel.`
        );
        playBeep('err');
        return;
      }
      const user = await loginWithEmail(cleanEmail, secret);
      await completeFirebaseSignIn(cleanEmail, targetRole, user);
    } catch (err) {
      const resolver = extractMfaResolver(err);
      if (resolver) {
        setMfaResolver(resolver);
        setMfaRoleTarget(selectedRole === 'owner' ? 'owner' : 'admin');
        setMfaCode('');
        setErrorMsg('');
        notifyToast('Se requiere verificación de segundo factor (MFA).', 'info');
      } else {
        setErrorMsg(mapAuthError(err));
        playBeep('err');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleMfaVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mfaResolver) return;
    const totpHint = mfaResolver.hints.find((h) => h.factorId === 'totp') || mfaResolver.hints[0];
    if (!totpHint) {
      setErrorMsg('No se encontró un factor TOTP compatible en tu cuenta.');
      return;
    }
    if (!/^\d{6}$/.test(mfaCode.trim())) {
      setErrorMsg('Ingresa el código de 6 dígitos de tu app autenticadora.');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    try {
      const user = await resolveTotpMfaSignIn(mfaResolver, totpHint.uid, mfaCode.trim());
      setMfaResolver(null);
      await completeFirebaseSignIn((user.email || email).toLowerCase(), mfaRoleTarget, user);
    } catch {
      setErrorMsg('Código MFA inválido o expirado. Inténtalo nuevamente.');
      playBeep('err');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = (recoveryEmail || email).trim();
    if (!target || !target.includes('@')) {
      setErrorMsg('Ingresa un correo electrónico válido para recuperar la contraseña.');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    try {
      await sendPasswordRecoveryEmail(target);
      setRecoverySent(true);
      playBeep('ok');
      notifyToast('Correo de recuperación enviado a ' + target, 'success');
    } catch (err) {
      setErrorMsg(mapAuthError(err));
      playBeep('err');
    } finally {
      setLoading(false);
    }
  };

  const handleRifFileUpload = async (file: File) => {
    setUploadingRif(true);
    try {
      const dataUrl = await compressImageFile(file, 900, 0.78);
      setPreForm((prev) => ({ ...prev, foto_rif: dataUrl }));
      notifyToast('Imagen del RIF adjuntada correctamente.', 'success');
    } catch (err) {
      notifyToast(
        err instanceof Error ? err.message : 'No se pudo procesar la foto del RIF.',
        'error'
      );
    } finally {
      setUploadingRif(false);
    }
  };

  const handlePreRegSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const nombreComercial = preForm.nombre_comercial.trim();
    const razonSocial = preForm.razon_social.trim() || nombreComercial;
    const rif = preForm.rif.trim().toUpperCase();
    const direccion = preForm.direccion_fiscal.trim();
    const telefono = preForm.telefono.trim();
    const repLegal = preForm.representante_legal.trim();
    const cedulaRep = preForm.cedula_representante.trim().toUpperCase();

    if (!nombreComercial || !rif || !direccion || !telefono || !repLegal || !cedulaRep) {
      setErrorMsg(
        'Completa todos los campos obligatorios: Nombre Comercial, RIF, Dirección Fiscal, WhatsApp, Representante Legal y Cédula.'
      );
      return;
    }

    setLoading(true);
    try {
      let currentUser = authUser;
      if (!currentUser || !currentUser.emailVerified) {
        currentUser = await loginWithGoogle();
      }
      const verifiedEmail = (currentUser.email || '').trim().toLowerCase();
      if (!verifiedEmail) {
        setErrorMsg('No se pudo obtener un correo verificado de tu cuenta Google.');
        return;
      }

      const now = Date.now();
      const reqId = `pre_${now}_${currentUser.uid.slice(0, 6)}`;
      const payload: Omit<PreRegistrationRecord, 'id'> = {
        applicantUid: currentUser.uid,
        email: verifiedEmail,
        nombre_local: nombreComercial,
        razon_social: razonSocial,
        rif,
        direccion_fiscal: direccion,
        telefono,
        contacto_nombre: repLegal,
        cedula_representante: cedulaRep,
        rubro: preForm.rubro.trim() || 'Comercio General',
        registro_mercantil: preForm.registro_mercantil.trim(),
        notas: preForm.notas.trim(),
        foto_rif: preForm.foto_rif || '',
        estado: 'pendiente',
        createdAt: now,
      };

      await setDoc(doc(db, 'platform_preregistrations', reqId), payload);
      setPreRegSent(true);
      setPreForm({
        nombre_comercial: '',
        razon_social: '',
        rif: '',
        direccion_fiscal: '',
        telefono: '',
        representante_legal: '',
        cedula_representante: '',
        rubro: 'Comercio General / Minimarket',
        registro_mercantil: '',
        notas: '',
        foto_rif: '',
      });
      playBeep('ok');
      notifyToast(
        '¡Pre-registro enviado con éxito! El propietario revisará tu negocio y te enviará tus credenciales con 5 días de regalo.',
        'success'
      );
    } catch (err) {
      setErrorMsg(mapAuthError(err));
      playBeep('err');
    } finally {
      setLoading(false);
    }
  };

  const activeViewKey = preRegMode
    ? 'prereg'
    : mfaResolver
    ? 'mfa'
    : recoveryMode
    ? 'recovery'
    : 'login';

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-gradient-to-b from-[#f4f9ff] via-white to-[#eef6ff] text-slate-900 relative">
      {/* Subtle Animated Ambient Background Orbs (compositor-only transforms) */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden z-0" aria-hidden="true">
        <motion.div
          animate={{ x: [0, 28, 0], y: [0, 18, 0] }}
          transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-32 -left-24 w-[520px] h-[520px] rounded-full bg-sky-200/45 blur-3xl"
        />
        <motion.div
          animate={{ x: [0, -24, 0], y: [0, -20, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-1/3 -right-28 w-[480px] h-[480px] rounded-full bg-cyan-200/35 blur-3xl"
        />
        <motion.div
          animate={{ x: [0, 18, 0], y: [0, -16, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -bottom-36 left-1/3 w-[440px] h-[440px] rounded-full bg-emerald-100/40 blur-3xl"
        />
      </div>

      {/* Sticky Top Navigation Bar with Quick Login & Pre-Registro Buttons */}
      <header className="sticky top-0 z-30 w-full border-b border-slate-200/80 bg-white/85 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10 h-16 sm:h-20 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="p-1.5 rounded-xl bg-sky-50 border border-sky-100 shrink-0"
            >
              <InnovaLogo size={34} />
            </motion.div>
            <div className="min-w-0">
              <div className="text-sm sm:text-base font-extrabold tracking-tight text-slate-900 truncate">
                Innova Grup POS
              </div>
              <div className="text-[11px] font-semibold text-slate-500 truncate hidden md:block">
                {localName || 'Plataforma Comercial Inteligente'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Quick Access: Iniciar Sesión */}
            <button
              type="button"
              onClick={() => {
                setPreRegMode(false);
                setPreRegSent(false);
                setRecoveryMode(false);
                setMfaResolver(null);
                setErrorMsg('');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition cursor-pointer ${
                !preRegMode
                  ? 'bg-sky-600 hover:bg-sky-700 text-white shadow-xs'
                  : 'bg-white hover:bg-sky-50 text-slate-700 border border-slate-200'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Iniciar Sesión</span>
              <span className="sm:hidden">Entrar</span>
            </button>

            {/* Quick Access: Registro / Pre-Registro */}
            <button
              type="button"
              onClick={() => {
                setPreRegMode(true);
                setPreRegSent(false);
                setRecoveryMode(false);
                setMfaResolver(null);
                setErrorMsg('');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition cursor-pointer ${
                preRegMode
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Pre-Registro</span>
              <span className="sm:hidden">Registro</span>
            </button>

            <button
              type="button"
              onClick={() => setAssistantOpen(true)}
              title="Abrir Asistente Virtual Innova Grup"
              className="px-2.5 sm:px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition cursor-pointer shadow-xs"
            >
              <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden lg:inline">Asesor IA</span>
            </button>

            <button
              type="button"
              onClick={() => window.location.reload()}
              title="Recargar página"
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-white hover:bg-sky-50 border border-slate-200 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5 text-sky-600" />
              <span className="hidden xl:inline">Recargar</span>
            </button>
          </div>
        </div>
      </header>

      {/* Primary Full-Screen Animated Login Centerpiece */}
      <main className="relative z-10 w-full">
        <section className="min-h-[calc(100vh-5rem)] max-w-5xl mx-auto px-4 sm:px-8 py-8 sm:py-12 flex flex-col items-center justify-center">
          {/* Animated Brand Header Above Main Login Interface */}
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="text-center mb-7 sm:mb-9 max-w-2xl"
          >
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 4.2, repeat: Infinity, ease: 'easeInOut' }}
              className="inline-flex p-3.5 rounded-3xl bg-white border border-sky-100 shadow-md mb-4"
            >
              <InnovaLogo size={62} />
            </motion.div>
            <p className="text-xs font-extrabold tracking-[0.26em] text-sky-600 uppercase">
              Innova Grup POS
            </p>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-950 mt-2 leading-[1.1] text-balance">
              {preRegMode
                ? 'Pre-Registro de Nuevo Negocio'
                : mfaResolver
                ? 'Verificación Multifactor (2FA)'
                : recoveryMode
                ? 'Restablecer Contraseña'
                : localName || 'Iniciar Sesión'}
            </h1>
            <p className="text-sm sm:text-base text-slate-500 mt-2.5 leading-relaxed">
              {mfaResolver
                ? 'Ingresa el código temporal de 6 dígitos generado por tu aplicación autenticadora.'
                : recoveryMode
                ? 'Te enviaremos un enlace seguro a tu correo electrónico registrado.'
                : preRegMode
                ? 'Registra los datos de tu comercio y recibe tus accesos con 5 días gratis al aprobarse.'
                : 'Selecciona tu perfil e ingresa tus credenciales para abrir tu punto de venta.'}
            </p>
          </motion.div>

          {/* Main Large Animated Login / Access Card */}
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.55, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className={`w-full ${
              preRegMode ? 'max-w-3xl' : 'max-w-xl'
            } bg-white/95 backdrop-blur-xl rounded-3xl border border-slate-200/90 shadow-[0_28px_80px_-28px_rgba(14,116,144,0.22)] overflow-hidden transition-all`}
          >
            <div className="h-2 bg-gradient-to-r from-sky-500 via-cyan-400 to-emerald-500" />

            <div className="p-6 sm:p-10">
                {authUser && selectedRole === 'cashier' && !preRegMode && (
                  <div className="mb-6 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs sm:text-sm text-emerald-950 flex flex-wrap items-center justify-between gap-2">
                    <span className="truncate">
                      Terminal vinculada: <b>{authUser.email}</b>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        void logoutFirebase();
                        setActiveTenantId(null);
                      }}
                      className="text-rose-700 font-bold inline-flex items-center gap-1 shrink-0 cursor-pointer hover:underline"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Desvincular
                    </button>
                  </div>
                )}

                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeViewKey}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.22 }}
                  >
                    {/* Pre-Registration Business Signup Form */}
                    {preRegMode ? (
                      <div className="space-y-5">
                        {/* Applicant verified email badge */}
                        <div className="p-4 rounded-2xl bg-sky-50/90 border border-sky-200 flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
                          {authUser?.email ? (
                            <div className="flex items-center gap-2 text-sky-950 font-semibold min-w-0">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span className="truncate">
                                Correo verificado: <b>{authUser.email}</b>
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 text-sky-900">
                              <ShieldCheck className="w-4 h-4 text-sky-600 shrink-0" />
                              <span>
                                Al enviar, validaremos tu correo con Google para proteger tu
                                solicitud.
                              </span>
                            </div>
                          )}
                          {!authUser?.email && (
                            <button
                              type="button"
                              disabled={loading}
                              onClick={async () => {
                                setLoading(true);
                                try {
                                  await loginWithGoogle();
                                } catch (err) {
                                  setErrorMsg(mapAuthError(err));
                                } finally {
                                  setLoading(false);
                                }
                              }}
                              className="px-3.5 py-2 rounded-xl bg-white border border-sky-200 hover:bg-sky-100 text-sky-800 font-bold text-xs cursor-pointer"
                            >
                              Verificar con Google ahora
                            </button>
                          )}
                        </div>

                        {/* Existing pre-registrations status for this applicant */}
                        {myPreRegs.length > 0 && (
                          <div className="space-y-2.5">
                            <p className="text-xs font-extrabold text-slate-600 uppercase tracking-wide">
                              Estado de tus Solicitudes
                            </p>
                            {myPreRegs.map((pr) => (
                              <div
                                key={pr.id}
                                className={`p-3.5 rounded-2xl border text-xs sm:text-sm flex flex-wrap items-center justify-between gap-2 ${
                                  pr.estado === 'aprobado'
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                                    : pr.estado === 'rechazado'
                                    ? 'bg-rose-50 border-rose-200 text-rose-950'
                                    : 'bg-amber-50 border-amber-200 text-amber-950'
                                }`}
                              >
                                <div className="min-w-0">
                                  <p className="font-extrabold truncate">
                                    {pr.nombre_local} · RIF {pr.rif}
                                  </p>
                                  <p className="text-xs opacity-85 mt-0.5">
                                    {pr.estado === 'aprobado'
                                      ? '¡Aprobado! Revisa tu WhatsApp o inicia sesión como Administrador.'
                                      : pr.estado === 'rechazado'
                                      ? `Rechazado${pr.nota_propietario ? `: ${pr.nota_propietario}` : ''}`
                                      : 'En revisión por el propietario. Recibirás tus accesos por WhatsApp.'}
                                  </p>
                                </div>
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/90 font-bold text-xs shrink-0">
                                  {pr.estado === 'aprobado' ? (
                                    <>
                                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />{' '}
                                      Aprobado
                                    </>
                                  ) : pr.estado === 'rechazado' ? (
                                    <>
                                      <XCircle className="w-3.5 h-3.5 text-rose-600" /> Rechazado
                                    </>
                                  ) : (
                                    <>
                                      <Clock className="w-3.5 h-3.5 text-amber-600" /> Pendiente
                                    </>
                                  )}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}

                        {preRegSent ? (
                          <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-3">
                            <Sparkles className="w-10 h-10 text-emerald-600 mx-auto" />
                            <h3 className="text-lg font-extrabold text-emerald-950">
                              ¡Pre-Registro Enviado Correctamente!
                            </h3>
                            <p className="text-sm text-emerald-900 leading-relaxed max-w-md mx-auto">
                              El propietario de <b>Innova Grup POS</b> revisará tus datos fiscales y
                              legales. Al aprobar tu negocio, recibirás un mensaje automático por{' '}
                              <b>WhatsApp</b> con tu correo, contraseña, PINes de acceso y{' '}
                              <b>5 días gratis de bienvenida</b>.
                            </p>
                            <button
                              type="button"
                              onClick={() => {
                                setPreRegSent(false);
                                setPreRegMode(false);
                              }}
                              className="mt-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold cursor-pointer"
                            >
                              Volver al Inicio de Sesión
                            </button>
                          </div>
                        ) : (
                          <form onSubmit={handlePreRegSubmit} className="space-y-4 text-sm">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Nombre Comercial del Negocio *
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={preForm.nombre_comercial}
                                  onChange={(e) =>
                                    setPreForm((p) => ({ ...p, nombre_comercial: e.target.value }))
                                  }
                                  placeholder="Ej: Inversiones El Sol"
                                  maxLength={120}
                                  className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>

                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Razón Social (Fiscal SENIAT) *
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={preForm.razon_social}
                                  onChange={(e) =>
                                    setPreForm((p) => ({ ...p, razon_social: e.target.value }))
                                  }
                                  placeholder="Ej: Inversiones El Sol C.A."
                                  maxLength={150}
                                  className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>

                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  RIF Fiscal (SENIAT) *
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={preForm.rif}
                                  onChange={(e) =>
                                    setPreForm((p) => ({ ...p, rif: e.target.value }))
                                  }
                                  placeholder="J-12345678-9 ó V-12345678-0"
                                  maxLength={35}
                                  className="w-full px-3.5 py-3 font-mono uppercase bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>

                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Teléfono WhatsApp (para enviar accesos) *
                                </label>
                                <input
                                  type="tel"
                                  required
                                  value={preForm.telefono}
                                  onChange={(e) =>
                                    setPreForm((p) => ({ ...p, telefono: e.target.value }))
                                  }
                                  placeholder="Ej: +58 412 1234567"
                                  maxLength={40}
                                  className="w-full px-3.5 py-3 font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>

                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Representante Legal / Dueño *
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={preForm.representante_legal}
                                  onChange={(e) =>
                                    setPreForm((p) => ({
                                      ...p,
                                      representante_legal: e.target.value,
                                    }))
                                  }
                                  placeholder="Nombre y Apellido"
                                  maxLength={120}
                                  className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>

                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Cédula del Representante *
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={preForm.cedula_representante}
                                  onChange={(e) =>
                                    setPreForm((p) => ({
                                      ...p,
                                      cedula_representante: e.target.value,
                                    }))
                                  }
                                  placeholder="V-20123456"
                                  maxLength={30}
                                  className="w-full px-3.5 py-3 font-mono uppercase bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                Domicilio Fiscal Completo *
                              </label>
                              <input
                                type="text"
                                required
                                value={preForm.direccion_fiscal}
                                onChange={(e) =>
                                  setPreForm((p) => ({ ...p, direccion_fiscal: e.target.value }))
                                }
                                placeholder="Av., Calle, Edificio/Local, Ciudad, Estado"
                                maxLength={250}
                                className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                              />
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Rubro / Actividad Comercial
                                </label>
                                <input
                                  type="text"
                                  value={preForm.rubro}
                                  onChange={(e) =>
                                    setPreForm((p) => ({ ...p, rubro: e.target.value }))
                                  }
                                  placeholder="Ej: Ferretería, Repuestos, Minimarket..."
                                  maxLength={100}
                                  className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>

                              <div>
                                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                  Datos de Registro Mercantil (Tomo / N°)
                                </label>
                                <input
                                  type="text"
                                  value={preForm.registro_mercantil}
                                  onChange={(e) =>
                                    setPreForm((p) => ({
                                      ...p,
                                      registro_mercantil: e.target.value,
                                    }))
                                  }
                                  placeholder="Ej: Reg. Mercantil I, Tomo 12-A, N° 45"
                                  maxLength={220}
                                  className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>
                            </div>

                            {/* Optional RIF photo upload */}
                            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                              <div className="flex items-center gap-3 min-w-0">
                                <FileText className="w-5 h-5 text-sky-600 shrink-0" />
                                <div className="min-w-0">
                                  <p className="text-xs font-bold text-slate-800">
                                    Foto del RIF o Documento Legal (Opcional)
                                  </p>
                                  <p className="text-[11px] text-slate-500">
                                    Acelera la aprobación y validación fiscal de tu comercio
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {preForm.foto_rif && (
                                  <img
                                    src={preForm.foto_rif}
                                    alt="RIF"
                                    className="w-11 h-11 rounded-lg object-cover border border-slate-200"
                                  />
                                )}
                                <label className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:bg-sky-50 text-slate-700 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer">
                                  <Upload className="w-3.5 h-3.5" />
                                  {uploadingRif
                                    ? 'Subiendo...'
                                    : preForm.foto_rif
                                    ? 'Cambiar Foto'
                                    : 'Adjuntar RIF'}
                                  <input
                                    type="file"
                                    accept="image/*"
                                    disabled={uploadingRif}
                                    onChange={(e) => {
                                      const f = e.target.files?.[0];
                                      if (f) void handleRifFileUpload(f);
                                      e.target.value = '';
                                    }}
                                    className="hidden"
                                  />
                                </label>
                              </div>
                            </div>

                            <div>
                              <label className="text-xs font-bold text-slate-700 block mb-1.5">
                                Notas adicionales (opcional)
                              </label>
                              <textarea
                                rows={2}
                                value={preForm.notas}
                                onChange={(e) =>
                                  setPreForm((p) => ({ ...p, notas: e.target.value }))
                                }
                                placeholder="Cantidad de cajas, impresora térmica o comentarios..."
                                maxLength={350}
                                className="w-full px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl resize-none focus:outline-none focus:border-sky-500 focus:bg-white"
                              />
                            </div>

                            {errorMsg && (
                              <p className="text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2.5">
                                {errorMsg}
                              </p>
                            )}

                            <button
                              type="submit"
                              disabled={loading || uploadingRif}
                              className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-60 text-white font-bold text-sm sm:text-base transition-all cursor-pointer shadow-sm inline-flex items-center justify-center gap-2"
                            >
                              <Building2 className="w-4 h-4" />
                              {loading
                                ? 'Enviando Pre-Registro...'
                                : 'Enviar Pre-Registro y Solicitar 5 Días Gratis'}
                            </button>
                          </form>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            setPreRegMode(false);
                            setPreRegSent(false);
                            setErrorMsg('');
                          }}
                          className="w-full py-2.5 text-xs sm:text-sm font-bold text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <ArrowLeft className="w-4 h-4" /> Volver al inicio de sesión
                        </button>
                      </div>
                    ) : mfaResolver ? (
                      /* MFA Challenge Screen */
                      <form onSubmit={handleMfaVerify} className="space-y-5">
                        <div className="p-4 rounded-2xl bg-sky-50 border border-sky-200 text-xs sm:text-sm text-sky-900 flex items-start gap-3">
                          <ShieldCheck className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                          <span>
                            Tu cuenta tiene autenticación multifactor activada. Ingresa el código de
                            6 dígitos de tu aplicación autenticadora.
                          </span>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-2">
                            Código de Verificación (6 dígitos)
                          </label>
                          <input
                            type="text"
                            inputMode="numeric"
                            maxLength={6}
                            value={mfaCode}
                            onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ''))}
                            placeholder="000000"
                            autoFocus
                            className="w-full px-4 py-4 text-center text-2xl font-mono font-bold tracking-[0.35em] bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-sky-500 focus:bg-white"
                          />
                        </div>

                        {errorMsg && (
                          <p className="text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2.5">
                            {errorMsg}
                          </p>
                        )}

                        <button
                          type="submit"
                          disabled={loading}
                          className="w-full py-3.5 px-5 rounded-2xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white font-bold text-base transition-colors cursor-pointer"
                        >
                          {loading ? 'Verificando...' : 'Verificar y Entrar'}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setMfaResolver(null);
                            setErrorMsg('');
                          }}
                          className="w-full py-2.5 text-xs sm:text-sm font-bold text-slate-500 hover:text-slate-800 flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <ArrowLeft className="w-4 h-4" /> Volver al inicio de sesión
                        </button>
                      </form>
                    ) : recoveryMode ? (
                      /* Password Recovery Screen */
                      <form onSubmit={handlePasswordReset} className="space-y-5">
                        {recoverySent ? (
                          <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2.5">
                            <CheckCircle2 className="w-9 h-9 text-emerald-600 mx-auto" />
                            <h3 className="text-base font-extrabold text-emerald-950">
                              Enlace enviado
                            </h3>
                            <p className="text-sm text-emerald-800 leading-relaxed">
                              Hemos enviado un correo de recuperación de Firebase Auth a{' '}
                              <b>{recoveryEmail || email}</b>. Revisa tu bandeja de entrada o spam.
                            </p>
                          </div>
                        ) : (
                          <>
                            <p className="text-sm text-slate-600 leading-relaxed">
                              Ingresa el correo asociado a tu cuenta de Administrador o Propietario
                              y te enviaremos un enlace seguro para restablecer tu contraseña.
                            </p>
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-2">
                                Correo electrónico
                              </label>
                              <div className="relative">
                                <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                                <input
                                  type="email"
                                  value={recoveryEmail}
                                  onChange={(e) => setRecoveryEmail(e.target.value)}
                                  placeholder="correo@innovagrup.com"
                                  className="w-full pl-11 pr-4 py-3.5 text-sm sm:text-base bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-sky-500 focus:bg-white"
                                />
                              </div>
                            </div>
                          </>
                        )}

                        {errorMsg && (
                          <p className="text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2.5">
                            {errorMsg}
                          </p>
                        )}

                        {!recoverySent && (
                          <button
                            type="submit"
                            disabled={loading}
                            className="w-full py-3.5 px-5 rounded-2xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white font-bold text-base transition-colors cursor-pointer"
                          >
                            {loading ? 'Enviando...' : 'Enviar correo de recuperación'}
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            setRecoveryMode(false);
                            setRecoverySent(false);
                            setErrorMsg('');
                          }}
                          className="w-full py-2.5 text-xs sm:text-sm font-bold text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <ArrowLeft className="w-4 h-4" /> Volver al inicio de sesión
                        </button>
                      </form>
                    ) : (
                      /* Main Spacious Login Form */
                      <form onSubmit={handleSubmit} className="space-y-5">
                        {/* Role Selector */}
                        <div className="grid grid-cols-3 gap-2 p-1.5 bg-slate-100 border border-slate-200/80 rounded-2xl">
                          {(
                            [
                              { id: 'cashier', label: 'Cajero', Icon: Store },
                              { id: 'admin', label: 'Admin', Icon: UserCog },
                              { id: 'owner', label: 'Propietario', Icon: Crown },
                            ] as const
                          ).map(({ id, label, Icon }) => {
                            const active = selectedRole === id;
                            return (
                              <button
                                key={id}
                                type="button"
                                onClick={() => handleRoleSwitch(id)}
                                className={`relative py-3.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                                  active ? 'text-sky-700' : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                {active && (
                                  <motion.span
                                    layoutId="auth-role-pill"
                                    transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                                    className="absolute inset-0 bg-white rounded-xl shadow-sm border border-sky-100"
                                  />
                                )}
                                <Icon className="w-5 h-5 relative z-10" />
                                <span className="relative z-10">{label}</span>
                              </button>
                            );
                          })}
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-2">
                            {selectedRole === 'cashier'
                              ? 'Correo del comercio'
                              : 'Correo electrónico'}
                          </label>
                          <div className="relative">
                            <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                            <input
                              type="email"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              placeholder="usuario@innovagrup.com"
                              autoComplete="username"
                              className="w-full pl-11 pr-4 py-3.5 text-sm sm:text-base bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-sky-500 focus:bg-white transition-colors"
                            />
                          </div>
                        </div>

                        {selectedRole === 'cashier' && !authUser && (
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-2">
                              Contraseña del comercio (para vincular terminal)
                            </label>
                            <div className="relative">
                              <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                              <input
                                type="password"
                                value={terminalPassword}
                                onChange={(e) => setTerminalPassword(e.target.value)}
                                placeholder="•••••••• (o vincula con Google abajo)"
                                className="w-full pl-11 pr-4 py-3.5 text-sm sm:text-base bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-sky-500 focus:bg-white transition-colors"
                              />
                            </div>
                          </div>
                        )}

                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <label className="text-xs font-bold text-slate-700">
                              {selectedRole === 'cashier'
                                ? 'PIN del cajero (4-8 dígitos)'
                                : 'Contraseña'}
                            </label>
                            {selectedRole !== 'cashier' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setRecoveryEmail(email);
                                  setRecoveryMode(true);
                                  setRecoverySent(false);
                                  setErrorMsg('');
                                }}
                                className="text-xs font-bold text-sky-600 hover:text-sky-700 cursor-pointer"
                              >
                                ¿Olvidaste tu contraseña?
                              </button>
                            )}
                          </div>
                          <div className="relative">
                            {selectedRole === 'cashier' ? (
                              <KeyRound className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                            ) : (
                              <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                            )}
                            <input
                              type={showSecret ? 'text' : 'password'}
                              inputMode={selectedRole === 'cashier' ? 'numeric' : 'text'}
                              value={secret}
                              onChange={(e) => setSecret(e.target.value)}
                              placeholder={selectedRole === 'cashier' ? '••••' : '••••••••'}
                              autoComplete="current-password"
                              className="w-full pl-11 pr-11 py-3.5 text-sm sm:text-base font-mono bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-sky-500 focus:bg-white transition-colors"
                            />
                            <button
                              type="button"
                              onClick={() => setShowSecret((s) => !s)}
                              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                              aria-label="Mostrar u ocultar clave"
                            >
                              {showSecret ? (
                                <EyeOff className="w-4 h-4" />
                              ) : (
                                <Eye className="w-4 h-4" />
                              )}
                            </button>
                          </div>
                        </div>

                        {errorMsg && (
                          <p className="text-xs sm:text-sm font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-4 py-3 leading-relaxed">
                            {errorMsg}
                          </p>
                        )}

                        <button
                          type="submit"
                          disabled={loading}
                          className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 disabled:opacity-60 text-white font-extrabold text-sm sm:text-base transition-all cursor-pointer shadow-[0_14px_28px_-12px_rgba(2,132,199,0.6)] btn-press"
                        >
                          {loading ? 'Validando credenciales...' : 'Autenticar e Iniciar'}
                        </button>

                        <div className="relative flex items-center py-1">
                          <div className="flex-grow border-t border-slate-200" />
                          <span className="shrink mx-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            o acceso rápido
                          </span>
                          <div className="flex-grow border-t border-slate-200" />
                        </div>

                        <button
                          type="button"
                          disabled={loading}
                          onClick={handleGoogleAccess}
                          className="w-full py-3.5 px-4 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 hover:border-slate-300 disabled:opacity-60 text-slate-800 font-bold text-xs sm:text-sm inline-flex items-center justify-center gap-2.5 transition-all cursor-pointer btn-press"
                        >
                          <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
                            <path
                              fill="#4285F4"
                              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                            />
                            <path
                              fill="#34A853"
                              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
                            />
                            <path
                              fill="#FBBC05"
                              d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
                            />
                            <path
                              fill="#EA4335"
                              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
                            />
                          </svg>
                          {selectedRole === 'cashier'
                            ? 'Vincular terminal con Google'
                            : 'Continuar con Google'}
                        </button>

                        {/* Register New Business (Pre-Registro) CTA */}
                        <div className="pt-4 border-t border-slate-100 space-y-3">
                          <button
                            type="button"
                            onClick={() => {
                              setPreRegMode(true);
                              setPreRegSent(false);
                              setErrorMsg('');
                            }}
                            className="w-full py-3.5 px-4 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 font-bold text-xs sm:text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                          >
                            <Building2 className="w-4 h-4 text-emerald-600" />
                            ¿Eres un negocio nuevo? Regístrate aquí (5 días gratis)
                          </button>

                          {selectedRole !== 'cashier' && (
                            <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                              <span className="flex items-center gap-1.5">
                                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                                Compatible con MFA Firebase
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  setRecoveryEmail(email);
                                  setRecoveryMode(true);
                                  setRecoverySent(false);
                                  setErrorMsg('');
                                }}
                                className="font-bold text-sky-700 hover:text-sky-600 underline cursor-pointer"
                              >
                                Recuperar acceso
                              </button>
                            </div>
                          )}
                        </div>
                      </form>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </motion.div>

            {/* Subtle Scroll Cue to Information Below */}
            <motion.a
              href="#info-plataforma"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.45, duration: 0.5 }}
              className="mt-8 inline-flex flex-col items-center gap-1 text-xs font-bold text-slate-400 hover:text-sky-600 transition-colors"
            >
              <span>Ver información del sistema</span>
              <motion.span
                animate={{ y: [0, 4, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              >
                <ChevronDown className="w-4 h-4" />
              </motion.span>
            </motion.a>
          </section>

          {/* Information Section Below the Main Login Screen */}
          <section
            id="info-plataforma"
            className="max-w-5xl mx-auto px-5 sm:px-8 pt-6 pb-24 space-y-8"
          >
            <div className="border-t border-slate-200/80 pt-10 text-center max-w-2xl mx-auto">
              <p className="text-xs font-extrabold tracking-[0.22em] text-sky-600 uppercase">
                Plataforma Comercial Innova Grup
              </p>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-1.5 tracking-tight">
                Todo lo que tu comercio necesita en el día a día
              </h2>
            </div>

            {/* General Platform Feature Cards (No SENIAT info) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {PLATFORM_HIGHLIGHTS.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.title}
                    initial={{ opacity: 0, y: 18 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{
                      duration: 0.45,
                      delay: idx * 0.08,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                    whileHover={{ y: -3 }}
                    className="p-6 rounded-2xl bg-white/95 backdrop-blur-sm border border-slate-200/85 shadow-xs hover:shadow-md hover:border-sky-200 transition-shadow"
                  >
                    <div
                      className={`w-11 h-11 rounded-xl border flex items-center justify-center mb-4 ${item.accent}`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900 mb-1.5">{item.title}</h3>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{item.desc}</p>
                  </motion.div>
                );
              })}
            </div>

            {/* Interactive Virtual Assistant Banner */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="p-6 sm:p-7 rounded-3xl bg-slate-950 text-white border border-slate-800 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5"
            >
              <div className="flex items-center gap-4 min-w-0">
                <motion.div
                  animate={{ y: [0, -4, 0] }}
                  transition={{ duration: 3.4, repeat: Infinity, ease: 'easeInOut' }}
                  className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-sky-400/70 bg-slate-800 flex items-center justify-center shrink-0"
                >
                  {!avatarBroken ? (
                    <img
                      src={innovaAvatarImg}
                      alt="Asistente Virtual Innova Grup"
                      referrerPolicy="no-referrer"
                      onError={() => setAvatarBroken(true)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Sparkles className="w-6 h-6 text-sky-400" />
                  )}
                </motion.div>
                <div className="min-w-0">
                  <p className="text-xs font-extrabold uppercase tracking-wider text-sky-400">
                    Asistente Virtual Innova Grup
                  </p>
                  <p className="text-base font-bold text-white mt-0.5">
                    ¿Necesitas ayuda para ingresar o consultar tu cuenta?
                  </p>
                  <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                    Verificación solo por correo sin Google; contraseña y PIN Admin para datos
                    privados.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAssistantOpen(true)}
                className="px-5 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-xs sm:text-sm inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition cursor-pointer"
              >
                Abrir chat
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          </section>
      </main>

      {/* Critical Emergency Restricted Access Warning Modal (Propietario) */}
      {ownerWarningOpen && (
        <div className="fixed inset-0 z-[220] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="w-full max-w-md rounded-3xl bg-slate-950 border-2 border-rose-600/90 shadow-[0_0_60px_-10px_rgba(225,29,72,0.7)] overflow-hidden text-white"
          >
            <div className="bg-gradient-to-r from-rose-700 via-red-600 to-rose-700 px-5 py-4 flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-black/30 border border-white/25 flex items-center justify-center shrink-0 animate-pulse">
                <ShieldAlert className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-100">
                  Alerta de Seguridad Crítica
                </p>
                <h2 className="text-base font-black tracking-tight text-white">
                  ACCESO ESTRICTAMENTE RESTRINGIDO
                </h2>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/40 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1.5 text-xs leading-relaxed text-rose-100">
                  <p className="font-extrabold text-white">
                    ÁREA EXCLUSIVA DEL PROPIETARIO DE C.C. INNOVA GRUP
                  </p>
                  <p>
                    Este módulo es de <strong>acceso totalmente restringido y monitoreado</strong>.
                    Cualquier intento de inicio de sesión no autorizado, manipulación o acceso
                    indebido queda registrado y{' '}
                    <strong className="text-rose-300">
                      causará acciones y problemas legales directos con C.C. INNOVA GRUP
                    </strong>
                    .
                  </p>
                  <p className="text-[11px] text-rose-200/80">
                    Si eres cliente, administrador de comercio o cajero, abandona esta ventana de
                    inmediato e ingresa por tu perfil correspondiente.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setOwnerWarningOpen(false)}
                className="w-full py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-sm transition cursor-pointer shadow-lg shadow-rose-950/60"
              >
                Volver / Salir inmediatamente
              </button>

              <div className="pt-3 flex justify-center">
                <button
                  type="button"
                  onClick={() => {
                    setOwnerWarningOpen(false);
                    applyRoleSwitch('owner');
                  }}
                  className="text-[10px] font-normal tracking-wide text-slate-600/60 hover:text-slate-400 transition-colors cursor-pointer select-none"
                >
                  continuar
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Animated Innova Grup Virtual Assistant Avatar (Email-only basic + Password & Admin PIN for private data) */}
      <InnovaAvatarAssistant
        contextMode="portal"
        externalOpen={assistantOpen}
        onExternalOpen={() => setAssistantOpen(true)}
        onExternalClose={() => setAssistantOpen(false)}
      />
    </div>
  );
};
