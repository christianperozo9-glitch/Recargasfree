import type { VerificationRequirementKey } from '../types/pos';

export interface VerificationRequirementDef {
  key: VerificationRequirementKey;
  label: string;
  shortLabel: string;
  description: string;
  detailPlaceholder: string;
}

export const VERIFICATION_REQUIREMENTS: VerificationRequirementDef[] = [
  {
    key: 'datos_fiscales',
    label: 'Datos Fiscales del Comercio',
    shortLabel: 'Datos Fiscales',
    description: 'Razón social completa, RIF actualizado y confirmación de actividad comercial.',
    detailPlaceholder: 'Ej: Inversiones Ejemplo C.A. · RIF J-12345678-9 · Actividad comercial',
  },
  {
    key: 'datos_domiciliarios',
    label: 'Datos Domiciliarios / Dirección Fiscal',
    shortLabel: 'Datos Domiciliarios',
    description: 'Dirección exacta del local o domicilio fiscal + recibo de servicio o constancia.',
    detailPlaceholder: 'Ej: Av. Principal, Edif. Centro, Local 4, Ciudad / Estado',
  },
  {
    key: 'verificacion_rif',
    label: 'Verificación de RIF',
    shortLabel: 'Verificación RIF',
    description: 'Fotografía clara o captura legible del Registro de Información Fiscal (RIF) vigente.',
    detailPlaceholder: 'Ej: RIF J-12345678-9 vigente hasta MM/AAAA',
  },
  {
    key: 'comprobacion_vida',
    label: 'Comprobación de Vida (Selfie + Cédula)',
    shortLabel: 'Comprobación de Vida',
    description: 'Fotografía nítida del titular sosteniendo su cédula de identidad o documento oficial.',
    detailPlaceholder: 'Ej: Titular Juan Pérez · C.I. V-18.456.789',
  },
  {
    key: 'certificacion_ingresos',
    label: 'Certificación de Ingresos',
    shortLabel: 'Cert. Ingresos',
    description: 'Constancia o certificación de ingresos emitida por contador público colegiado.',
    detailPlaceholder: 'Ej: Certificación emitida fecha / monto mensual estimado',
  },
  {
    key: 'certificacion_gastos',
    label: 'Certificación de Gastos',
    shortLabel: 'Cert. Gastos',
    description: 'Soporte o certificación de estructura de gastos operativos del comercio.',
    detailPlaceholder: 'Ej: Relación de gastos operativos del período vigente',
  },
  {
    key: 'verificacion_seniat',
    label: 'Verificación del SENIAT',
    shortLabel: 'Verificación SENIAT',
    description: 'Captura del portal SENIAT verificando estatus fiscal activo del contribuyente.',
    detailPlaceholder: 'Ej: Estatus activo en portal SENIAT',
  },
  {
    key: 'comprobacion_seniat',
    label: 'Comprobación de SENIAT / Declaración',
    shortLabel: 'Comprobación SENIAT',
    description: 'Comprobante de declaración o constancia oficial emitida por el SENIAT.',
    detailPlaceholder: 'Ej: Nro. de planilla / fecha de declaración SENIAT',
  },
  {
    key: 'registro_mercantil',
    label: 'Registro Mercantil',
    shortLabel: 'Registro Mercantil',
    description: 'Fotografía o copia digital del Acta Constitutiva o Registro Mercantil vigente.',
    detailPlaceholder: 'Ej: Tomo / Número / Año del Registro Mercantil',
  },
];

export function buildDefaultVerificationRequisitos(): Record<VerificationRequirementKey, boolean> {
  return {
    datos_fiscales: true,
    datos_domiciliarios: true,
    verificacion_rif: true,
    comprobacion_vida: false,
    certificacion_ingresos: false,
    certificacion_gastos: false,
    verificacion_seniat: false,
    comprobacion_seniat: false,
    registro_mercantil: false,
  };
}
