import React, { useEffect, useMemo, useRef, useState } from 'react';
import { collection, onSnapshot, orderBy, query } from 'firebase/firestore';
import {
  Bot,
  Building2,
  Crown,
  Loader2,
  MessageCircle,
  MessageSquare,
  RotateCcw,
  Search,
  Send,
  Sparkles,
  Trash2,
  User,
  Wand2,
} from 'lucide-react';
import { db } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import type { OwnerChatMessage, TenantRecord } from '../types/pos';

const AI_QUICK_INTENTS = [
  {
    id: 'bienvenida',
    label: 'Bienvenida',
    instruction:
      'Envía un saludo cálido de bienvenida a Innova Grup POS recordándole que cuenta con soporte técnico directo y deseándole excelentes ventas.',
  },
  {
    id: 'seguimiento',
    label: 'Seguimiento',
    instruction:
      'Haz un seguimiento amigable para saber cómo le ha ido con el punto de venta, facturación e impresora térmica, y si necesita ayuda con algo.',
  },
  {
    id: 'renovacion',
    label: 'Recordar Membresía',
    instruction:
      'Envía un recordatorio cortés y profesional sobre el estado de su membresía e invítalo a renovar a tiempo para no interrumpir sus ventas.',
  },
  {
    id: 'documentos',
    label: 'Pedir Documentos',
    instruction:
      'Solicita amablemente que suba sus documentos actualizados en el botón de Actualización de Datos para mantener al día su perfil fiscal.',
  },
  {
    id: 'responder',
    label: 'Responder Último',
    instruction:
      'Responde de forma clara, servicial y profesional al último mensaje enviado por el cliente en la conversación.',
  },
  {
    id: 'promo',
    label: 'Promoción',
    instruction:
      'Informa brevemente que tenemos descuentos y meses de regalo en planes semestrales y anuales de Innova Grup POS.',
  },
] as const;

function cleanPhoneForWhatsApp(raw: string): string {
  const digits = (raw || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('0') && digits.length === 11) return `58${digits.slice(1)}`;
  if (digits.length === 10 && digits.startsWith('4')) return `58${digits}`;
  return digits;
}

export const OwnerAiChatTab: React.FC = () => {
  const {
    tenants,
    activeTenantId,
    sendOwnerChatMessage,
    clearOwnerChat,
    notifyToast,
    playBeep,
  } = usePos();

  const [selectedClientId, setSelectedClientId] = useState<string>(
    activeTenantId || tenants[0]?.id || ''
  );
  const [clientSearch, setClientSearch] = useState('');
  const [messages, setMessages] = useState<OwnerChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [sending, setSending] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearingChat, setClearingChat] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!selectedClientId && tenants.length > 0) {
      setSelectedClientId(activeTenantId || tenants[0].id);
    }
  }, [tenants, activeTenantId, selectedClientId]);

  const selectedClient: TenantRecord | null = useMemo(
    () => tenants.find((t) => t.id === selectedClientId) || null,
    [tenants, selectedClientId]
  );

  const filteredClients = useMemo(() => {
    const q = clientSearch.trim().toLowerCase();
    if (!q) return tenants;
    return tenants.filter(
      (t) =>
        (t.nombre_local || '').toLowerCase().includes(q) ||
        (t.rif || '').toLowerCase().includes(q) ||
        (t.email || '').toLowerCase().includes(q)
    );
  }, [tenants, clientSearch]);

  // Real-time chat stream for selected client
  useEffect(() => {
    if (!selectedClientId) {
      setMessages([]);
      return;
    }
    const q = query(
      collection(db, 'tenants', selectedClientId, 'owner_chat'),
      orderBy('timestamp', 'asc')
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: OwnerChatMessage[] = snap.docs.map((d) => ({
          ...(d.data() as Omit<OwnerChatMessage, 'id'>),
          id: d.id,
        }));
        setMessages(list);
        setTimeout(() => chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 60);
      },
      () => {
        setMessages([]);
      }
    );
    return () => unsub();
  }, [selectedClientId]);

  const requestAiDraft = async (instructionOverride?: string): Promise<string | null> => {
    if (!selectedClient) {
      notifyToast('Selecciona primero un cliente de la lista.', 'warning');
      return null;
    }
    const instr = (instructionOverride ?? aiPrompt).trim();
    const venceStr = selectedClient.membresia?.vence
      ? new Date(selectedClient.membresia.vence).toLocaleDateString('es-VE')
      : 'Sin vencimiento';
    const membershipSummary = `${selectedClient.membresia?.nombre || 'Activa'} (${
      selectedClient.membresia?.estado || 'activa'
    }, vence: ${venceStr})`;

    setAiBusy(true);
    try {
      const resp = await fetch('/api/owner/ai-chat-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: selectedClient.nombre_local,
          clientRif: selectedClient.rif || '',
          clientEmail: selectedClient.email || '',
          membershipStatus: membershipSummary,
          instruction: instr || 'Redacta un mensaje amable de atención al cliente y soporte.',
          recentMessages: messages.slice(-8).map((m) => ({
            senderRole: m.senderRole,
            text: m.text,
          })),
        }),
      });
      const data = (await resp.json()) as { text?: string; error?: string };
      if (!resp.ok || !data.text) {
        notifyToast(
          data.error || 'No se pudo generar el mensaje con el Asistente Virtual Innova Grup.',
          'error'
        );
        return null;
      }
      return data.text.trim();
    } catch {
      notifyToast('Error de comunicación con el servicio de Innova Grup IA.', 'error');
      return null;
    } finally {
      setAiBusy(false);
    }
  };

  const handleGenerateDraft = async (instructionOverride?: string) => {
    const text = await requestAiDraft(instructionOverride);
    if (text) {
      setDraft(text);
      notifyToast('Mensaje redactado por Innova Grup IA. Puedes revisarlo o enviarlo.', 'success');
    }
  };

  const handleAutoSendWithAi = async (instructionOverride?: string) => {
    if (!selectedClient) return;
    const text = await requestAiDraft(instructionOverride);
    if (!text) return;
    setSending(true);
    try {
      await sendOwnerChatMessage(selectedClient.id, text, 'ai_bot', true);
      setAiPrompt('');
      playBeep('ok');
      notifyToast(`Innova Grup envió respuesta automática a ${selectedClient.nombre_local}.`, 'success');
    } finally {
      setSending(false);
    }
  };

  const handleClearClientChat = async () => {
    if (!selectedClient) return;
    setClearingChat(true);
    try {
      await clearOwnerChat(selectedClient.id);
      setConfirmClear(false);
      setDraft('');
      setAiPrompt('');
    } finally {
      setClearingChat(false);
    }
  };

  const handleManualSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClient || !draft.trim()) return;
    setSending(true);
    try {
      await sendOwnerChatMessage(selectedClient.id, draft.trim(), 'owner', false);
      setDraft('');
      playBeep('ok');
    } finally {
      setSending(false);
    }
  };

  const waHref = useMemo(() => {
    if (!selectedClient) return '';
    const phone = cleanPhoneForWhatsApp(selectedClient.telefono || '');
    const msgToUse =
      draft.trim() ||
      [...messages].reverse().find((m) => m.senderRole !== 'client')?.text ||
      `Hola ${selectedClient.nombre_local}, te escribimos desde Innova Grup POS.`;
    return phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(msgToUse)}`
      : `https://wa.me/?text=${encodeURIComponent(msgToUse)}`;
  }, [selectedClient, draft, messages]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-[620px]">
      {/* Left: Client Selector */}
      <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 flex flex-col overflow-hidden max-h-[680px]">
        <div className="p-4 border-b border-slate-200 space-y-2.5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-slate-900">Chat Innova Grup · Asistente Virtual</h3>
              <p className="text-[11px] text-slate-500">
                Selecciona un comercio para chatear o activar respuestas automáticas de Innova Grup
              </p>
            </div>
          </div>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={clientSearch}
              onChange={(e) => setClientSearch(e.target.value)}
              placeholder="Filtrar cliente por nombre, RIF o correo..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 scrollbar-thin">
          {filteredClients.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              No hay clientes registrados que coincidan.
            </div>
          ) : (
            filteredClients.map((t) => {
              const active = t.id === selectedClientId;
              const isExpired =
                t.membresia?.estado === 'suspendida' ||
                (t.membresia?.vence ? t.membresia.vence < Date.now() : false);
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setSelectedClientId(t.id)}
                  className={`w-full text-left p-3.5 transition-colors cursor-pointer flex items-start gap-2.5 ${
                    active ? 'bg-indigo-50/80 border-l-4 border-indigo-600' : 'hover:bg-slate-50'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      active
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <p className="text-xs font-extrabold text-slate-900 truncate">
                        {t.nombre_local}
                      </p>
                      <span
                        className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-md shrink-0 ${
                          isExpired
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {isExpired ? 'Vencida' : 'Activa'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate font-mono">
                      {t.rif || t.email}
                    </p>
                    {t.telefono && (
                      <p className="text-[10px] text-slate-400 font-mono truncate">{t.telefono}</p>
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Right: Conversation Thread + Google Gemini AI Bot Studio */}
      <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 flex flex-col overflow-hidden max-h-[680px]">
        {!selectedClient ? (
          <div className="flex-1 flex flex-col items-center justify-center p-10 text-center text-slate-400 space-y-2">
            <MessageSquare className="w-10 h-10 opacity-40" />
            <p className="text-sm font-bold text-slate-600">Selecciona un cliente a la izquierda</p>
            <p className="text-xs max-w-xs">
              Podrás ver el historial de chat en tiempo real y enviar mensajes automáticos con el Asistente Virtual Innova Grup.
            </p>
          </div>
        ) : (
          <>
            {/* Selected Client Header */}
            <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-r from-indigo-50/70 via-white to-sky-50/60 flex flex-wrap items-center justify-between gap-2 shrink-0">
              <div className="min-w-0">
                <h4 className="text-sm font-extrabold text-slate-900 truncate">
                  {selectedClient.nombre_local}
                </h4>
                <p className="text-[11px] text-slate-500 truncate">
                  {selectedClient.email}
                  {selectedClient.rif ? ` · RIF ${selectedClient.rif}` : ''}
                  {selectedClient.telefono ? ` · Tel: ${selectedClient.telefono}` : ''}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                {messages.length > 0 && !confirmClear && (
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    className="px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                    title="Restablecer y borrar conversación"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Borrar chat
                  </button>
                )}
                {confirmClear && (
                  <div className="flex items-center gap-1 bg-rose-50 border border-rose-200 rounded-xl px-2 py-1">
                    <button
                      type="button"
                      disabled={clearingChat}
                      onClick={() => void handleClearClientChat()}
                      className="px-2 py-0.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer disabled:opacity-50"
                    >
                      {clearingChat ? 'Borrando...' : 'Confirmar borrado'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClear(false)}
                      className="px-2 py-0.5 rounded-lg bg-white text-slate-600 text-[11px] font-semibold cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setDraft('');
                    setAiPrompt('');
                    notifyToast('Borrador y campos restablecidos.', 'info');
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                  title="Restablecer borrador"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Restablecer
                </button>
                {waHref && (
                  <a
                    href={waHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-[#25D366] hover:bg-[#1fb857] text-white text-xs font-bold inline-flex items-center gap-1.5 shrink-0"
                    title="Enviar borrador o último mensaje por WhatsApp al cliente"
                  >
                    <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                  </a>
                )}
              </div>
            </div>

            {/* Innova Grup AI Virtual Assistant Control Panel */}
            <div className="px-4 py-3 bg-indigo-50/50 border-b border-indigo-100 space-y-2.5 shrink-0">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-[11px] font-extrabold text-indigo-950 flex items-center gap-1.5 uppercase tracking-wide">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  Innova Grup · Asistente Virtual IA (Respuestas Automáticas)
                </span>
                {aiBusy && (
                  <span className="text-[11px] font-bold text-indigo-700 inline-flex items-center gap-1">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Innova Grup redactando...
                  </span>
                )}
              </div>

              {/* Quick Intent Buttons */}
              <div className="flex flex-wrap gap-1.5">
                {AI_QUICK_INTENTS.map((intent) => (
                  <button
                    key={intent.id}
                    type="button"
                    disabled={aiBusy || sending}
                    onClick={() => void handleGenerateDraft(intent.instruction)}
                    className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-100 border border-indigo-200 text-indigo-900 text-[11px] font-semibold cursor-pointer disabled:opacity-50"
                  >
                    {intent.label}
                  </button>
                ))}
              </div>

              {/* Custom AI Instruction + Auto-Send */}
              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="Instrucción para Innova Grup IA (ej: avísale que su Modo Fiscal ya está activo)..."
                  maxLength={350}
                  className="flex-1 min-w-[200px] px-3 py-1.5 text-xs bg-white border border-indigo-200 rounded-xl focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  disabled={aiBusy || sending}
                  onClick={() => void handleGenerateDraft()}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-indigo-100 border border-indigo-300 text-indigo-800 text-xs font-bold inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                >
                  <Wand2 className="w-3.5 h-3.5" /> Redactar
                </button>
                <button
                  type="button"
                  disabled={aiBusy || sending}
                  onClick={() => void handleAutoSendWithAi()}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-700 hover:to-sky-700 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-2xs"
                >
                  <Bot className="w-3.5 h-3.5" /> Responder con Innova Grup
                </button>
              </div>
            </div>

            {/* Messages Stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/60 scrollbar-thin">
              {messages.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400 space-y-1">
                  <Bot className="w-8 h-8 mx-auto text-indigo-300" />
                  <p className="font-bold text-slate-600">
                    Inicia la conversación con {selectedClient.nombre_local}
                  </p>
                  <p>
                    Usa Innova Grup arriba para generar y enviar una respuesta automática al instante.
                  </p>
                </div>
              ) : (
                messages.map((m) => {
                  const isClient = m.senderRole === 'client';
                  const isAi = m.senderRole === 'ai_bot' || m.aiGenerated;
                  return (
                    <div
                      key={m.id}
                      className={`flex ${isClient ? 'justify-start' : 'justify-end'}`}
                    >
                      <div
                        className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-xs shadow-2xs space-y-1 ${
                          isClient
                            ? 'bg-white border border-slate-200 text-slate-900 rounded-bl-sm'
                            : isAi
                            ? 'bg-gradient-to-br from-indigo-600 to-sky-600 text-white rounded-br-sm'
                            : 'bg-slate-900 text-white rounded-br-sm'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 text-[10px] font-bold opacity-85">
                          {isClient ? (
                            <>
                              <User className="w-3 h-3 text-sky-600" />
                              <span className="text-slate-700">{m.senderName || 'Cliente'}</span>
                            </>
                          ) : isAi ? (
                            <>
                              <Bot className="w-3 h-3" />
                              <span>Innova Grup · Asistente Virtual</span>
                            </>
                          ) : (
                            <>
                              <Crown className="w-3 h-3 text-amber-300" />
                              <span>{m.senderName || 'Propietario · Innova Grup'}</span>
                            </>
                          )}
                        </div>
                        <p className="whitespace-pre-wrap leading-relaxed">{m.text}</p>
                        <div
                          className={`text-[10px] font-mono ${
                            isClient ? 'text-slate-400' : 'text-white/75 text-right'
                          }`}
                        >
                          {new Date(m.timestamp).toLocaleString('es-VE', {
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Manual Message Composer */}
            <form
              onSubmit={handleManualSend}
              className="p-3.5 border-t border-slate-200 bg-white flex items-end gap-2 shrink-0"
            >
              <textarea
                rows={2}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    if (draft.trim() && !sending) {
                      void handleManualSend(e);
                    }
                  }
                }}
                placeholder="Escribe un mensaje directo o edita el borrador generado por la IA..."
                maxLength={1500}
                className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl resize-none focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={sending || !draft.trim()}
                className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <Send className="w-3.5 h-3.5" /> Enviar
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
