export type ScannerTransport = 'hid-keyboard' | 'webhid' | 'webserial' | 'webusb' | 'camera';

export interface HardwareScanEvent {
  code: string;
  transport: ScannerTransport;
  latencyMs: number;
  timestamp: number;
  deviceName?: string;
}

export interface ConnectedScannerDevice {
  id: string;
  name: string;
  transport: 'webhid' | 'webserial' | 'webusb';
  vendorId?: number;
  productId?: number;
  status: 'connected' | 'listening';
}

const listeners = new Set<(ev: HardwareScanEvent) => void>();
const deviceListeners = new Set<(devices: ConnectedScannerDevice[]) => void>();
let connectedDevices: ConnectedScannerDevice[] = [];
let globalWedgeEnabled = true;

export function setGlobalScannerWedgeEnabled(enabled: boolean) {
  globalWedgeEnabled = enabled;
}

export function isGlobalScannerWedgeEnabled(): boolean {
  return globalWedgeEnabled;
}

export function subscribeHardwareScans(cb: (ev: HardwareScanEvent) => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

export function subscribeScannerDevices(cb: (devices: ConnectedScannerDevice[]) => void): () => void {
  deviceListeners.add(cb);
  cb(connectedDevices);
  return () => {
    deviceListeners.delete(cb);
  };
}

export function getConnectedScannerDevices(): ConnectedScannerDevice[] {
  return connectedDevices;
}

export function emitHardwareScan(ev: HardwareScanEvent) {
  const clean = ev.code.trim();
  if (!clean) return;
  listeners.forEach((cb) => {
    try {
      cb({ ...ev, code: clean });
    } catch {
      // ignore subscriber errors
    }
  });
}

function upsertDevice(dev: ConnectedScannerDevice) {
  const idx = connectedDevices.findIndex((d) => d.id === dev.id);
  if (idx >= 0) {
    connectedDevices = connectedDevices.map((d, i) => (i === idx ? dev : d));
  } else {
    connectedDevices = [...connectedDevices, dev];
  }
  deviceListeners.forEach((cb) => cb(connectedDevices));
}

export function getScannerCapabilities() {
  const nav = navigator as unknown as {
    hid?: { requestDevice: (opts: unknown) => Promise<unknown[]>; getDevices: () => Promise<unknown[]> };
    serial?: { requestPort: (opts?: unknown) => Promise<unknown>; getPorts: () => Promise<unknown[]> };
    usb?: { requestDevice: (opts: unknown) => Promise<unknown>; getDevices: () => Promise<unknown[]> };
  };
  return {
    hidKeyboardWedge: true,
    webHid: Boolean(nav.hid?.requestDevice),
    webSerial: Boolean(nav.serial?.requestPort),
    webUsb: Boolean(nav.usb?.requestDevice),
  };
}

export async function connectWebHidScanner(): Promise<ConnectedScannerDevice | null> {
  const nav = navigator as unknown as {
    hid?: {
      requestDevice: (opts: { filters: unknown[] }) => Promise<
        Array<{
          opened: boolean;
          productName?: string;
          vendorId?: number;
          productId?: number;
          open: () => Promise<void>;
          addEventListener: (ev: string, fn: (e: { data: DataView }) => void) => void;
        }>
      >;
    };
  };
  if (!nav.hid?.requestDevice) {
    throw new Error('Este navegador no soporta WebHID. El lector igual funciona por emulación de teclado USB/Inalámbrico.');
  }
  const devices = await nav.hid.requestDevice({ filters: [] });
  if (!devices || devices.length === 0) return null;
  const dev = devices[0];
  if (!dev.opened) {
    await dev.open();
  }
  let rawBuffer = '';
  let lastReportTs = Date.now();
  dev.addEventListener('inputreport', (event) => {
    const view = event.data;
    if (!view) return;
    const now = Date.now();
    if (now - lastReportTs > 250) rawBuffer = '';
    lastReportTs = now;
    // Extract ASCII printable bytes if present in vendor HID POS payload
    let chunk = '';
    let hasEnter = false;
    for (let i = 0; i < view.byteLength; i++) {
      const byte = view.getUint8(i);
      if (byte === 13 || byte === 10) {
        hasEnter = true;
      } else if (byte >= 32 && byte <= 126) {
        chunk += String.fromCharCode(byte);
      }
    }
    if (chunk) rawBuffer += chunk;
    if (hasEnter && rawBuffer.length >= 2) {
      emitHardwareScan({
        code: rawBuffer,
        transport: 'webhid',
        latencyMs: 12,
        timestamp: now,
        deviceName: dev.productName || 'Lector WebHID',
      });
      rawBuffer = '';
    }
  });

  const info: ConnectedScannerDevice = {
    id: `hid_${dev.vendorId || 0}_${dev.productId || 0}`,
    name: dev.productName || `Lector HID (${dev.vendorId?.toString(16) || 'USB'})`,
    transport: 'webhid',
    vendorId: dev.vendorId,
    productId: dev.productId,
    status: 'listening',
  };
  upsertDevice(info);
  return info;
}

export async function connectWebSerialScanner(): Promise<ConnectedScannerDevice | null> {
  const nav = navigator as unknown as {
    serial?: {
      requestPort: () => Promise<{
        readable?: ReadableStream<Uint8Array> | null;
        open: (opts: { baudRate: number }) => Promise<void>;
        getInfo: () => { usbVendorId?: number; usbProductId?: number };
      }>;
    };
  };
  if (!nav.serial?.requestPort) {
    throw new Error('Este navegador no soporta WebSerial. El lector igual funciona por emulación de teclado USB/Inalámbrico.');
  }
  const port = await nav.serial.requestPort();
  await port.open({ baudRate: 9600 });
  const portInfo = port.getInfo?.() || {};
  const devName = portInfo.usbVendorId
    ? `Lector Serial/Wireless (VID ${portInfo.usbVendorId.toString(16).toUpperCase()})`
    : 'Lector Serial COM';

  const info: ConnectedScannerDevice = {
    id: `serial_${portInfo.usbVendorId || 'com'}_${portInfo.usbProductId || Date.now()}`,
    name: devName,
    transport: 'webserial',
    vendorId: portInfo.usbVendorId,
    productId: portInfo.usbProductId,
    status: 'listening',
  };
  upsertDevice(info);

  if (port.readable) {
    const reader = port.readable.getReader();
    const decoder = new TextDecoder();
    let acc = '';
    let startTs = 0;
    (async () => {
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          if (!value) continue;
          if (!acc) startTs = Date.now();
          acc += decoder.decode(value, { stream: true });
          const lines = acc.split(/[\r\n]+/);
          if (lines.length > 1) {
            for (let i = 0; i < lines.length - 1; i++) {
              const code = lines[i].trim();
              if (code.length >= 2) {
                emitHardwareScan({
                  code,
                  transport: 'webserial',
                  latencyMs: Math.max(5, Date.now() - startTs),
                  timestamp: Date.now(),
                  deviceName: devName,
                });
              }
            }
            acc = lines[lines.length - 1];
            startTs = Date.now();
          }
        }
      } catch {
        // port closed or disconnected
      } finally {
        reader.releaseLock();
      }
    })();
  }

  return info;
}

export async function connectWebUsbScanner(): Promise<ConnectedScannerDevice | null> {
  const nav = navigator as unknown as {
    usb?: {
      requestDevice: (opts: { filters: unknown[] }) => Promise<{
        productName?: string;
        manufacturerName?: string;
        vendorId?: number;
        productId?: number;
      }>;
    };
  };
  if (!nav.usb?.requestDevice) {
    throw new Error('Este navegador no soporta WebUSB.');
  }
  const dev = await nav.usb.requestDevice({ filters: [] });
  const info: ConnectedScannerDevice = {
    id: `usb_${dev.vendorId || 0}_${dev.productId || 0}`,
    name: dev.productName || dev.manufacturerName || 'Receptor USB Lector',
    transport: 'webusb',
    vendorId: dev.vendorId,
    productId: dev.productId,
    status: 'connected',
  };
  upsertDevice(info);
  return info;
}

/**
 * Installs a universal high-speed HID keyboard-wedge detector that catches scans from
 * any wired USB, 2.4GHz wireless dongle, or Bluetooth barcode scanner.
 * Distinguishes rapid burst keystrokes (< 65ms avg or < 90ms between chars) ending in Enter/Tab
 * from normal typing — even when another input is not focused!
 */
export function attachUniversalWedgeDetector(
  onScan: (ev: HardwareScanEvent) => void,
  options?: { allowInsideInputs?: boolean }
): () => void {
  let buffer = '';
  let firstKeyTs = 0;
  let lastKeyTs = 0;

  const reset = () => {
    buffer = '';
    firstKeyTs = 0;
    lastKeyTs = 0;
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (!globalWedgeEnabled) return;
    const now = performance.now();
    const target = e.target as HTMLElement | null;
    const tag = target?.tagName || '';
    const isEditable =
      tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || Boolean(target?.isContentEditable);

    if (e.ctrlKey || e.metaKey || e.altKey) {
      reset();
      return;
    }

    if (now - lastKeyTs > 130 && buffer.length > 0) {
      reset();
    }

    if (e.key === 'Enter' || e.key === 'Tab') {
      const code = buffer.trim();
      const elapsed = lastKeyTs > firstKeyTs ? lastKeyTs - firstKeyTs : 0;
      const avgMs = code.length > 1 ? elapsed / (code.length - 1) : 0;
      const looksLikeHardwareBurst = code.length >= 3 && avgMs <= 80;

      if (looksLikeHardwareBurst) {
        if (!isEditable || options?.allowInsideInputs) {
          if (isEditable && e.key === 'Enter' && (target as HTMLInputElement).dataset?.scannerInput !== 'true') {
            // Avoid double submission when scanner focused inside search box unless handled
          }
          const ev: HardwareScanEvent = {
            code,
            transport: 'hid-keyboard',
            latencyMs: Math.round(elapsed),
            timestamp: Date.now(),
            deviceName: 'Lector Universal USB / Inalámbrico',
          };
          onScan(ev);
          emitHardwareScan(ev);
        }
      }
      reset();
      return;
    }

    if (e.key.length === 1) {
      if (!buffer) {
        firstKeyTs = now;
      }
      buffer += e.key;
      lastKeyTs = now;
    }
  };

  window.addEventListener('keydown', handleKeyDown, true);
  return () => {
    window.removeEventListener('keydown', handleKeyDown, true);
  };
}
