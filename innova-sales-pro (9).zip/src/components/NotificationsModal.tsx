import React, { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  BellOff,
  BellRing,
  Bot,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Crown,
  Info,
  Loader2,
  Megaphone,
  MessageSquare,
  RotateCcw,
  Send,
  Smartphone,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { usePos } from '../context/PosContext';

interface NotificationsModalProps {
  open: boolean;
  onClose: () => void;
  onOpenVerification?: () => void;
}

interface InboxItem {
  key: string;
  titulo: string;
  texto: string;
  tipo: 'info' | 'warning' | 'critical' | 'update';
  audiencia?: 'all' | 'cashier' | 'admin';
  enviado_por?: string;
  timestamp?: number;
  con_voz?: boolean;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  open,
  onClose,
  onOpenVerification,
}) => {
  const {
    config,
    activeTenant,
    notificationHistory,
    deleteNotification,
    clearAllNotifications,
    pushSupported,
    pushPermission,
    pushEnabled,
    togglePushNotifications,
    sendTestPushNotification,
    role,
    activeTenantId,
    ownerChatMessages,
    sendOwnerChatMessage,
    clearOwnerChat,
  } = usePos();

  const [tab, setTab] = useState<'inbox' | 'chat'>('inbox');
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [clearingAll, setClearingAll] = useState(false);
  const [togglingPush, setTogglingPush] = useState(false);
  const [testingPush, setTestingPush] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [sendingChat, setSendingChat] = useState(false);
  const [aiAutoReply, setAiAutoReply] = useState(true);
  const [aiReplying, setAiReplying] = useState(false);
  const [confirmClearChat, setConfirmClearChat] = useState(false);
  const [clearingChat, setClearingChat] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const inboxItems = useMemo<InboxItem[]>(() => {
    const list: InboxItem[] = notificationHistory.map((n) => ({
      key: n.key,
      titulo: n.titulo || 'Comunicado del Propietario',
      texto: n.texto || '',
      tipo: n.tipo || 'info',
      audiencia: n.audiencia,
      enviado_por: n.enviado_por,
      timestamp: n.timestamp,
      con_voz: n.con_voz,
    }));

    const activeB = config.broadcast;
    if (activeB && activeB.texto) {
      const alreadyInHistory = list.some(
        (it) =>
          it.texto === activeB.texto &&
          (it.titulo === (activeB.titulo || 'Comunicado del Propietario') ||
            (it.timestamp && activeB.timestamp && Math.abs(it.timestamp - activeB.timestamp) < 5000))
      );
      if (!alreadyInHistory) {
        list.unshift({
          key: '__active_broadcast__',
          titulo: activeB.titulo || 'Aviso del Propietario',
          texto: activeB.texto,
          tipo: activeB.tipo || 'info',
          audiencia: activeB.audiencia,
          enviado_por: activeB.enviado_por || 'Propietario',
          timestamp: activeB.timestamp || Date.now(),
          con_voz: activeB.con_voz,
        });
      }
    }

    return list.filter((it) => {
      if (!it.audiencia || it.audiencia === 'all') return true;
      if (!role || role === 'owner') return true;
      return it.audiencia === role;
    });
  }, [config.broadcast, notificationHistory, role]);

  if (!open) return null;

  const isPushActive = pushSupported && pushEnabled && pushPermission === 'granted';
  const isPushDenied = pushSupported && pushPermission === 'denied';

  const handleTogglePush = async () => {
    setTogglingPush(true);
    try {
      await togglePushNotifications();
    } finally {
      setTogglingPush(false);
    }
  };

  const handleTestPush = async () => {
    setTestingPush(true);
    try {
      await sendTestPushNotification();
    } finally {
      setTestingPush(false);
    }
  };

  const handleDeleteOne = async (key: string) => {
    setBusyKey(key);
    try {
      await deleteNotification(key);
    } finally {
      setBusyKey(null);
    }
  };

  const handleClearAll = async () => {
    setClearingAll(true);
    try {
      await clearAllNotifications();
      setConfirmClearAll(false);
    } finally {
      setClearingAll(false);
    }
  };

  const handleSendChatReply = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = chatInput.trim();
    if (!text || !activeTenantId) return;
    setSendingChat(true);
    try {
      await sendOwnerChatMessage(activeTenantId, text, 'client', false);
      setChatInput('');
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 80);

      // Interactive Innova Grup Virtual Assistant auto-response
      if (aiAutoReply) {
        setAiReplying(true);
        try {
          const vence = Number(activeTenant?.membresia?.vence || 0);
          const diasRestantes =
            vence > 0 ? Math.ceil((vence - Date.now()) / (1000 * 60 * 60 * 24)) : null;
          const res = await fetch('/api/innova-assistant', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: text,
              mode: 'client_chat',
              verified: Boolean(activeTenant),
              verifiedAccount: activeTenant
                ? {
                    nombre_local: activeTenant.nombre_local,
                    razon_social: activeTenant.razon_social || activeTenant.nombre_local,
                    email: activeTenant.email,
                    rif: activeTenant.rif || '',
                    contacto_nombre: activeTenant.contacto_nombre || '',
                    telefono: activeTenant.telefono || '',
                    estado_cuenta: activeTenant.activo ? 'Activa' : 'Inactiva',
                    membresia_plan: activeTenant.membresia?.nombre || 'Activa',
                    membresia_estado: activeTenant.membresia?.estado || 'activa',
                    dias_restantes: diasRestantes,
                    verificacion_pendiente: Boolean(activeTenant.verificacion_datos?.activo),
                    seniat_modo_fiscal: config.seniat_legal_activo === true,
                  }
                : null,
              history: ownerChatMessages.slice(-8).map((m) => ({
                role: m.senderRole === 'client' ? 'user' : 'assistant',
                text: m.text,
              })),
            }),
          });
          const data = (await res.json()) as { reply?: string };
          if (data.reply) {
            await sendOwnerChatMessage(activeTenantId, data.reply, 'ai_bot', true);
            setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
          }
        } catch {
          // ignore silent AI network error
        } finally {
          setAiReplying(false);
        }
      }
    } finally {
      setSendingChat(false);
    }
  };

  const handleClearChatHistory = async () => {
    if (!activeTenantId) return;
    setClearingChat(true);
    try {
      await clearOwnerChat(activeTenantId);
      setConfirmClearChat(false);
      setChatInput('');
    } finally {
      setClearingChat(false);
    }
  };

  const getTypeVisual = (tipo: InboxItem['tipo']) => {
    switch (tipo) {
      case 'critical':
        return {
          bar: 'bg-rose-500',
          border: 'border-rose-200 bg-rose-50/40',
          iconBg: 'bg-rose-100 text-rose-600',
          label: 'Urgente',
          labelColor: 'text-rose-700',
          Icon: AlertTriangle,
        };
      case 'warning':
        return {
          bar: 'bg-amber-500',
          border: 'border-amber-200 bg-amber-50/40',
          iconBg: 'bg-amber-100 text-amber-700',
          label: 'Importante',
          labelColor: 'text-amber-700',
          Icon: Megaphone,
        };
      case 'update':
        return {
          bar: 'bg-indigo-500',
          border: 'border-indigo-200 bg-indigo-50/35',
          iconBg: 'bg-indigo-100 text-indigo-700',
          label: 'Actualización',
          labelColor: 'text-indigo-700',
          Icon: Sparkles,
        };
      default:
        return {
          bar: 'bg-sky-500',
          border: 'border-slate-200 bg-white',
          iconBg: 'bg-sky-100 text-sky-700',
          label: 'Informativo',
          labelColor: 'text-sky-700',
          Icon: Info,
        };
    }
  };

  const audienceLabel = (aud?: InboxItem['audiencia']) => {
    if (aud === 'admin') return 'Administradores';
    if (aud === 'cashier') return 'Cajeros';
    return 'Todos';
  };

  return (
    <div
      className="fixed inset-0 z-[170] bg-slate-900/35 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl border border-slate-200/90 shadow-2xl max-w-2xl w-full max-h-[88vh] flex flex-col overflow-hidden animate-panel-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200/80 bg-gradient-to-r from-sky-50 via-white to-cyan-50/70 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-cyan-500 text-white flex items-center justify-center shadow-sm shrink-0">
              {tab === 'chat' ? (
                <MessageSquare className="w-5 h-5" />
              ) : isPushActive ? (
                <BellRing className="w-5 h-5" />
              ) : (
                <Bell className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <h3 className="text-base font-extrabold text-slate-900 truncate">
                Centro de Notificaciones y Chat
              </h3>
              <p className="text-xs text-slate-500 truncate">
                Alertas Push, bandeja de comunicados y mensajes directos del propietario
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer shrink-0 btn-press"
            aria-label="Cerrar notificaciones"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Bar */}
        <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-200/80 flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setTab('inbox')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
              tab === 'inbox'
                ? 'bg-sky-600 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            Notificaciones ({inboxItems.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('chat')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
              tab === 'chat'
                ? 'bg-indigo-600 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            Chat Innova Grup ({ownerChatMessages.length})
          </button>
        </div>

        {tab === 'chat' ? (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            {/* Chat Innova Grup Toolbar: Auto-reply toggle + Reset & Clear Chat */}
            <div className="px-4 py-2 bg-indigo-50/70 border-b border-indigo-100 flex flex-wrap items-center justify-between gap-2 shrink-0">
              <label className="inline-flex items-center gap-2 text-[11px] font-bold text-indigo-950 cursor-pointer">
                <input
                  type="checkbox"
                  checked={aiAutoReply}
                  onChange={(e) => setAiAutoReply(e.target.checked)}
                  className="rounded border-indigo-300 text-indigo-600"
                />
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                Auto-respuesta Innova Grup IA
              </label>

              <div className="flex items-center gap-1.5">
                {ownerChatMessages.length > 0 && !confirmClearChat && (
                  <>
                    <button
                      type="button"
                      onClick={() => setConfirmClearChat(true)}
                      className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                      title="Restablecer conversación"
                    >
                      <RotateCcw className="w-3 h-3" /> Restablecer
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClearChat(true)}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                      title="Borrar todo el chat"
                    >
                      <Trash2 className="w-3 h-3" /> Borrar chat
                    </button>
                  </>
                )}
                {confirmClearChat && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={clearingChat}
                      onClick={() => void handleClearChatHistory()}
                      className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer disabled:opacity-50"
                    >
                      {clearingChat ? 'Borrando...' : 'Sí, borrar'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClearChat(false)}
                      className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-slate-600 text-[11px] font-semibold cursor-pointer"
                    >
                      No
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 bg-slate-50/60 scrollbar-thin">
              {ownerChatMessages.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-white py-10 px-4 text-center space-y-2">
                  <Bot className="w-8 h-8 text-indigo-400 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Asistente Virtual Innova Grup</p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Escribe cualquier pregunta o mensaje abajo. El Asistente Virtual Innova Grup te
                    responderá automáticamente al instante y también quedará visible para el propietario.
                  </p>
                </div>
              ) : (
                ownerChatMessages.map((msg) => {
                  const isClient = msg.senderRole === 'client';
                  const isAi = msg.senderRole === 'ai_bot' || msg.aiGenerated;
                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isClient ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-xs shadow-2xs space-y-1 ${
                          isClient
                            ? 'bg-sky-600 text-white rounded-br-sm'
                            : isAi
                            ? 'bg-indigo-50 border border-indigo-200 text-slate-900 rounded-bl-sm'
                            : 'bg-white border border-slate-200 text-slate-900 rounded-bl-sm'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 text-[10px] font-bold opacity-80">
                          {isClient ? (
                            <span>Tú · {msg.senderName}</span>
                          ) : isAi ? (
                            <>
                              <Bot className="w-3 h-3 text-indigo-600" />
                              <span className="text-indigo-700">Innova Grup · Asistente Virtual</span>
                            </>
                          ) : (
                            <>
                              <Crown className="w-3 h-3 text-amber-600" />
                              <span className="text-slate-700">{msg.senderName || 'Propietario · Innova Grup'}</span>
                            </>
                          )}
                        </div>
                        <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                        <div
                          className={`text-[10px] font-mono ${
                            isClient ? 'text-sky-100 text-right' : 'text-slate-400'
                          }`}
                        >
                          {new Date(msg.timestamp).toLocaleString('es-VE', {
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              {aiReplying && (
                <div className="flex justify-start">
                  <div className="bg-indigo-50 border border-indigo-200 text-indigo-800 rounded-2xl rounded-bl-sm px-3.5 py-2 text-xs font-semibold inline-flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                    Innova Grup está respondiendo...
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {activeTenantId && (
              <form
                onSubmit={handleSendChatReply}
                className="p-3.5 border-t border-slate-200 bg-white flex items-center gap-2 shrink-0"
              >
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Escribe tu consulta para Innova Grup..."
                  maxLength={1200}
                  className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  disabled={sendingChat || aiReplying || !chatInput.trim()}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" /> Enviar
                </button>
              </form>
            )}
          </div>
        ) : (
          /* Scrollable Content */
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 scrollbar-thin">
            {/* Section 1: Push Notifications Activation */}
            <div
              className={`rounded-2xl border p-4 space-y-3 ${
                isPushActive
                  ? 'border-emerald-200 bg-emerald-50/50'
                  : isPushDenied
                  ? 'border-rose-200 bg-rose-50/40'
                  : 'border-sky-200/80 bg-sky-50/40'
              }`}
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isPushActive
                        ? 'bg-emerald-100 text-emerald-700'
                        : isPushDenied
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-sky-100 text-sky-700'
                    }`}
                  >
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-bold text-slate-900">
                        Notificaciones Push (Android & Web)
                      </h4>
                      <span
                        className={`text-[11px] font-bold ${
                          isPushActive
                            ? 'text-emerald-700'
                            : isPushDenied
                            ? 'text-rose-700'
                            : 'text-slate-500'
                        }`}
                      >
                        ·{' '}
                        {!pushSupported
                          ? 'No disponible en este navegador'
                          : isPushActive
                          ? 'Activas'
                          : isPushDenied
                          ? 'Bloqueadas en navegador'
                          : 'Desactivadas'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      {isPushActive
                        ? 'Recibirás alertas instantáneas del propietario, aprobaciones de membresía y respuestas de soporte en tu celular Android o navegador.'
                        : isPushDenied
                        ? 'Los permisos fueron bloqueados en el navegador. Toca el ícono del candado en la barra de dirección y habilita "Notificaciones".'
                        : 'Activa las notificaciones para enterarte al instante de comunicados del propietario, actualizaciones y soporte.'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  disabled={!pushSupported || togglingPush}
                  onClick={handleTogglePush}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center gap-2 cursor-pointer whitespace-nowrap btn-press disabled:opacity-50 ${
                    isPushActive
                      ? 'bg-white border border-slate-200 hover:bg-slate-50 text-slate-700'
                      : 'bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white shadow-xs'
                  }`}
                >
                  {isPushActive ? (
                    <>
                      <BellOff className="w-4 h-4 text-slate-500" /> Silenciar notificaciones
                    </>
                  ) : (
                    <>
                      <BellRing className="w-4 h-4" /> Activar notificaciones
                    </>
                  )}
                </button>

                {isPushActive && (
                  <button
                    type="button"
                    disabled={testingPush}
                    onClick={handleTestPush}
                    className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap btn-press disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" /> Probar notificación
                  </button>
                )}
              </div>
            </div>

            {/* Section 2: Inbox History */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Megaphone className="w-4 h-4 text-sky-600" />
                  <h4 className="text-sm font-extrabold text-slate-900">
                    Bandeja de Notificaciones
                  </h4>
                  <span className="text-xs font-mono font-bold text-slate-500 tabular-nums">
                    ({inboxItems.length})
                  </span>
                </div>

                {inboxItems.length > 0 && !confirmClearAll && (
                  <button
                    type="button"
                    onClick={() => setConfirmClearAll(true)}
                    className="px-3 py-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap btn-press"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Vaciar bandeja
                  </button>
                )}
              </div>

              {/* In-app Clear All Confirmation */}
              {confirmClearAll && (
                <div className="rounded-2xl border border-rose-300 bg-rose-50 p-3.5 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-rose-900 font-semibold">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>
                      ¿Seguro que deseas eliminar todas las notificaciones ({inboxItems.length})?
                    </span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      disabled={clearingAll}
                      onClick={handleClearAll}
                      className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer whitespace-nowrap disabled:opacity-50"
                    >
                      {clearingAll ? 'Vaciando...' : 'Sí, vaciar todo'}
                    </button>
                    <button
                      type="button"
                      disabled={clearingAll}
                      onClick={() => setConfirmClearAll(false)}
                      className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer whitespace-nowrap"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}

              {inboxItems.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 py-10 px-4 text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Tu bandeja está vacía</p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Aquí aparecerán todas las notificaciones y comunicados enviados por el propietario
                    del sistema.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {inboxItems.map((item) => {
                    const vis = getTypeVisual(item.tipo);
                    const TypeIcon = vis.Icon;
                    const isDeleting = busyKey === item.key;
                    const dateLabel = item.timestamp
                      ? new Date(item.timestamp).toLocaleString('es-VE', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'Reciente';

                    return (
                      <div
                        key={item.key}
                        className={`relative rounded-2xl border overflow-hidden transition-all ${vis.border}`}
                      >
                        <div className={`absolute left-0 top-0 bottom-0 w-1 ${vis.bar}`} />
                        <div className="pl-4 pr-3.5 py-3.5 flex items-start gap-3">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${vis.iconBg}`}
                          >
                            <TypeIcon className="w-4 h-4" />
                          </div>

                          <div className="flex-1 min-w-0 space-y-1">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <h5 className="text-sm font-bold text-slate-900 leading-snug">
                                  {item.titulo}
                                </h5>
                                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-slate-500 mt-0.5">
                                  <span className={`font-bold ${vis.labelColor}`}>{vis.label}</span>
                                  <span>·</span>
                                  <span>De: {item.enviado_por || 'Propietario'}</span>
                                  <span>·</span>
                                  <span>Para: {audienceLabel(item.audiencia)}</span>
                                </div>
                              </div>

                              <button
                                type="button"
                                disabled={isDeleting}
                                onClick={() => handleDeleteOne(item.key)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer shrink-0 transition-colors disabled:opacity-40"
                                title="Eliminar esta notificación"
                                aria-label={`Eliminar notificación ${item.titulo}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                            <p className="text-xs text-slate-700 whitespace-pre-wrap leading-relaxed pt-1">
                              {item.texto}
                            </p>

                            {onOpenVerification &&
                              (item.key.startsWith('verif_') ||
                                /verificaci[oó]n|actualizaci[oó]n de datos|documentos/i.test(
                                  `${item.titulo} ${item.texto}`
                                )) && (
                                <div className="pt-2">
                                  <button
                                    type="button"
                                    onClick={() => onOpenVerification()}
                                    className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold inline-flex items-center gap-1.5 shadow-xs cursor-pointer btn-press"
                                  >
                                    <ClipboardCheck className="w-3.5 h-3.5" />
                                    Verificar ahora
                                  </button>
                                </div>
                              )}

                            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 pt-1 font-mono tabular-nums">
                              <Clock className="w-3 h-3" />
                              <span>{dateLabel}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200/80 bg-slate-50/70 flex items-center justify-between gap-2 shrink-0">
          <span className="text-[11px] text-slate-500">
            {isPushActive ? 'Alertas Push activas en este dispositivo' : 'Push en pausa'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer btn-press"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
