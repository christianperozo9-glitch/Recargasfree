import React from 'react';
import { Laptop, Monitor, Smartphone } from 'lucide-react';
import { usePos, type ViewMode } from '../context/PosContext';

interface ViewModeToggleProps {
  compact?: boolean;
  tone?: 'light' | 'dark';
}

const OPTIONS: { id: ViewMode; label: string; shortLabel: string; Icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'auto', label: 'Auto', shortLabel: 'Auto', Icon: Laptop },
  { id: 'desktop', label: 'Escritorio', shortLabel: 'PC', Icon: Monitor },
  { id: 'mobile', label: 'Móvil', shortLabel: 'Móvil', Icon: Smartphone },
];

export const ViewModeToggle: React.FC<ViewModeToggleProps> = ({
  compact = false,
  tone = 'light',
}) => {
  const { viewMode, setViewMode, notifyToast } = usePos();

  const handleSelect = (mode: ViewMode) => {
    setViewMode(mode);
    const label =
      mode === 'desktop'
        ? 'Modo Escritorio activado'
        : mode === 'mobile'
        ? 'Modo Móvil activado'
        : 'Modo Adaptable (Auto) activado';
    notifyToast(label, 'info');
  };

  return (
    <div
      className={`inline-flex items-center gap-0.5 p-1 rounded-xl shrink-0 ${
        tone === 'dark'
          ? 'bg-white/10 border border-white/15'
          : 'bg-slate-100 border border-slate-200'
      }`}
      role="group"
      aria-label="Modo de pantalla"
    >
      {OPTIONS.map(({ id, label, shortLabel, Icon }) => {
        const active = viewMode === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => handleSelect(id)}
            title={`Cambiar a vista ${label}`}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
              active
                ? tone === 'dark'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : tone === 'dark'
                ? 'text-white/85 hover:text-white hover:bg-white/10'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Icon className="w-3.5 h-3.5 shrink-0" />
            <span>{compact ? shortLabel : label}</span>
          </button>
        );
      })}
    </div>
  );
};
