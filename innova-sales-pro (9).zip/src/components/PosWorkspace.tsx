import React, { useEffect, useMemo, useState } from 'react';
import {
  Ban,
  Boxes,
  Calculator,
  Camera,
  Check,
  CreditCard,
  FileDown,
  FileText,
  Minus,
  Percent,
  Plus,
  Printer,
  Scale,
  Search,
  ShoppingBasket,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import type { Product } from '../types/pos';
import { attachUniversalWedgeDetector, subscribeHardwareScans } from '../utils/barcodeScanner';
import { formatRateNumber } from '../utils/currencies';
import { evaluateMathExpression, formatMoney } from '../utils/format';
import { generateInvoicePDF, generatePresupuestoPDF } from '../utils/pdfGenerator';
import { ProductThumb } from './ProductThumb';

interface PosWorkspaceProps {
  onOpenPayment: () => void;
  onOpenScanner: (target: 'sale' | 'register', onScanned?: (code: string) => void) => void;
  onOpenDevices?: () => void;
  onOpenVoidInvoice?: () => void;
  mobileView: 'catalog' | 'cart';
}

type CatalogFilter = 'all' | 'in_stock' | 'low' | 'frac' | 'bulto';

export const PosWorkspace: React.FC<PosWorkspaceProps> = ({
  onOpenPayment,
  onOpenScanner,
  onOpenDevices,
  onOpenVoidInvoice,
  mobileView,
}) => {
  const {
    role,
    cashierPermissions,
    products,
    liveSales,
    bcvRate,
    secondaryRate,
    tertiaryRate,
    localCurrencyCode,
    localCurrency,
    rateEditable,
    updateRate,
    cart,
    selectedSaleRate,
    setSelectedSaleRate,
    ivaActive,
    toggleIva,
    globalParallelOverrideVes,
    setGlobalParallelOverrideVes,
    addToCart,
    updateCartQty,
    removeFromCart,
    setCartItemDiscount,
    clearCart,
    getEffectiveUnitPrice,
    getActiveRateValue,
    cartTotals,
    localName,
    isMobileLayout,
    activePrinter,
    invoiceMode,
    setInvoiceMode,
    lastCompletedSale,
    dispatchSaleInvoice,
    notifyToast,
    playBeep,
  } = usePos();

  const canEditRates =
    (role === 'owner' || rateEditable) &&
    (role !== 'cashier' || cashierPermissions.editar_tasas === true);
  const canDiscount = role !== 'cashier' || cashierPermissions.aplicar_rebajas === true;
  const canVoidInvoice = role !== 'cashier' || cashierPermissions.anular_factura === true;
  const canTools = role !== 'cashier' || cashierPermissions.herramientas === true;

  const [searchQuery, setSearchQuery] = useState('');
  const [browseAll, setBrowseAll] = useState(true);
  const [catalogFilter, setCatalogFilter] = useState<CatalogFilter>('all');
  const [qtyModalProduct, setQtyModalProduct] = useState<Product | null>(null);
  const [qtyModalMode, setQtyModalMode] = useState<'detal' | 'bulto'>('detal');
  const [qtyInput, setQtyInput] = useState('1');

  // Per-item discount modal
  const [discountProduct, setDiscountProduct] = useState<{
    cartKey: string;
    label: string;
    priceVes: string;
  } | null>(null);

  // Parallel calculator modal
  const [parallelCalcOpen, setParallelCalcOpen] = useState(false);
  const [parallelUsd, setParallelUsd] = useState('');
  const [parallelVes, setParallelVes] = useState('');

  // Inline rate editor modal
  const [editingRate, setEditingRate] = useState<'bcv' | 'secundaria' | 'terciaria' | null>(null);
  const [rateDraft, setRateDraft] = useState('');

  // Presupuesto client prompt modal (replaces window.prompt safely in iframes)
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [quoteClientName, setQuoteClientName] = useState('');

  // Auxiliary calculator
  const [calcOpen, setCalcOpen] = useState(false);
  const [calcExpr, setCalcExpr] = useState('');

  // Universal barcode scanner listener (USB wired HID, 2.4GHz wireless, Bluetooth HID, WebHID & Serial COM)
  useEffect(() => {
    const processScannedCode = (rawCode: string) => {
      const code = rawCode.trim().toLowerCase();
      if (!code) return;
      const matched = products.find(
        (p) => (p.barcode || '').toLowerCase() === code || (p.id || '').toLowerCase() === code
      );
      if (matched) {
        if (matched.stock <= 0) {
          notifyToast(`"${matched.id}" agotado en inventario.`, 'warning');
          playBeep('err');
        } else {
          addToCart(matched, 1);
          setSearchQuery('');
          notifyToast(`Escaneado: ${matched.id}`, 'success');
        }
      } else {
        setSearchQuery(rawCode.trim());
        notifyToast(`Código "${rawCode.trim()}" no encontrado en inventario.`, 'warning');
        playBeep('err');
      }
    };

    const unsubWedge = attachUniversalWedgeDetector(
      (ev) => {
        if (ev.transport === 'hid-keyboard') {
          processScannedCode(ev.code);
        }
      },
      { allowInsideInputs: true }
    );
    const unsubHw = subscribeHardwareScans((ev) => {
      if (ev.transport !== 'hid-keyboard') {
        processScannedCode(ev.code);
      }
    });

    return () => {
      unsubWedge();
      unsubHw();
    };
  }, [addToCart, notifyToast, playBeep, products]);

  const liveMetrics = useMemo(() => {
    let totalBs = 0;
    let totalUsd = 0;
    liveSales.forEach((v) => {
      totalBs += Number(v.monto_total_ves) || 0;
      totalUsd += Number(v.monto_total_usd_bcv) || 0;
    });
    return { count: liveSales.length, totalBs, totalUsd };
  }, [liveSales]);

  const matchedProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const filterFn = (p: Product) => {
      if (catalogFilter === 'in_stock' && p.stock <= 0) return false;
      if (catalogFilter === 'low' && (p.stock <= 0 || p.stock > 5)) return false;
      if (catalogFilter === 'frac' && !p.fraccionable) return false;
      if (catalogFilter === 'bulto' && !(p.ventaPorBulto && (p.unidadesPorBulto || 0) > 1)) return false;
      return true;
    };

    if (!q) {
      if (!browseAll) return [];
      return products.filter(filterFn).slice(0, 48);
    }
    const results: Product[] = [];
    for (let i = 0; i < products.length; i++) {
      const p = products[i];
      if (!filterFn(p)) continue;
      if ((p.id || '').toLowerCase().includes(q) || (p.barcode && p.barcode.toLowerCase().includes(q))) {
        results.push(p);
        if (results.length >= 48) break;
      }
    }
    return results;
  }, [browseAll, catalogFilter, products, searchQuery]);

  const openQtyModal = (p: Product, preferredMode: 'detal' | 'bulto' = 'detal') => {
    if (p.stock <= 0) {
      notifyToast('Producto agotado en inventario.', 'warning');
      return;
    }
    const supportsBulto = p.ventaPorBulto === true && (Number(p.unidadesPorBulto) || 0) > 1;
    setQtyModalProduct(p);
    setQtyModalMode(preferredMode === 'bulto' && supportsBulto ? 'bulto' : 'detal');
    setQtyInput('1');
  };

  const confirmQtyModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qtyModalProduct) return;
    const val = Number(qtyInput) || 0;
    addToCart(qtyModalProduct, val, qtyModalMode);
    setQtyModalProduct(null);
  };

  const openParallelCalc = () => {
    if (cart.length === 0) {
      notifyToast('Agrega artículos al carrito primero.', 'warning');
      return;
    }
    setSelectedSaleRate('2');
    const sumUsd = cart.reduce(
      (acc, i) => acc + getEffectiveUnitPrice(i.product, i.saleUnit || 'detal') * i.quantity,
      0
    );
    setParallelUsd(sumUsd.toFixed(2));
    setParallelVes((sumUsd * secondaryRate).toFixed(2));
    setParallelCalcOpen(true);
  };

  const handleOpenPresupuesto = () => {
    if (cart.length === 0) {
      notifyToast('Agrega productos al carrito para generar un presupuesto.', 'warning');
      return;
    }
    setQuoteClientName('');
    setQuoteModalOpen(true);
  };

  const handleGeneratePresupuesto = (e: React.FormEvent) => {
    e.preventDefault();
    const rate = getActiveRateValue();
    const factor = ivaActive ? 1.16 : 1;
    generatePresupuestoPDF(
      localName,
      quoteClientName.trim(),
      cart.map((i) => {
        const isBulto = i.saleUnit === 'bulto' && (Number(i.product.unidadesPorBulto) || 0) > 1;
        return {
          name: isBulto ? `${i.product.id} (Bulto ×${i.product.unidadesPorBulto})` : i.product.id,
          quantity: i.quantity,
          unitUsd: getEffectiveUnitPrice(i.product, i.saleUnit || 'detal'),
        };
      }),
      rate,
      factor
    );
    setQuoteModalOpen(false);
    notifyToast('Presupuesto PDF descargado.', 'success');
  };

  const handleCalcPress = (key: string) => {
    if (key === 'C') setCalcExpr('');
    else if (key === '=') setCalcExpr(evaluateMathExpression(calcExpr));
    else setCalcExpr((prev) => (prev === 'Error' ? key : prev + key));
  };

  const cycleInvoiceMode = () => {
    const order = ['auto', 'pdf', 'printer', 'none'] as const;
    const next = order[(order.indexOf(invoiceMode) + 1) % order.length];
    setInvoiceMode(next);
    const label =
      next === 'auto'
        ? activePrinter
          ? `Automático (Impresora: ${activePrinter.name})`
          : 'Automático (PDF si no hay impresora)'
        : next === 'pdf'
        ? 'Siempre PDF automático'
        : next === 'printer'
        ? 'Impresora térmica / navegador'
        : 'Solo registrar venta';
    notifyToast(`Facturación al cobrar: ${label}`, 'info');
  };

  const rateToUse = getActiveRateValue();

  return (
    <div className={isMobileLayout ? 'flex-1 w-full' : 'flex-1 w-full'}>
      <div
        className={
          isMobileLayout
            ? 'grid grid-cols-1 gap-4 items-start'
            : 'grid grid-cols-[minmax(0,1fr)_390px] xl:grid-cols-[minmax(0,1fr)_430px] gap-5 items-start'
        }
      >
        {/* Left Column: Catalog & Live Shift Monitor */}
        <div
          className={`space-y-4 min-w-0 ${
            isMobileLayout && mobileView === 'cart' ? 'hidden' : 'block'
          }`}
        >
          {/* Desktop/Mobile KPI & Exchange Rates Header Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              {/* Exchange Rate Quick Tiles */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                <button
                  type="button"
                  onClick={() => {
                    if (!canEditRates) {
                      setSelectedSaleRate('1');
                      setGlobalParallelOverrideVes(null);
                      return;
                    }
                    setEditingRate('bcv');
                    setRateDraft(formatRateNumber(bcvRate, localCurrencyCode));
                  }}
                  className={`px-3 py-2 rounded-xl border text-left transition-colors cursor-pointer ${
                    selectedSaleRate === '1'
                      ? 'border-emerald-300 bg-emerald-50/70'
                      : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100'
                  }`}
                  title={
                    canEditRates
                      ? `Editar ${localCurrency.rateLabel} (USD → ${localCurrency.code})`
                      : `Seleccionar ${localCurrency.rateLabel}`
                  }
                >
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    USD → {localCurrency.rateLabel}
                  </span>
                  <span className="font-mono tabular-nums font-extrabold text-sm text-emerald-700">
                    {formatRateNumber(bcvRate, localCurrencyCode)} {localCurrency.shortLabel}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!canEditRates) {
                      setSelectedSaleRate('2');
                      setGlobalParallelOverrideVes(null);
                      return;
                    }
                    setEditingRate('secundaria');
                    setRateDraft(formatRateNumber(secondaryRate, localCurrencyCode));
                  }}
                  className={`px-3 py-2 rounded-xl border text-left transition-colors cursor-pointer ${
                    selectedSaleRate === '2'
                      ? 'border-sky-300 bg-sky-50/70'
                      : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100'
                  }`}
                  title={canEditRates ? 'Editar Tasa 2 / Paralelo 1' : 'Seleccionar Tasa 2'}
                >
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    {localCurrencyCode === 'VES' ? 'Paralelo 1' : 'Tasa Ref. 2'}
                  </span>
                  <span className="font-mono tabular-nums font-extrabold text-sm text-sky-700">
                    {formatRateNumber(secondaryRate, localCurrencyCode)} {localCurrency.shortLabel}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!canEditRates) {
                      setSelectedSaleRate('3');
                      setGlobalParallelOverrideVes(null);
                      return;
                    }
                    setEditingRate('terciaria');
                    setRateDraft(formatRateNumber(tertiaryRate, localCurrencyCode));
                  }}
                  className={`px-3 py-2 rounded-xl border text-left transition-colors cursor-pointer ${
                    selectedSaleRate === '3'
                      ? 'border-indigo-300 bg-indigo-50/70'
                      : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100'
                  }`}
                  title={canEditRates ? 'Editar Tasa 3 / Paralelo 2' : 'Seleccionar Tasa 3'}
                >
                  <span className="text-[11px] font-semibold text-slate-500 block">
                    {localCurrencyCode === 'VES' ? 'Paralelo 2' : 'Tasa Ref. 3'}
                  </span>
                  <span className="font-mono tabular-nums font-extrabold text-sm text-indigo-700">
                    {formatRateNumber(tertiaryRate, localCurrencyCode)} {localCurrency.shortLabel}
                  </span>
                </button>
              </div>

              {/* Shift KPIs + Tools */}
              <div className="flex flex-wrap items-center gap-2.5 ml-auto">
                <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-right">
                  <span className="text-[11px] font-medium text-slate-500 block">
                    Turno activo · {liveMetrics.count} {liveMetrics.count === 1 ? 'venta' : 'ventas'}
                  </span>
                  <div className="flex items-baseline gap-2 justify-end tabular-nums">
                    <span className="font-mono font-extrabold text-sm text-emerald-700">
                      ${liveMetrics.totalUsd.toFixed(2)}
                    </span>
                    <span className="font-mono font-bold text-xs text-slate-700">
                      {formatMoney(liveMetrics.totalBs)} {localCurrency.shortLabel}
                    </span>
                  </div>
                </div>

                {/* Printer / Invoice mode status quick action */}
                <button
                  type="button"
                  onClick={() => (onOpenDevices ? onOpenDevices() : cycleInvoiceMode())}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                    activePrinter
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                  title="Configurar impresora o facturación PDF"
                >
                  <Printer className="w-4 h-4 shrink-0" />
                  <span className="hidden sm:inline">
                    {activePrinter
                      ? activePrinter.name
                      : invoiceMode === 'pdf'
                      ? 'Auto PDF'
                      : invoiceMode === 'printer'
                      ? 'Impresora'
                      : invoiceMode === 'none'
                      ? 'Sin factura'
                      : 'Auto (PDF / Impresora)'}
                  </span>
                </button>

                {lastCompletedSale && (
                  <button
                    type="button"
                    onClick={() => void dispatchSaleInvoice(lastCompletedSale)}
                    className="px-2.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    title="Reimprimir / descargar última factura"
                  >
                    <FileDown className="w-4 h-4 text-sky-600" />
                    <span className="hidden xl:inline">Última Factura</span>
                  </button>
                )}

                {canVoidInvoice && onOpenVoidInvoice && (
                  <button
                    type="button"
                    onClick={onOpenVoidInvoice}
                    className="px-2.5 py-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    title="Anular factura y devolver stock (requiere autorización Admin)"
                  >
                    <Ban className="w-4 h-4 shrink-0" />
                    <span className="hidden xl:inline">Anular Factura</span>
                  </button>
                )}

                {canTools && (
                  <button
                    type="button"
                    onClick={() => setCalcOpen((v) => !v)}
                    className={`p-2.5 rounded-xl border cursor-pointer ${
                      calcOpen
                        ? 'border-sky-500 bg-sky-50 text-sky-700'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                    title="Calculadora auxiliar"
                  >
                    <Calculator className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Search, Barcode Scanner & Filter Strip */}
          <div className="bg-white rounded-2xl border border-slate-200 p-3.5 space-y-2.5">
            <div className="flex gap-2.5">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  id="pos-search-input"
                  data-scanner-input="true"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && searchQuery.trim().length >= 3) {
                      const code = searchQuery.trim().toLowerCase();
                      const exact = products.find(
                        (p) => (p.barcode || '').toLowerCase() === code
                      );
                      if (exact) {
                        e.preventDefault();
                        if (exact.stock > 0) {
                          addToCart(exact, 1);
                          setSearchQuery('');
                        } else {
                          notifyToast(`"${exact.id}" agotado.`, 'warning');
                        }
                      }
                    }
                  }}
                  placeholder="Buscar producto por nombre o escanear código de barras (F2)..."
                  className="w-full pl-10 pr-9 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-700 cursor-pointer"
                    aria-label="Limpiar búsqueda"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() =>
                  onOpenScanner('sale', (code) => {
                    setSearchQuery(code);
                    const found = products.find(
                      (p) => (p.barcode || '').toLowerCase() === code.toLowerCase()
                    );
                    if (found) openQtyModal(found);
                  })
                }
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 shadow-xs btn-press"
              >
                <Camera className="w-4 h-4" />
                <span className="hidden sm:inline">Escáner</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: 'all', label: `Todos (${products.length})` },
                    { id: 'in_stock', label: 'Disponibles' },
                    { id: 'bulto', label: 'Por Bulto' },
                    { id: 'frac', label: 'Fraccionables' },
                    { id: 'low', label: 'Stock bajo' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      setCatalogFilter(f.id);
                      setBrowseAll(true);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-semibold cursor-pointer transition-all whitespace-nowrap btn-press ${
                      catalogFilter === f.id
                        ? 'bg-sky-500 text-white shadow-xs'
                        : 'bg-sky-50/70 text-slate-700 hover:bg-sky-100/80 hover:text-sky-800'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
              {!searchQuery.trim() && (
                <button
                  type="button"
                  onClick={() => setBrowseAll((v) => !v)}
                  className="text-sky-700 font-semibold hover:underline cursor-pointer"
                >
                  {browseAll ? 'Ocultar catálogo' : 'Mostrar catálogo'}
                </button>
              )}
            </div>
          </div>

          {/* Catalog Grid */}
          {!searchQuery.trim() && !browseAll ? (
            <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 sm:p-10 text-center space-y-3">
              <Search className="w-8 h-8 text-slate-300 mx-auto" />
              <div>
                <h3 className="text-sm font-bold text-slate-800">
                  Catálogo sincronizado ({products.length} artículos)
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Escribe el nombre, referencia o escanea un código de barras para mostrar resultados
                  instantáneos con sus 3 niveles de precio.
                </p>
              </div>
              {products.length > 0 && (
                <button
                  type="button"
                  onClick={() => setBrowseAll(true)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold cursor-pointer"
                >
                  Mostrar catálogo de productos
                </button>
              )}
            </div>
          ) : matchedProducts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
              <p className="text-sm font-semibold text-rose-600">
                No se encontraron productos para esta búsqueda o filtro
              </p>
            </div>
          ) : (
            <div
              className={`grid gap-3.5 ${
                isMobileLayout
                  ? 'grid-cols-1'
                  : 'grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4'
              }`}
            >
              {matchedProducts.map((p) => {
                const p1 = p.price;
                const isOut = p.stock <= 0;
                const isLow = p.stock > 0 && p.stock <= 5;
                const supportsBulto =
                  p.ventaPorBulto === true && (Number(p.unidadesPorBulto) || 0) > 1;
                const upb = supportsBulto ? Number(p.unidadesPorBulto) : 1;
                const bultoUsd = supportsBulto ? getEffectiveUnitPrice(p, 'bulto') : 0;
                const availableBultos = supportsBulto ? Math.floor(p.stock / upb) : 0;
                const inCartDetal = cart.find(
                  (c) => c.product.key === p.key && (c.saleUnit || 'detal') === 'detal'
                );
                const inCartBulto = cart.find(
                  (c) => c.product.key === p.key && c.saleUnit === 'bulto'
                );
                const hasInCart = Boolean(inCartDetal || inCartBulto);

                return (
                  <div
                    key={p.key}
                    className={`bg-white/95 rounded-2xl border p-4 flex flex-col justify-between card-lift ${
                      hasInCart
                        ? 'border-sky-300 ring-1 ring-sky-200 bg-sky-50/25'
                        : isOut
                        ? 'border-rose-200 bg-rose-50/40 opacity-75'
                        : isLow
                        ? 'border-amber-200'
                        : 'border-slate-200/80'
                    }`}
                  >
                    <div>
                      <div className="flex items-start gap-3 mb-3">
                        <ProductThumb name={p.id} image={p.image} className="w-13 h-13 text-sm shrink-0" />
                        <div className="min-w-0 flex-1">
                          <h4 className="font-bold text-sm text-slate-900 line-clamp-2 leading-snug">
                            {p.id}
                          </h4>
                          <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-slate-500 mt-1 font-mono tabular-nums">
                            <span className="truncate max-w-[110px]">{p.barcode || 'Sin código'}</span>
                            <span>·</span>
                            <span
                              className={`font-semibold ${
                                isOut
                                  ? 'text-rose-600'
                                  : isLow
                                  ? 'text-amber-700'
                                  : 'text-slate-700'
                              }`}
                            >
                              {isOut
                                ? 'Agotado'
                                : supportsBulto
                                ? `${p.stock} uds (${availableBultos} bult.)`
                                : `${p.stock} uds`}
                            </span>
                            {p.fraccionable && (
                              <span className="text-[10px] font-sans font-bold text-cyan-700">
                                · Fracc.
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 space-y-2.5">
                      <div className="space-y-0.5 text-xs font-mono tabular-nums">
                        <div
                          className={`flex justify-between ${
                            selectedSaleRate === '1'
                              ? 'text-emerald-700 font-extrabold'
                              : 'text-slate-600'
                          }`}
                        >
                          <span>{localCurrency.rateLabel}</span>
                          <span>
                            ${p1.toFixed(2)} · {formatMoney(p1 * bcvRate)} {localCurrency.shortLabel}
                          </span>
                        </div>
                        <div
                          className={`flex justify-between ${
                            selectedSaleRate === '2' ? 'text-sky-700 font-extrabold' : 'text-slate-600'
                          }`}
                        >
                          <span>{localCurrencyCode === 'VES' ? 'P1' : 'T2'}</span>
                          <span>
                            ${p1.toFixed(2)} · {formatMoney(p1 * secondaryRate)} {localCurrency.shortLabel}
                          </span>
                        </div>
                        <div
                          className={`flex justify-between ${
                            selectedSaleRate === '3'
                              ? 'text-indigo-700 font-extrabold'
                              : 'text-slate-600'
                          }`}
                        >
                          <span>{localCurrencyCode === 'VES' ? 'P2' : 'T3'}</span>
                          <span>
                            ${p1.toFixed(2)} · {formatMoney(p1 * tertiaryRate)} {localCurrency.shortLabel}
                          </span>
                        </div>
                      </div>

                      {supportsBulto && (
                        <div className="px-2.5 py-1.5 rounded-xl bg-indigo-50/80 border border-indigo-200/70 flex items-center justify-between gap-2 text-[11px] font-mono tabular-nums">
                          <span className="font-sans font-bold text-indigo-800 inline-flex items-center gap-1">
                            <Boxes className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                            Bulto ×{upb}
                          </span>
                          <span className="font-extrabold text-indigo-900">
                            ${bultoUsd.toFixed(2)} · {formatMoney(bultoUsd * rateToUse)} {localCurrency.shortLabel}
                          </span>
                        </div>
                      )}

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          disabled={isOut}
                          onClick={() => openQtyModal(p, 'detal')}
                          className="flex-1 py-2 px-2 rounded-xl border border-slate-200 bg-white hover:bg-sky-50 hover:border-sky-200 hover:text-sky-700 disabled:opacity-40 text-slate-700 text-xs font-semibold cursor-pointer whitespace-nowrap btn-press"
                        >
                          {hasInCart
                            ? `En caja (${[
                                inCartDetal ? `${inCartDetal.quantity}u` : '',
                                inCartBulto ? `${inCartBulto.quantity}b` : '',
                              ]
                                .filter(Boolean)
                                .join('+')})`
                            : p.fraccionable
                            ? 'Fracc. / Cant.'
                            : 'Cantidad...'}
                        </button>
                        <button
                          type="button"
                          disabled={isOut}
                          onClick={() => addToCart(p, 1, 'detal')}
                          className="px-2.5 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 disabled:bg-slate-200 disabled:from-slate-200 disabled:to-slate-200 disabled:text-slate-400 text-white text-xs font-bold inline-flex items-center justify-center gap-1 shrink-0 cursor-pointer shadow-xs btn-press whitespace-nowrap"
                          aria-label={`Agregar 1 unidad de ${p.id}`}
                          title="Agregar 1 unidad al detal"
                        >
                          <Plus className="w-3.5 h-3.5" /> {supportsBulto ? 'Detal' : '1'}
                        </button>
                        {supportsBulto && (
                          <button
                            type="button"
                            disabled={availableBultos < 1}
                            onClick={() => addToCart(p, 1, 'bulto')}
                            className="px-2.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs font-bold inline-flex items-center justify-center gap-1 shrink-0 cursor-pointer shadow-xs btn-press whitespace-nowrap"
                            aria-label={`Agregar 1 bulto de ${p.id}`}
                            title={
                              availableBultos < 1
                                ? `Stock insuficiente para 1 bulto completo (${upb} uds)`
                                : `Agregar 1 bulto (×${upb} uds)`
                            }
                          >
                            <Boxes className="w-3.5 h-3.5" /> Bulto
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Sticky Cart & Rate Mode */}
        <div
          className={`bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col ${
            isMobileLayout
              ? mobileView === 'catalog'
                ? 'hidden'
                : 'flex'
              : 'flex sticky top-20 max-h-[calc(100vh-6rem)]'
          }`}
        >
          <div className="px-4 py-3.5 border-b border-slate-200 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <ShoppingBasket className="w-4 h-4 text-sky-600 shrink-0" />
              <h2 className="font-bold text-sm text-slate-900 truncate">Carrito de Compra</h2>
              <span className="text-xs font-mono font-semibold text-slate-500 tabular-nums shrink-0">
                ({cart.length})
              </span>
            </div>
            {cart.length > 0 && (
              <button
                type="button"
                onClick={clearCart}
                className="px-2.5 py-1 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                title="Cancelar y vaciar carrito"
              >
                <X className="w-3.5 h-3.5" /> Vaciar
              </button>
            )}
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5 min-h-[200px] scrollbar-thin">
            {cart.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <ShoppingBasket className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-xs font-medium">El carrito está vacío</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Haz clic en "+1" o escanea un producto para comenzar
                </p>
              </div>
            ) : (
              cart.map((item) => {
                const isDiscounted = item.customDiscountVes !== null;
                const isBulto =
                  item.saleUnit === 'bulto' &&
                  item.product.ventaPorBulto === true &&
                  (Number(item.product.unidadesPorBulto) || 0) > 1;
                const lineKey = item.cartKey || `${item.product.key}__${item.saleUnit || 'detal'}`;
                const unitUsd = getEffectiveUnitPrice(item.product, isBulto ? 'bulto' : 'detal');
                const originalBs = unitUsd * rateToUse;
                const activeBs = isDiscounted ? item.customDiscountVes! : originalBs;
                const displayUsd = isDiscounted ? (rateToUse > 0 ? activeBs / rateToUse : 0) : unitUsd;
                const lineBs = activeBs * item.quantity;

                return (
                  <div
                    key={lineKey}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                      isDiscounted
                        ? 'border-amber-300 bg-amber-50/40'
                        : isBulto
                        ? 'border-indigo-200 bg-indigo-50/40'
                        : 'border-slate-200 bg-slate-50/60'
                    }`}
                  >
                    <ProductThumb name={item.product.id} image={item.product.image} className="w-10 h-10 text-xs shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className="text-xs font-bold text-slate-900 truncate">{item.product.id}</p>
                        {isBulto && (
                          <span className="text-[10px] font-bold text-indigo-700 font-mono">
                            [BULTO ×{item.product.unidadesPorBulto}]
                          </span>
                        )}
                        {isDiscounted && (
                          <span className="text-[10px] font-bold text-amber-700">Rebaja</span>
                        )}
                      </div>
                      <p className="text-[11px] font-mono tabular-nums text-slate-600 mt-0.5">
                        <b className="text-emerald-800">${(displayUsd * item.quantity).toFixed(2)}</b> ·{' '}
                        <b className="text-slate-900">
                          {formatMoney(lineBs)} {localCurrency.shortLabel}
                        </b>{' '}
                        <span className="text-slate-400">
                          (${displayUsd.toFixed(2)} c/u)
                        </span>
                        {isBulto && (
                          <span className="text-indigo-700 ml-1">
                            ({item.quantity * (item.product.unidadesPorBulto || 1)} uds)
                          </span>
                        )}
                      </p>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {canDiscount && (
                        <button
                          type="button"
                          onClick={() =>
                            setDiscountProduct({
                              cartKey: lineKey,
                              label: isBulto
                                ? `${item.product.id} (Bulto ×${item.product.unidadesPorBulto})`
                                : item.product.id,
                              priceVes: activeBs.toFixed(2),
                            })
                          }
                          title="Aplicar rebaja"
                          className="w-7 h-7 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-800 flex items-center justify-center cursor-pointer"
                        >
                          <Tag className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => updateCartQty(lineKey, -1)}
                        className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 flex items-center justify-center cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-mono tabular-nums font-bold w-8 text-center">
                        {!isBulto && item.product.fraccionable ? item.quantity.toFixed(2) : item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateCartQty(lineKey, 1)}
                        className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 flex items-center justify-center cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeFromCart(lineKey)}
                        title="Quitar artículo"
                        className="w-7 h-7 rounded-lg text-rose-600 hover:bg-rose-50 flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Rate Selection & Totals */}
          <div className="p-4 border-t border-slate-200 space-y-3 bg-slate-50/70 rounded-b-2xl">
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setSelectedSaleRate('1');
                  setGlobalParallelOverrideVes(null);
                }}
                className={`py-2 px-2 rounded-xl border text-[11px] font-bold cursor-pointer transition-all btn-press ${
                  selectedSaleRate === '1'
                    ? 'bg-emerald-500 text-white border-emerald-500 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-emerald-50/70'
                }`}
              >
                {localCurrency.rateLabel} · {formatRateNumber(bcvRate, localCurrencyCode)}
              </button>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedSaleRate('2');
                    setGlobalParallelOverrideVes(null);
                  }}
                  className={`w-full py-2 px-2 rounded-xl border text-[11px] font-bold cursor-pointer transition-colors ${
                    selectedSaleRate === '2'
                      ? 'bg-sky-600 text-white border-sky-600'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {localCurrencyCode === 'VES' ? 'P1' : 'T2'} · {formatRateNumber(secondaryRate, localCurrencyCode)}
                </button>
                {canDiscount && (
                  <button
                    type="button"
                    onClick={openParallelCalc}
                    title="Ajuste de precio paralelo"
                    className="absolute -top-2 -right-1.5 w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow cursor-pointer"
                  >
                    <Scale className="w-3 h-3" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  setSelectedSaleRate('3');
                  setGlobalParallelOverrideVes(null);
                }}
                className={`py-2 px-2 rounded-xl border text-[11px] font-bold cursor-pointer transition-colors ${
                  selectedSaleRate === '3'
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {localCurrencyCode === 'VES' ? 'P2' : 'T3'} · {formatRateNumber(tertiaryRate, localCurrencyCode)}
              </button>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={toggleIva}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
                    ivaActive
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  <Percent className="w-3 h-3" />
                  {ivaActive ? 'IVA 16% aplicado' : 'Sumar IVA 16%'}
                </button>
                <span className="text-xs font-mono tabular-nums text-slate-500">
                  {ivaActive ? `+${formatMoney(cartTotals.ivaVes)} ${localCurrency.shortLabel}` : 'Sin IVA'}
                </span>
              </div>

              <div className="flex items-baseline justify-between pt-1">
                <span className="text-xs font-bold text-slate-700">Total Principal (USD)</span>
                <span className="text-xl font-mono tabular-nums font-extrabold text-emerald-700">
                  ${cartTotals.totalUsdBcv.toFixed(2)}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs pt-1 border-t border-dashed border-slate-200">
                <span className="text-slate-600 font-medium">
                  Equivalente {localCurrency.name} ({selectedSaleRate === '1' ? localCurrency.rateLabel : selectedSaleRate === '2' ? (localCurrencyCode === 'VES' ? 'Paralelo 1' : 'Tasa 2') : (localCurrencyCode === 'VES' ? 'Paralelo 2' : 'Tasa 3')})
                </span>
                <span className="font-mono tabular-nums font-extrabold text-slate-900">
                  {formatMoney(cartTotals.totalVes)} {localCurrency.shortLabel}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <button
                  type="button"
                  onClick={cycleInvoiceMode}
                  className="inline-flex items-center gap-1 text-sky-700 hover:underline cursor-pointer"
                  title="Cambiar modo de emisión de factura"
                >
                  <Printer className="w-3 h-3" />
                  {invoiceMode === 'auto'
                    ? activePrinter
                      ? `Imprimir: ${activePrinter.name}`
                      : 'Auto: PDF al cobrar'
                    : invoiceMode === 'pdf'
                    ? 'Factura PDF automática'
                    : invoiceMode === 'printer'
                    ? 'Impresión directa'
                    : 'Sin comprobante'}
                </button>
                <span>{cartTotals.modeLabel}</span>
              </div>
            </div>

            <div className={canTools ? 'grid grid-cols-[auto_1fr] gap-2' : 'grid grid-cols-1'}>
              {canTools && (
                <button
                  type="button"
                  onClick={handleOpenPresupuesto}
                  className="px-3.5 py-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  title="Generar Presupuesto PDF"
                >
                  <FileText className="w-4 h-4 text-sky-600" />
                  Presupuesto
                </button>
              )}
              <button
                type="button"
                onClick={onOpenPayment}
                className="py-3 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-sm whitespace-nowrap"
              >
                <CreditCard className="w-4 h-4" />
                Cobrar Venta
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Quantity & Mode (Detal / Bulto / Fraccionable) Modal */}
      {qtyModalProduct && (() => {
        const supportsBulto =
          qtyModalProduct.ventaPorBulto === true && (Number(qtyModalProduct.unidadesPorBulto) || 0) > 1;
        const upb = supportsBulto ? Number(qtyModalProduct.unidadesPorBulto) : 1;
        const isBulto = supportsBulto && qtyModalMode === 'bulto';
        const maxQty = isBulto ? Math.floor(qtyModalProduct.stock / upb) : qtyModalProduct.stock;
        const qtyNum = Number(qtyInput) || 0;
        const unitUsd = getEffectiveUnitPrice(qtyModalProduct, isBulto ? 'bulto' : 'detal');
        const lineUsd = unitUsd * Math.max(0, qtyNum);
        const lineBs = lineUsd * rateToUse;
        const unitsDeducted = isBulto ? qtyNum * upb : qtyNum;

        return (
          <div className="fixed inset-0 z-[150] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
            <form
              onSubmit={confirmQtyModal}
              className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 relative"
            >
              <button
                type="button"
                onClick={() => setQtyModalProduct(null)}
                className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                aria-label="Cerrar"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-3 pr-7">
                <ProductThumb name={qtyModalProduct.id} image={qtyModalProduct.image} className="w-14 h-14 text-sm shrink-0" />
                <div className="min-w-0">
                  <h3 className="font-bold text-sm text-slate-900 leading-snug">{qtyModalProduct.id}</h3>
                  <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                    Stock: <b>{qtyModalProduct.stock} uds</b>
                    {supportsBulto ? ` (${Math.floor(qtyModalProduct.stock / upb)} bultos)` : ''}
                  </p>
                </div>
              </div>

              {supportsBulto && (
                <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setQtyModalMode('detal');
                      setQtyInput('1');
                    }}
                    className={`py-2 px-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                      !isBulto
                        ? 'bg-white text-sky-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Al Detal · ${qtyModalProduct.price.toFixed(2)}
                  </button>
                  <button
                    type="button"
                    disabled={Math.floor(qtyModalProduct.stock / upb) < 1}
                    onClick={() => {
                      setQtyModalMode('bulto');
                      setQtyInput('1');
                    }}
                    className={`py-2 px-2 rounded-lg text-xs font-bold cursor-pointer transition-all disabled:opacity-40 inline-flex items-center justify-center gap-1 ${
                      isBulto
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Boxes className="w-3.5 h-3.5" /> Bulto ×{upb} · $
                    {getEffectiveUnitPrice(qtyModalProduct, 'bulto').toFixed(2)}
                  </button>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {isBulto
                    ? `Cantidad de Bultos (×${upb} uds c/u)`
                    : `Cantidad ${qtyModalProduct.fraccionable ? '(fraccionable / decimales)' : '(unidades al detal)'}`}
                </label>
                <input
                  type="number"
                  step={!isBulto && qtyModalProduct.fraccionable ? '0.01' : '1'}
                  min={!isBulto && qtyModalProduct.fraccionable ? '0.01' : '1'}
                  max={Math.max(1, maxQty)}
                  value={qtyInput}
                  onChange={(e) => setQtyInput(e.target.value)}
                  autoFocus
                  className="w-full px-4 py-3 text-center text-xl font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
                />
                {!isBulto && qtyModalProduct.fraccionable && (
                  <div className="grid grid-cols-4 gap-1.5 mt-2">
                    {['0.25', '0.50', '0.75', '1.50'].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setQtyInput(preset)}
                        className="py-1.5 rounded-lg bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 text-cyan-800 text-xs font-mono font-bold cursor-pointer"
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {qtyNum > 0 && (
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono tabular-nums flex items-center justify-between gap-2">
                  <span className="text-slate-600 font-sans">
                    Total ({unitsDeducted} uds):
                  </span>
                  <span className="font-extrabold text-emerald-700">
                    ${lineUsd.toFixed(2)} · {formatMoney(lineBs)} {localCurrency.shortLabel}
                  </span>
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setQtyModalProduct(null)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`flex-1 py-2.5 rounded-xl text-white text-xs font-bold cursor-pointer ${
                    isBulto ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-sky-600 hover:bg-sky-700'
                  }`}
                >
                  {isBulto ? 'Agregar Bulto' : 'Agregar al Carrito'}
                </button>
              </div>
            </form>
          </div>
        );
      })()}

      {/* Item Discount Modal */}
      {discountProduct && (
        <div className="fixed inset-0 z-[160] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 relative">
            <button
              type="button"
              onClick={() => setDiscountProduct(null)}
              className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
            <div>
              <h3 className="font-bold text-base text-slate-900 pr-7">Aplicar Rebaja Unitaria</h3>
              <p className="text-xs text-slate-500 mt-0.5">{discountProduct.label}</p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nuevo precio unitario en {localCurrency.name} ({localCurrency.shortLabel})
              </label>
              <input
                type="number"
                step="0.01"
                value={discountProduct.priceVes}
                onChange={(e) =>
                  setDiscountProduct((prev) => (prev ? { ...prev, priceVes: e.target.value } : null))
                }
                className="w-full px-4 py-2.5 text-center font-mono text-lg font-bold bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setDiscountProduct(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const val = Number(discountProduct.priceVes);
                  if (val > 0) {
                    setCartItemDiscount(discountProduct.cartKey, val);
                    setDiscountProduct(null);
                  }
                }}
                className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer"
              >
                Aplicar Rebaja
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Parallel Price Calculator Modal */}
      {parallelCalcOpen && (
        <div className="fixed inset-0 z-[160] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 relative">
            <button
              type="button"
              onClick={() => setParallelCalcOpen(false)}
              className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-base text-slate-900 pr-7">Ajuste de Precio Paralelo</h3>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Monto USD ($)</label>
              <input
                type="number"
                step="0.01"
                value={parallelUsd}
                onChange={(e) => {
                  setParallelUsd(e.target.value);
                  setParallelVes(((Number(e.target.value) || 0) * secondaryRate).toFixed(2));
                }}
                className="w-full px-3 py-2 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-sky-700 mb-1">
                Monto {localCurrency.name} ({localCurrency.shortLabel})
              </label>
              <input
                type="number"
                step="0.01"
                value={parallelVes}
                onChange={(e) => {
                  setParallelVes(e.target.value);
                  setParallelUsd(
                    secondaryRate > 0 ? ((Number(e.target.value) || 0) / secondaryRate).toFixed(2) : '0'
                  );
                }}
                className="w-full px-3 py-2 text-center font-mono font-bold bg-sky-50 border border-sky-200 rounded-xl text-sky-900"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setParallelCalcOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const ves = Number(parallelVes);
                  if (ves > 0) {
                    setGlobalParallelOverrideVes(ves);
                    setParallelCalcOpen(false);
                    notifyToast('Precio global ajustado a tasa Paralelo.', 'success');
                  }
                }}
                className="flex-1 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-semibold cursor-pointer"
              >
                Confirmar Precio
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inline Rate Editor Modal */}
      {editingRate && (
        <div className="fixed inset-0 z-[160] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-xs w-full p-5 space-y-4 relative">
            <button
              type="button"
              onClick={() => setEditingRate(null)}
              className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-bold text-sm text-slate-900 pr-7">
              Editar{' '}
              {editingRate === 'bcv'
                ? `${localCurrency.rateLabel} (${localCurrency.shortLabel})`
                : editingRate === 'secundaria'
                ? localCurrencyCode === 'VES'
                  ? 'Paralelo 1 (Bs)'
                  : `Tasa Ref. 2 (${localCurrency.shortLabel})`
                : localCurrencyCode === 'VES'
                ? 'Paralelo 2 (Bs)'
                : `Tasa Ref. 3 (${localCurrency.shortLabel})`}
            </h3>
            <input
              type="number"
              step={localCurrencyCode === 'EUR' ? '0.0001' : '0.01'}
              value={rateDraft}
              onChange={(e) => setRateDraft(e.target.value)}
              autoFocus
              className="w-full px-3 py-2.5 text-center font-mono text-lg font-bold bg-slate-50 border border-slate-200 rounded-xl"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setEditingRate(null)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={async () => {
                  const v = Number(rateDraft);
                  if (v > 0) {
                    await updateRate(editingRate, v);
                    setEditingRate(null);
                  }
                }}
                className="flex-1 py-2 rounded-xl bg-sky-600 text-white text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" /> Guardar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Presupuesto Client Name Modal */}
      {quoteModalOpen && (
        <div className="fixed inset-0 z-[160] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleGeneratePresupuesto}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-5 space-y-4 relative"
          >
            <button
              type="button"
              onClick={() => setQuoteModalOpen(false)}
              className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
            <div>
              <h3 className="font-bold text-sm text-slate-900 pr-7">Generar Presupuesto PDF</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Indica el nombre del cliente o déjalo vacío para presupuesto general.
              </p>
            </div>
            <input
              type="text"
              value={quoteClientName}
              onChange={(e) => setQuoteClientName(e.target.value)}
              placeholder="Nombre del cliente (opcional)"
              autoFocus
              className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setQuoteModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <FileDown className="w-3.5 h-3.5" /> Descargar PDF
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Safe Auxiliary Calculator Floating Panel */}
      {calcOpen && (
        <div className="fixed bottom-20 right-5 z-[145] w-72 bg-white rounded-2xl border border-slate-200 shadow-2xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Calculator className="w-3.5 h-3.5 text-sky-600" /> Calculadora Auxiliar
            </span>
            <button
              type="button"
              onClick={() => setCalcOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar calculadora"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <input
            type="text"
            readOnly
            value={calcExpr}
            placeholder="0"
            className="w-full px-3 py-2.5 text-right font-mono text-lg font-bold bg-slate-50 border border-slate-200 rounded-xl mb-3"
          />
          <div className="grid grid-cols-4 gap-1.5">
            {['C', '/', '*', '-', '7', '8', '9', '+', '4', '5', '6', '(', '1', '2', '3', ')', '0', '.', '='].map(
              (k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => handleCalcPress(k)}
                  className={`py-2.5 rounded-xl font-mono text-sm font-bold cursor-pointer ${
                    k === 'C'
                      ? 'bg-rose-50 text-rose-600 hover:bg-rose-100'
                      : k === '='
                      ? 'col-span-2 bg-sky-600 text-white hover:bg-sky-700'
                      : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                  }`}
                >
                  {k}
                </button>
              )
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export { generateInvoicePDF };
