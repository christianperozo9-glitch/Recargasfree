# Security Specification — Innova Grup Multi-Tenant POS

## 1. Data Invariants
1. **Strict Tenant Isolation**: Every business/client node lives under `/tenants/{tenantId}` and all operational records (products, sales, closures, fiados, taller, cashiers, users, notifications, tickets, membership_payments) live in subcollections under `/tenants/{tenantId}/...`. A tenant owner (`ownerUid == request.auth.uid` or verified `email == tenant.email`) can read/write ONLY inside their own `tenantId` subtree.
2. **Master Owner Authority**: Platform-wide settings (`/platform/config`), master admin registry (`/admins/{uid}`), tenant provisioning (`/tenants/{tenantId}` creation/deletion/membership control), and cross-tenant approval of membership payments are restricted strictly to verified Master Owners (`christianperozo9@gmail.com` with `email_verified == true` or verified `/admins/{uid}`).
3. **Immutable Ownership & Tenant Binding**: On updates inside `/tenants/{tenantId}`, a non-Master-Owner tenant cannot alter `ownerUid`, `membresia`, `congelado`, `admin_bloqueado`, `mantenimiento`, or `activo` (preventing self-extension of expired memberships or bypassing freezes).
4. **Verified Email Guard**: Every rule evaluating `request.auth.token.email` MUST strictly verify `request.auth.token.email_verified == true`.
5. **Bounded Payloads & Valid IDs**: Every document ID path variable is validated (`isValidId(id)` -> `^[a-zA-Z0-9_-]{1,128}$`) and all string/array fields enforce explicit `.size()` boundaries.

## 2. The "Dirty Dozen" Attack Payloads
1. **Unauthenticated Tenant Read**: `{ auth: null, op: "get", path: "/tenants/t1/products/p1" }` -> `PERMISSION_DENIED`.
2. **Cross-Tenant Inventory Theft**: `{ auth: { uid: "tenantA" }, op: "get", path: "/tenants/tenantB/products/p1" }` -> `PERMISSION_DENIED`.
3. **Cross-Tenant List Scraping**: `{ auth: { uid: "tenantA" }, op: "list", path: "/tenants" }` without `ownerUid == tenantA` filter -> `PERMISSION_DENIED`.
4. **Privilege Escalation via /admins Self-Write**: `{ auth: { uid: "attacker" }, op: "create", path: "/admins/attacker", data: { uid: "attacker", email: "a@b.com", role: "owner" } }` -> `PERMISSION_DENIED`.
5. **Membership Self-Renewal Tampering**: `{ auth: { uid: "tenantA" }, op: "update", path: "/tenants/tenantA", data: { membresia: { estado: "activa", vence: 9999999999999 } } }` -> `PERMISSION_DENIED`.
6. **Unfreeze Self-Bypass**: `{ auth: { uid: "tenantA" }, op: "update", path: "/tenants/tenantA", data: { congelado: false, activo: true } }` -> `PERMISSION_DENIED`.
7. **Payment Self-Approval**: `{ auth: { uid: "tenantA" }, op: "update", path: "/platform_payments/pay1", data: { estado: "aprobado" } }` -> `PERMISSION_DENIED`.
8. **Spoofed Email Claim (email_verified: false)**: `{ auth: { uid: "spoof", token: { email: "christianperozo9@gmail.com", email_verified: false } }, op: "write", path: "/platform/config" }` -> `PERMISSION_DENIED`.
9. **Ghost / Shadow Field Injection on Product Create**: `{ auth: { uid: "tenantA" }, op: "create", path: "/tenants/tenantA/products/p1", data: { nombre: "Filtro", precio: 10, stock: 5, adminOverride: true } }` -> `PERMISSION_DENIED`.
10. **ID Poisoning Attack**: `{ auth: { uid: "tenantA" }, op: "create", path: "/tenants/tenantA/products/../../admins/x", data: { ... } }` -> `PERMISSION_DENIED`.
11. **Denial-of-Wallet Oversized String**: `{ auth: { uid: "tenantA" }, op: "create", path: "/tenants/tenantA/tickets/t1", data: { msg: "A".repeat(10000) } }` -> `PERMISSION_DENIED`.
12. **Platform Config Hijack by Tenant**: `{ auth: { uid: "tenantA" }, op: "update", path: "/platform/config", data: { whatsapp_membresia: "584140000000" } }` -> `PERMISSION_DENIED`.
