/**
 * Security Rules Verification Specification (Dirty Dozen Test Cases)
 * Documents required PERMISSION_DENIED invariants verified against firestore.rules.
 */
export interface RuleTestCase {
  name: string;
  actorUid: string | null;
  emailVerified?: boolean;
  email?: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  payload?: Record<string, unknown>;
  expected: 'DENY' | 'ALLOW';
}

export const DIRTY_DOZEN_TESTS: RuleTestCase[] = [
  {
    name: '1. Unauthenticated product read denied',
    actorUid: null,
    operation: 'get',
    path: '/tenants/t1/products/p1',
    expected: 'DENY',
  },
  {
    name: '2. Cross-tenant product read denied',
    actorUid: 'tenant_a_uid',
    operation: 'get',
    path: '/tenants/tenant_b_uid/products/p1',
    expected: 'DENY',
  },
  {
    name: '3. Blanket tenant list scraping denied',
    actorUid: 'tenant_a_uid',
    operation: 'list',
    path: '/tenants',
    expected: 'DENY',
  },
  {
    name: '4. Self-registration in /admins denied',
    actorUid: 'attacker_uid',
    operation: 'create',
    path: '/admins/attacker_uid',
    payload: { uid: 'attacker_uid', email: 'attacker@evil.com', role: 'owner' },
    expected: 'DENY',
  },
  {
    name: '5. Tenant self-modifying membership expiration denied',
    actorUid: 'tenant_a_uid',
    operation: 'update',
    path: '/tenants/tenant_a_uid',
    payload: { membresia: { estado: 'activa', vence: 9999999999999 } },
    expected: 'DENY',
  },
  {
    name: '6. Tenant self-unfreezing denied',
    actorUid: 'tenant_a_uid',
    operation: 'update',
    path: '/tenants/tenant_a_uid',
    payload: { congelado: false, activo: true },
    expected: 'DENY',
  },
  {
    name: '7. Tenant self-approving membership payment denied',
    actorUid: 'tenant_a_uid',
    operation: 'update',
    path: '/platform_payments/pay_1',
    payload: { estado: 'aprobado' },
    expected: 'DENY',
  },
  {
    name: '8. Unverified email spoofing Master Owner denied',
    actorUid: 'spoof_uid',
    email: 'christianperozo9@gmail.com',
    emailVerified: false,
    operation: 'update',
    path: '/platform/config',
    payload: { whatsapp_membresia: '580000000000' },
    expected: 'DENY',
  },
  {
    name: '9. Shadow field injection on product create denied',
    actorUid: 'tenant_a_uid',
    operation: 'create',
    path: '/tenants/tenant_a_uid/products/prod_1',
    payload: { nombre: 'Aceite', precio: 12, stock: 10, shadowFlag: true },
    expected: 'DENY',
  },
  {
    name: '10. Invalid document ID rejected',
    actorUid: 'tenant_a_uid',
    operation: 'create',
    path: '/tenants/tenant_a_uid/products/invalid$id',
    payload: { nombre: 'Aceite', precio: 12, stock: 10 },
    expected: 'DENY',
  },
  {
    name: '11. Oversized ticket payload rejected',
    actorUid: 'tenant_a_uid',
    operation: 'create',
    path: '/platform_tickets/tk_1',
    payload: {
      tenantId: 'tenant_a_uid',
      ownerUid: 'tenant_a_uid',
      t: 1700000000000,
      usuario: 'user@store.com',
      msg: 'X'.repeat(5000),
      estado: 'nuevo',
    },
    expected: 'DENY',
  },
  {
    name: '12. Tenant modifying global Pago Movil denied',
    actorUid: 'tenant_a_uid',
    operation: 'update',
    path: '/platform/config',
    payload: { pago_movil: { tel: '04120000000' } },
    expected: 'DENY',
  },
];
