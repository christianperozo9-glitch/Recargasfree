import React, { useState } from 'react';
import { multiFactor, updatePassword, type TotpSecret } from 'firebase/auth';
import {
  CheckCircle2,
  Copy,
  KeyRound,
  Mail,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import {
  createPinCredentials,
  finalizeTotpEnrollment,
  reauthenticateCurrentUser,
  sendPasswordRecoveryEmail,
  startTotpEnrollment,
  unenrollMfaFactor,
} from '../lib/firebase';
import { usePos } from '../context/PosContext';

interface AccountSecurityModalProps {
  open: boolean;
  onClose: () => void;
}

export const AccountSecurityModal: React.FC<AccountSecurityModalProps> = ({ open, onClose }) => {
  const {
    authUser,
    role,
    activeTenantId,
    activeTenant,
    updateTenantRecord,
    notifyToast,
    playBeep,
  } = usePos();
  const [totpSecret, setTotpSecret] = useState<TotpSecret | null>(null);
  const [secretKey, setSecretKey] = useState('');
  const [qrUri, setQrUri] = useState('');
  const [code, setCode] = useState('');
  const [reauthPassword, setReauthPassword] = useState('');
  const [needsReauth, setNeedsReauth] = useState(false);
  const [busy, setBusy] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [confirmUnenrollUid, setConfirmUnenrollUid] = useState<string | null>(null);

  // Admin Closing PIN & Caja PIN configuration
  const [newAdminPin, setNewAdminPin] = useState('');
  const [newCajaPin, setNewCajaPin] = useState('');
  const [savingPin, setSavingPin] = useState(false);

  // Direct password change
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [changingPwd, setChangingPwd] = useState(false);

  if (!open) return null;

  const enrolledFactors = authUser ? multiFactor(authUser).enrolledFactors : [];

  const handleDirectPasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser?.email) return;
    if (!currentPwd) {
      setStatusMsg('Ingresa tu contraseña actual para autorizar el cambio.');
      return;
    }
    if (newPwd.length < 6) {
      setStatusMsg('La nueva contraseña debe tener al menos 6 caracteres.');
      return;
    }
    if (newPwd !== confirmPwd) {
      setStatusMsg('La confirmación de la nueva contraseña no coincide.');
      return;
    }
    setChangingPwd(true);
    setStatusMsg('');
    try {
      await reauthenticateCurrentUser(authUser.email, currentPwd);
      await updatePassword(authUser, newPwd);
      setCurrentPwd('');
      setNewPwd('');
      setConfirmPwd('');
      playBeep('ok');
      notifyToast('Contraseña de acceso actualizada correctamente.', 'success');
    } catch (err) {
      const fbErr = err as { code?: string; message?: string };
      if (fbErr.code === 'auth/wrong-password' || fbErr.code === 'auth/invalid-credential') {
        setStatusMsg('La contraseña actual es incorrecta.');
      } else {
        setStatusMsg(fbErr.message || 'No se pudo cambiar la contraseña.');
      }
      playBeep('err');
    } finally {
      setChangingPwd(false);
    }
  };

  const handleSaveAdminPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId) return;
    const cleanAdmin = newAdminPin.trim();
    const cleanCaja = newCajaPin.trim();
    if (!cleanAdmin && !cleanCaja) {
      notifyToast('Ingresa al menos un nuevo PIN Administrativo o PIN de Caja.', 'warning');
      return;
    }
    if (cleanAdmin && cleanAdmin.length < 4) {
      notifyToast('El PIN Administrativo debe tener al menos 4 dígitos.', 'warning');
      return;
    }
    if (cleanCaja && cleanCaja.length < 4) {
      notifyToast('El PIN de Caja debe tener al menos 4 dígitos.', 'warning');
      return;
    }
    setSavingPin(true);
    try {
      const patch: Record<string, string> = {};
      if (cleanAdmin) {
        const creds = await createPinCredentials(cleanAdmin);
        patch.admin_pin_salt = creds.salt;
        patch.admin_pin_hash = creds.hash;
      }
      if (cleanCaja) {
        const creds = await createPinCredentials(cleanCaja);
        patch.caja_pin_salt = creds.salt;
        patch.caja_pin_hash = creds.hash;
      }
      await updateTenantRecord(activeTenantId, patch);
      setNewAdminPin('');
      setNewCajaPin('');
      playBeep('ok');
      notifyToast('Credenciales PIN actualizadas correctamente.', 'success');
    } finally {
      setSavingPin(false);
    }
  };

  const handleStartMfa = async () => {
    if (!authUser) {
      notifyToast('Inicia sesión con correo Firebase para configurar MFA.', 'warning');
      return;
    }
    setBusy(true);
    setStatusMsg('');
    try {
      const res = await startTotpEnrollment(authUser, 'Innova Grup POS');
      setTotpSecret(res.secret);
      setSecretKey(res.secretKey);
      setQrUri(res.qrUri);
      setNeedsReauth(false);
    } catch (err) {
      const fbErr = err as { code?: string; message?: string };
      if (fbErr.code === 'auth/requires-recent-login') {
        setNeedsReauth(true);
        setStatusMsg('Por seguridad, confirma tu contraseña actual para activar MFA.');
      } else if (fbErr.code === 'auth/operation-not-allowed') {
        setStatusMsg(
          'Habilita TOTP MFA en Firebase Console (Authentication → Sign-in method → Multi-factor authentication) para completar el enrolamiento.'
        );
      } else {
        setStatusMsg(fbErr.message || 'No se pudo iniciar el registro MFA.');
      }
      playBeep('err');
    } finally {
      setBusy(false);
    }
  };

  const handleReauth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser?.email || !reauthPassword) return;
    setBusy(true);
    try {
      await reauthenticateCurrentUser(authUser.email, reauthPassword);
      setNeedsReauth(false);
      setReauthPassword('');
      await handleStartMfa();
    } catch {
      setStatusMsg('Contraseña incorrecta.');
      playBeep('err');
    } finally {
      setBusy(false);
    }
  };

  const handleConfirmEnrollment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser || !totpSecret) return;
    if (!/^\d{6}$/.test(code.trim())) {
      setStatusMsg('Ingresa el código de 6 dígitos generado por tu app autenticadora.');
      return;
    }
    setBusy(true);
    setStatusMsg('');
    try {
      await finalizeTotpEnrollment(authUser, totpSecret, code.trim());
      setTotpSecret(null);
      setSecretKey('');
      setQrUri('');
      setCode('');
      playBeep('ok');
      notifyToast('Autenticación multifactor (TOTP) activada correctamente.', 'success');
    } catch (err) {
      const fbErr = err as { message?: string };
      setStatusMsg(fbErr.message || 'Código inválido. Verifica la hora del dispositivo.');
      playBeep('err');
    } finally {
      setBusy(false);
    }
  };

  const handleUnenroll = async (uid: string) => {
    if (!authUser) return;
    setBusy(true);
    try {
      await unenrollMfaFactor(authUser, uid);
      setConfirmUnenrollUid(null);
      notifyToast('Factor MFA eliminado.', 'info');
    } catch (err) {
      const fbErr = err as { code?: string; message?: string };
      if (fbErr.code === 'auth/requires-recent-login') {
        setNeedsReauth(true);
        setStatusMsg('Confirma tu contraseña actual antes de desactivar MFA.');
      } else {
        setStatusMsg(fbErr.message || 'No se pudo eliminar el factor.');
      }
    } finally {
      setBusy(false);
    }
  };

  const handleSendReset = async () => {
    if (!authUser?.email) return;
    setBusy(true);
    try {
      await sendPasswordRecoveryEmail(authUser.email);
      playBeep('ok');
      notifyToast(`Correo de restablecimiento enviado a ${authUser.email}`, 'success');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Error enviando correo.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[150] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-sky-600" />
            <h3 className="font-bold text-slate-900 text-base">Seguridad de Cuenta y MFA</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {!authUser ? (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-600">
              Inicia sesión como Administrador o Propietario con tu correo Firebase para gestionar
              autenticación multifactor (2FA) y recuperación de contraseña.
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-200">
                <div>
                  <p className="text-xs font-semibold text-slate-500">Cuenta conectada</p>
                  <p className="text-sm font-bold text-slate-900">{authUser.email}</p>
                </div>
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleSendReset}
                  className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                >
                  <Mail className="w-3.5 h-3.5 text-sky-600" /> Cambiar / Recuperar clave
                </button>
              </div>

              {/* Direct Password Change */}
              <form
                onSubmit={handleDirectPasswordChange}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5"
              >
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-sky-600" />
                  Cambiar Contraseña Directamente
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="password"
                    value={currentPwd}
                    onChange={(e) => setCurrentPwd(e.target.value)}
                    placeholder="Clave actual"
                    className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                  />
                  <input
                    type="password"
                    value={newPwd}
                    onChange={(e) => setNewPwd(e.target.value)}
                    placeholder="Nueva clave (mín. 6)"
                    className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                  />
                  <input
                    type="password"
                    value={confirmPwd}
                    onChange={(e) => setConfirmPwd(e.target.value)}
                    placeholder="Confirmar clave"
                    className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={changingPwd}
                    className="px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    {changingPwd ? 'Actualizando...' : 'Actualizar Contraseña'}
                  </button>
                </div>
              </form>

              {(role === 'admin' || role === 'owner') && activeTenantId && (
                <form
                  onSubmit={handleSaveAdminPin}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                      PIN Administrativo y PIN de Caja
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      Admin: {activeTenant?.admin_pin_hash ? 'OK' : 'No'} · Caja:{' '}
                      {activeTenant?.caja_pin_hash ? 'OK' : 'No'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Solo el PIN Administrativo o la contraseña de administrador autorizan cierres de caja y anulaciones de facturas.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="password"
                      inputMode="numeric"
                      value={newAdminPin}
                      onChange={(e) => setNewAdminPin(e.target.value.replace(/\D/g, ''))}
                      placeholder={
                        activeTenant?.admin_pin_hash
                          ? 'Nuevo PIN Admin (opcional)'
                          : 'Crear PIN Admin (mín. 4)'
                      }
                      maxLength={12}
                      className="px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                    />
                    <input
                      type="password"
                      inputMode="numeric"
                      value={newCajaPin}
                      onChange={(e) => setNewCajaPin(e.target.value.replace(/\D/g, ''))}
                      placeholder={
                        activeTenant?.caja_pin_hash
                          ? 'Nuevo PIN Caja (opcional)'
                          : 'Crear PIN Caja (mín. 4)'
                      }
                      maxLength={12}
                      className="px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={savingPin}
                      className="px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                    >
                      {savingPin ? 'Guardando...' : 'Guardar PINs'}
                    </button>
                  </div>
                </form>
              )}

              {/* Enrolled MFA factors */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Autenticación Multifactor (TOTP)
                  </h4>
                  <span className="text-xs font-semibold text-slate-500">
                    {enrolledFactors.length > 0 ? 'Activa' : 'No configurada'}
                  </span>
                </div>

                {enrolledFactors.length > 0 ? (
                  <div className="space-y-2">
                    {enrolledFactors.map((f) => (
                      <div
                        key={f.uid}
                        className="flex items-center justify-between p-3 rounded-xl border border-emerald-200 bg-emerald-50/50 gap-2"
                      >
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <div>
                            <p className="text-xs font-bold text-slate-900">
                              {f.displayName || 'App Autenticadora'}
                            </p>
                            <p className="text-[11px] text-slate-500">Factor: {f.factorId}</p>
                          </div>
                        </div>
                        {confirmUnenrollUid === f.uid ? (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => void handleUnenroll(f.uid)}
                              disabled={busy}
                              className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-semibold cursor-pointer"
                            >
                              Confirmar
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmUnenrollUid(null)}
                              className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-slate-600 text-[11px] font-semibold cursor-pointer"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmUnenrollUid(f.uid)}
                            disabled={busy}
                            className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer"
                            title="Eliminar factor MFA"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">
                    Protege el acceso administrativo y de propietario solicitando un código TOTP de
                    6 dígitos (Google Authenticator, Authy, 1Password) al iniciar sesión.
                  </p>
                )}
              </div>

              {needsReauth && (
                <form onSubmit={handleReauth} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 relative">
                  <button
                    type="button"
                    onClick={() => setNeedsReauth(false)}
                    className="absolute top-3 right-3 p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 cursor-pointer"
                    aria-label="Cancelar"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                  <p className="text-xs font-semibold text-slate-700 pr-6">
                    Confirma tu contraseña actual para continuar:
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      value={reauthPassword}
                      onChange={(e) => setReauthPassword(e.target.value)}
                      placeholder="Contraseña actual"
                      className="flex-1 px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                    />
                    <button
                      type="submit"
                      disabled={busy}
                      className="px-4 py-2 rounded-lg bg-sky-600 text-white text-xs font-semibold cursor-pointer"
                    >
                      Confirmar
                    </button>
                  </div>
                </form>
              )}

              {totpSecret ? (
                <form onSubmit={handleConfirmEnrollment} className="p-4 rounded-xl bg-sky-50 border border-sky-200 space-y-3 relative">
                  <button
                    type="button"
                    onClick={() => {
                      setTotpSecret(null);
                      setSecretKey('');
                      setQrUri('');
                      setCode('');
                    }}
                    className="absolute top-3 right-3 p-1 rounded-lg text-sky-700 hover:bg-sky-100 cursor-pointer"
                    aria-label="Cancelar registro MFA"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <p className="text-xs font-bold text-sky-900 pr-7">
                    1. Añade esta clave en tu app autenticadora (Google Authenticator / Authy):
                  </p>
                  <div className="flex items-center gap-2 bg-white border border-sky-200 rounded-lg px-3 py-2">
                    <KeyRound className="w-4 h-4 text-sky-600 shrink-0" />
                    <code className="text-xs font-mono font-bold text-slate-900 flex-1 break-all">
                      {secretKey}
                    </code>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(secretKey);
                        notifyToast('Clave secreta copiada', 'info');
                      }}
                      className="p-1.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                      title="Copiar clave"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  {qrUri && (
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(qrUri);
                        notifyToast('Enlace otpauth:// copiado', 'info');
                      }}
                      className="text-[11px] font-semibold text-sky-700 hover:underline cursor-pointer"
                    >
                      Copiar URI completo (otpauth://)
                    </button>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-sky-900 mb-1">
                      2. Ingresa el código de 6 dígitos para activar:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={6}
                        value={code}
                        onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                        placeholder="123456"
                        className="flex-1 px-3 py-2 text-center font-mono font-bold tracking-widest bg-white border border-sky-200 rounded-lg"
                      />
                      <button
                        type="submit"
                        disabled={busy}
                        className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                      >
                        Activar MFA
                      </button>
                    </div>
                  </div>
                </form>
              ) : (
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleStartMfa}
                  className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors cursor-pointer"
                >
                  {enrolledFactors.length > 0 ? 'Agregar otro factor TOTP' : 'Configurar MFA (2FA)'}
                </button>
              )}

              {statusMsg && (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>{statusMsg}</span>
                </div>
              )}
            </>
          )}
        </div>

        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
