import React, { useState } from 'react';
import {
  AlertTriangle,
  Ban,
  KeyRound,
  Lock,
  PackageCheck,
  Receipt,
  Search,
  ShieldCheck,
  X,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import type { CierreRecord, SaleTransaction } from '../types/pos';
import { formatMoney } from '../utils/format';

interface VoidInvoiceModalProps {
  open: boolean;
  onClose: () => void;
  defaultScope?: 'shift' | 'closures';
}

type PendingVoidTarget =
  | { kind: 'live'; sale: SaleTransaction }
  | { kind: 'closure'; closure: CierreRecord; saleIndex: number };

export const VoidInvoiceModal: React.FC<VoidInvoiceModalProps> = ({
  open,
  onClose,
  defaultScope = 'shift',
}) => {
  const {
    liveSales,
    savedCierres,
    verifyAdminAuthorization,
    voidLiveSale,
    voidClosureSale,
    notifyToast,
    playBeep,
  } = usePos();

  const [scope, setScope] = useState<'shift' | 'closures'>(defaultScope);
  const [search, setSearch] = useState('');
  const [target, setTarget] = useState<PendingVoidTarget | null>(null);
  const [authMode, setAuthMode] = useState<'password' | 'pin'>('password');
  const [secret, setSecret] = useState('');
  const [authError, setAuthError] = useState('');
  const [processing, setProcessing] = useState(false);

  if (!open) return null;

  const q = search.trim().toLowerCase();

  const filteredLive = liveSales.filter((s) => {
    if (!q) return true;
    const invNum = `fac-${String(s.timestamp).slice(-8)}`.toLowerCase();
    return (
      invNum.includes(q) ||
      (s.metodo_pago || '').toLowerCase().includes(q) ||
      (s.cliente_nombre || '').toLowerCase().includes(q) ||
      (s.cliente_cedula || '').toLowerCase().includes(q) ||
      (s.usuario || '').toLowerCase().includes(q) ||
      (s.items || []).some((it) => String(it.id || '').toLowerCase().includes(q))
    );
  });

  const closureEntries: Array<{ closure: CierreRecord; saleIndex: number }> = [];
  savedCierres.slice(0, 25).forEach((c) => {
    (c.detalle_ventas || []).forEach((v, idx) => {
      if (
        !q ||
        (c.fecha || '').toLowerCase().includes(q) ||
        (v.metodo || '').toLowerCase().includes(q) ||
        (v.productos || '').toLowerCase().includes(q) ||
        (v.cliente_nombre || '').toLowerCase().includes(q) ||
        (v.cliente_cedula || '').toLowerCase().includes(q) ||
        (v.usuario || '').toLowerCase().includes(q)
      ) {
        closureEntries.push({ closure: c, saleIndex: idx });
      }
    });
  });

  const handleConfirmVoid = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!target) return;
    setAuthError('');
    if (!secret.trim()) {
      setAuthError(
        authMode === 'password'
          ? 'Ingresa la contraseña del Administrador para autorizar la anulación.'
          : 'Ingresa el PIN del Administrador para autorizar la anulación.'
      );
      playBeep('err');
      return;
    }

    setProcessing(true);
    try {
      const check = await verifyAdminAuthorization(secret.trim(), authMode);
      if (!check.ok) {
        setAuthError(check.error || 'Autorización administrativa denegada.');
        playBeep('err');
        return;
      }

      if (target.kind === 'live') {
        await voidLiveSale(target.sale, check.label || 'Admin');
      } else {
        await voidClosureSale(target.closure, target.saleIndex, check.label || 'Admin');
      }
      setTarget(null);
      setSecret('');
      setAuthError('');
    } catch (err) {
      notifyToast(
        'Error al anular factura: ' + (err instanceof Error ? err.message : 'error'),
        'error'
      );
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[155] bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3 bg-rose-50/60">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0">
              <Ban className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-extrabold text-slate-900">
                Anular Factura y Restablecer Stock
              </h3>
              <p className="text-[11px] text-slate-600">
                Elimina la venta del turno o cierre y devuelve automáticamente los productos al inventario. Requiere clave de Administrador.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white text-slate-500 cursor-pointer shrink-0"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scope tabs & search */}
        <div className="px-5 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2.5 bg-slate-50">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                setScope('shift');
                setTarget(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer whitespace-nowrap ${
                scope === 'shift'
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              Turno Actual ({liveSales.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setScope('closures');
                setTarget(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer whitespace-nowrap ${
                scope === 'closures'
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              En Cierres Guardados ({closureEntries.length})
            </button>
          </div>
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar factura, cliente o producto..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl"
            />
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {target ? (
            <form
              onSubmit={handleConfirmVoid}
              className="p-4 rounded-2xl border-2 border-rose-200 bg-rose-50/50 space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-rose-800">
                    <AlertTriangle className="w-4 h-4" />
                    Confirmar Anulación de Factura
                  </div>
                  {target.kind === 'live' ? (
                    <div className="text-xs text-slate-700 space-y-0.5">
                      <p className="font-bold">
                        Factura FAC-{String(target.sale.timestamp).slice(-8)} · {target.sale.fecha}{' '}
                        {target.sale.hora}
                      </p>
                      <p>
                        Método: <b>{target.sale.metodo_pago}</b> · Monto:{' '}
                        <span className="font-mono font-bold text-rose-700">
                          {formatMoney(target.sale.monto_total_ves)} Bs ($
                          {Number(target.sale.monto_total_usd_bcv || 0).toFixed(2)})
                        </span>
                      </p>
                      {target.sale.cliente_nombre && (
                        <p>
                          Cliente: <b>{target.sale.cliente_nombre}</b> ({target.sale.cliente_cedula})
                        </p>
                      )}
                      <p className="text-[11px] text-emerald-800 inline-flex items-center gap-1 pt-1">
                        <PackageCheck className="w-3.5 h-3.5" /> Se devolverán al inventario:{' '}
                        {(target.sale.items || [])
                          .map((i) => `${i.id} (+${i.cantidad})`)
                          .join(', ')}
                      </p>
                    </div>
                  ) : (
                    (() => {
                      const sale = target.closure.detalle_ventas[target.saleIndex];
                      return (
                        <div className="text-xs text-slate-700 space-y-0.5">
                          <p className="font-bold">
                            Cierre {target.closure.fecha} · Hora {sale.hora} · {sale.metodo}
                          </p>
                          <p>
                            Total en cierre:{' '}
                            <span className="font-mono font-bold text-rose-700">
                              {formatMoney(sale.total_ves)} Bs
                            </span>
                          </p>
                          <p className="text-[11px] text-emerald-800 inline-flex items-center gap-1 pt-1">
                            <PackageCheck className="w-3.5 h-3.5" /> Se devolverán al inventario:{' '}
                            {(sale.items || []).map((i) => `${i.nombre} (+${i.cantidad})`).join(', ')}
                          </p>
                        </div>
                      );
                    })()
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setTarget(null);
                    setSecret('');
                    setAuthError('');
                  }}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cambiar factura
                </button>
              </div>

              <div className="p-3.5 rounded-xl bg-white border border-rose-200 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-rose-600" />
                    Autorización del Administrador
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('password');
                        setSecret('');
                        setAuthError('');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer inline-flex items-center gap-1 ${
                        authMode === 'password'
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <Lock className="w-3 h-3" /> Contraseña Admin
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('pin');
                        setSecret('');
                        setAuthError('');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer inline-flex items-center gap-1 ${
                        authMode === 'pin'
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <KeyRound className="w-3 h-3" /> PIN Admin
                    </button>
                  </div>
                </div>

                <input
                  type="password"
                  value={secret}
                  onChange={(e) => {
                    setSecret(
                      authMode === 'pin' ? e.target.value.replace(/\D/g, '').slice(0, 8) : e.target.value
                    );
                    setAuthError('');
                  }}
                  inputMode={authMode === 'pin' ? 'numeric' : 'text'}
                  placeholder={
                    authMode === 'password'
                      ? 'Contraseña de la cuenta Administrador'
                      : 'PIN de Administrador (4 a 8 dígitos)'
                  }
                  autoFocus
                  className="w-full px-3.5 py-2.5 text-sm font-mono bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
                {authError && <p className="text-xs font-bold text-rose-600">{authError}</p>}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTarget(null);
                      setSecret('');
                      setAuthError('');
                    }}
                    className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={processing}
                    className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-extrabold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Ban className="w-4 h-4" />
                    {processing ? 'Anulando...' : 'Autorizar y Anular Factura'}
                  </button>
                </div>
              </div>
            </form>
          ) : scope === 'shift' ? (
            filteredLive.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400">
                No hay facturas en el turno actual para anular.
              </div>
            ) : (
              <div className="space-y-2">
                {filteredLive.map((s) => (
                  <div
                    key={s.key || s.timestamp}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-rose-300 flex flex-wrap items-center justify-between gap-3 transition-colors"
                  >
                    <div className="min-w-0 flex-1 space-y-0.5 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono font-extrabold text-slate-900 inline-flex items-center gap-1">
                          <Receipt className="w-3.5 h-3.5 text-sky-600" />
                          FAC-{String(s.timestamp).slice(-8)}
                        </span>
                        <span className="text-slate-500 font-mono text-[11px]">
                          {s.fecha} {s.hora}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[11px]">
                          {s.metodo_pago}
                        </span>
                        {s.cliente_nombre && (
                          <span className="text-[11px] font-semibold text-indigo-700">
                            {s.cliente_nombre} ({s.cliente_cedula})
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-600 truncate">
                        {(s.items || []).map((i) => `${i.id} x${i.cantidad}`).join(' · ')}
                      </p>
                      <p className="text-[11px] text-slate-400">Operador: {s.usuario}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right font-mono tabular-nums">
                        <div className="text-xs font-extrabold text-slate-900">
                          {formatMoney(s.monto_total_ves)} Bs
                        </div>
                        <div className="text-[11px] text-emerald-700 font-semibold">
                          ${Number(s.monto_total_usd_bcv || 0).toFixed(2)} USD
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setTarget({ kind: 'live', sale: s });
                          setSecret('');
                          setAuthError('');
                        }}
                        className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 border border-rose-200 text-xs font-bold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors"
                      >
                        <Ban className="w-3.5 h-3.5" /> Anular
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : closureEntries.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No hay facturas registradas en los cierres guardados.
            </div>
          ) : (
            <div className="space-y-2">
              {closureEntries.map(({ closure, saleIndex }) => {
                const v = closure.detalle_ventas[saleIndex];
                return (
                  <div
                    key={`${closure.key}_${saleIndex}`}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-rose-300 flex flex-wrap items-center justify-between gap-3 transition-colors"
                  >
                    <div className="min-w-0 flex-1 space-y-0.5 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono font-bold text-slate-800">
                          Cierre {closure.fecha} · {v.hora}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[11px]">
                          {v.metodo}
                        </span>
                        {v.cliente_nombre && (
                          <span className="text-[11px] font-semibold text-indigo-700">
                            {v.cliente_nombre} ({v.cliente_cedula})
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-600 truncate">{v.productos}</p>
                      <p className="text-[11px] text-slate-400">Operador: {v.usuario}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right font-mono tabular-nums">
                        <div className="text-xs font-extrabold text-slate-900">
                          {formatMoney(v.total_ves)} Bs
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setTarget({ kind: 'closure', closure, saleIndex });
                          setSecret('');
                          setAuthError('');
                        }}
                        className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 border border-rose-200 text-xs font-bold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors"
                      >
                        <Ban className="w-3.5 h-3.5" /> Anular
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
