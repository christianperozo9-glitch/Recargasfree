import React, { useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Activity,
  AlertTriangle,
  Ban,
  Bell,
  BellRing,
  BookOpen,
  Bot,
  CheckCircle2,
  ClipboardCheck,
  CreditCard,
  Crown,
  Headphones,
  Info,
  Keyboard,
  Loader2,
  Lock,
  LogOut,
  Menu,
  Monitor,
  Music,
  Package,
  Pause,
  Play,
  Printer,
  RefreshCw,
  RotateCw,
  Shield,
  ShoppingBasket,
  SkipBack,
  SkipForward,
  Smartphone,
  Snowflake,
  Sparkles,
  Square,
  Store,
  Wrench,
  X,
} from 'lucide-react';
import { IG_THEMES, PosProvider, usePos } from './context/PosContext';
import { MASTER_OWNER_EMAIL } from './lib/firebase';
import { AppErrorBoundary } from './components/ErrorBoundary';
import { ViewModeToggle } from './components/ViewModeToggle';
import { InnovaLogo } from './components/InnovaLogo';
import { SplashIntro } from './components/SplashIntro';
import { AuthPortal } from './components/AuthPortal';
import { PosWorkspace } from './components/PosWorkspace';
import { PaymentModal } from './components/PaymentModal';
import { FiadosModal } from './components/FiadosModal';
import { CloseShiftModal } from './components/CloseShiftModal';
import { AdminPanel } from './components/AdminPanel';
import { OwnerPanel } from './components/OwnerPanel';
import { AccountSecurityModal } from './components/AccountSecurityModal';
import { PriceCheckerView } from './components/PriceCheckerView';
import { PWAInstallButton } from './components/PWAInstallButton';
import { VoidInvoiceModal } from './components/VoidInvoiceModal';
import { NotificationsModal } from './components/NotificationsModal';
import { ClientVerificationModal } from './components/ClientVerificationModal';
import { InnovaAvatarAssistant } from './components/InnovaAvatarAssistant';
import { MotorRepairModal, TallerModal } from './components/WorkshopModals';
import {
  BarcodeScannerModal,
  DevicesModal,
  MembershipModal,
  MusicPlayerModal,
  type MusicExternalCommand,
  type MusicPlayerStateSummary,
  ShortcutsModal,
  SupportModal,
} from './components/UtilityModals';
import { formatMoney } from './utils/format';

const AppContent: React.FC = () => {
  const {
    systemBusy,
    systemBusyLabel,
    firebaseReady,
    authUser,
    activeTenant,
    role,
    operatorName,
    localName,
    cart,
    cartTotals,
    products,
    activeTheme,
    toggleIva,
    addToCart,
    syncAllRates,
    ratesSyncing,
    config,
    notificationHistory,
    toasts,
    activeBroadcast,
    dismissBroadcast,
    maintenanceMode,
    maintenanceMessage,
    userFrozen,
    membershipExpired,
    activeMembershipWarning,
    dismissMembershipWarning,
    cashierPermissions,
    runtimeError,
    clearRuntimeError,
    viewMode,
    setViewMode,
    isMobileLayout,
    isWideViewport,
    pushSupported,
    pushPermission,
    pushEnabled,
    activePrinter,
    invoiceConfig,
    verificationConfig,
    verificationPendingCount,
    notifyToast,
    playBeep,
    logout,
  } = usePos();

  // Public self-service Price Checker route (?consultor=<tenantId>) & in-app preview
  const [publicCheckerTenantId] = useState<string | null>(() => {
    try {
      const val = new URLSearchParams(window.location.search).get('consultor');
      return val && val.trim() ? val.trim() : null;
    } catch {
      return null;
    }
  });
  const [previewCheckerTenantId, setPreviewCheckerTenantId] = useState<string | null>(null);

  const [splashDone, setSplashDone] = useState(false);
  const [ownerPosMode, setOwnerPosMode] = useState(false);
  const [mobileView, setMobileView] = useState<'catalog' | 'cart'>('catalog');
  const [drawerOpen, setDrawerOpen] = useState(false);

  const isAuthorizedOwner =
    role === 'owner' && (authUser?.email || '').toLowerCase() === MASTER_OWNER_EMAIL.toLowerCase();

  // Granular cashier permission flags (Default for cashiers: POS sales ONLY)
  const allowFiados = role !== 'cashier' || cashierPermissions.fiados === true;
  const allowMotor = role !== 'cashier' || cashierPermissions.motor === true;
  const allowTaller = role !== 'cashier' || cashierPermissions.taller === true;
  const allowEditRates = role !== 'cashier' || cashierPermissions.editar_tasas === true;
  const allowCloseShift = role !== 'cashier' || cashierPermissions.cerrar_caja === true;
  const allowVoidInvoice = role !== 'cashier' || cashierPermissions.anular_factura === true;
  const allowTools = role !== 'cashier' || cashierPermissions.herramientas === true;

  // Modals state
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [fiadosOpen, setFiadosOpen] = useState(false);
  const [closeShiftOpen, setCloseShiftOpen] = useState(false);
  const [voidInvoiceOpen, setVoidInvoiceOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [securityOpen, setSecurityOpen] = useState(false);
  const [motorOpen, setMotorOpen] = useState(false);
  const [tallerOpen, setTallerOpen] = useState(false);
  const [devicesOpen, setDevicesOpen] = useState(false);
  const [musicOpen, setMusicOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [membershipOpen, setMembershipOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [verificationOpen, setVerificationOpen] = useState(false);
  const [innovaChatOpen, setInnovaChatOpen] = useState(false);

  // Persistent background YouTube player state & external command bridge
  const [musicState, setMusicState] = useState<MusicPlayerStateSummary>({
    active: false,
    playing: false,
    title: '',
    channel: '',
  });
  const [musicCmd, setMusicCmd] = useState<MusicExternalCommand | null>(null);
  const [musicPopoverOpen, setMusicPopoverOpen] = useState(false);

  const sendMusicCommand = useCallback((type: MusicExternalCommand['type']) => {
    setMusicCmd((prev) => ({ type, seq: (prev?.seq || 0) + 1 }));
    if (type === 'cancel') {
      setMusicPopoverOpen(false);
    }
  }, []);

  const isSystemLoading = Boolean(systemBusy || ratesSyncing);
  const showVerificationAlert = Boolean(verificationConfig?.activo && role && role !== 'owner');
  const canConfigurePrinters = allowTools;

  const inboxCount =
    notificationHistory.length +
    (config.broadcast?.texto &&
    !notificationHistory.some((n) => n.texto === config.broadcast?.texto)
      ? 1
      : 0);

  // Camera barcode scanner target
  const [scannerState, setScannerState] = useState<{
    open: boolean;
    target: 'sale' | 'register';
    onScanned?: (code: string) => void;
  }>({ open: false, target: 'sale' });

  const openScanner = useCallback(
    (target: 'sale' | 'register', onScanned?: (code: string) => void) => {
      setScannerState({ open: true, target, onScanned });
    },
    []
  );

  const handleBarcodeDetected = useCallback(
    (code: string) => {
      if (scannerState.target === 'register' && scannerState.onScanned) {
        scannerState.onScanned(code);
        playBeep('ok');
        return;
      }
      const clean = code.trim().toLowerCase();
      const matched = products.find(
        (p) => (p.barcode || '').toLowerCase() === clean || (p.id || '').toLowerCase() === clean
      );
      if (matched) {
        addToCart(matched, 1);
        notifyToast(`Escaneado: ${matched.id}`, 'success');
      } else {
        notifyToast(`Código "${code}" no encontrado en inventario.`, 'warning');
        playBeep('err');
      }
    },
    [addToCart, notifyToast, playBeep, products, scannerState]
  );

  // Apply theme CSS custom property accent smoothly
  const themeObj = IG_THEMES.find((t) => t.id === activeTheme) || IG_THEMES[0];

  // Close all action modals automatically when membership reaches 0 days
  useEffect(() => {
    if (role && !isAuthorizedOwner && membershipExpired) {
      setPaymentOpen(false);
      setFiadosOpen(false);
      setCloseShiftOpen(false);
      setAdminOpen(false);
      setMotorOpen(false);
      setTallerOpen(false);
      setDrawerOpen(false);
    }
  }, [isAuthorizedOwner, membershipExpired, role]);

  // Keyboard shortcuts F1-F12 for active POS roles
  useEffect(() => {
    if (!role || (isAuthorizedOwner && !ownerPosMode) || (!isAuthorizedOwner && membershipExpired)) return;
    const onKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'F1':
          e.preventDefault();
          setShortcutsOpen(true);
          break;
        case 'F2':
          e.preventDefault();
          document.getElementById('pos-search-input')?.focus();
          break;
        case 'F3':
          e.preventDefault();
          openScanner('sale');
          break;
        case 'F4':
          e.preventDefault();
          if (allowFiados) setFiadosOpen(true);
          break;
        case 'F5':
          e.preventDefault();
          toggleIva();
          break;
        case 'F6':
          e.preventDefault();
          if (allowMotor) setMotorOpen(true);
          break;
        case 'F7':
          e.preventDefault();
          if (allowTaller) setTallerOpen(true);
          break;
        case 'F8':
          e.preventDefault();
          if (cart.length > 0) setPaymentOpen(true);
          break;
        case 'F9':
          e.preventDefault();
          if (allowCloseShift) setCloseShiftOpen(true);
          break;
        case 'F10':
          e.preventDefault();
          if (role === 'admin' || role === 'owner') setAdminOpen(true);
          break;
        case 'F12':
          e.preventDefault();
          logout();
          break;
        default:
          break;
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    allowCloseShift,
    allowFiados,
    allowMotor,
    allowTaller,
    cart.length,
    isAuthorizedOwner,
    logout,
    membershipExpired,
    openScanner,
    ownerPosMode,
    role,
    toggleIva,
  ]);

  if (publicCheckerTenantId) {
    return <PriceCheckerView tenantId={publicCheckerTenantId} />;
  }

  if (previewCheckerTenantId) {
    return (
      <PriceCheckerView
        tenantId={previewCheckerTenantId}
        onExitPreview={() => setPreviewCheckerTenantId(null)}
      />
    );
  }

  return (
    <div className="min-h-screen text-slate-900">
      {!splashDone && (
        <SplashIntro ready={firebaseReady} onFinish={() => setSplashDone(true)} />
      )}

      {splashDone && !role && <AuthPortal />}

      {splashDone && isAuthorizedOwner && !ownerPosMode && (
        <OwnerPanel
          onOpenSecurity={() => setSecurityOpen(true)}
          onEnterPos={() => setOwnerPosMode(true)}
        />
      )}

      {splashDone && role && (!isAuthorizedOwner || ownerPosMode) && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className={`min-h-screen flex flex-col ${
            viewMode === 'mobile' && isWideViewport
              ? 'max-w-[460px] mx-auto shadow-2xl border-x border-sky-100 bg-white/80 relative'
              : 'w-full'
          }`}
        >
          {/* Crisp Frosted Light Top Bar */}
          <header className="sticky top-0 z-30 bg-white/92 backdrop-blur-xl text-slate-800 border-b border-slate-200/80 shadow-[0_6px_24px_-16px_rgba(14,116,144,0.18)]">
            <div
              className="h-[3px] w-full relative overflow-hidden"
              style={{
                background: `linear-gradient(90deg, ${themeObj.c1}, ${themeObj.c2})`,
              }}
            >
              {isSystemLoading && (
                <motion.div
                  initial={{ x: '-100%' }}
                  animate={{ x: '250%' }}
                  transition={{ repeat: Infinity, duration: 1.15, ease: 'easeInOut' }}
                  className="absolute inset-y-0 w-2/5 bg-white/85 shadow-[0_0_10px_rgba(255,255,255,0.95)]"
                />
              )}
            </div>

            {/* Owner-Activated Data Verification & Update Alert Bar (Top of Menu) */}
            <AnimatePresence>
              {showVerificationAlert && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.25 }}
                  className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 text-white border-b border-amber-600/30 overflow-hidden"
                >
                  <div className="max-w-[1440px] mx-auto px-3 sm:px-5 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="relative flex h-2.5 w-2.5 shrink-0">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-80" />
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-white" />
                      </span>
                      <ClipboardCheck className="w-4 h-4 shrink-0" />
                      <div className="min-w-0">
                        <span className="font-extrabold">
                          Actualización y Verificación de Datos Requerida:
                        </span>{' '}
                        <span className="text-amber-50 font-medium">
                          {verificationPendingCount > 0
                            ? `Tienes ${verificationPendingCount} requisito(s) pendiente(s) por enviar o corregir.`
                            : 'Tus documentos fueron enviados y están en proceso de verificación.'}
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setVerificationOpen(true)}
                      className="px-3 py-1 rounded-lg bg-white text-amber-800 hover:bg-amber-50 font-extrabold text-[11px] inline-flex items-center gap-1.5 shadow-2xs cursor-pointer shrink-0 btn-press"
                    >
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      {verificationPendingCount > 0 ? 'Verificar ahora' : 'Ver Estado'}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="max-w-[1440px] mx-auto px-3 sm:px-5 h-15 flex items-center justify-between gap-2">
              {/* Zone 1: Brand + Store Identity + Animated Network Status */}
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-0.5 rounded-xl bg-sky-50/90 border border-sky-100 shrink-0">
                  <InnovaLogo size={34} />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-sm tracking-tight text-slate-900 truncate">
                      {localName}
                    </span>
                    {/* Clean Server-Connected Indicator with Smooth Pulse Animation */}
                    <motion.span
                      initial={{ opacity: 0.75, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.22 }}
                      className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold border bg-emerald-50 text-emerald-700 border-emerald-200/80 whitespace-nowrap shrink-0"
                      title="Conectada al servidor en tiempo real"
                    >
                      <span className="relative flex h-2 w-2 shrink-0">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                      </span>
                      <Activity className="w-3 h-3 text-emerald-600 animate-pulse shrink-0" />
                      <span className="hidden xs:inline sm:inline">Conectada</span>
                    </motion.span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 truncate font-medium">
                    <span className="truncate">
                      {operatorName || 'Operador'} ·{' '}
                      {role === 'admin'
                        ? 'Administrador'
                        : role === 'owner'
                        ? 'Propietario'
                        : 'Cajero'}
                    </span>
                    {isSystemLoading && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-sky-600 shrink-0">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        <span className="hidden md:inline">
                          {systemBusyLabel || (ratesSyncing ? 'Actualizando tasas...' : 'Cargando...')}
                        </span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Zone 2: Concise Action Navigation (Desktop Mode) */}
              <nav
                className={`${
                  isMobileLayout ? 'hidden' : 'flex'
                } items-center gap-1 text-xs font-semibold overflow-x-auto scrollbar-thin`}
              >
                {isAuthorizedOwner && (
                  <button
                    type="button"
                    onClick={() => setOwnerPosMode(false)}
                    className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200/80 text-amber-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                  >
                    <Crown className="w-3.5 h-3.5 text-amber-600" /> Panel Propietario
                  </button>
                )}
                {(role === 'admin' || isAuthorizedOwner) && (
                  <button
                    type="button"
                    onClick={() => setAdminOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200/80 text-sky-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                  >
                    <Package className="w-3.5 h-3.5 text-sky-600" /> Inventario & Admin
                  </button>
                )}
                {canConfigurePrinters && (
                  <button
                    type="button"
                    onClick={() => setDevicesOpen(true)}
                    className={`px-2.5 py-1.5 rounded-xl inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer btn-press border ${
                      activePrinter
                        ? 'bg-emerald-50/90 hover:bg-emerald-100 border-emerald-200/80 text-emerald-800'
                        : 'bg-slate-50 hover:bg-sky-50 border-slate-200/80 text-slate-700 hover:text-sky-700'
                    }`}
                    title={`Facturación precisa e impresoras · ${invoiceConfig.impresora_nombre || 'Impresora Térmica'} (${invoiceConfig.ancho_papel || '80mm'})`}
                  >
                    <span className="relative inline-flex">
                      <Printer className={`w-3.5 h-3.5 ${activePrinter ? 'text-emerald-600' : 'text-sky-600'}`} />
                      {activePrinter && (
                        <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      )}
                    </span>
                    Impresora
                  </button>
                )}
                {allowFiados && (
                  <button
                    type="button"
                    onClick={() => setFiadosOpen(true)}
                    className="px-3 py-1.5 rounded-xl text-slate-700 hover:bg-sky-50/80 hover:text-sky-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-slate-500" /> Fiados
                  </button>
                )}
                {allowMotor && (
                  <button
                    type="button"
                    onClick={() => setMotorOpen(true)}
                    className="px-3 py-1.5 rounded-xl text-slate-700 hover:bg-sky-50/80 hover:text-sky-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                  >
                    <Wrench className="w-3.5 h-3.5 text-slate-500" /> Motor
                  </button>
                )}
                {allowTaller && (
                  <button
                    type="button"
                    onClick={() => setTallerOpen(true)}
                    className="px-3 py-1.5 rounded-xl text-slate-700 hover:bg-sky-50/80 hover:text-sky-700 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                  >
                    <Store className="w-3.5 h-3.5 text-slate-500" /> Taller
                  </button>
                )}
                {allowEditRates && (
                  <button
                    type="button"
                    disabled={ratesSyncing}
                    onClick={() => void syncAllRates(false)}
                    className="px-2.5 py-1.5 rounded-xl text-slate-700 hover:bg-sky-50/80 hover:text-sky-700 disabled:opacity-60 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                    title="Sincronizar tasas BCV y Paralelo/USDT"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 text-sky-500 ${ratesSyncing ? 'animate-spin' : ''}`}
                    />{' '}
                    {ratesSyncing ? 'Actualizando...' : 'Tasas'}
                  </button>
                )}
                {allowVoidInvoice && (
                  <button
                    type="button"
                    onClick={() => setVoidInvoiceOpen(true)}
                    className="px-2.5 py-1.5 rounded-xl text-rose-700 hover:bg-rose-50 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                    title="Anular factura y devolver stock (Autorización Admin)"
                  >
                    <Ban className="w-3.5 h-3.5 text-rose-500" /> Anular
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setDrawerOpen(true)}
                  className="px-2.5 py-1.5 rounded-xl text-slate-600 hover:bg-slate-100 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer btn-press"
                  title="Más herramientas"
                >
                  <Menu className="w-4 h-4" />
                </button>
              </nav>

              {/* Zone 3: Music Mini-Control + Primary Shift Action + Printer (Mobile) + Notifications + Mode */}
              <div className="flex items-center gap-1.5 shrink-0 relative">
                {/* Floating Top-Bar Active Music Icon & Quick Controls */}
                <AnimatePresence>
                  {musicState.active && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="relative"
                    >
                      <button
                        type="button"
                        onClick={() => setMusicPopoverOpen((v) => !v)}
                        className={`px-2.5 py-1.5 rounded-xl border inline-flex items-center gap-1.5 cursor-pointer btn-press transition-colors ${
                          musicState.playing
                            ? 'bg-gradient-to-r from-sky-500 to-indigo-500 text-white border-sky-400 shadow-sm'
                            : 'bg-sky-50 text-sky-700 border-sky-200 hover:bg-sky-100'
                        }`}
                        title={
                          musicState.title
                            ? `Música: ${musicState.title} (${musicState.playing ? 'Reproduciendo' : 'En pausa'})`
                            : 'Controlar música en segundo plano'
                        }
                        aria-label="Controlar música en segundo plano"
                      >
                        <Music className={`w-3.5 h-3.5 shrink-0 ${musicState.playing ? 'animate-pulse' : ''}`} />
                        {musicState.playing ? (
                          <span className="inline-flex items-end gap-[2px] h-3" aria-hidden="true">
                            <motion.span
                              animate={{ height: ['35%', '100%', '45%'] }}
                              transition={{ repeat: Infinity, duration: 0.7, ease: 'easeInOut' }}
                              className="w-[2.5px] rounded-full bg-white"
                            />
                            <motion.span
                              animate={{ height: ['90%', '30%', '100%'] }}
                              transition={{ repeat: Infinity, duration: 0.55, ease: 'easeInOut' }}
                              className="w-[2.5px] rounded-full bg-white"
                            />
                            <motion.span
                              animate={{ height: ['45%', '85%', '35%'] }}
                              transition={{ repeat: Infinity, duration: 0.8, ease: 'easeInOut' }}
                              className="w-[2.5px] rounded-full bg-white"
                            />
                          </span>
                        ) : (
                          <Pause className="w-3 h-3 shrink-0" />
                        )}
                      </button>

                      {/* Mini-Player Quick Controls Popover */}
                      <AnimatePresence>
                        {musicPopoverOpen && (
                          <>
                            <div
                              className="fixed inset-0 z-[138]"
                              onClick={() => setMusicPopoverOpen(false)}
                            />
                            <motion.div
                              initial={{ opacity: 0, y: -8, scale: 0.96 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: -8, scale: 0.96 }}
                              transition={{ duration: 0.18 }}
                              className="absolute right-0 mt-2 w-72 bg-white/98 backdrop-blur-xl rounded-2xl border border-sky-200 shadow-2xl p-3.5 z-[140] space-y-3"
                            >
                              <div className="flex items-center gap-2.5">
                                {musicState.thumbnail ? (
                                  <img
                                    src={musicState.thumbnail}
                                    alt={musicState.title}
                                    className="w-11 h-11 rounded-xl object-cover border border-slate-200 shrink-0"
                                  />
                                ) : (
                                  <div className="w-11 h-11 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                                    <Music className="w-5 h-5" />
                                  </div>
                                )}
                                <div className="min-w-0 flex-1">
                                  <p className="text-xs font-extrabold text-slate-900 truncate">
                                    {musicState.title || 'Reproduciendo música'}
                                  </p>
                                  <p className="text-[11px] text-slate-500 truncate">
                                    {musicState.channel || 'YouTube Audio'}
                                  </p>
                                  <span
                                    className={`inline-block mt-0.5 text-[10px] font-bold ${
                                      musicState.playing ? 'text-emerald-600' : 'text-amber-600'
                                    }`}
                                  >
                                    {musicState.playing ? '● En reproducción (2do plano)' : '❚❚ En pausa'}
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center justify-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => sendMusicCommand('prev')}
                                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                                  title="Canción anterior"
                                >
                                  <SkipBack className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => sendMusicCommand('toggle')}
                                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                                >
                                  {musicState.playing ? (
                                    <>
                                      <Pause className="w-4 h-4" /> Pausar
                                    </>
                                  ) : (
                                    <>
                                      <Play className="w-4 h-4" /> Reanudar
                                    </>
                                  )}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => sendMusicCommand('next')}
                                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                                  title="Siguiente canción"
                                >
                                  <SkipForward className="w-4 h-4" />
                                </button>
                              </div>

                              <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-slate-100">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setMusicPopoverOpen(false);
                                    setMusicOpen(true);
                                  }}
                                  className="py-1.5 px-2.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 text-[11px] font-bold inline-flex items-center justify-center gap-1 cursor-pointer"
                                >
                                  <Music className="w-3.5 h-3.5" /> Reproductor
                                </button>
                                <button
                                  type="button"
                                  onClick={() => sendMusicCommand('cancel')}
                                  className="py-1.5 px-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold inline-flex items-center justify-center gap-1 cursor-pointer"
                                >
                                  <Square className="w-3 h-3 fill-current" /> Cancelar
                                </button>
                              </div>
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  )}
                </AnimatePresence>

                {allowCloseShift && (
                  <button
                    type="button"
                    onClick={() => setCloseShiftOpen(true)}
                    className="px-3.5 py-1.5 rounded-xl text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer shadow-xs hover:brightness-105 btn-press"
                    style={{
                      background: `linear-gradient(135deg, ${themeObj.accent || '#0284c7'}, ${themeObj.c2})`,
                    }}
                  >
                    Cerrar Turno
                  </button>
                )}
                {isMobileLayout && canConfigurePrinters && (
                  <button
                    type="button"
                    onClick={() => setDevicesOpen(true)}
                    className={`relative p-2 rounded-xl cursor-pointer btn-press transition-colors ${
                      activePrinter
                        ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/80'
                        : 'bg-slate-100/90 hover:bg-sky-50 text-slate-600 hover:text-sky-700'
                    }`}
                    title="Configurar Impresora y Facturación Precisa"
                    aria-label="Configurar Impresora"
                  >
                    <Printer className="w-4 h-4" />
                    {activePrinter && (
                      <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500" />
                    )}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setInnovaChatOpen(true)}
                  className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-700 hover:to-sky-700 text-white text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer shadow-xs btn-press"
                  title="Abrir Chat con el Asistente Virtual Innova Grup IA"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Chat Innova Grup</span>
                  <span className="md:hidden">IA</span>
                </button>
                <PWAInstallButton compact />
                <button
                  type="button"
                  onClick={() => setNotificationsOpen(true)}
                  className={`relative p-2 rounded-xl cursor-pointer btn-press transition-colors ${
                    pushSupported && pushEnabled && pushPermission === 'granted'
                      ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/80'
                      : 'bg-slate-100/90 hover:bg-sky-50 text-slate-600 hover:text-sky-700'
                  }`}
                  title="Centro de Notificaciones (Push e historial del propietario)"
                  aria-label="Centro de Notificaciones"
                >
                  {pushSupported && pushEnabled && pushPermission === 'granted' ? (
                    <BellRing className="w-4 h-4" />
                  ) : (
                    <Bell className="w-4 h-4" />
                  )}
                  {inboxCount > 0 && (
                    <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-mono font-extrabold flex items-center justify-center shadow-xs">
                      {inboxCount > 99 ? '99+' : inboxCount}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const next = isMobileLayout ? 'desktop' : 'mobile';
                    setViewMode(next);
                    notifyToast(
                      next === 'desktop' ? 'Modo Escritorio activado' : 'Modo Móvil activado',
                      'info'
                    );
                  }}
                  className="p-2 rounded-xl bg-slate-100/90 hover:bg-sky-50 text-slate-600 hover:text-sky-700 cursor-pointer btn-press"
                  title={isMobileLayout ? 'Cambiar a Modo Escritorio' : 'Cambiar a Modo Móvil'}
                  aria-label="Cambiar modo de pantalla"
                >
                  {isMobileLayout ? (
                    <Monitor className="w-4 h-4" />
                  ) : (
                    <Smartphone className="w-4 h-4" />
                  )}
                </button>
                {isMobileLayout && (
                  <button
                    type="button"
                    onClick={() => setDrawerOpen(true)}
                    className="p-2 rounded-xl bg-slate-100/90 hover:bg-sky-50 text-slate-700 cursor-pointer btn-press"
                    aria-label="Menú"
                  >
                    <Menu className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => window.location.reload()}
                  className="p-2 rounded-xl bg-slate-100/80 hover:bg-sky-50 text-slate-600 hover:text-sky-700 cursor-pointer btn-press"
                  title="Recargar página"
                  aria-label="Recargar página"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={logout}
                  className="hidden sm:inline-flex p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer btn-press"
                  title="Cerrar sesión (F12)"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          </header>

          {/* Main Workspace */}
          <div className={`flex-1 p-3 sm:p-5 max-w-[1440px] w-full mx-auto ${isMobileLayout ? 'pb-20' : ''}`}>
            <PosWorkspace
              onOpenPayment={() => setPaymentOpen(true)}
              onOpenScanner={openScanner}
              onOpenDevices={allowTools ? () => setDevicesOpen(true) : undefined}
              onOpenVoidInvoice={allowVoidInvoice ? () => setVoidInvoiceOpen(true) : undefined}
              mobileView={mobileView}
            />
          </div>

          {/* Mobile Bottom Navigation */}
          {isMobileLayout && (
            <div
              className={`bg-white border-t border-slate-200 px-2 py-1.5 grid ${
                allowFiados ? 'grid-cols-5' : 'grid-cols-4'
              } gap-1 text-[11px] font-semibold z-30 ${
                viewMode === 'mobile' && isWideViewport
                  ? 'sticky bottom-0 w-full'
                  : 'fixed bottom-0 inset-x-0'
              }`}
            >
              <button
                type="button"
                onClick={() => setMobileView('catalog')}
                className={`py-1.5 min-h-[44px] rounded-xl flex flex-col items-center justify-center cursor-pointer ${
                  mobileView === 'catalog' ? 'text-sky-700 bg-sky-50' : 'text-slate-600'
                }`}
              >
                <Package className="w-4 h-4" /> Catálogo
              </button>
              <button
                type="button"
                onClick={() => setMobileView('cart')}
                className={`py-1.5 min-h-[44px] rounded-xl flex flex-col items-center justify-center cursor-pointer ${
                  mobileView === 'cart' ? 'text-sky-700 bg-sky-50' : 'text-slate-600'
                }`}
              >
                <ShoppingBasket className="w-4 h-4" /> Carrito ({cart.length})
              </button>
              <button
                type="button"
                disabled={cart.length === 0}
                onClick={() => setPaymentOpen(true)}
                className="py-1.5 min-h-[44px] rounded-xl flex flex-col items-center justify-center bg-emerald-600 text-white disabled:opacity-40 cursor-pointer"
              >
                <CreditCard className="w-4 h-4" /> ${formatMoney(cartTotals.totalUsdBcv)}
              </button>
              {allowFiados && (
                <button
                  type="button"
                  onClick={() => setFiadosOpen(true)}
                  className="py-1.5 min-h-[44px] rounded-xl flex flex-col items-center justify-center text-slate-600 cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" /> Fiados
                </button>
              )}
              <button
                type="button"
                onClick={() => setDrawerOpen(true)}
                className="py-1.5 min-h-[44px] rounded-xl flex flex-col items-center justify-center text-slate-600 cursor-pointer"
              >
                <Menu className="w-4 h-4" /> Más
              </button>
            </div>
          )}
        </motion.div>
      )}

      {/* Animated Tools Side Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[135] bg-slate-900/20 backdrop-blur-sm flex justify-end"
            onClick={() => setDrawerOpen(false)}
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white/95 backdrop-blur-xl w-80 max-w-full h-full shadow-2xl border-l border-sky-100 p-5 flex flex-col justify-between overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">Herramientas del Sistema</h3>
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  className="text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-1.5 text-xs font-semibold">
                {isAuthorizedOwner && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setOwnerPosMode(false);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl bg-amber-50 text-amber-900 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Crown className="w-4 h-4 text-amber-600" /> Ir al Panel Maestro Propietario
                  </button>
                )}
                {(role === 'admin' || isAuthorizedOwner) && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setAdminOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Package className="w-4 h-4 text-sky-600" /> Administración e Inventario
                  </button>
                )}
                {(role === 'admin' || isAuthorizedOwner) && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setSecurityOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Shield className="w-4 h-4 text-indigo-600" /> Seguridad de Cuenta / MFA
                  </button>
                )}
                {allowFiados && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setFiadosOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                  >
                    <BookOpen className="w-4 h-4 text-rose-600" /> Cuentas por Cobrar (Fiados)
                  </button>
                )}
                {allowMotor && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setMotorOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Wrench className="w-4 h-4 text-sky-600" /> Registrar Reparación Motor
                  </button>
                )}
                {allowTaller && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setTallerOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Store className="w-4 h-4 text-emerald-600" /> Control y Cierre de Taller
                  </button>
                )}
                {allowVoidInvoice && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setVoidInvoiceOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl hover:bg-rose-50 text-rose-700 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Ban className="w-4 h-4 text-rose-600" /> Anular Factura (Autorización Admin)
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    setInnovaChatOpen(true);
                  }}
                  className="w-full px-3 py-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-900 flex items-center gap-2.5 cursor-pointer"
                >
                  <Bot className="w-4 h-4 text-indigo-600" /> Chat Innova Grup · Asistente IA
                </button>
                {showVerificationAlert && (
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      setVerificationOpen(true);
                    }}
                    className="w-full px-3 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 flex items-center justify-between gap-2 cursor-pointer"
                  >
                    <span className="inline-flex items-center gap-2.5">
                      <ClipboardCheck className="w-4 h-4 text-amber-600" /> Verificación de Datos
                    </span>
                    {verificationPendingCount > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-bold">
                        {verificationPendingCount}
                      </span>
                    )}
                  </button>
                )}
                {allowTools && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        setMusicOpen(true);
                      }}
                      className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center justify-between gap-2.5 cursor-pointer"
                    >
                      <span className="inline-flex items-center gap-2.5">
                        <Music className="w-4 h-4 text-sky-600" /> Música Ambiental (YouTube)
                      </span>
                      {musicState.active && (
                        <span
                          className={`w-2 h-2 rounded-full ${
                            musicState.playing ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'
                          }`}
                        />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        setDevicesOpen(true);
                      }}
                      className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center justify-between gap-2.5 cursor-pointer"
                    >
                      <span className="inline-flex items-center gap-2.5">
                        <Printer className="w-4 h-4 text-sky-600" /> Facturación e Impresoras
                      </span>
                      {activePrinter && (
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      )}
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    setShortcutsOpen(true);
                  }}
                  className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                >
                  <Keyboard className="w-4 h-4 text-slate-600" /> Atajos de Teclado (F1-F12)
                </button>
                {(role === 'admin' || isAuthorizedOwner) && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        setMembershipOpen(true);
                      }}
                      className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                    >
                      <Crown className="w-4 h-4 text-amber-600" /> Membresía y Renovación
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDrawerOpen(false);
                        setSupportOpen(true);
                      }}
                      className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-100 text-slate-800 flex items-center gap-2.5 cursor-pointer"
                    >
                      <Headphones className="w-4 h-4 text-sky-600" /> Soporte Técnico
                    </button>
                  </>
                )}
                {role === 'cashier' && (
                  <p className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-[11px] font-normal text-slate-500">
                    Modo Cajero activo. El administrador gestiona qué módulos adicionales puedes utilizar.
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2.5 pt-3 border-t border-slate-100">
              <div className="space-y-1.5">
                <span className="text-[11px] font-semibold text-slate-500 block">
                  Modo de Pantalla
                </span>
                <ViewModeToggle />
              </div>
              <div className="flex flex-col gap-2">
                <PWAInstallButton className="w-full justify-center" />
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    setNotificationsOpen(true);
                  }}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-2 cursor-pointer border ${
                    pushSupported && pushEnabled && pushPermission === 'granted'
                      ? 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-800'
                      : 'bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-800'
                  }`}
                >
                  {pushSupported && pushEnabled && pushPermission === 'granted' ? (
                    <BellRing className="w-4 h-4" />
                  ) : (
                    <Bell className="w-4 h-4" />
                  )}
                  <span>
                    Centro de Notificaciones{inboxCount > 0 ? ` (${inboxCount})` : ''}
                  </span>
                </button>
              </div>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCw className="w-4 h-4" /> Recargar Página
              </button>
              <button
                type="button"
                onClick={() => {
                  setDrawerOpen(false);
                  logout();
                }}
                className="w-full py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-4 h-4" /> Cerrar Sesión
              </button>
            </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Remote Overlays (Maintenance / Frozen User — Owner Panel NEVER enters maintenance) */}
      {splashDone && role && !isAuthorizedOwner && maintenanceMode && (
        <div className="fixed inset-0 z-[185] bg-slate-900/25 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white/95 backdrop-blur-xl border border-amber-100 rounded-3xl max-w-md w-full p-7 text-center space-y-4 shadow-2xl animate-panel-in">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200/80 flex items-center justify-center mx-auto">
              <Lock className="w-7 h-7 text-amber-500" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900">Sistema en Mantenimiento</h3>
            <p className="text-sm text-slate-600 whitespace-pre-wrap">
              {maintenanceMessage ||
                'El propietario ha activado el modo mantenimiento temporal. Las operaciones se reanudarán en breve.'}
            </p>
            <button
              type="button"
              onClick={logout}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white text-xs font-semibold cursor-pointer shadow-xs btn-press"
            >
              Cerrar Sesión
            </button>
          </div>
        </div>
      )}

      {splashDone && role === 'cashier' && userFrozen && !maintenanceMode && (
        <div className="fixed inset-0 z-[185] bg-slate-900/25 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white/95 backdrop-blur-xl border border-sky-100 rounded-3xl max-w-md w-full p-7 text-center space-y-4 shadow-2xl animate-panel-in">
            <div className="w-14 h-14 rounded-2xl bg-sky-50 border border-sky-200/80 flex items-center justify-center mx-auto">
              <Snowflake className="w-7 h-7 text-sky-500" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900">Terminal Pausada Remotamente</h3>
            <p className="text-sm text-slate-600">
              Esta sesión de caja ha sido congelada desde el panel de gerencia.
            </p>
            <button
              type="button"
              onClick={logout}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white text-xs font-semibold cursor-pointer shadow-xs btn-press"
            >
              Salir del Turno
            </button>
          </div>
        </div>
      )}

      {/* Membership Expiration Warning Modal */}
      {splashDone && role && role !== 'owner' && activeMembershipWarning && !membershipOpen && (
        <div className="fixed inset-0 z-[179] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-amber-200 max-w-md w-full overflow-hidden shadow-2xl">
            <div className="px-5 py-3.5 bg-amber-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4" />
                <h4 className="text-sm font-bold">{activeMembershipWarning.titulo}</h4>
              </div>
              <button
                type="button"
                onClick={dismissMembershipWarning}
                className="text-white/80 hover:text-white cursor-pointer"
                aria-label="Cerrar aviso"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-sm text-slate-800 whitespace-pre-wrap">
                {activeMembershipWarning.mensaje}
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    dismissMembershipWarning();
                    setMembershipOpen(true);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer"
                >
                  Renovar ahora
                </button>
                <button
                  type="button"
                  onClick={dismissMembershipWarning}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Entendido
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Broadcast Notification Modal */}
      {splashDone && role && activeBroadcast && (
        <div className="fixed inset-0 z-[180] bg-slate-900/20 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white/95 backdrop-blur-xl rounded-3xl border border-slate-200/80 max-w-md w-full overflow-hidden shadow-2xl animate-panel-in">
            <div
              className={`px-5 py-3.5 text-white flex items-center justify-between ${
                activeBroadcast.tipo === 'critical'
                  ? 'bg-gradient-to-r from-rose-500 to-pink-500'
                  : activeBroadcast.tipo === 'warning'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-400'
                  : 'bg-gradient-to-r from-sky-500 to-cyan-500'
              }`}
            >
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                <h4 className="text-sm font-bold">{activeBroadcast.titulo || 'Aviso de Gerencia'}</h4>
              </div>
              <button
                type="button"
                onClick={dismissBroadcast}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-sm text-slate-800 whitespace-pre-wrap">{activeBroadcast.texto}</p>
              <div className="flex flex-col sm:flex-row gap-2">
                {(verificationConfig?.activo ||
                  /verificaci[oó]n|actualizaci[oó]n de datos|documentos/i.test(
                    `${activeBroadcast.titulo || ''} ${activeBroadcast.texto || ''}`
                  )) && (
                  <button
                    type="button"
                    onClick={() => {
                      dismissBroadcast();
                      setVerificationOpen(true);
                    }}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold inline-flex items-center justify-center gap-1.5 cursor-pointer btn-press shadow-xs"
                  >
                    <ClipboardCheck className="w-4 h-4" />
                    Verificar ahora
                  </button>
                )}
                <button
                  type="button"
                  onClick={dismissBroadcast}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white text-xs font-semibold cursor-pointer btn-press"
                >
                  Entendido
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Runtime Error Recovery Banner */}
      {runtimeError && (
        <div className="fixed bottom-20 lg:bottom-4 right-4 z-[205] max-w-sm w-full px-4 sm:px-0">
          <div className="bg-white/95 backdrop-blur-xl border border-rose-200 rounded-2xl shadow-xl p-4 space-y-2.5 animate-panel-in">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 text-rose-700">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span className="text-xs font-bold">Se detectó un error en la aplicación</span>
              </div>
              <button
                type="button"
                onClick={clearRuntimeError}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
                aria-label="Cerrar alerta"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-[11px] text-slate-600 line-clamp-2 break-words">{runtimeError}</p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="flex-1 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer btn-press"
              >
                <RotateCw className="w-3.5 h-3.5" /> Recargar página
              </button>
              <button
                type="button"
                onClick={clearRuntimeError}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer btn-press"
              >
                Ignorar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Animated Toast Stack */}
      <div className="fixed top-4 right-4 z-[200] flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
        <AnimatePresence initial={false}>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -12, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 24, scale: 0.96 }}
              transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
              className={`pointer-events-auto px-4 py-3 rounded-2xl shadow-[0_12px_28px_-12px_rgba(15,23,42,0.16)] backdrop-blur-xl border text-xs font-semibold flex items-center gap-2.5 bg-white/95 ${
                t.type === 'success'
                  ? 'border-emerald-200 text-emerald-900'
                  : t.type === 'warning'
                  ? 'border-amber-200 text-amber-900'
                  : t.type === 'error'
                  ? 'border-rose-200 text-rose-900'
                  : 'border-sky-200 text-slate-900'
              }`}
            >
              {t.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              ) : t.type === 'warning' || t.type === 'error' ? (
                <AlertTriangle
                  className={`w-4 h-4 shrink-0 ${
                    t.type === 'error' ? 'text-rose-500' : 'text-amber-500'
                  }`}
                />
              ) : (
                <Info className="w-4 h-4 text-sky-500 shrink-0" />
              )}
              <span>{t.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Floating Animated System Loading Pill when busy */}
      <AnimatePresence>
        {isSystemLoading && splashDone && role && (
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.94 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-20 lg:bottom-5 left-1/2 -translate-x-1/2 z-[195] pointer-events-none"
          >
            <div className="px-4 py-2 rounded-full bg-slate-900/90 text-white backdrop-blur-md shadow-xl border border-white/15 flex items-center gap-2 text-xs font-semibold">
              <Loader2 className="w-3.5 h-3.5 text-sky-400 animate-spin" />
              <span>{systemBusyLabel || (ratesSyncing ? 'Sincronizando tasas...' : 'Cargando datos...')}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* All POS Modals */}
      <PaymentModal open={paymentOpen} onClose={() => setPaymentOpen(false)} />
      <FiadosModal open={fiadosOpen} onClose={() => setFiadosOpen(false)} />
      <CloseShiftModal open={closeShiftOpen} onClose={() => setCloseShiftOpen(false)} />
      <VoidInvoiceModal open={voidInvoiceOpen} onClose={() => setVoidInvoiceOpen(false)} />
      <AdminPanel
        open={adminOpen}
        onClose={() => setAdminOpen(false)}
        onOpenSecurity={() => setSecurityOpen(true)}
        onOpenScanner={openScanner}
        onOpenFiados={() => setFiadosOpen(true)}
        onOpenCloseShift={() => setCloseShiftOpen(true)}
        onOpenTaller={() => setTallerOpen(true)}
        onOpenMotor={() => setMotorOpen(true)}
        onOpenSupport={() => setSupportOpen(true)}
        onOpenMembership={() => setMembershipOpen(true)}
        onOpenPriceChecker={(tid) => {
          setAdminOpen(false);
          setPreviewCheckerTenantId(tid);
        }}
      />
      <AccountSecurityModal open={securityOpen} onClose={() => setSecurityOpen(false)} />
      <MotorRepairModal open={motorOpen} onClose={() => setMotorOpen(false)} />
      <TallerModal open={tallerOpen} onClose={() => setTallerOpen(false)} />
      <BarcodeScannerModal
        open={scannerState.open}
        onClose={() => setScannerState((prev) => ({ ...prev, open: false }))}
        onDetected={handleBarcodeDetected}
      />
      <DevicesModal open={devicesOpen} onClose={() => setDevicesOpen(false)} />
      <MusicPlayerModal
        open={musicOpen}
        onClose={() => setMusicOpen(false)}
        onStateChange={setMusicState}
        externalCommand={musicCmd}
      />
      <ShortcutsModal open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />
      <SupportModal open={supportOpen} onClose={() => setSupportOpen(false)} />
      <NotificationsModal
        open={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        onOpenVerification={() => {
          setNotificationsOpen(false);
          setVerificationOpen(true);
        }}
      />
      <ClientVerificationModal
        open={verificationOpen}
        onClose={() => setVerificationOpen(false)}
      />
      {splashDone && role && (
        <InnovaAvatarAssistant
          contextMode="pos"
          activeTenant={activeTenant}
          seniatActive={config.seniat_legal_activo === true}
          externalOpen={innovaChatOpen}
          onExternalClose={() => setInnovaChatOpen(false)}
          hideFloatingButton
        />
      )}
      <MembershipModal
        open={membershipOpen}
        forcedLock={Boolean(splashDone && role && !isAuthorizedOwner && membershipExpired)}
        onClose={() => setMembershipOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppErrorBoundary>
      <PosProvider>
        <AppContent />
      </PosProvider>
    </AppErrorBoundary>
  );
}
