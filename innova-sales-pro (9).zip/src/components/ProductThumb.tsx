import React, { useState } from 'react';
import { avatarHue, initialsOf } from '../utils/format';

interface ProductThumbProps {
  name: string;
  image?: string;
  className?: string;
}

export const ProductThumb: React.FC<ProductThumbProps> = ({
  name,
  image,
  className = 'w-12 h-12 text-xs',
}) => {
  const [imgFailed, setImgFailed] = useState(false);
  const hue = avatarHue(name);
  const initials = initialsOf(name);

  return (
    <div
      className={`relative rounded-xl overflow-hidden shrink-0 flex items-center justify-center font-bold text-white select-none ${className}`}
      style={{
        background: `linear-gradient(135deg, hsl(${hue}, 68%, 40%), hsl(${(hue + 38) % 360}, 72%, 54%))`,
      }}
    >
      <span>{initials}</span>
      {image && !imgFailed && (
        <img
          src={image}
          alt={name}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="absolute inset-0 w-full h-full object-cover"
        />
      )}
    </div>
  );
};
