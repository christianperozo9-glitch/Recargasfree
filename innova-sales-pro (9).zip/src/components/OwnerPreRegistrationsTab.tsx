import React, { useMemo, useState } from 'react';
import { deleteDoc, doc, updateDoc } from 'firebase/firestore';
import {
  Building2,
  CheckCircle2,
  Clock,
  Copy,
  Eye,
  EyeOff,
  FileText,
  Gift,
  KeyRound,
  Lock,
  MessageCircle,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  UserCheck,
  X,
  XCircle,
} from 'lucide-react';
import { db } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import type { PreRegistrationRecord } from '../types/pos';

function cleanPhoneForWhatsApp(raw: string): string {
  const digits = (raw || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('0') && digits.length === 11) {
    return `58${digits.slice(1)}`;
  }
  if (digits.length === 10 && digits.startsWith('4')) {
    return `58${digits}`;
  }
  return digits;
}

function generateSecureTempPassword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#';
  let out = 'Inv';
  for (let i = 0; i < 7; i++) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return out;
}

interface ApprovedResultState {
  preReg: PreRegistrationRecord;
  tenantId: string;
  email: string;
  password: string;
  adminPin: string;
  cajaPin: string;
  trialDays: number;
  authNotice: string;
}

export const OwnerPreRegistrationsTab: React.FC<{
  onOpenClient?: (tenantId: string) => void;
}> = ({ onOpenClient }) => {
  const {
    preRegistrations,
    registerNewTenantClient,
    operatorEmail,
    notifyToast,
    playBeep,
  } = usePos();

  const [filter, setFilter] = useState<'all' | 'pendiente' | 'aprobado' | 'rechazado'>('all');
  const [search, setSearch] = useState('');
  const [zoomRif, setZoomRif] = useState<{ src: string; title: string } | null>(null);

  // Approval configuration modal
  const [approvingItem, setApprovingItem] = useState<PreRegistrationRecord | null>(null);
  const [cfgPassword, setCfgPassword] = useState('');
  const [showPassword, setShowPassword] = useState(true);
  const [cfgAdminPin, setCfgAdminPin] = useState('1234');
  const [cfgCajaPin, setCfgCajaPin] = useState('0000');
  const [cfgTrialDays, setCfgTrialDays] = useState(5);
  const [submittingApproval, setSubmittingApproval] = useState(false);

  // Success panel with WhatsApp welcome button
  const [approvedSuccess, setApprovedSuccess] = useState<ApprovedResultState | null>(null);

  // Reject / Delete inline state
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectNote, setRejectNote] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const counts = useMemo(() => {
    let pendiente = 0;
    let aprobado = 0;
    let rechazado = 0;
    preRegistrations.forEach((p) => {
      if (p.estado === 'aprobado') aprobado += 1;
      else if (p.estado === 'rechazado') rechazado += 1;
      else pendiente += 1;
    });
    return { pendiente, aprobado, rechazado, total: preRegistrations.length };
  }, [preRegistrations]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return preRegistrations.filter((p) => {
      if (filter !== 'all' && p.estado !== filter) return false;
      if (!q) return true;
      return (
        (p.nombre_local || '').toLowerCase().includes(q) ||
        (p.razon_social || '').toLowerCase().includes(q) ||
        (p.rif || '').toLowerCase().includes(q) ||
        (p.email || '').toLowerCase().includes(q) ||
        (p.contacto_nombre || '').toLowerCase().includes(q)
      );
    });
  }, [preRegistrations, filter, search]);

  const openApprovalModal = (item: PreRegistrationRecord) => {
    setApprovingItem(item);
    setCfgPassword(generateSecureTempPassword());
    setShowPassword(true);
    setCfgAdminPin('1234');
    setCfgCajaPin('0000');
    setCfgTrialDays(5);
  };

  const buildWelcomeWhatsAppUrl = (res: ApprovedResultState): string => {
    const phone = cleanPhoneForWhatsApp(res.preReg.telefono);
    const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
    const msg = [
      `🎉 *¡BIENVENIDO A INNOVA GRUP POS!* 🎉`,
      ``,
      `Hola *${res.preReg.contacto_nombre || res.preReg.nombre_local}*,`,
      `Tu negocio *${res.preReg.nombre_local}* (RIF: ${res.preReg.rif}) ha sido *APROBADO* oficialmente en nuestro sistema de ventas.`,
      ``,
      `🎁 *REGALO DE BIENVENIDA:* Tienes *${res.trialDays} días GRATIS* activos para comenzar a vender de inmediato.`,
      ``,
      `🔐 *TUS CREDENCIALES DE ACCESO:*`,
      `• *Enlace del Sistema:* ${appUrl}`,
      `• *Correo:* ${res.email}`,
      `• *Contraseña:* ${res.password}`,
      `• *PIN de Administrador:* ${res.adminPin}`,
      `• *PIN de Caja Principal:* ${res.cajaPin}`,
      ``,
      `Puedes ingresar con tu correo y contraseña o directamente con tu cuenta Google (${res.email}).`,
      `¡Mucho éxito en tus ventas! 🚀`,
      `— *Equipo Innova Grup POS*`,
    ].join('\n');

    return phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
  };

  const handleConfirmApproval = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!approvingItem) return;

    const cleanPass = cfgPassword.trim();
    const cleanAdminPin = cfgAdminPin.replace(/\D/g, '');
    const cleanCajaPin = cfgCajaPin.replace(/\D/g, '');

    if (cleanPass.length < 6) {
      notifyToast('La contraseña debe tener al menos 6 caracteres.', 'warning');
      return;
    }
    if (cleanAdminPin.length < 4 || cleanAdminPin.length > 8) {
      notifyToast('El PIN de Administrador debe tener entre 4 y 8 dígitos.', 'warning');
      return;
    }
    if (cleanCajaPin.length < 4 || cleanCajaPin.length > 8) {
      notifyToast('El PIN de Caja debe tener entre 4 y 8 dígitos.', 'warning');
      return;
    }

    setSubmittingApproval(true);
    try {
      const days = Math.max(1, Math.min(365, Number(cfgTrialDays) || 5));
      const { tenant, authResult } = await registerNewTenantClient({
        email: approvingItem.email,
        password: cleanPass,
        nombre_local: approvingItem.nombre_local,
        razon_social: approvingItem.razon_social || approvingItem.nombre_local,
        rif: approvingItem.rif,
        direccion_fiscal: approvingItem.direccion_fiscal,
        telefono: approvingItem.telefono,
        contacto_nombre: approvingItem.contacto_nombre,
        admin_pin: cleanAdminPin,
        caja_pin: cleanCajaPin,
        cajero_nombre: 'Caja Principal',
        trial_days: days,
        plan_label_override: `${days} Días de Regalo · Bienvenida`,
      });

      const now = Date.now();
      await updateDoc(doc(db, 'platform_preregistrations', approvingItem.id), {
        estado: 'aprobado',
        tenantIdAprobado: tenant.id,
        reviewedAt: now,
        reviewedBy: operatorEmail || 'Propietario',
      });

      const authNotice = authResult.authCreated
        ? 'Cuenta creada en Firebase Auth con la contraseña configurada.'
        : authResult.warning ||
          'Comercio registrado en Firestore. El cliente puede entrar con Google inmediatamente.';

      setApprovedSuccess({
        preReg: approvingItem,
        tenantId: tenant.id,
        email: approvingItem.email,
        password: cleanPass,
        adminPin: cleanAdminPin,
        cajaPin: cleanCajaPin,
        trialDays: days,
        authNotice,
      });
      setApprovingItem(null);
      playBeep('ok');
      notifyToast(
        `¡Negocio "${approvingItem.nombre_local}" aprobado con ${days} días de regalo!`,
        'success'
      );
    } catch (err) {
      notifyToast(
        err instanceof Error ? err.message : 'No se pudo aprobar el negocio.',
        'error'
      );
      playBeep('err');
    } finally {
      setSubmittingApproval(false);
    }
  };

  const handleReject = async (item: PreRegistrationRecord) => {
    try {
      const now = Date.now();
      await updateDoc(doc(db, 'platform_preregistrations', item.id), {
        estado: 'rechazado',
        nota_propietario: rejectNote.trim() || 'Solicitud rechazada por administración.',
        reviewedAt: now,
        reviewedBy: operatorEmail || 'Propietario',
      });
      setRejectingId(null);
      setRejectNote('');
      notifyToast(`Pre-registro de "${item.nombre_local}" marcado como rechazado.`, 'warning');
    } catch {
      notifyToast('Error al rechazar la solicitud.', 'error');
    }
  };

  const handleDelete = async (item: PreRegistrationRecord) => {
    try {
      await deleteDoc(doc(db, 'platform_preregistrations', item.id));
      setDeletingId(null);
      notifyToast('Pre-registro eliminado.', 'info');
    } catch {
      notifyToast('No se pudo eliminar el pre-registro.', 'error');
    }
  };

  const handleCopyCredentials = (res: ApprovedResultState) => {
    const text = `Innova Grup POS — Accesos Aprobados (${res.preReg.nombre_local})\nEnlace: ${window.location.origin}\nCorreo: ${res.email}\nContraseña: ${res.password}\nPIN Admin: ${res.adminPin}\nPIN Caja: ${res.cajaPin}\nRegalo: ${res.trialDays} días gratis`;
    void navigator.clipboard?.writeText(text);
    notifyToast('Credenciales copiadas al portapapeles.', 'success');
  };

  return (
    <div className="space-y-5">
      {/* Header & KPI Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                Pre-Registros de Nuevos Negocios
              </h2>
              <p className="text-xs text-slate-500">
                Revisa datos fiscales y legales, aprueba automáticamente con 5 días de regalo y envía accesos por WhatsApp
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-bold">
            <span className="px-2.5 py-1 rounded-xl bg-amber-50 border border-amber-200 text-amber-800">
              {counts.pendiente} Pendiente(s)
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800">
              {counts.aprobado} Aprobado(s)
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-rose-50 border border-rose-200 text-rose-800">
              {counts.rechazado} Rechazado(s)
            </span>
          </div>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por negocio, razón social, RIF, representante o correo..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
            />
          </div>
          <div className="flex items-center gap-1.5">
            {(
              [
                { id: 'all', label: `Todos (${counts.total})` },
                { id: 'pendiente', label: `Pendientes (${counts.pendiente})` },
                { id: 'aprobado', label: `Aprobados (${counts.aprobado})` },
                { id: 'rechazado', label: `Rechazados (${counts.rechazado})` },
              ] as const
            ).map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
                  filter === f.id
                    ? 'bg-sky-600 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Approved Success Banner with 1-Click Automatic WhatsApp Welcome Button */}
      {approvedSuccess && (
        <div className="bg-gradient-to-br from-emerald-50 via-white to-teal-50 rounded-2xl border-2 border-emerald-300 p-5 shadow-md space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-emerald-950">
                  ¡Negocio Aprobado y Registrado Automáticamente!
                </h3>
                <p className="text-xs text-emerald-800 mt-0.5">
                  <b>{approvedSuccess.preReg.nombre_local}</b> ya tiene su nodo POS activo con{' '}
                  <b>{approvedSuccess.trialDays} días de regalo</b>. {approvedSuccess.authNotice}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setApprovedSuccess(null)}
              className="p-1.5 rounded-lg bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
            <div className="p-3 rounded-xl bg-white border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Correo</span>
              <span className="font-mono font-bold text-slate-900 break-all">
                {approvedSuccess.email}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-white border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">
                Contraseña
              </span>
              <span className="font-mono font-bold text-slate-900">{approvedSuccess.password}</span>
            </div>
            <div className="p-3 rounded-xl bg-white border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">
                PIN Administrador
              </span>
              <span className="font-mono font-bold text-indigo-700">
                {approvedSuccess.adminPin}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-white border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">
                PIN Caja Principal
              </span>
              <span className="font-mono font-bold text-sky-700">{approvedSuccess.cajaPin}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <a
              href={buildWelcomeWhatsAppUrl(approvedSuccess)}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#1fb857] text-white text-xs font-extrabold inline-flex items-center gap-2 shadow-sm"
            >
              <MessageCircle className="w-4 h-4" />
              Enviar Bienvenida Automática por WhatsApp (Credenciales + {approvedSuccess.trialDays}{' '}
              Días Gratis)
            </a>
            <button
              type="button"
              onClick={() => handleCopyCredentials(approvedSuccess)}
              className="px-3.5 py-2.5 rounded-xl bg-white border border-emerald-200 hover:bg-emerald-50 text-emerald-900 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" /> Copiar Credenciales
            </button>
            {onOpenClient && (
              <button
                type="button"
                onClick={() => onOpenClient(approvedSuccess.tenantId)}
                className="px-3.5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold cursor-pointer"
              >
                Abrir Cliente en Panel
              </button>
            )}
          </div>
        </div>
      )}

      {/* Pre-Registrations List */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-10 text-center space-y-2">
          <Building2 className="w-9 h-9 text-slate-300 mx-auto" />
          <p className="text-sm font-bold text-slate-700">No hay pre-registros en esta vista</p>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Cuando un nuevo comercio se registre desde la pantalla de inicio con sus datos fiscales y
            legales, aparecerá aquí al instante para aprobarlo.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const isPending = item.estado === 'pendiente';
            const isApproved = item.estado === 'aprobado';
            const cleanWa = cleanPhoneForWhatsApp(item.telefono);
            const quickWaMsg = encodeURIComponent(
              `Hola ${item.contacto_nombre || item.nombre_local}, te escribimos desde Innova Grup POS respecto a tu pre-registro de ${item.nombre_local} (RIF ${item.rif}).`
            );

            return (
              <div
                key={item.id}
                className={`bg-white rounded-2xl border p-4 sm:p-5 space-y-3 shadow-2xs ${
                  isPending
                    ? 'border-amber-200'
                    : isApproved
                    ? 'border-emerald-200'
                    : 'border-rose-200'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    {item.foto_rif ? (
                      <button
                        type="button"
                        onClick={() =>
                          setZoomRif({
                            src: item.foto_rif!,
                            title: `RIF / Documento Legal · ${item.nombre_local}`,
                          })
                        }
                        className="w-16 h-16 rounded-xl border border-slate-200 overflow-hidden bg-slate-100 shrink-0 cursor-pointer hover:ring-2 hover:ring-sky-400 relative group"
                        title="Ver foto del RIF"
                      >
                        <img
                          src={item.foto_rif}
                          alt="RIF"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute inset-0 bg-slate-950/35 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                          <Eye className="w-4 h-4" />
                        </span>
                      </button>
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 text-slate-500 flex items-center justify-center shrink-0">
                        <Building2 className="w-5 h-5" />
                      </div>
                    )}

                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-sm font-extrabold text-slate-900">
                          {item.nombre_local}
                        </h3>
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 font-mono text-[11px] font-bold text-slate-700">
                          RIF: {item.rif}
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase ${
                            isPending
                              ? 'bg-amber-100 text-amber-800'
                              : isApproved
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {isPending ? (
                            <>
                              <Clock className="w-3 h-3" /> Pendiente
                            </>
                          ) : isApproved ? (
                            <>
                              <CheckCircle2 className="w-3 h-3" /> Aprobado
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3 h-3" /> Rechazado
                            </>
                          )}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-1 text-xs text-slate-600 pt-1">
                        <p>
                          <b className="text-slate-800">Razón Social:</b> {item.razon_social}
                        </p>
                        <p>
                          <b className="text-slate-800">Representante:</b> {item.contacto_nombre}{' '}
                          ({item.cedula_representante})
                        </p>
                        <p>
                          <b className="text-slate-800">Correo:</b>{' '}
                          <span className="font-mono">{item.email}</span>
                        </p>
                        <p>
                          <b className="text-slate-800">WhatsApp:</b>{' '}
                          <span className="font-mono">{item.telefono}</span>
                        </p>
                        <p>
                          <b className="text-slate-800">Rubro:</b> {item.rubro || 'General'}
                        </p>
                        <p>
                          <b className="text-slate-800">Fecha:</b>{' '}
                          {new Date(item.createdAt).toLocaleString('es-VE')}
                        </p>
                      </div>

                      <p className="text-xs text-slate-700 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-100">
                        <b>Domicilio Fiscal:</b> {item.direccion_fiscal}
                        {item.registro_mercantil && (
                          <>
                            {' '}
                            · <b>Reg. Mercantil:</b> {item.registro_mercantil}
                          </>
                        )}
                      </p>

                      {item.notas && (
                        <p className="text-[11px] text-slate-500 italic">Notas: {item.notas}</p>
                      )}
                      {item.nota_propietario && item.estado === 'rechazado' && (
                        <p className="text-xs text-rose-700 font-semibold">
                          Motivo de rechazo: {item.nota_propietario}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Strip */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
                  {isPending && (
                    <button
                      type="button"
                      onClick={() => openApprovalModal(item)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Gift className="w-4 h-4" />
                      Aprobar Negocio (Configurar Claves + 5 Días Gratis)
                    </button>
                  )}

                  {isApproved && item.tenantIdAprobado && onOpenClient && (
                    <button
                      type="button"
                      onClick={() => onOpenClient(item.tenantIdAprobado!)}
                      className="px-3.5 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 font-bold cursor-pointer"
                    >
                      Ver Comercio Registrado
                    </button>
                  )}

                  {cleanWa && (
                    <a
                      href={`https://wa.me/${cleanWa}?text=${quickWaMsg}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-semibold inline-flex items-center gap-1.5"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                    </a>
                  )}

                  {item.foto_rif && (
                    <button
                      type="button"
                      onClick={() =>
                        setZoomRif({
                          src: item.foto_rif!,
                          title: `RIF · ${item.nombre_local}`,
                        })
                      }
                      className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5" /> Ver RIF
                    </button>
                  )}

                  {isPending && rejectingId !== item.id && (
                    <button
                      type="button"
                      onClick={() => {
                        setRejectingId(item.id);
                        setRejectNote('');
                      }}
                      className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Rechazar
                    </button>
                  )}

                  {deletingId === item.id ? (
                    <div className="ml-auto flex items-center gap-1.5">
                      <span className="text-[11px] font-bold text-rose-700">¿Eliminar?</span>
                      <button
                        type="button"
                        onClick={() => void handleDelete(item)}
                        className="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white font-bold cursor-pointer"
                      >
                        Sí
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeletingId(null)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-100 text-slate-700 font-semibold cursor-pointer"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setDeletingId(item.id)}
                      className="ml-auto px-2.5 py-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 inline-flex items-center gap-1 cursor-pointer"
                      title="Eliminar pre-registro"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Inline Reject Box */}
                {rejectingId === item.id && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 flex flex-wrap items-center gap-2 text-xs">
                    <input
                      type="text"
                      value={rejectNote}
                      onChange={(e) => setRejectNote(e.target.value)}
                      placeholder="Motivo del rechazo (opcional)..."
                      maxLength={200}
                      className="flex-1 min-w-[200px] px-3 py-1.5 bg-white border border-rose-200 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => void handleReject(item)}
                      className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
                    >
                      Confirmar Rechazo
                    </button>
                    <button
                      type="button"
                      onClick={() => setRejectingId(null)}
                      className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 font-semibold cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Approval Modal: Configure Password, Admin PIN, Cashier PIN & 5 Free Trial Days */}
      {approvingItem && (
        <div className="fixed inset-0 z-[190] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-3">
          <form
            onSubmit={handleConfirmApproval}
            className="bg-white rounded-3xl border border-slate-200 max-w-lg w-full overflow-hidden shadow-2xl"
          >
            <div className="px-5 py-4 bg-gradient-to-r from-emerald-50 via-white to-teal-50 border-b border-emerald-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                  Aprobar Negocio · {approvingItem.nombre_local}
                </h3>
                <p className="text-xs text-slate-500">
                  Configura la contraseña y PINes de acceso · Se asignarán días gratis de bienvenida
                </p>
              </div>
              <button
                type="button"
                onClick={() => setApprovingItem(null)}
                className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3.5 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-0.5">
                <p className="font-bold text-slate-900">
                  {approvingItem.razon_social} · RIF {approvingItem.rif}
                </p>
                <p className="text-slate-600">
                  Correo de acceso: <b className="font-mono">{approvingItem.email}</b>
                </p>
                <p className="text-slate-600">
                  WhatsApp destino: <b className="font-mono">{approvingItem.telefono}</b>
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-700 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-sky-600" /> Contraseña Inicial de Acceso *
                  </label>
                  <button
                    type="button"
                    onClick={() => setCfgPassword(generateSecureTempPassword())}
                    className="text-[11px] font-bold text-sky-600 hover:underline inline-flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" /> Generar otra
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={cfgPassword}
                    onChange={(e) => setCfgPassword(e.target.value)}
                    className="w-full px-3 py-2 pr-9 font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-indigo-600" /> PIN Administrador (4-8 díg.)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    required
                    maxLength={8}
                    value={cfgAdminPin}
                    onChange={(e) => setCfgAdminPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-emerald-600" /> PIN Caja (4-8 díg.)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    required
                    maxLength={8}
                    value={cfgCajaPin}
                    onChange={(e) => setCfgCajaPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-emerald-950 font-bold">
                  <Gift className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Días de Regalo de Bienvenida:</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min={1}
                    max={90}
                    value={cfgTrialDays}
                    onChange={(e) => setCfgTrialDays(Math.max(1, Number(e.target.value) || 5))}
                    className="w-16 px-2 py-1 text-center font-mono font-bold bg-white border border-emerald-300 rounded-lg"
                  />
                  <span className="font-bold text-emerald-800">días</span>
                </div>
              </div>
            </div>

            <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={submittingApproval}
                onClick={() => setApprovingItem(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={submittingApproval}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                {submittingApproval
                  ? 'Registrando Comercio...'
                  : 'Aprobar y Registrar Automáticamente'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* RIF Image Zoom Lightbox */}
      {zoomRif && (
        <div
          className="fixed inset-0 z-[210] bg-slate-950/85 flex items-center justify-center p-4"
          onClick={() => setZoomRif(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">{zoomRif.title}</span>
              <button
                type="button"
                onClick={() => setZoomRif(null)}
                className="p-1.5 rounded-lg bg-slate-100 text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 bg-slate-900 flex justify-center">
              <img
                src={zoomRif.src}
                alt={zoomRif.title}
                className="max-h-[75vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
