import React, { useEffect, useMemo, useState } from 'react';
import {
  Banknote,
  BookOpen,
  Building2,
  Calculator,
  CheckCircle2,
  CreditCard,
  DollarSign,
  FileDown,
  Fingerprint,
  Layers,
  Plus,
  Printer,
  ShoppingBag,
  Smartphone,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import type { SplitPaymentLeg } from '../types/pos';
import { formatRateNumber } from '../utils/currencies';
import { formatMoney, round2 } from '../utils/format';
import { ViewModeToggle } from './ViewModeToggle';

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
}

const CASHEA_LEVELS = [
  { id: 'manual', label: 'Manual', fullLabel: 'Manual (Libre)', inicialPct: null as number | null, cuotas: [3, 6] },
  { id: 'nivel1', label: 'N1 · 60%', fullLabel: 'Nivel 1 (60% Inicial)', inicialPct: 60, cuotas: [3] },
  { id: 'nivel2', label: 'N2 · 50%', fullLabel: 'Nivel 2 (50% Inicial)', inicialPct: 50, cuotas: [3] },
  { id: 'nivel3', label: 'N3 · 40%', fullLabel: 'Nivel 3 (40% Inicial)', inicialPct: 40, cuotas: [3, 6] },
  { id: 'nivel4', label: 'N4 · 40% (6c)', fullLabel: 'Nivel 4 (40% Inicial · 6c)', inicialPct: 40, cuotas: [3, 6] },
  { id: 'nivel5', label: 'N5 · 25%', fullLabel: 'Nivel 5 (25% Inicial)', inicialPct: 25, cuotas: [3, 6, 9] },
  { id: 'nivel6', label: 'N6 · 20%', fullLabel: 'Nivel 6 (20% Inicial)', inicialPct: 20, cuotas: [3, 6, 9, 12] },
] as const;

const SPLIT_METHODS = [
  'Pago Móvil',
  'Efectivo Bs',
  'Efectivo Dolar',
  'Débito',
  'Biopago',
  'Transferencia',
  'Zelle',
  'Binance / USDT',
];

const CasheaLogoIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 36 36" fill="none" className={className} aria-hidden="true">
    <rect width="36" height="36" rx="9" fill="#FFF000" />
    <path
      d="M23.8 13.6C22.6 11.9 20.6 10.9 18.2 10.9C14.1 10.9 11 14 11 18C11 22 14.1 25.1 18.2 25.1C20.7 25.1 22.8 24 24 22.1L21 20.1C20.4 21.1 19.4 21.7 18.2 21.7C16.1 21.7 14.7 20.2 14.7 18C14.7 15.8 16.1 14.3 18.2 14.3C19.4 14.3 20.3 14.8 20.9 15.7L23.8 13.6Z"
      fill="#111827"
    />
    <circle cx="25.2" cy="18" r="2.2" fill="#111827" />
  </svg>
);

const ALL_PAYMENT_METHODS = [
  { id: 'Pago Móvil', label: 'Pago Móvil', icon: Smartphone },
  { id: 'Biopago', label: 'Biopago', icon: Fingerprint },
  { id: 'Efectivo Bs', label: 'Efectivo Bs', icon: Banknote },
  { id: 'Débito', label: 'Débito', icon: CreditCard },
  { id: 'Transferencia', label: 'Transferencia', icon: Building2 },
  { id: 'Efectivo Dolar', label: 'Efectivo USD', icon: DollarSign },
  { id: 'Pago Mixto', label: 'Pago Fraccionado', icon: Layers },
  { id: 'Cashea', label: 'Cashea', icon: CasheaLogoIcon },
  { id: 'Fiado', label: 'Fiado / Crédito', icon: BookOpen },
];

export const PaymentModal: React.FC<PaymentModalProps> = ({ open, onClose }) => {
  const {
    cart,
    cartTotals,
    getActiveRateValue,
    getEffectiveUnitPrice,
    processSale,
    fiados,
    customers,
    cashierPermissions,
    role,
    notifyToast,
    invoiceMode,
    setInvoiceMode,
    activePrinter,
    isMobileLayout,
    viewMode,
    isWideViewport,
    localCurrency,
    localCurrencyCode,
  } = usePos();

  const [selected, setSelected] = useState<string>('');
  const [pagoMovilRef, setPagoMovilRef] = useState('');
  const [cashBsReceived, setCashBsReceived] = useState('');
  const [usdDiscountActive, setUsdDiscountActive] = useState(false);
  const [usdCustom, setUsdCustom] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Live sale-time dual-currency equivalent calculator (always active during checkout)
  const [liveCalcCurrency, setLiveCalcCurrency] = useState<'USD' | 'LOCAL'>('USD');
  const [liveCalcAmount, setLiveCalcAmount] = useState<string>('');

  // Optional billing customer fields (always visible inline on full-screen checkout)
  const [billCedula, setBillCedula] = useState('');
  const [billNombre, setBillNombre] = useState('');

  // Split / Fractional payment state ("Pago Fraccionado / Mixto")
  const [splitLegs, setSplitLegs] = useState<SplitPaymentLeg[]>([]);
  const [splitMethod, setSplitMethod] = useState<string>('Pago Móvil');
  const [splitCurrency, setSplitCurrency] = useState<'USD' | 'VES'>('USD');
  const [splitAmount, setSplitAmount] = useState<string>('');
  const [splitRef, setSplitRef] = useState<string>('');

  // Cashea state
  const [casheaLevelId, setCasheaLevelId] = useState<string>('manual');
  const [casheaInicialUsd, setCasheaInicialUsd] = useState<string>('');
  const [casheaCuotas, setCasheaCuotas] = useState<string>('3');

  // Fiado state
  const [fModalidad, setFModalidad] = useState<'credito' | 'contado_pendiente'>('contado_pendiente');
  const [fNombre, setFNombre] = useState('');
  const [fCedula, setFCedula] = useState('');
  const [fTelefono, setFTelefono] = useState('');
  const [fDireccion, setFDireccion] = useState('');
  const [fCuotas, setFCuotas] = useState('2');
  const [fVence, setFVence] = useState('');
  const [fLimite, setFLimite] = useState('');
  const [fInicial, setFInicial] = useState('');
  const [fNota, setFNota] = useState('');

  // Close on Escape key
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !submitting) {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose, open, submitting]);

  const canApplyDiscounts = role !== 'cashier' || cashierPermissions.aplicar_rebajas;
  const canUseFiados = role !== 'cashier' || cashierPermissions.fiados;

  const visibleMethods = useMemo(
    () =>
      ALL_PAYMENT_METHODS.filter((m) => (m.id === 'Fiado' ? canUseFiados : true)).map((m) =>
        m.id === 'Efectivo Bs'
          ? { ...m, label: `Efectivo ${localCurrency.shortLabel}` }
          : m
      ),
    [canUseFiados, localCurrency.shortLabel]
  );

  const existingFiadoClients = useMemo(() => {
    const map = new Map<string, { cedula: string; nombre: string; telefono?: string; direccion?: string }>();
    Object.entries(fiados).forEach(([ced, group]) => {
      const first = Object.values(group || {})[0];
      if (first) {
        map.set(ced, {
          cedula: first.cedula || ced,
          nombre: first.cliente,
          telefono: first.telefono,
          direccion: first.direccion,
        });
      }
    });
    return Array.from(map.values());
  }, [fiados]);

  const activeRate = getActiveRateValue();

  // Split payment totals & remaining balance
  const splitStats = useMemo(() => {
    const paidVes = round2(splitLegs.reduce((acc, l) => acc + (Number(l.monto_ves) || 0), 0));
    const paidUsd = round2(splitLegs.reduce((acc, l) => acc + (Number(l.monto_usd) || 0), 0));
    const remVes = round2(Math.max(0, cartTotals.totalVes - paidVes));
    const remUsd = round2(Math.max(0, cartTotals.totalUsdBcv - paidUsd));
    const changeVes = round2(Math.max(0, paidVes - cartTotals.totalVes));
    const changeUsd = round2(Math.max(0, paidUsd - cartTotals.totalUsdBcv));
    const isComplete = splitLegs.length > 0 && remUsd <= 0.02;
    return { paidVes, paidUsd, remVes, remUsd, changeVes, changeUsd, isComplete };
  }, [cartTotals.totalUsdBcv, cartTotals.totalVes, splitLegs]);

  // Cashea calculations
  const casheaCalc = useMemo(() => {
    const totalUsd = round2(cartTotals.totalUsdBcv);
    const totalBs = round2(cartTotals.totalVes);
    const parsedInicial = Number(casheaInicialUsd);
    const inicialUsd = Number.isFinite(parsedInicial)
      ? round2(Math.max(0, Math.min(totalUsd, parsedInicial)))
      : 0;
    const inicialBs =
      totalUsd > 0 ? round2(totalBs * (inicialUsd / totalUsd)) : round2(inicialUsd * activeRate);
    const restanteUsd = round2(Math.max(0, totalUsd - inicialUsd));
    const restanteBs = round2(Math.max(0, totalBs - inicialBs));
    const cuotas = Math.max(1, Math.round(Number(casheaCuotas) || 3));
    const cuotaUsd = round2(restanteUsd / cuotas);
    const cuotaBs = round2(restanteBs / cuotas);
    const pct = totalUsd > 0 ? Math.round((inicialUsd / totalUsd) * 100) : 0;
    return {
      totalUsd,
      totalBs,
      inicialUsd,
      inicialBs,
      restanteUsd,
      restanteBs,
      cuotas,
      cuotaUsd,
      cuotaBs,
      pct,
    };
  }, [activeRate, cartTotals.totalUsdBcv, cartTotals.totalVes, casheaCuotas, casheaInicialUsd]);

  // Effective display total (handles custom USD cash discount preview)
  const displayTotals = useMemo(() => {
    const customUsdVal = Number(usdCustom);
    if (
      canApplyDiscounts &&
      selected === 'Efectivo Dolar' &&
      usdDiscountActive &&
      Number.isFinite(customUsdVal) &&
      customUsdVal > 0
    ) {
      return {
        usd: round2(customUsdVal),
        ves: round2(customUsdVal * activeRate),
        discounted: true,
      };
    }
    return {
      usd: cartTotals.totalUsdBcv,
      ves: cartTotals.totalVes,
      discounted: false,
    };
  }, [
    activeRate,
    canApplyDiscounts,
    cartTotals.totalUsdBcv,
    cartTotals.totalVes,
    selected,
    usdCustom,
    usdDiscountActive,
  ]);

  if (!open) return null;

  const handleSelectCasheaLevel = (levelId: string) => {
    setCasheaLevelId(levelId);
    const lvl = CASHEA_LEVELS.find((l) => l.id === levelId);
    if (lvl && lvl.inicialPct !== null) {
      const autoInicial = round2((cartTotals.totalUsdBcv * lvl.inicialPct) / 100);
      setCasheaInicialUsd(autoInicial.toFixed(2));
      if (!lvl.cuotas.includes(Number(casheaCuotas) as never)) {
        setCasheaCuotas(String(lvl.cuotas[0]));
      }
    }
  };

  const handleSelectMethod = (methodId: string) => {
    setSelected(methodId);
    if (methodId === 'Cashea' && casheaInicialUsd === '') {
      const def = round2(cartTotals.totalUsdBcv * 0.4);
      setCasheaInicialUsd(def.toFixed(2));
      setCasheaLevelId('manual');
    }
    if (methodId === 'Pago Mixto' && splitLegs.length === 0) {
      setSplitAmount('');
    }
    if (methodId === 'Fiado' && !fCedula && billCedula) {
      setFCedula(billCedula);
      if (!fNombre && billNombre) setFNombre(billNombre);
    }
  };

  const handleAddSplitLeg = () => {
    const val = Number(splitAmount);
    if (!(val > 0)) {
      notifyToast('Ingresa un monto mayor a 0 para este método.', 'warning');
      return;
    }
    const rate = activeRate > 0 ? activeRate : 1;
    const montoVes = splitCurrency === 'VES' ? round2(val) : round2(val * rate);
    const montoUsd = splitCurrency === 'USD' ? round2(val) : round2(val / rate);

    setSplitLegs((prev) => [
      ...prev,
      {
        metodo: splitMethod,
        monto_ves: montoVes,
        monto_usd: montoUsd,
        referencia: splitRef.trim() || undefined,
      },
    ]);
    setSplitAmount('');
    setSplitRef('');
  };

  const handleFillRemainingSplit = () => {
    if (splitStats.remUsd <= 0) return;
    if (splitCurrency === 'USD') {
      setSplitAmount(splitStats.remUsd.toFixed(2));
    } else {
      setSplitAmount(splitStats.remVes.toFixed(2));
    }
  };

  const handleRemoveSplitLeg = (index: number) => {
    setSplitLegs((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleBillingCedulaChange = (val: string) => {
    setBillCedula(val);
    const clean = val.trim().toLowerCase();
    const match = customers.find((c) => c.cedula.trim().toLowerCase() === clean);
    if (match) {
      setBillNombre(match.nombre);
    }
  };

  const handlePickRegisteredCustomer = (custKey: string) => {
    const match = customers.find((c) => c.key === custKey);
    if (match) {
      setBillCedula(match.cedula);
      setBillNombre(match.nombre);
      if (selected === 'Fiado') {
        setFCedula(match.cedula);
        setFNombre(match.nombre);
        if (match.telefono) setFTelefono(match.telefono);
        if (match.direccion) setFDireccion(match.direccion);
      }
    }
  };

  const handlePickExistingFiadoClient = (ced: string) => {
    const match = existingFiadoClients.find((c) => c.cedula === ced);
    if (match) {
      setFCedula(match.cedula);
      setFNombre(match.nombre);
      setFTelefono(match.telefono || '');
      setFDireccion(match.direccion || '');
    }
  };

  const handleConfirm = async () => {
    if (!selected) {
      notifyToast('Selecciona un método de pago.', 'warning');
      return;
    }
    if (selected === 'Fiado' && (!fNombre.trim() || !fCedula.trim())) {
      notifyToast('Ingresa el nombre y la cédula del cliente para el Fiado.', 'warning');
      return;
    }
    if (selected === 'Cashea') {
      const parsedIni = Number(casheaInicialUsd);
      if (casheaInicialUsd.trim() === '' || !Number.isFinite(parsedIni) || parsedIni < 0) {
        notifyToast('Ingresa el monto de la inicial en dólares para Cashea.', 'warning');
        return;
      }
      if (parsedIni > cartTotals.totalUsdBcv + 0.01) {
        notifyToast('La inicial no puede superar el total de la venta.', 'warning');
        return;
      }
    }
    if (selected === 'Pago Mixto') {
      if (splitLegs.length === 0) {
        notifyToast('Agrega al menos un pago en el desglose fraccionado.', 'warning');
        return;
      }
      if (!splitStats.isComplete) {
        notifyToast(
          `Faltan $${splitStats.remUsd.toFixed(2)} USD (${formatMoney(splitStats.remVes)} Bs) por cubrir.`,
          'warning'
        );
        return;
      }
    }

    setSubmitting(true);
    const chosenLevel = CASHEA_LEVELS.find((l) => l.id === casheaLevelId);
    const ok = await processSale({
      paymentMethod: selected,
      usdCustomAmount:
        canApplyDiscounts && selected === 'Efectivo Dolar' && usdDiscountActive && Number(usdCustom) > 0
          ? Number(usdCustom)
          : null,
      invoiceModeOverride: invoiceMode,
      referenciaPago: selected === 'Pago Móvil' ? pagoMovilRef.trim() || undefined : undefined,
      casheaData:
        selected === 'Cashea'
          ? {
              nivel: chosenLevel?.fullLabel || 'Manual (Libre)',
              inicialUsd: casheaCalc.inicialUsd,
              cuotas: casheaCalc.cuotas,
            }
          : undefined,
      splitPayments: selected === 'Pago Mixto' ? splitLegs : undefined,
      customerInfo:
        billCedula.trim() || billNombre.trim()
          ? {
              cedula: billCedula.trim(),
              nombre: billNombre.trim(),
            }
          : undefined,
      fiadoData:
        selected === 'Fiado'
          ? {
              cliente: fNombre.trim(),
              cedula: fCedula.trim(),
              telefono: fTelefono.trim(),
              direccion: fDireccion.trim(),
              nota: fNota.trim(),
              modalidad: fModalidad,
              cuotas: fModalidad === 'contado_pendiente' ? 1 : Math.max(2, Number(fCuotas) || 2),
              fecha_vencimiento: fVence,
              limite_credito: Number(fLimite) || 0,
              inicial_usd: Number(fInicial) || 0,
            }
          : undefined,
    });
    setSubmitting(false);
    if (ok) {
      setSelected('');
      setPagoMovilRef('');
      setCashBsReceived('');
      setUsdDiscountActive(false);
      setUsdCustom('');
      setCasheaLevelId('manual');
      setCasheaInicialUsd('');
      setCasheaCuotas('3');
      setSplitLegs([]);
      setSplitAmount('');
      setSplitRef('');
      setBillCedula('');
      setBillNombre('');
      setFModalidad('contado_pendiente');
      setFCuotas('2');
      setFNombre('');
      setFCedula('');
      setFTelefono('');
      setFDireccion('');
      setFVence('');
      setFLimite('');
      setFInicial('');
      setFNota('');
      onClose();
    }
  };

  const canSubmit =
    Boolean(selected) &&
    !submitting &&
    (selected !== 'Pago Mixto' || splitStats.isComplete) &&
    (selected !== 'Fiado' || (Boolean(fNombre.trim()) && Boolean(fCedula.trim())));

  const cashBsRecVal = Number(cashBsReceived) || 0;
  const cashBsChange = round2(Math.max(0, cashBsRecVal - cartTotals.totalVes));
  const cashBsMissing = round2(Math.max(0, cartTotals.totalVes - cashBsRecVal));

  const isFramedMobilePreview = viewMode === 'mobile' && isWideViewport;

  const checkoutShell = (
    <div
      className={
        isFramedMobilePreview
          ? 'max-w-[460px] w-full h-[96vh] rounded-3xl border border-sky-200/90 shadow-[0_28px_70px_-24px_rgba(14,116,144,0.3)] bg-[#f4f7fc] flex flex-col overflow-hidden animate-panel-in'
          : 'fixed inset-0 z-[100] bg-[#f4f7fc] flex flex-col overflow-hidden animate-panel-in'
      }
    >
      {/* Top Accent Bar */}
      <div className="h-[3px] w-full bg-gradient-to-r from-sky-400 via-cyan-400 to-emerald-400 shrink-0" />

      {/* Full-Screen Checkout Header */}
      <header
        className={`shrink-0 bg-white border-b border-slate-200 flex items-center justify-between gap-2 ${
          isMobileLayout ? 'px-3 py-2.5' : 'px-5 py-2.5'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 flex items-center justify-center shrink-0">
            <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0">
            <h2 className="text-xs sm:text-base font-extrabold text-slate-900 truncate">
              {isMobileLayout ? 'Pasarela de Cobro' : 'Pasarela de Cobro · Finalizar Venta'}
            </h2>
            <p className="text-[10px] sm:text-xs text-slate-500 font-mono truncate">
              {cartTotals.modeLabel} · 1 USD = {formatRateNumber(activeRate, localCurrencyCode)}{' '}
              {localCurrency.shortLabel} · {cart.length} art.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <ViewModeToggle compact />
          {!isMobileLayout && (
            <span className="hidden xl:inline text-[11px] font-mono text-slate-400">
              ESC para volver
            </span>
          )}
          <button
            type="button"
            disabled={submitting}
            onClick={onClose}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
            aria-label="Cerrar pasarela de cobro"
          >
            <X className="w-4 h-4" />
            <span>{isMobileLayout ? 'Volver' : 'Volver a Caja'}</span>
          </button>
        </div>
      </header>

      {/* Main Checkout Workspace: Single Scrollable Window in Mobile Mode / Single Zero-Scroll Full Screen in Desktop Mode */}
      <main
        className={
          isMobileLayout
            ? 'flex-1 min-h-0 overflow-y-auto overscroll-contain p-3 pb-6 flex flex-col gap-3'
            : 'flex-1 min-h-0 p-3.5 grid grid-cols-12 gap-3.5 overflow-hidden'
        }
      >
        {/* LEFT COLUMN (Desktop 4 cols) / SPLIT SECTIONS (Mobile: Total first, Cart/Billing/Receipt below method panel) */}
        <section
          className={
            isMobileLayout
              ? 'contents'
              : 'col-span-4 flex flex-col gap-3 min-h-0'
          }
        >
          {/* Amount Summary Card + Real-Time Sale-Time Currency Equivalent Selector */}
          <div
            className={`bg-white rounded-2xl border border-sky-200/80 shadow-xs p-3.5 sm:p-4 shrink-0 space-y-2.5 ${
              isMobileLayout ? 'order-1' : ''
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 block">
                  Total Principal (USD)
                </span>
                <div
                  className={`${
                    isMobileLayout ? 'text-2xl' : 'text-2xl xl:text-3xl'
                  } font-black font-mono tabular-nums text-emerald-700 mt-0.5 leading-none`}
                >
                  ${displayTotals.usd.toFixed(2)}
                </div>
              </div>
              <div className="text-right">
                <span className="text-[11px] font-bold uppercase tracking-wider text-sky-700 block">
                  En {localCurrency.name}
                </span>
                <div
                  className={`${
                    isMobileLayout ? 'text-xl' : 'text-xl xl:text-2xl'
                  } font-black font-mono tabular-nums text-slate-900 mt-0.5 leading-none`}
                >
                  {formatMoney(displayTotals.ves)}{' '}
                  <span className="text-sm font-bold text-slate-500">{localCurrency.shortLabel}</span>
                </div>
              </div>
            </div>

            {displayTotals.discounted && (
              <div className="pt-2 border-t border-emerald-100 flex items-center justify-between text-[11px] font-semibold text-emerald-700">
                <span>Precio especial Efectivo USD aplicado</span>
                <span className="font-mono line-through text-slate-400">
                  ${cartTotals.totalUsdBcv.toFixed(2)}
                </span>
              </div>
            )}

            {/* Real-time sale-time currency & received amount equivalent */}
            {(() => {
              const rawInput = Number(liveCalcAmount) || 0;
              const hasInput = rawInput > 0;
              const equivUsd =
                liveCalcCurrency === 'USD'
                  ? round2(rawInput)
                  : activeRate > 0
                  ? round2(rawInput / activeRate)
                  : 0;
              const equivLocal =
                liveCalcCurrency === 'LOCAL'
                  ? round2(rawInput)
                  : round2(rawInput * activeRate);
              const diffUsd = round2(equivUsd - displayTotals.usd);
              const diffLocal = round2(equivLocal - displayTotals.ves);
              const isShort = hasInput && diffUsd < -0.01;
              const isChange = hasInput && diffUsd > 0.01;

              return (
                <div className="pt-2.5 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between gap-1.5">
                    <span className="text-[11px] font-bold text-slate-700 inline-flex items-center gap-1">
                      <Calculator className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                      Equivalente al Vender
                    </span>
                    <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-[10px] font-bold">
                      <button
                        type="button"
                        onClick={() => setLiveCalcCurrency('USD')}
                        className={`px-2 py-0.5 rounded-md cursor-pointer transition-colors ${
                          liveCalcCurrency === 'USD'
                            ? 'bg-emerald-600 text-white'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        USD ($)
                      </button>
                      <button
                        type="button"
                        onClick={() => setLiveCalcCurrency('LOCAL')}
                        className={`px-2 py-0.5 rounded-md cursor-pointer transition-colors ${
                          liveCalcCurrency === 'LOCAL'
                            ? 'bg-sky-600 text-white'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {localCurrency.code} ({localCurrency.shortLabel})
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      step="0.01"
                      value={liveCalcAmount}
                      onChange={(e) => setLiveCalcAmount(e.target.value)}
                      placeholder={
                        liveCalcCurrency === 'USD'
                          ? `Monto recibido en USD (ej. ${Math.ceil(displayTotals.usd)})`
                          : `Monto en ${localCurrency.shortLabel} (ej. ${displayTotals.ves.toFixed(0)})`
                      }
                      className="flex-1 min-w-0 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setLiveCalcAmount(
                          liveCalcCurrency === 'USD'
                            ? displayTotals.usd.toFixed(2)
                            : displayTotals.ves.toFixed(2)
                        )
                      }
                      className="px-2 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-[10px] font-bold text-sky-700 cursor-pointer whitespace-nowrap"
                    >
                      Exacto
                    </button>
                    {liveCalcAmount && (
                      <button
                        type="button"
                        onClick={() => setLiveCalcAmount('')}
                        className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 cursor-pointer"
                        title="Limpiar"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {hasInput && (
                    <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 text-[11px] font-mono tabular-nums space-y-1">
                      <div className="flex items-center justify-between gap-2 text-slate-700">
                        <span className="font-sans font-semibold">Equivale a:</span>
                        <span className="font-bold text-slate-900">
                          ${equivUsd.toFixed(2)} USD · {formatMoney(equivLocal)} {localCurrency.shortLabel}
                        </span>
                      </div>
                      {isShort ? (
                        <div className="flex items-center justify-between gap-2 text-rose-700 font-bold">
                          <span className="font-sans">Falta:</span>
                          <span>
                            ${Math.abs(diffUsd).toFixed(2)} · {formatMoney(Math.abs(diffLocal))}{' '}
                            {localCurrency.shortLabel}
                          </span>
                        </div>
                      ) : isChange ? (
                        <div className="flex items-center justify-between gap-2 text-emerald-700 font-extrabold">
                          <span className="font-sans">Vuelto / Cambio:</span>
                          <span>
                            ${diffUsd.toFixed(2)} · {formatMoney(diffLocal)} {localCurrency.shortLabel}
                          </span>
                        </div>
                      ) : (
                        <div className="text-emerald-700 font-sans font-bold text-right">
                          Pago exacto cubierto en ambas monedas
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Compact Cart Items Summary */}
          <div
            className={`bg-white rounded-2xl border border-slate-200 p-3 flex flex-col ${
              isMobileLayout ? 'order-4 shrink-0' : 'flex-1 min-h-[96px] overflow-hidden'
            }`}
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100 shrink-0">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <ShoppingBag className="w-3.5 h-3.5 text-sky-600" />
                Resumen del Carrito ({cart.length})
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                {round2(
                  cart.reduce((acc, it) => {
                    const isBulto =
                      it.saleUnit === 'bulto' &&
                      it.product.ventaPorBulto === true &&
                      (Number(it.product.unidadesPorBulto) || 0) > 1;
                    return (
                      acc +
                      it.quantity * (isBulto ? Number(it.product.unidadesPorBulto) || 1 : 1)
                    );
                  }, 0)
                )}{' '}
                und.
              </span>
            </div>
            <div
              className={`divide-y divide-slate-100 mt-1 pr-0.5 ${
                isMobileLayout ? 'max-h-48 overflow-y-auto' : 'flex-1 overflow-y-auto'
              }`}
            >
              {cart.map((item) => {
                const isBulto =
                  item.saleUnit === 'bulto' &&
                  item.product.ventaPorBulto === true &&
                  (Number(item.product.unidadesPorBulto) || 0) > 1;
                const unitsPerBulto = isBulto ? Number(item.product.unidadesPorBulto) || 1 : 1;
                const lineKey = item.cartKey || `${item.product.key}__${isBulto ? 'bulto' : 'detal'}`;
                const unitUsd = getEffectiveUnitPrice(item.product, isBulto ? 'bulto' : 'detal');
                const lineUsd = round2(unitUsd * item.quantity);
                const lineBs = round2(lineUsd * activeRate);
                return (
                  <div
                    key={lineKey}
                    className="py-1.5 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-800 truncate leading-tight flex items-center gap-1.5">
                        <span className="truncate">{item.product.id}</span>
                        {isBulto && (
                          <span className="shrink-0 text-[9px] font-extrabold uppercase tracking-wide px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                            Bulto ×{unitsPerBulto}
                          </span>
                        )}
                      </p>
                      <p className="text-[10px] font-mono text-slate-500">
                        {item.quantity} {isBulto ? (item.quantity === 1 ? 'bulto' : 'bultos') : 'und.'} × ${unitUsd.toFixed(2)}
                        {isBulto ? ` (${round2(item.quantity * unitsPerBulto)} und.)` : ''}
                      </p>
                    </div>
                    <div className="text-right font-mono tabular-nums shrink-0">
                      <p className="font-bold text-slate-900">${lineUsd.toFixed(2)}</p>
                      <p className="text-[10px] text-slate-500">
                        {formatMoney(lineBs)} {localCurrency.shortLabel}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Optional Customer Billing Info — Always Visible Inline */}
          <div
            className={`bg-white rounded-2xl border border-slate-200 p-3 shrink-0 space-y-2 ${
              isMobileLayout ? 'order-5' : ''
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-sky-600" />
                Cliente en Factura (Opcional)
              </span>
              {customers.length > 0 && (
                <select
                  defaultValue=""
                  onChange={(e) => {
                    if (e.target.value) handlePickRegisteredCustomer(e.target.value);
                  }}
                  className="text-[11px] px-2 py-1 rounded-lg border border-slate-200 bg-slate-50 text-slate-700 max-w-[165px]"
                >
                  <option value="">Elegir registrado...</option>
                  {customers.map((c) => (
                    <option key={c.key} value={c.key}>
                      {c.nombre} ({c.cedula})
                    </option>
                  ))}
                </select>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <input
                type="text"
                value={billCedula}
                onChange={(e) => handleBillingCedulaChange(e.target.value)}
                placeholder="Cédula o RIF (ej. V-12345678)"
                maxLength={40}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs"
              />
              <input
                type="text"
                value={billNombre}
                onChange={(e) => setBillNombre(e.target.value)}
                placeholder="Nombre / Razón social"
                maxLength={140}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
            </div>
          </div>

          {/* Invoice Output Selector */}
          <div
            className={`bg-white rounded-2xl border border-slate-200 p-3 shrink-0 space-y-2 ${
              isMobileLayout ? 'order-6' : ''
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                {activePrinter ? (
                  <Printer className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <FileDown className="w-3.5 h-3.5 text-sky-600" />
                )}
                Salida de Comprobante
              </span>
              <span className="text-[11px] text-slate-500 truncate">
                {activePrinter ? `Lista: ${activePrinter.name}` : 'PDF / Navegador'}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1.5 text-[11px]">
              {[
                { id: 'auto' as const, label: 'Auto' },
                { id: 'pdf' as const, label: 'PDF' },
                { id: 'printer' as const, label: 'Impresora' },
                { id: 'none' as const, label: 'Sin recibo' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setInvoiceMode(opt.id)}
                  className={`py-1.5 px-2 rounded-xl border font-semibold cursor-pointer transition-colors whitespace-nowrap ${
                    invoiceMode === opt.id
                      ? 'bg-sky-600 border-sky-600 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* RIGHT COLUMN (Desktop 8 cols) / METHOD + DETAILS (Mobile order-2 & order-3) */}
        <section
          className={
            isMobileLayout
              ? 'contents'
              : 'col-span-8 flex flex-col gap-3 min-h-0'
          }
        >
          {/* Payment Methods Grid — All Visible Together */}
          <div
            className={`bg-white rounded-2xl border border-slate-200 p-3 sm:p-3.5 shrink-0 space-y-2.5 ${
              isMobileLayout ? 'order-2' : ''
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-800">
                1. Selecciona el Método de Pago
              </span>
              <span className="text-[11px] font-semibold text-sky-700 truncate">
                {selected
                  ? `Seleccionado: ${selected === 'Efectivo Bs' ? `Efectivo ${localCurrency.shortLabel}` : selected}`
                  : 'Elige una opción'}
              </span>
            </div>

            <div
              className={`grid gap-2 ${
                isMobileLayout
                  ? 'grid-cols-2'
                  : 'grid-cols-3 xl:grid-cols-5'
              }`}
            >
              {visibleMethods.map((m) => {
                const Icon = m.icon;
                const active = selected === m.id;
                const isCashea = m.id === 'Cashea';
                const isSplit = m.id === 'Pago Mixto';
                const isFiado = m.id === 'Fiado';
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => handleSelectMethod(m.id)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer btn-press ${
                      active
                        ? isCashea
                          ? 'bg-amber-400 border-amber-500 text-slate-950 shadow-sm ring-2 ring-amber-200'
                          : isSplit
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm ring-2 ring-indigo-200'
                          : isFiado
                          ? 'bg-amber-600 border-amber-600 text-white shadow-sm ring-2 ring-amber-200'
                          : 'bg-sky-600 border-sky-600 text-white shadow-sm ring-2 ring-sky-200'
                        : 'bg-slate-50/80 border-slate-200 text-slate-700 hover:border-sky-300 hover:bg-sky-50/50'
                    }`}
                  >
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        active
                          ? isCashea
                            ? 'text-slate-950'
                            : 'text-white'
                          : 'text-sky-600'
                      }`}
                    />
                    <span className="truncate">{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dynamic Payment Method Configuration Panel — Full visible flow in Mobile, Zero-Scroll fit in Desktop */}
          <div
            className={`bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-4 flex flex-col justify-between ${
              isMobileLayout
                ? 'order-3 shrink-0 overflow-visible'
                : 'flex-1 min-h-0 overflow-hidden'
            }`}
          >
            {!selected && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-4 space-y-2.5">
                <div className="w-12 h-12 rounded-2xl bg-sky-50 border border-sky-100 text-sky-600 flex items-center justify-center">
                  <CreditCard className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Elige un método de pago arriba para continuar
                  </h3>
                  <p className="text-xs text-slate-500 max-w-md mt-0.5">
                    Todas las opciones (Pago Móvil con referencia, Efectivo {localCurrency.shortLabel}/USD, Pago Fraccionado, Cashea y Fiado/Crédito) se configuran aquí mismo.
                  </p>
                </div>
              </div>
            )}

            {/* PAGO MÓVIL */}
            {selected === 'Pago Móvil' && (
              <div className="flex-1 flex flex-col justify-center">
                <div
                  className={`grid gap-3.5 items-stretch ${
                    isMobileLayout ? 'grid-cols-1' : 'grid-cols-2'
                  }`}
                >
                  <div className="p-4 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-bold text-sky-950 flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-sky-600" />
                        N° de Referencia Pago Móvil (Opcional)
                      </label>
                      {pagoMovilRef && (
                        <button
                          type="button"
                          onClick={() => setPagoMovilRef('')}
                          className="text-[11px] font-semibold text-rose-600 hover:underline cursor-pointer"
                        >
                          Limpiar
                        </button>
                      )}
                    </div>
                    <input
                      type="text"
                      value={pagoMovilRef}
                      onChange={(e) => setPagoMovilRef(e.target.value)}
                      placeholder="Ej. 04829103 o últimos 4-8 dígitos"
                      maxLength={60}
                      autoFocus
                      className="w-full px-3.5 py-2.5 bg-white border border-sky-300 rounded-xl text-sm font-mono font-bold text-slate-900"
                    />
                    <p className="text-[11px] text-sky-800">
                      Si la ingresas, quedará registrada en la factura, en el ticket térmico y en el cierre de caja.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-center space-y-2">
                    <span className="text-xs font-bold text-slate-700">Monto exacto a verificar en Pago Móvil</span>
                    <div className="text-2xl font-black font-mono tabular-nums text-emerald-700">
                      {formatMoney(cartTotals.totalVes)} {localCurrency.shortLabel}
                    </div>
                    <div className="text-xs font-mono text-slate-500">
                      Principal ${cartTotals.totalUsdBcv.toFixed(2)} USD · Tasa{' '}
                      {formatRateNumber(activeRate, localCurrencyCode)} {localCurrency.shortLabel}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* EFECTIVO MONEDA LOCAL (with built-in instant vuelto calculator) */}
            {selected === 'Efectivo Bs' && (
              <div className="flex-1 flex flex-col justify-center">
                <div
                  className={`grid gap-3.5 items-stretch ${
                    isMobileLayout ? 'grid-cols-1' : 'grid-cols-2'
                  }`}
                >
                  <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 space-y-2.5">
                    <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                      <Calculator className="w-4 h-4 text-emerald-600" />
                      Calculadora Rápida de Vuelto en {localCurrency.name} ({localCurrency.shortLabel})
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={cashBsReceived}
                      onChange={(e) => setCashBsReceived(e.target.value)}
                      placeholder={`Recibido en ${localCurrency.shortLabel} (Total: ${cartTotals.totalVes.toFixed(2)})`}
                      className="w-full px-3.5 py-2.5 bg-white border border-emerald-300 rounded-xl text-sm font-mono font-bold text-slate-900"
                    />
                    <div className="flex flex-wrap gap-1.5">
                      {[cartTotals.totalVes, Math.ceil(cartTotals.totalVes / 100) * 100, Math.ceil(cartTotals.totalVes / 500) * 500].map(
                        (preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setCashBsReceived(preset.toFixed(2))}
                            className="px-2.5 py-1 rounded-lg bg-white border border-emerald-200 hover:bg-emerald-100 text-[11px] font-mono font-bold text-emerald-800 cursor-pointer"
                          >
                            {formatMoney(preset)} {localCurrency.shortLabel}
                          </button>
                        )
                      )}
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-center space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-600 font-semibold">Total Venta:</span>
                      <span className="font-mono font-bold text-slate-900">
                        ${cartTotals.totalUsdBcv.toFixed(2)} · {formatMoney(cartTotals.totalVes)}{' '}
                        {localCurrency.shortLabel}
                      </span>
                    </div>
                    {cashBsRecVal > 0 ? (
                      cashBsMissing > 0 ? (
                        <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-between text-xs font-bold text-rose-700">
                          <span>Falta por recibir:</span>
                          <span className="font-mono">
                            {formatMoney(cashBsMissing)} {localCurrency.shortLabel} ($
                            {(activeRate > 0 ? cashBsMissing / activeRate : 0).toFixed(2)})
                          </span>
                        </div>
                      ) : (
                        <div className="p-2.5 rounded-xl bg-emerald-100/80 border border-emerald-300 flex items-center justify-between text-sm font-extrabold text-emerald-900">
                          <span>Vuelto a entregar:</span>
                          <span className="font-mono">
                            {formatMoney(cashBsChange)} {localCurrency.shortLabel} ($
                            {(activeRate > 0 ? cashBsChange / activeRate : 0).toFixed(2)})
                          </span>
                        </div>
                      )
                    ) : (
                      <p className="text-xs text-slate-500">
                        Listo para registrar el cobro en Efectivo {localCurrency.name} por $
                        {cartTotals.totalUsdBcv.toFixed(2)} USD ({formatMoney(cartTotals.totalVes)}{' '}
                        {localCurrency.shortLabel}).
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* DÉBITO / BIOPAGO / TRANSFERENCIA */}
            {(selected === 'Débito' || selected === 'Biopago' || selected === 'Transferencia') && (
              <div className="flex-1 flex flex-col justify-center">
                <div className="p-5 rounded-2xl bg-sky-50/50 border border-sky-200/80 flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-sky-700">
                      Cobro directo · {selected}
                    </span>
                    <h4 className="text-lg font-extrabold text-slate-900">
                      Listo para procesar por {formatMoney(cartTotals.totalVes)} {localCurrency.shortLabel}
                    </h4>
                    <p className="text-xs text-slate-600">
                      Principal ${cartTotals.totalUsdBcv.toFixed(2)} USD a tasa{' '}
                      {formatRateNumber(activeRate, localCurrencyCode)} {localCurrency.shortLabel}. Presiona “Confirmar y Cobrar” para emitir el comprobante.
                    </p>
                  </div>
                  <div className="px-4 py-3 rounded-xl bg-white border border-sky-200 text-right font-mono tabular-nums">
                    <span className="text-[11px] font-sans font-semibold text-slate-500 block">A debitar</span>
                    <span className="text-xl font-black text-sky-700">
                      {formatMoney(cartTotals.totalVes)} {localCurrency.shortLabel}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* EFECTIVO USD */}
            {selected === 'Efectivo Dolar' && (
              <div className="flex-1 flex flex-col justify-center">
                <div
                  className={`grid gap-3.5 items-stretch ${
                    isMobileLayout ? 'grid-cols-1' : 'grid-cols-2'
                  }`}
                >
                  <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                    {canApplyDiscounts ? (
                      <>
                        <label className="flex items-center gap-2 text-xs font-bold text-emerald-950 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={usdDiscountActive}
                            onChange={(e) => {
                              setUsdDiscountActive(e.target.checked);
                              if (e.target.checked && !usdCustom) {
                                setUsdCustom(cartTotals.totalUsdBcv.toFixed(2));
                              }
                            }}
                            className="w-4 h-4 rounded border-emerald-400 accent-emerald-600"
                          />
                          Aplicar precio especial / descuento en Divisas (USD)
                        </label>
                        {usdDiscountActive ? (
                          <div className="space-y-2">
                            <input
                              type="number"
                              step="0.01"
                              value={usdCustom}
                              onChange={(e) => setUsdCustom(e.target.value)}
                              placeholder={cartTotals.totalUsdBcv.toFixed(2)}
                              className="w-full px-3.5 py-2.5 bg-white border border-emerald-300 rounded-xl text-base font-mono font-extrabold text-emerald-900"
                            />
                            <div className="flex flex-wrap gap-1.5">
                              {[1, 2, 5].map((off) => {
                                const target = round2(Math.max(0.5, cartTotals.totalUsdBcv - off));
                                return (
                                  <button
                                    key={off}
                                    type="button"
                                    onClick={() => setUsdCustom(target.toFixed(2))}
                                    className="px-2.5 py-1 rounded-lg bg-white border border-emerald-200 hover:bg-emerald-100 text-[11px] font-mono font-bold text-emerald-800 cursor-pointer"
                                  >
                                    -${off} (${target.toFixed(2)})
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        ) : (
                          <p className="text-xs text-emerald-800">
                            Activa la casilla si deseas acordar un monto especial en dólares en efectivo para esta venta.
                          </p>
                        )}
                      </>
                    ) : (
                      <p className="text-xs text-emerald-900">
                        Cobro en efectivo divisas USD por el monto exacto de la venta.
                      </p>
                    )}
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-center space-y-1.5">
                    <span className="text-xs font-bold text-slate-600">Total a recibir en Efectivo USD</span>
                    <div className="text-3xl font-black font-mono tabular-nums text-emerald-700">
                      ${displayTotals.usd.toFixed(2)}
                    </div>
                    <span className="text-xs font-mono text-slate-500">
                      Equivalente en {localCurrency.name}: {formatMoney(displayTotals.ves)}{' '}
                      {localCurrency.shortLabel}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* PAGO FRACCIONADO / MIXTO — Side-by-side Zero-Scroll Builder */}
            {selected === 'Pago Mixto' && (
              <div className="flex-1 min-h-0 flex flex-col gap-2.5">
                {/* Live Balance Meter Row */}
                <div className="grid grid-cols-3 gap-2 shrink-0">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] font-semibold text-slate-500 block">Total Venta</span>
                    <span className="text-sm font-mono font-extrabold text-slate-900">
                      ${cartTotals.totalUsdBcv.toFixed(2)}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500 block">
                      {formatMoney(cartTotals.totalVes)} {localCurrency.shortLabel}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                    <span className="text-[10px] font-semibold text-emerald-700 block">Cubierto</span>
                    <span className="text-sm font-mono font-extrabold text-emerald-800">
                      ${splitStats.paidUsd.toFixed(2)}
                    </span>
                    <span className="text-[10px] font-mono text-emerald-700 block">
                      {formatMoney(splitStats.paidVes)} {localCurrency.shortLabel}
                    </span>
                  </div>
                  <div
                    className={`p-2.5 rounded-xl border ${
                      splitStats.isComplete
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'bg-rose-50 border-rose-200 text-rose-800'
                    }`}
                  >
                    <span className="text-[10px] font-semibold block opacity-90">
                      {splitStats.isComplete ? 'Estado' : 'Resta por Pagar'}
                    </span>
                    <span className="text-sm font-mono font-extrabold">
                      {splitStats.isComplete ? 'COMPLETO' : `$${splitStats.remUsd.toFixed(2)}`}
                    </span>
                    <span className="text-[10px] font-mono block opacity-90">
                      {splitStats.isComplete
                        ? splitStats.changeUsd > 0.01
                          ? `Vuelto $${splitStats.changeUsd.toFixed(2)}`
                          : 'Listo para cobrar'
                        : `${formatMoney(splitStats.remVes)} ${localCurrency.shortLabel}`}
                    </span>
                  </div>
                </div>

                {/* Side-by-side Add Leg Form + Added Legs List */}
                <div
                  className={`grid gap-3 ${
                    isMobileLayout ? 'grid-cols-1' : 'flex-1 min-h-0 grid-cols-12'
                  }`}
                >
                  {/* Left: Add Split Leg */}
                  <div
                    className={`${
                      isMobileLayout ? '' : 'col-span-6'
                    } p-3 rounded-2xl bg-indigo-50/50 border border-indigo-200/80 flex flex-col justify-between gap-2 text-xs`}
                  >
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] font-semibold text-indigo-900 block mb-1">
                          Método de Pago
                        </label>
                        <select
                          value={splitMethod}
                          onChange={(e) => setSplitMethod(e.target.value)}
                          className="w-full px-2.5 py-2 bg-white border border-indigo-200 rounded-xl text-xs font-semibold"
                        >
                          {SPLIT_METHODS.map((m) => (
                            <option key={m} value={m}>
                              {m === 'Efectivo Bs' ? `Efectivo ${localCurrency.shortLabel}` : m}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-indigo-900 block mb-1">
                          Moneda
                        </label>
                        <div className="grid grid-cols-2 gap-1">
                          <button
                            type="button"
                            onClick={() => setSplitCurrency('USD')}
                            className={`py-2 rounded-xl border font-bold cursor-pointer ${
                              splitCurrency === 'USD'
                                ? 'bg-indigo-600 border-indigo-600 text-white'
                                : 'bg-white border-indigo-200 text-slate-700'
                            }`}
                          >
                            USD ($)
                          </button>
                          <button
                            type="button"
                            onClick={() => setSplitCurrency('VES')}
                            className={`py-2 rounded-xl border font-bold cursor-pointer ${
                              splitCurrency === 'VES'
                                ? 'bg-indigo-600 border-indigo-600 text-white'
                                : 'bg-white border-indigo-200 text-slate-700'
                            }`}
                          >
                            {localCurrency.shortLabel}
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[11px] font-semibold text-indigo-900">
                            Monto ({splitCurrency === 'USD' ? '$' : localCurrency.shortLabel})
                          </label>
                          {splitStats.remUsd > 0 && (
                            <button
                              type="button"
                              onClick={handleFillRemainingSplit}
                              className="text-[10px] font-bold text-indigo-700 hover:underline cursor-pointer"
                            >
                              Resto
                            </button>
                          )}
                        </div>
                        <input
                          type="number"
                          step="0.01"
                          value={splitAmount}
                          onChange={(e) => setSplitAmount(e.target.value)}
                          placeholder={
                            splitCurrency === 'USD'
                              ? splitStats.remUsd.toFixed(2)
                              : splitStats.remVes.toFixed(2)
                          }
                          className="w-full px-2.5 py-2 bg-white border border-indigo-200 rounded-xl font-mono font-bold"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-indigo-900 block mb-1">
                          Referencia (opc.)
                        </label>
                        <input
                          type="text"
                          value={splitRef}
                          onChange={(e) => setSplitRef(e.target.value)}
                          placeholder="Últimos 4-6 dígitos"
                          maxLength={40}
                          className="w-full px-2.5 py-2 bg-white border border-indigo-200 rounded-xl font-mono"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleAddSplitLeg}
                      className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" /> Agregar Parte al Pago Fraccionado
                    </button>
                  </div>

                  {/* Right: Added Split Legs List */}
                  <div
                    className={`${
                      isMobileLayout ? 'max-h-52' : 'col-span-6 min-h-0'
                    } p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col`}
                  >
                    <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 shrink-0">
                      <span className="text-xs font-bold text-slate-800">
                        Pagos agregados ({splitLegs.length})
                      </span>
                      {splitLegs.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setSplitLegs([])}
                          className="text-[11px] font-semibold text-rose-600 hover:underline cursor-pointer"
                        >
                          Limpiar todo
                        </button>
                      )}
                    </div>
                    <div className="flex-1 overflow-y-auto mt-1.5 space-y-1.5">
                      {splitLegs.length === 0 ? (
                        <div className="h-full flex items-center justify-center text-center text-xs text-slate-400 px-3">
                          Agrega uno o más métodos a la izquierda (ej. $10 en Efectivo USD + resto en Pago Móvil).
                        </div>
                      ) : (
                        splitLegs.map((leg, idx) => (
                          <div
                            key={`${leg.metodo}-${idx}`}
                            className="px-2.5 py-2 rounded-xl bg-white border border-slate-200 flex items-center justify-between gap-2 text-xs"
                          >
                            <div className="min-w-0">
                              <span className="font-bold text-slate-900 block truncate">
                                {leg.metodo}
                              </span>
                              {leg.referencia && (
                                <span className="text-[10px] font-mono text-slate-500">
                                  Ref: {leg.referencia}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <div className="text-right font-mono tabular-nums">
                                <span className="font-bold text-emerald-700 block">
                                  ${leg.monto_usd.toFixed(2)}
                                </span>
                                <span className="text-[10px] text-slate-500">
                                  {formatMoney(leg.monto_ves)} {localCurrency.shortLabel}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRemoveSplitLeg(idx)}
                                className="p-1 rounded-lg hover:bg-rose-50 text-rose-500 cursor-pointer"
                                title="Quitar pago"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* CASHEA — Responsive Split Panel */}
            {selected === 'Cashea' && (
              <div
                className={`grid gap-3.5 items-stretch ${
                  isMobileLayout ? 'grid-cols-1' : 'flex-1 grid-cols-12'
                }`}
              >
                <div
                  className={`${
                    isMobileLayout ? '' : 'col-span-7'
                  } p-3.5 rounded-2xl bg-amber-50/60 border border-amber-300/80 flex flex-col justify-between gap-2.5 text-xs`}
                >
                  <div className="flex items-center gap-2">
                    <CasheaLogoIcon className="w-6 h-6 shrink-0" />
                    <div>
                      <h4 className="font-extrabold text-slate-900">Configuración Cashea</h4>
                      <p className="text-[11px] text-slate-600">
                        La inicial entra hoy al cierre de caja; el saldo queda en cuotas.
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      Nivel del Cliente
                    </label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {CASHEA_LEVELS.map((lvl) => (
                        <button
                          key={lvl.id}
                          type="button"
                          onClick={() => handleSelectCasheaLevel(lvl.id)}
                          className={`py-1.5 px-2 rounded-lg border text-[11px] font-bold cursor-pointer transition ${
                            casheaLevelId === lvl.id
                              ? 'bg-slate-900 border-slate-900 text-amber-300'
                              : 'bg-white border-amber-200 text-slate-700 hover:bg-amber-100/60'
                          }`}
                        >
                          {lvl.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[11px] font-bold text-slate-700 block mb-1">
                        Inicial a pagar hoy (USD) *
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max={cartTotals.totalUsdBcv}
                        value={casheaInicialUsd}
                        onChange={(e) => {
                          setCasheaInicialUsd(e.target.value);
                          setCasheaLevelId('manual');
                        }}
                        placeholder="0.00"
                        className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl font-mono font-bold text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-700 block mb-1">
                        Cuotas sin interés
                      </label>
                      <div className="grid grid-cols-4 gap-1">
                        {[3, 6, 9, 12].map((c) => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => setCasheaCuotas(String(c))}
                            className={`py-2 rounded-xl border font-mono font-bold cursor-pointer ${
                              Number(casheaCuotas) === c
                                ? 'bg-amber-500 border-amber-500 text-white'
                                : 'bg-white border-amber-200 text-slate-700'
                            }`}
                          >
                            {c}c
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  className={`${
                    isMobileLayout ? '' : 'col-span-5'
                  } p-4 rounded-2xl bg-slate-900 text-white flex flex-col justify-between gap-2 text-xs`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-700">
                    <span className="font-bold text-amber-300">Desglose Cashea</span>
                    <span className="font-mono text-slate-300">{casheaCalc.pct}% inicial</span>
                  </div>
                  <div className="space-y-2 font-mono tabular-nums">
                    <div className="flex items-center justify-between">
                      <span className="font-sans text-slate-300">Inicial hoy (Caja):</span>
                      <span className="text-base font-extrabold text-emerald-400">
                        ${casheaCalc.inicialUsd.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="font-sans">Inicial en {localCurrency.shortLabel}:</span>
                      <span>
                        {formatMoney(casheaCalc.inicialBs)} {localCurrency.shortLabel}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                      <span className="font-sans text-slate-300">Saldo financiado:</span>
                      <span className="font-bold text-amber-300">${casheaCalc.restanteUsd.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-sans text-slate-300">{casheaCalc.cuotas} cuotas de:</span>
                      <span className="font-bold text-white">
                        ${casheaCalc.cuotaUsd.toFixed(2)} ({formatMoney(casheaCalc.cuotaBs)}{' '}
                        {localCurrency.shortLabel})
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* FIADO / CRÉDITO — Compact 3-Column Zero-Scroll Form */}
            {selected === 'Fiado' && (
              <div className="flex-1 flex flex-col justify-between gap-2.5 text-xs">
                {/* Top Mode Toggle + Existing Customer Quick Pick */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-amber-200/70">
                  <div className="grid grid-cols-2 gap-1.5 flex-1 min-w-[260px]">
                    <button
                      type="button"
                      onClick={() => {
                        setFModalidad('contado_pendiente');
                        setFCuotas('1');
                      }}
                      className={`py-1.5 px-2.5 rounded-xl border font-bold cursor-pointer transition ${
                        fModalidad === 'contado_pendiente'
                          ? 'bg-amber-600 border-amber-600 text-white'
                          : 'bg-amber-50 border-amber-200 text-amber-900 hover:bg-amber-100'
                      }`}
                    >
                      Factura Pendiente (Pago Único)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setFModalidad('credito');
                        if (Number(fCuotas) < 2) setFCuotas('2');
                      }}
                      className={`py-1.5 px-2.5 rounded-xl border font-bold cursor-pointer transition ${
                        fModalidad === 'credito'
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'bg-indigo-50 border-indigo-200 text-indigo-900 hover:bg-indigo-100'
                      }`}
                    >
                      A Crédito (Por Cuotas)
                    </button>
                  </div>

                  {existingFiadoClients.length > 0 && (
                    <select
                      defaultValue=""
                      onChange={(e) => {
                        if (e.target.value) handlePickExistingFiadoClient(e.target.value);
                      }}
                      className="px-2.5 py-1.5 rounded-xl border border-amber-300 bg-amber-50 text-xs font-semibold text-amber-950 max-w-[200px]"
                    >
                      <option value="">Cliente fiado previo...</option>
                      {existingFiadoClients.map((c) => (
                        <option key={c.cedula} value={c.cedula}>
                          {c.nombre} ({c.cedula})
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                {/* Fiado Field Grid — 1-2 cols in Mobile, 3 cols in Desktop */}
                <div
                  className={`grid gap-2 ${
                    isMobileLayout ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-3'
                  }`}
                >
                  <div>
                    <label className="text-[11px] font-bold text-amber-900 block mb-0.5">
                      Cédula / RIF *
                    </label>
                    <input
                      type="text"
                      value={fCedula}
                      onChange={(e) => setFCedula(e.target.value)}
                      placeholder="V-12345678"
                      className="w-full px-2.5 py-1.5 bg-amber-50/40 border border-amber-300 rounded-xl font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-amber-900 block mb-0.5">
                      Nombre del Cliente *
                    </label>
                    <input
                      type="text"
                      value={fNombre}
                      onChange={(e) => setFNombre(e.target.value)}
                      placeholder="Nombre completo"
                      className="w-full px-2.5 py-1.5 bg-amber-50/40 border border-amber-300 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-0.5">
                      Teléfono
                    </label>
                    <input
                      type="text"
                      value={fTelefono}
                      onChange={(e) => setFTelefono(e.target.value)}
                      placeholder="0414-0000000"
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-0.5">
                      Inicial / Abono Hoy (USD)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={fInicial}
                      onChange={(e) => setFInicial(e.target.value)}
                      placeholder="0.00"
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    />
                  </div>

                  {fModalidad === 'credito' ? (
                    <div>
                      <label className="text-[11px] font-bold text-indigo-800 block mb-0.5">
                        N° de Cuotas
                      </label>
                      <input
                        type="number"
                        min="2"
                        max="36"
                        value={fCuotas}
                        onChange={(e) => setFCuotas(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-indigo-50/50 border border-indigo-300 rounded-xl font-mono font-bold"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-0.5">
                        Límite Crédito (USD)
                      </label>
                      <input
                        type="number"
                        step="1"
                        value={fLimite}
                        onChange={(e) => setFLimite(e.target.value)}
                        placeholder="Opcional"
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                      />
                    </div>
                  )}

                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-0.5">
                      Fecha Vencimiento
                    </label>
                    <input
                      type="date"
                      value={fVence}
                      onChange={(e) => setFVence(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div className={isMobileLayout ? '' : 'col-span-2'}>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-0.5">
                      Dirección
                    </label>
                    <input
                      type="text"
                      value={fDireccion}
                      onChange={(e) => setFDireccion(e.target.value)}
                      placeholder="Dirección del cliente (opcional)"
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-0.5">
                      Nota / Observación
                    </label>
                    <input
                      type="text"
                      value={fNota}
                      onChange={(e) => setFNota(e.target.value)}
                      placeholder="Detalle adicional"
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Pinned Bottom Confirmation Bar */}
      <footer
        className={`shrink-0 bg-white border-t border-slate-200 flex items-center justify-between gap-2.5 ${
          isMobileLayout ? 'px-3 py-2.5 flex-col items-stretch' : 'px-5 py-3 flex-wrap'
        }`}
      >
        <div className="flex flex-wrap items-center gap-1.5 text-xs min-w-0">
          {selected ? (
            <>
              <span className="font-bold text-slate-900">
                Método: {selected === 'Efectivo Bs' ? `Efectivo ${localCurrency.shortLabel}` : selected}
              </span>
              <span className="text-slate-300">·</span>
              <span className="font-mono font-bold text-emerald-700">
                ${displayTotals.usd.toFixed(2)} USD ({formatMoney(displayTotals.ves)}{' '}
                {localCurrency.shortLabel})
              </span>
              {selected === 'Pago Mixto' && !splitStats.isComplete && (
                <span className="text-rose-600 font-semibold">
                  · Falta ${splitStats.remUsd.toFixed(2)} ({formatMoney(splitStats.remVes)}{' '}
                  {localCurrency.shortLabel})
                </span>
              )}
              {selected === 'Fiado' && (!fNombre.trim() || !fCedula.trim()) && (
                <span className="text-amber-700 font-semibold">
                  · Completa Cédula y Nombre del cliente
                </span>
              )}
            </>
          ) : (
            <span className="text-slate-500">
              Selecciona un método de pago para habilitar el cobro.
            </span>
          )}
        </div>

        <div className={`flex items-center gap-2 shrink-0 ${isMobileLayout ? 'w-full' : ''}`}>
          <button
            type="button"
            disabled={submitting}
            onClick={onClose}
            className={`${
              isMobileLayout ? 'flex-1 justify-center' : ''
            } px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-100 cursor-pointer whitespace-nowrap inline-flex items-center`}
          >
            Cancelar
          </button>
          <button
            type="button"
            disabled={!canSubmit}
            onClick={handleConfirm}
            className={`${
              isMobileLayout ? 'flex-[2] justify-center' : ''
            } px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs sm:text-sm font-bold inline-flex items-center gap-2 cursor-pointer whitespace-nowrap shadow-sm btn-press`}
          >
            <CheckCircle2 className="w-4 h-4" />
            {submitting ? 'Procesando cobro...' : 'Confirmar y Cobrar'}
          </button>
        </div>
      </footer>
    </div>
  );

  if (isFramedMobilePreview) {
    return (
      <div className="fixed inset-0 z-[100] bg-slate-900/35 backdrop-blur-sm flex items-center justify-center p-2">
        {checkoutShell}
      </div>
    );
  }

  return checkoutShell;
};
