import React, { useEffect, useState } from 'react';
import {
  Check,
  DollarSign,
  Globe,
  Lock,
  RefreshCw,
  SlidersHorizontal,
  TrendingUp,
  Unlock,
} from 'lucide-react';
import { usePos } from '../context/PosContext';
import {
  formatRateNumber,
  SUPPORTED_CURRENCIES,
  type CurrencyCode,
} from '../utils/currencies';
import { formatMoney } from '../utils/format';

interface CurrencyRateManagerProps {
  mode: 'owner' | 'admin';
  tenantLabel?: string;
}

export const CurrencyRateManager: React.FC<CurrencyRateManagerProps> = ({
  mode,
  tenantLabel,
}) => {
  const {
    bcvRate,
    secondaryRate,
    tertiaryRate,
    localCurrencyCode,
    localCurrency,
    rateEditable,
    setLocalCurrency,
    setRateEditable,
    syncCurrencyRate,
    syncAllRates,
    syncUsdtRate,
    updateRate,
    ratesSyncing,
    notifyToast,
  } = usePos();

  const [rate1Draft, setRate1Draft] = useState(formatRateNumber(bcvRate, localCurrencyCode));
  const [rate2Draft, setRate2Draft] = useState(formatRateNumber(secondaryRate, localCurrencyCode));
  const [rate3Draft, setRate3Draft] = useState(formatRateNumber(tertiaryRate, localCurrencyCode));
  const [savingManual, setSavingManual] = useState(false);
  const [switchingCode, setSwitchingCode] = useState<CurrencyCode | null>(null);

  useEffect(() => {
    setRate1Draft(formatRateNumber(bcvRate, localCurrencyCode));
    setRate2Draft(formatRateNumber(secondaryRate, localCurrencyCode));
    setRate3Draft(formatRateNumber(tertiaryRate, localCurrencyCode));
  }, [bcvRate, secondaryRate, tertiaryRate, localCurrencyCode]);

  const canEditFields = rateEditable || mode === 'owner';

  const handleSelectCurrency = async (code: CurrencyCode) => {
    if (switchingCode) return;
    setSwitchingCode(code);
    try {
      await setLocalCurrency(code, true);
    } finally {
      setSwitchingCode(null);
    }
  };

  const handleSaveManualRates = async () => {
    if (!canEditFields) {
      notifyToast(
        'Activa "Permitir tasa manual editable" si deseas fijar una tasa personalizada.',
        'warning'
      );
      return;
    }
    const r1 = Number(rate1Draft);
    const r2 = Number(rate2Draft);
    const r3 = Number(rate3Draft);
    if (!Number.isFinite(r1) || r1 <= 0) {
      notifyToast('Ingresa una tasa principal válida mayor a 0.', 'error');
      return;
    }
    setSavingManual(true);
    try {
      await updateRate('bcv', r1);
      if (Number.isFinite(r2) && r2 > 0) await updateRate('secundaria', r2);
      if (Number.isFinite(r3) && r3 > 0) await updateRate('terciaria', r3);
    } finally {
      setSavingManual(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Globe className="w-4 h-4 text-sky-600" />
            Moneda de Trabajo y Tasas del Día (Doble Moneda)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            El <strong>Dólar (USD $)</strong> se mantiene siempre como moneda principal compatible con la moneda local seleccionada
            {tenantLabel ? ` para ${tenantLabel}` : ''}.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={ratesSyncing || Boolean(switchingCode)}
            onClick={() =>
              void (localCurrencyCode === 'VES'
                ? syncAllRates(false)
                : syncCurrencyRate(localCurrencyCode, false))
            }
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${ratesSyncing ? 'animate-spin' : ''}`} />
            {ratesSyncing ? 'Consultando API...' : `Actualizar Tasa ${localCurrency.code} (API)`}
          </button>
        </div>
      </div>

      {/* Active Dual-Currency Pair Summary */}
      <div className="p-3.5 rounded-xl bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center shrink-0">
            <DollarSign className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-300 block">
              Par Activo en Caja y Ventas
            </span>
            <p className="text-sm font-extrabold">
              USD ($) Principal + {localCurrency.name} ({localCurrency.shortLabel})
            </p>
          </div>
        </div>

        <div className="text-right font-mono tabular-nums">
          <span className="text-[10px] font-sans uppercase tracking-wider text-slate-300 block">
            {localCurrency.apiSourceLabel}
          </span>
          <span className="text-lg sm:text-xl font-black text-emerald-300">
            1 USD = {formatRateNumber(bcvRate, localCurrencyCode)} {localCurrency.shortLabel}
          </span>
        </div>
      </div>

      {/* Selectable Working Currencies Grid */}
      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-700">
            1. Selecciona la moneda local compatible con USD ($)
          </span>
          <span className="text-[11px] text-slate-500">
            Al seleccionar se actualiza automáticamente con la tasa del día
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
          {SUPPORTED_CURRENCIES.map((cur) => {
            const isSelected = cur.code === localCurrencyCode;
            const isLoadingThis = switchingCode === cur.code;
            return (
              <button
                key={cur.code}
                type="button"
                disabled={Boolean(switchingCode)}
                onClick={() => void handleSelectCurrency(cur.code)}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer relative ${
                  isSelected
                    ? 'bg-sky-50 border-sky-500 ring-2 ring-sky-200/80 shadow-xs'
                    : 'bg-slate-50/70 border-slate-200 hover:bg-white hover:border-sky-300'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span
                    className={`text-xs font-black font-mono ${
                      isSelected ? 'text-sky-700' : 'text-slate-800'
                    }`}
                  >
                    USD + {cur.code}
                  </span>
                  {isLoadingThis ? (
                    <RefreshCw className="w-3.5 h-3.5 text-sky-600 animate-spin shrink-0" />
                  ) : isSelected ? (
                    <Check className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                  ) : (
                    <span className="text-[10px] font-mono font-bold text-slate-400">
                      {cur.shortLabel}
                    </span>
                  )}
                </div>
                <p className="text-[11px] font-semibold text-slate-700 truncate mt-0.5">
                  {cur.name}
                </p>
                <p className="text-[10px] text-slate-400 truncate">{cur.country}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Editable Manual Rate Toggle + Inputs */}
      <div className="p-3.5 rounded-xl bg-slate-50/90 border border-slate-200 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-600 shrink-0" />
            <div>
              <span className="text-xs font-bold text-slate-800 block">
                2. Tasa Manual Editable (Opcional)
              </span>
              <span className="text-[11px] text-slate-500">
                {rateEditable
                  ? 'Activa: puedes ajustar libremente la tasa manual o sincronizarla con la API.'
                  : 'Bloqueada a API: la tasa se rige automáticamente por la API del día.'}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void setRateEditable(!rateEditable)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
              rateEditable
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100'
                : 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100'
            }`}
          >
            {rateEditable ? (
              <>
                <Unlock className="w-3.5 h-3.5" /> Tasa Editable: ACTIVA
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5" /> Solo API (Activar edición)
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
          <div>
            <label className="font-semibold text-slate-600 block mb-1">
              {localCurrency.rateLabel} Principal ({localCurrency.shortLabel})
            </label>
            <input
              type="number"
              step={localCurrencyCode === 'EUR' ? '0.0001' : '0.01'}
              disabled={!canEditFields}
              value={rate1Draft}
              onChange={(e) => setRate1Draft(e.target.value)}
              className="w-full px-3 py-2 font-mono font-bold bg-white disabled:bg-slate-100 disabled:text-slate-500 border border-slate-200 rounded-xl"
            />
          </div>
          <div>
            <label className="font-semibold text-slate-600 block mb-1">
              {localCurrencyCode === 'VES'
                ? 'Paralelo 1 / USDT (Bs)'
                : `Tasa Referencia 2 (${localCurrency.shortLabel})`}
            </label>
            <input
              type="number"
              step={localCurrencyCode === 'EUR' ? '0.0001' : '0.01'}
              disabled={!canEditFields}
              value={rate2Draft}
              onChange={(e) => setRate2Draft(e.target.value)}
              className="w-full px-3 py-2 font-mono font-bold bg-white disabled:bg-slate-100 disabled:text-slate-500 border border-slate-200 rounded-xl"
            />
          </div>
          <div>
            <label className="font-semibold text-slate-600 block mb-1">
              {localCurrencyCode === 'VES'
                ? 'Paralelo 2 (Bs)'
                : `Tasa Referencia 3 (${localCurrency.shortLabel})`}
            </label>
            <input
              type="number"
              step={localCurrencyCode === 'EUR' ? '0.0001' : '0.01'}
              disabled={!canEditFields}
              value={rate3Draft}
              onChange={(e) => setRate3Draft(e.target.value)}
              className="w-full px-3 py-2 font-mono font-bold bg-white disabled:bg-slate-100 disabled:text-slate-500 border border-slate-200 rounded-xl"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={!canEditFields || savingManual}
            onClick={() => void handleSaveManualRates()}
            className="flex-1 min-w-[180px] py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            {savingManual ? 'Guardando...' : 'Guardar Tasas Manuales'}
          </button>

          {localCurrencyCode === 'VES' && (
            <>
              <button
                type="button"
                disabled={ratesSyncing}
                onClick={() => void syncCurrencyRate('VES', false)}
                className="px-3 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Solo BCV
              </button>
              <button
                type="button"
                disabled={ratesSyncing}
                onClick={() => void syncUsdtRate(false)}
                className="px-3 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Solo USDT
              </button>
            </>
          )}
        </div>
      </div>

      {/* Live Dual-Currency Quick Reference Table */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono tabular-nums">
        {[1, 10, 50, 100].map((usdSample) => (
          <div
            key={usdSample}
            className="px-3 py-2 rounded-xl bg-sky-50/60 border border-sky-100 flex items-center justify-between gap-2"
          >
            <span className="font-bold text-slate-800">${usdSample}</span>
            <span className="font-extrabold text-sky-800 truncate">
              {formatMoney(usdSample * bcvRate)} {localCurrency.shortLabel}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
