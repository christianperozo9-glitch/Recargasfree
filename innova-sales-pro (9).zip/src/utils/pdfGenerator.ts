import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import JsBarcode from 'jsbarcode';
import type {
  CierreRecord,
  FiadoAbono,
  FiadoItem,
  FiadoRecord,
  PagoMovilVerificationResult,
  SaleItem,
  SaleTransaction,
  SupplierPurchaseRecord,
  TallerRepair,
  TenantInvoiceConfig,
} from '../types/pos';
import type { TenantMetaForReceipt } from './thermalPrinter';
import { avatarDataUrl, formatMoney } from './format';

type JsPDFWithAutoTable = jsPDF & { lastAutoTable?: { finalY: number } };

function drawInnovaMark(doc: jsPDF, x: number, y: number, s: number) {
  doc.setFillColor(14, 165, 233);
  doc.roundedRect(x, y, s, s, 3, 3, 'F');
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(x + s * 0.42, y + s * 0.35, s * 0.16, s * 0.42, 1, 1, 'F');
  doc.setFillColor(34, 211, 238);
  doc.circle(x + s * 0.5, y + s * 0.22, s * 0.09, 'F');
}

function drawTenantLogoOrMark(
  doc: jsPDF,
  x: number,
  y: number,
  s: number,
  invoiceConfig?: Partial<TenantInvoiceConfig> | null
) {
  const logoUrl = invoiceConfig?.logo_data_url;
  if (logoUrl && invoiceConfig?.mostrar_logo !== false && /^data:image\//i.test(logoUrl)) {
    try {
      const fmt = /image\/jpe?g/i.test(logoUrl) ? 'JPEG' : /image\/webp/i.test(logoUrl) ? 'WEBP' : 'PNG';
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(x, y, s, s, 2.5, 2.5, 'F');
      doc.addImage(logoUrl, fmt, x + 1, y + 1, s - 2, s - 2, undefined, 'FAST');
      return;
    } catch {
      // fallback to mark
    }
  }
  drawInnovaMark(doc, x, y, s);
}

export function generateCierrePDF(
  cierre: CierreRecord,
  localName: string,
  invoiceConfig?: Partial<TenantInvoiceConfig> | null
): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' }) as JsPDFWithAutoTable;
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const navy: [number, number, number] = [12, 74, 110];
  const accent: [number, number, number] = [14, 165, 233];
  const mute: [number, number, number] = [100, 116, 139];
  const ink: [number, number, number] = [30, 41, 59];

  const qtyFmt = (n: number) => String(Math.round((Number(n) || 0) * 100) / 100);

  const tableBase = {
    theme: 'striped' as const,
    margin: { left: 14, right: 14 },
    styles: { font: 'helvetica', fontSize: 9, cellPadding: 2.2, textColor: ink, valign: 'middle' as const },
    headStyles: { fillColor: navy, textColor: [255, 255, 255] as [number, number, number], fontStyle: 'bold' as const },
    alternateRowStyles: { fillColor: [247, 249, 252] as [number, number, number] },
  };

  const section = (title: string, yPos: number) => {
    doc.setFillColor(...accent);
    doc.rect(14, yPos - 4, 1.8, 5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(...navy);
    doc.text(title, 18, yPos);
  };

  const needPage = (yPos: number, h: number) => {
    if (yPos + h > H - 20) {
      doc.addPage();
      return 20;
    }
    return yPos;
  };

  // Header
  doc.setFillColor(...navy);
  doc.rect(0, 0, W, 34, 'F');
  doc.setFillColor(...accent);
  doc.rect(0, 34, W, 1.6, 'F');
  drawTenantLogoOrMark(doc, 14, 7, 20, invoiceConfig);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.setTextColor(255, 255, 255);
  doc.text('INNOVA', 38, 18);
  const w1 = doc.getTextWidth('INNOVA ');
  doc.setTextColor(34, 211, 238);
  doc.text('GRUP', 38 + w1, 18);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(203, 213, 225);
  doc.text(`Reporte de Cierre de Caja  |  ${localName || 'Innova Grup'}`, 38, 25);

  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(`${cierre.fecha || ''}  ${cierre.hora || ''}`, W - 14, 16, { align: 'right' });
  doc.setTextColor(203, 213, 225);
  doc.text(`Cajero: ${cierre.cerrado_por || '-'}`, W - 14, 23, { align: 'right' });

  // KPIs
  const kpis = [
    ['TRANSACCIONES', String(cierre.cantidad_ventas || 0)],
    ['TOTAL RECAUDADO', `${formatMoney(cierre.total_general_ves)} Bs`],
    ['EQUIV. USD (BCV)', `$ ${formatMoney(cierre.total_general_usd)}`],
  ];
  const cardW = (W - 28 - 8) / 3;
  kpis.forEach((k, i) => {
    const x = 14 + i * (cardW + 4);
    doc.setFillColor(244, 246, 251);
    doc.roundedRect(x, 42, cardW, 20, 3, 3, 'F');
    doc.setFillColor(...accent);
    doc.rect(x, 42, 1.6, 20, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(...mute);
    doc.text(k[0], x + 6, 49);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(...navy);
    doc.text(k[1], x + 6, 57);
  });

  // Payment methods
  let y = 74;
  section('DESGLOSE POR MÉTODO DE PAGO', y);
  const mBs = cierre.totales_metodos_ves || {};
  const mUsd = cierre.totales_metodos_usd || {};
  const mRows = Object.keys(mBs).map((m) => [
    m === 'Cashea' ? 'Cashea (Inicial aprobada)' : m,
    `${formatMoney(mBs[m])} Bs`,
    `$ ${formatMoney(mUsd[m])}`,
  ]);

  autoTable(doc, {
    ...tableBase,
    startY: y + 3,
    head: [['Método', 'Total Bs', 'Equiv. USD']],
    body: mRows.length ? mRows : [['Sin transacciones', '-', '-']],
    columnStyles: { 1: { halign: 'right' }, 2: { halign: 'right' } },
  });

  // Sold products
  const prods = Array.isArray(cierre.productos_vendidos)
    ? cierre.productos_vendidos
    : cierre.productos_vendidos && typeof cierre.productos_vendidos === 'object'
    ? Object.values(cierre.productos_vendidos as Record<string, CierreRecord['productos_vendidos'][number]>)
    : [];
  y = needPage((doc.lastAutoTable?.finalY || y) + 10, 40);
  section('PRODUCTOS VENDIDOS', y);
  autoTable(doc, {
    ...tableBase,
    startY: y + 3,
    head: [['', 'Producto', 'Cant.', 'Total Bs', 'Total USD']],
    body: prods.length
      ? prods.map((p) => ['', String(p.nombre), qtyFmt(p.cantidad), formatMoney(p.total_ves), `$ ${formatMoney(p.total_usd)}`])
      : [['', 'Este cierre no contiene detalle de productos.', '', '', '']],
    styles: { ...tableBase.styles, minCellHeight: 12 },
    columnStyles: { 0: { cellWidth: 14 }, 2: { halign: 'center', cellWidth: 18 }, 3: { halign: 'right' }, 4: { halign: 'right' } },
    didDrawCell: (data) => {
      if (prods.length && data.section === 'body' && data.column.index === 0) {
        const p = prods[data.row.index];
        if (p) {
          try {
            const url = avatarDataUrl(p.nombre);
            if (url) doc.addImage(url, 'PNG', data.cell.x + 2, data.cell.y + 1.5, 9, 9);
          } catch {
            // ignore avatar draw error
          }
        }
      }
    },
  });

  // Detail per sale
  const dv = Array.isArray(cierre.detalle_ventas)
    ? cierre.detalle_ventas
    : cierre.detalle_ventas && typeof cierre.detalle_ventas === 'object'
    ? Object.values(cierre.detalle_ventas as Record<string, CierreRecord['detalle_ventas'][number]>)
    : [];
  const dRows: string[][] = [];
  dv.forEach((v, i) => {
    const items = Array.isArray(v.items)
      ? v.items
      : v.items && typeof v.items === 'object'
      ? Object.values(v.items as Record<string, CierreRecord['detalle_ventas'][number]['items'][number]>)
      : [];
    if (items.length) {
      items.forEach((x, j) =>
        dRows.push([
          j === 0 ? `#${i + 1} ${v.hora || ''}` : '',
          j === 0 ? String(v.metodo || '') : '',
          String(x.nombre),
          qtyFmt(x.cantidad),
          formatMoney(x.precio_ves),
          formatMoney(x.subtotal_ves),
        ])
      );
    } else {
      dRows.push([`#${i + 1} ${v.hora || ''}`, String(v.metodo || ''), String(v.productos || ''), '', '', formatMoney(v.total_ves)]);
    }
    if ((v.cashea_restante_usd || 0) > 0) {
      dRows.push([
        '',
        '',
        `Total compra: ${formatMoney(v.cashea_total_venta_ves || 0)} Bs | Pendiente Cashea (${
          v.cashea_cuotas || 3
        } cuotas): $ ${formatMoney(v.cashea_restante_usd || 0)}`,
        '',
        '',
        '',
      ]);
      dRows.push(['', '', 'Inicial aprobada en cierre', '', '', `${formatMoney(v.total_ves)} Bs`]);
    } else {
      dRows.push(['', '', 'Total de la venta', '', '', `${formatMoney(v.total_ves)} Bs`]);
    }
  });

  if (dRows.length) {
    y = needPage((doc.lastAutoTable?.finalY || y) + 10, 40);
    section('DETALLE DE CADA VENTA', y);
    autoTable(doc, {
      ...tableBase,
      startY: y + 3,
      head: [['Venta', 'Método', 'Producto', 'Cant.', 'Precio Bs', 'Subtotal Bs']],
      body: dRows,
      columnStyles: { 3: { halign: 'center' }, 4: { halign: 'right' }, 5: { halign: 'right' } },
    });
  }

  // Totals block
  y = needPage((doc.lastAutoTable?.finalY || y) + 8, 40);
  const total = Number(cierre.total_general_ves) || 0;
  const casheaPendBs = Number(cierre.cashea_pendiente_ves) || 0;
  const casheaPendUsd = Number(cierre.cashea_pendiente_usd) || 0;
  const rows: string[][] = [];
  if (cierre.subtotal_productos_ves !== undefined) {
    const sub = Number(cierre.subtotal_productos_ves) || 0;
    const iva = Number(cierre.total_iva_ves) || 0;
    const ajuste = total + casheaPendBs - sub - iva;
    rows.push(['Subtotal de productos', `${formatMoney(sub)} Bs`]);
    if (iva > 0) rows.push(['IVA (16%)', `${formatMoney(iva)} Bs`]);
    if (Math.abs(ajuste) > 0.01) rows.push(['Ajuste por tasa / descuento global', `${formatMoney(ajuste)} Bs`]);
  }
  if (casheaPendUsd > 0) {
    rows.push([
      'Pendiente Cashea (No sumado al cierre)',
      `$ ${formatMoney(casheaPendUsd)} (${formatMoney(casheaPendBs)} Bs)`,
    ]);
  }
  rows.push(['TOTAL RECAUDADO', `${formatMoney(total)} Bs`]);

  autoTable(doc, {
    startY: y,
    theme: 'plain',
    margin: { left: W - 14 - 95, right: 14 },
    body: rows,
    styles: { font: 'helvetica', fontSize: 9.5, cellPadding: 1.8, textColor: ink },
    columnStyles: { 1: { halign: 'right', fontStyle: 'bold' } },
    didParseCell: (d) => {
      if (d.row.index === rows.length - 1) {
        d.cell.styles.fontStyle = 'bold';
        d.cell.styles.fontSize = 11;
        d.cell.styles.textColor = navy;
      }
    },
  });

  // Footer
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.line(14, H - 14, W - 14, H - 14);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(...mute);
    doc.text(`Innova Grup - Generado el ${new Date().toLocaleString('es-VE')}`, 14, H - 8);
    doc.text(`Página ${i} de ${pages}`, W - 14, H - 8, { align: 'right' });
  }

  const d = new Date(cierre.timestamp || Date.now());
  const stamp = d.toISOString().slice(0, 16).replace(/[:T]/g, '-');
  doc.save(`Cierre_InnovaGrup_${stamp}.pdf`);
  return true;
}

export function generatePresupuestoPDF(
  localName: string,
  clientName: string,
  items: Array<{ name: string; quantity: number; unitUsd: number }>,
  rate: number,
  ivaFactor: number
) {
  const doc = new jsPDF() as JsPDFWithAutoTable;
  const totalUsd = items.reduce((s, i) => s + i.unitUsd * i.quantity, 0) * ivaFactor;

  doc.setFillColor(12, 74, 110);
  doc.rect(0, 0, 210, 28, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(`${localName} · PRESUPUESTO`, 14, 14);
  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`Fecha: ${new Date().toLocaleString('es-VE')}${clientName ? `   |   Cliente: ${clientName}` : ''}`, 14, 22);

  autoTable(doc, {
    startY: 34,
    head: [['Producto', 'Cant.', 'Precio USD', 'Subtotal USD', 'Subtotal Bs']],
    body: items.map((i) => [
      i.name,
      String(i.quantity),
      `$${i.unitUsd.toFixed(2)}`,
      `$${(i.unitUsd * i.quantity).toFixed(2)}`,
      `${(i.unitUsd * i.quantity * rate).toFixed(2)} Bs`,
    ]),
    headStyles: { fillColor: [12, 74, 110] },
  });

  const y = (doc.lastAutoTable?.finalY || 40) + 10;
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(
    `Total: $${totalUsd.toFixed(2)} USD  /  ${(totalUsd * rate).toFixed(2)} Bs${ivaFactor > 1 ? ' (IVA 16% incluido)' : ''}`,
    14,
    y
  );
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Presupuesto sin valor fiscal. Precios sujetos a variación cambiaria.', 14, y + 7);
  doc.save(`Presupuesto_${Date.now()}.pdf`);
}

export function generateTallerPDF(localName: string, repairs: TallerRepair[]) {
  const doc = new jsPDF() as JsPDFWithAutoTable;
  doc.setFontSize(14);
  doc.text(`${localName} · Cierre de Taller (${new Date().toLocaleString('es-VE')})`, 14, 16);
  autoTable(doc, {
    startY: 22,
    head: [['Hora', 'Mecánico', 'Detalle', 'Pago', 'USD', 'Bs']],
    body: repairs.map((x) => [
      x.hora,
      x.mecanico,
      x.descripcion || 'Reparación de motor',
      x.metodo_pago,
      `$${Number(x.usd).toFixed(2)}`,
      `${Number(x.bs).toFixed(2)} Bs`,
    ]),
    headStyles: { fillColor: [12, 74, 110] },
  });
  const totalUsd = repairs.reduce((s, x) => s + Number(x.usd || 0), 0);
  const totalBs = repairs.reduce((s, x) => s + Number(x.bs || 0), 0);
  const y = (doc.lastAutoTable?.finalY || 40) + 10;
  doc.setFontSize(12);
  doc.text(`Total Taller: $${totalUsd.toFixed(2)} USD  (${totalBs.toFixed(2)} Bs)`, 14, y);
  doc.save(`Cierre_Taller_${Date.now()}.pdf`);
}

export function generateFiadoStatementPDF(
  localName: string,
  fiado: FiadoRecord,
  bcvRate: number,
  totalUsd: number,
  paidUsd: number
) {
  const doc = new jsPDF() as JsPDFWithAutoTable;
  const remaining = Math.max(0, totalUsd - paidUsd);
  const items: FiadoItem[] = Array.isArray(fiado.items) ? fiado.items : Object.values(fiado.items || {});
  const abonos: FiadoAbono[] = Object.values(fiado.abonos || {});

  doc.setFillColor(12, 74, 110);
  doc.rect(0, 0, 210, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text(`${localName} · ESTADO DE CUENTA (FIADO)`, 14, 13);
  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Cliente: ${fiado.cliente}  |  C.I.: ${fiado.cedula}${fiado.telefono ? `  |  Tel: ${fiado.telefono}` : ''}`,
    14,
    21
  );
  const modeLabel =
    fiado.modalidad === 'contado_pendiente'
      ? 'Factura Pendiente (Pago Único)'
      : `A Crédito (${fiado.cuotas || 1} cuota${(fiado.cuotas || 1) > 1 ? 's' : ''})`;
  doc.text(
    `Emitido: ${fiado.fecha}${fiado.fecha_vencimiento ? `  |  Vence: ${fiado.fecha_vencimiento}` : ''}  |  ${modeLabel}${fiado.numero_factura ? `  |  ${fiado.numero_factura}` : ''}`,
    14,
    27
  );

  autoTable(doc, {
    startY: 36,
    head: [['Artículo', 'Cant.', 'Precio USD', 'Subtotal USD']],
    body: items.map((it) => [
      it.nombre,
      String(it.cant),
      `$${Number(it.usd).toFixed(2)}`,
      `$${(Number(it.usd) * Number(it.cant)).toFixed(2)}`,
    ]),
    headStyles: { fillColor: [12, 74, 110] },
  });

  let y = (doc.lastAutoTable?.finalY || 45) + 8;
  if (abonos.length) {
    autoTable(doc, {
      startY: y,
      head: [['Fecha', 'Tipo', 'Método / Ref.', 'Monto USD']],
      body: abonos.map((a) => [
        a.fecha || (a.ts ? new Date(a.ts).toLocaleString('es-VE') : '-'),
        a.tipo || 'abono',
        `${a.metodo || '-'}${a.referencia ? ` (Ref: ${a.referencia})` : ''}`,
        `$${Number(a.usd).toFixed(2)}`,
      ]),
      headStyles: { fillColor: [5, 150, 105] },
    });
    y = (doc.lastAutoTable?.finalY || y) + 10;
  }

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(`Total Factura: $${totalUsd.toFixed(2)} (${(totalUsd * bcvRate).toFixed(2)} Bs)`, 14, y);
  doc.text(`Total Abonado: $${paidUsd.toFixed(2)} (${(paidUsd * bcvRate).toFixed(2)} Bs)`, 14, y + 6);
  doc.setTextColor(remaining > 0.01 ? 225 : 5, remaining > 0.01 ? 29 : 150, remaining > 0.01 ? 72 : 105);
  doc.text(
    `Saldo Pendiente: $${remaining.toFixed(2)} (${(remaining * bcvRate).toFixed(2)} Bs)`,
    14,
    y + 12
  );
  doc.save(`Estado_Cuenta_${fiado.cedula}_${Date.now()}.pdf`);
}

export function generateContractPDF(localName: string, planName: string, priceText: string, validUntil: string, active: boolean) {
  const doc = new jsPDF();
  doc.setFillColor(14, 165, 233);
  doc.rect(0, 0, 210, 28, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('CONTRATO DE MEMBRESÍA - INNOVA GROUP', 14, 14);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Cliente: ${localName}  |  Emisión: ${new Date().toLocaleDateString('es-VE')}`, 14, 22);

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(10.5);
  const lines = [
    `Plan contratado: ${planName}`,
    `Monto de referencia: ${priceText}`,
    `Vigente hasta: ${validUntil}`,
    `Estado actual: ${active ? 'Activa' : 'Suspendida'}`,
    '',
    'PRIMERA - Objeto: Innova Group otorga al Cliente licencia de uso del sistema Innova Grup POS.',
    'SEGUNDA - Vigencia: El acceso permanece activo hasta la fecha de vencimiento del plan contratado.',
    'TERCERA - Pago: El Cliente realiza el pago por los canales autorizados e informa la referencia.',
    'CUARTA - Datos: La información de ventas, inventario y clientes pertenece íntegramente al Cliente.',
    'QUINTA - Soporte: El Proveedor brinda asistencia técnica desde la bandeja integrada de soporte.',
  ];
  let y = 40;
  lines.forEach((line) => {
    const wrapped = doc.splitTextToSize(line, 180);
    doc.text(wrapped, 14, y);
    y += wrapped.length * 6 + 2;
  });

  doc.line(14, 240, 90, 240);
  doc.line(120, 240, 196, 240);
  doc.setFontSize(9);
  doc.text('Innova Group (Proveedor)', 14, 246);
  doc.text(`${localName} (Cliente)`, 120, 246);
  doc.save(`Contrato_Membresia_${localName.replace(/\s+/g, '_')}.pdf`);
}

export function generateRenewalPDF(localName: string, planName: string, priceText: string, prevDate: string, newDate: string, bonusMonths: number) {
  const doc = new jsPDF();
  doc.setFillColor(14, 165, 233);
  doc.rect(0, 0, 210, 28, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('CONSTANCIA DE RENOVACIÓN - INNOVA GROUP', 14, 14);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Cliente: ${localName}  |  Fecha: ${new Date().toLocaleDateString('es-VE')}`, 14, 22);

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(11);
  const lines = [
    `Local beneficiario: ${localName}`,
    `Plan renovado: ${planName}`,
    `Monto: ${priceText}`,
    bonusMonths > 0 ? `Promoción aplicada: +${bonusMonths} mes(es) de regalo` : '',
    `Vencimiento anterior: ${prevDate}`,
    `Nuevo vencimiento: ${newDate}`,
    '',
    'Innova Group certifica la renovación exitosa de la licencia de uso del sistema POS.',
  ].filter(Boolean);

  let y = 42;
  lines.forEach((line) => {
    doc.text(line, 14, y);
    y += 8;
  });
  doc.save(`Renovacion_Membresia_${localName.replace(/\s+/g, '_')}.pdf`);
}

export interface DatabaseAuthContractParams {
  tenantId: string;
  localName: string;
  razonSocial?: string;
  rif?: string;
  email: string;
  telefono?: string;
  contactoNombre?: string;
  direccionFiscal?: string;
  ownerEmail: string;
  planName?: string;
  validUntil?: string;
}

export function generateDatabaseAuthorizationPDF(params: DatabaseAuthContractParams): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const navy: [number, number, number] = [12, 74, 110];
  const accent: [number, number, number] = [14, 165, 233];
  const ink: [number, number, number] = [30, 41, 59];
  const mute: [number, number, number] = [100, 116, 139];

  const folio = `AUT-${Date.now().toString().slice(-6)}`;
  const emitDate = new Date().toLocaleDateString('es-VE');

  // Header
  doc.setFillColor(...navy);
  doc.rect(0, 0, W, 34, 'F');
  doc.setFillColor(...accent);
  doc.rect(0, 34, W, 1.5, 'F');
  drawInnovaMark(doc, 14, 7, 20);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13.5);
  doc.setTextColor(255, 255, 255);
  doc.text('CONTRATO DE AUTORIZACIÓN DE ACCESO A BASE DE DATOS', 38, 14);
  doc.setFontSize(10);
  doc.setTextColor(34, 211, 238);
  doc.text('CON CONSENTIMIENTO EXPRESO DEL PROPIETARIO · INNOVA GROUP', 38, 21);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`Folio: ${folio}   |   Fecha de emisión: ${emitDate}`, 38, 28);

  // Client & Node Box
  doc.setFillColor(244, 246, 251);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 42, W - 28, 46, 3, 3, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(...navy);
  doc.text('1. IDENTIFICACIÓN DEL USUARIO Y NODO DE BASE DE DATOS AUTORIZADO', 18, 49);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(...ink);
  doc.text(`Comercio / Local: ${params.localName}`, 18, 56);
  doc.text(`Razón Social: ${params.razonSocial || params.localName}`, 18, 62);
  doc.text(`RIF / Doc. Fiscal: ${params.rif || 'No especificado'}`, 18, 68);
  doc.text(`Dirección Fiscal: ${params.direccionFiscal || 'No especificada'}`, 18, 74);
  doc.text(`Correo de Acceso: ${params.email}`, 18, 80);

  doc.text(`Nodo Firestore: tenants/${params.tenantId}`, W - 18, 56, { align: 'right' });
  doc.text(`Contacto: ${params.contactoNombre || '-'}`, W - 18, 62, { align: 'right' });
  doc.text(`Teléfono: ${params.telefono || '-'}`, W - 18, 68, { align: 'right' });
  doc.text(`Plan Actual: ${params.planName || 'Estándar'}`, W - 18, 74, { align: 'right' });
  doc.text(`Vigencia: ${params.validUntil || 'Activa'}`, W - 18, 80, { align: 'right' });

  // Owner consent box
  doc.setFillColor(240, 253, 250);
  doc.setDrawColor(167, 243, 208);
  doc.roundedRect(14, 93, W - 28, 18, 3, 3, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(6, 95, 70);
  doc.text('2. PROPIETARIO AUTORIZANTE DE LA PLATAFORMA', 18, 100);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Titular Maestro: Innova Group · Correo autorizado: ${params.ownerEmail}`,
    18,
    106.5
  );

  // Clauses
  let y = 122;
  const clauses = [
    'PRIMERA - Consentimiento y Habilitación: El Propietario de la plataforma Innova Group otorga consentimiento expreso para que el Usuario arriba identificado acceda, consulte y registre operaciones comerciales exclusivamente dentro de su nodo individual asignado en la base de datos en la nube (Cloud Firestore).',
    'SEGUNDA - Aislamiento de Información: La infraestructura multiusuario garantiza que la información del Usuario (productos, inventario, ventas, cierres de caja, cuentas por cobrar y cajeros) permanezca aislada en su nodo privado, sin acceso a registros de otros comercios ni al panel maestro del Propietario.',
    'TERCERA - Custodia de Credenciales: El Usuario es responsable directo de la confidencialidad de su correo electrónico, contraseña de autenticación y pines de seguridad otorgados a sus administradores y cajeros.',
    'CUARTA - Vigencia, Auditoría y Suspensión: El acceso a la base de datos permanecerá habilitado mientras la membresía del Usuario mantenga días disponibles activos. Al llegar a cero (0) días o en caso de incumplimiento de pago, el sistema suspenderá las operaciones hasta su renovación.',
    'QUINTA - Propiedad de los Datos: Toda la data comercial cargada por el Usuario dentro de su nodo individual es propiedad exclusiva del Cliente, pudiendo exportarla en reportes PDF, CSV o respaldos JSON cuando su cuenta se encuentre activa.',
  ];

  doc.setFontSize(9.5);
  doc.setTextColor(...ink);
  clauses.forEach((clause) => {
    const wrapped = doc.splitTextToSize(clause, W - 28);
    doc.text(wrapped, 14, y);
    y += wrapped.length * 5.2 + 4.5;
  });

  // Signatures
  const sigY = Math.max(y + 18, 244);
  doc.setDrawColor(148, 163, 184);
  doc.line(18, sigY, 92, sigY);
  doc.line(W - 92, sigY, W - 18, sigY);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...navy);
  doc.text('CONSENTIMIENTO DEL PROPIETARIO', 55, sigY + 5, { align: 'center' });
  doc.text('USUARIO / CLIENTE AUTORIZADO', W - 55, sigY + 5, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(...mute);
  doc.text(`Innova Group · ${params.ownerEmail}`, 55, sigY + 10, { align: 'center' });
  doc.text(`${params.localName} (${params.rif || params.email})`, W - 55, sigY + 10, { align: 'center' });

  doc.setDrawColor(226, 232, 240);
  doc.line(14, H - 14, W - 14, H - 14);
  doc.setFontSize(8);
  doc.text(`Documento generado el ${new Date().toLocaleString('es-VE')} · Folio ${folio}`, 14, H - 8);
  doc.text('Innova Group POS', W - 14, H - 8, { align: 'right' });

  const safeName = params.localName.replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_') || 'Cliente';
  doc.save(`Autorizacion_Base_Datos_${safeName}.pdf`);
  return true;
}

export interface MembershipRenewalContractParams {
  tenantId: string;
  localName: string;
  razonSocial?: string;
  rif?: string;
  email: string;
  telefono?: string;
  planName: string;
  planMonths: number;
  bonusMonths: number;
  baseUsd: number;
  discountPct: number;
  finalUsd: number;
  bcvRate: number;
  prevDate: string;
  newDate: string;
  ownerEmail: string;
  active: boolean;
}

export function generateMembershipRenewalContractPDF(params: MembershipRenewalContractParams): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const navy: [number, number, number] = [12, 74, 110];
  const accent: [number, number, number] = [16, 185, 129];
  const ink: [number, number, number] = [30, 41, 59];
  const mute: [number, number, number] = [100, 116, 139];

  const folio = `REN-${Date.now().toString().slice(-6)}`;
  const emitDate = new Date().toLocaleDateString('es-VE');
  const finalBs = params.finalUsd * (params.bcvRate || 0);

  // Header
  doc.setFillColor(...navy);
  doc.rect(0, 0, W, 34, 'F');
  doc.setFillColor(...accent);
  doc.rect(0, 34, W, 1.5, 'F');
  drawInnovaMark(doc, 14, 7, 20);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14.5);
  doc.setTextColor(255, 255, 255);
  doc.text('CONTRATO DE RENOVACIÓN DE MEMBRESÍA', 38, 14);
  doc.setFontSize(10);
  doc.setTextColor(167, 243, 208);
  doc.text('LICENCIA DE USO COMERCIAL · INNOVA GROUP POS', 38, 21);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`Folio: ${folio}   |   Fecha de renovación: ${emitDate}`, 38, 28);

  // Client summary
  doc.setFillColor(244, 246, 251);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 42, W - 28, 34, 3, 3, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(...navy);
  doc.text('DATOS DEL COMERCIO BENEFICIARIO', 18, 49);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(...ink);
  doc.text(`Local / Comercio: ${params.localName}`, 18, 56);
  doc.text(`Razón Social: ${params.razonSocial || params.localName}`, 18, 62);
  doc.text(`RIF / Doc. Fiscal: ${params.rif || 'No especificado'}`, 18, 68);

  doc.text(`Correo Cuenta: ${params.email}`, W - 18, 56, { align: 'right' });
  doc.text(`Teléfono: ${params.telefono || '-'}`, W - 18, 62, { align: 'right' });
  doc.text(`Nodo: tenants/${params.tenantId}`, W - 18, 68, { align: 'right' });

  // Contracted Plan Box
  doc.setFillColor(236, 253, 245);
  doc.setDrawColor(167, 243, 208);
  doc.roundedRect(14, 82, W - 28, 44, 3, 3, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(6, 95, 70);
  doc.text('DETALLE DEL PLAN CONTRATADO EN LA RENOVACIÓN', 18, 89);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(...ink);
  const totalMeses = params.planMonths + params.bonusMonths;
  doc.text(`Plan Seleccionado: ${params.planName}`, 18, 96.5);
  doc.text(
    `Duración Contratada: ${params.planMonths} mes(es)${
      params.bonusMonths > 0 ? ` + ${params.bonusMonths} mes(es) bono = ${totalMeses} mes(es)` : ''
    }`,
    18,
    103
  );
  doc.text(`Vencimiento Anterior: ${params.prevDate}`, 18, 109.5);
  doc.text(`Nuevo Vencimiento: ${params.newDate}`, 18, 116);

  doc.text(`Monto Base Plan: $${params.baseUsd.toFixed(2)} USD`, W - 18, 96.5, { align: 'right' });
  doc.text(
    `Descuento / Promoción: ${params.discountPct > 0 ? `-${params.discountPct}%` : 'Sin descuento'}`,
    W - 18,
    103,
    { align: 'right' }
  );
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(6, 95, 70);
  doc.text(
    `Total Plan: $${params.finalUsd.toFixed(2)} USD (${formatMoney(finalBs)} Bs)`,
    W - 18,
    109.5,
    { align: 'right' }
  );
  doc.text(
    `Estado Licencia: ${params.active ? 'ACTIVA' : 'PENDIENTE / VENCIDA'}`,
    W - 18,
    116,
    { align: 'right' }
  );

  // Clauses
  let y = 138;
  const clauses = [
    `PRIMERA - Objeto de Renovación: Innova Group renueva al Cliente "${params.localName}" la licencia de uso del sistema Innova Grup POS bajo el plan "${params.planName}", por un total de ${totalMeses} mes(es) de servicio continuo en su nodo asignado.`,
    'SEGUNDA - Conteo de Días y Bloqueo Automático: La vigencia de la membresía se descuenta automáticamente día a día desde el panel del Cliente. Al llegar a cero (0) días disponibles, las funciones operativas quedan pausadas hasta reportar la siguiente renovación.',
    'TERCERA - Validación de Pago: El Cliente realizará el abono correspondiente a través de Pago Móvil, enlaces de pago o canales autorizados del Propietario, enviando el comprobante de referencia para su aprobación.',
    'CUARTA - Soporte Técnico y Actualizaciones: Durante la vigencia del plan contratado, el Cliente cuenta con actualizaciones en tiempo real, respaldo en la nube y atención mediante el módulo integrado de soporte técnico.',
  ];

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(...ink);
  clauses.forEach((clause) => {
    const wrapped = doc.splitTextToSize(clause, W - 28);
    doc.text(wrapped, 14, y);
    y += wrapped.length * 5.2 + 4.5;
  });

  // Signatures
  const sigY = Math.max(y + 18, 244);
  doc.setDrawColor(148, 163, 184);
  doc.line(18, sigY, 92, sigY);
  doc.line(W - 92, sigY, W - 18, sigY);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...navy);
  doc.text('AUTORIZACIÓN PROPIETARIO', 55, sigY + 5, { align: 'center' });
  doc.text('ACEPTACIÓN DEL CLIENTE', W - 55, sigY + 5, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(...mute);
  doc.text(`Innova Group · ${params.ownerEmail}`, 55, sigY + 10, { align: 'center' });
  doc.text(`${params.localName} (${params.rif || params.email})`, W - 55, sigY + 10, { align: 'center' });

  doc.setDrawColor(226, 232, 240);
  doc.line(14, H - 14, W - 14, H - 14);
  doc.setFontSize(8);
  doc.text(`Documento generado el ${new Date().toLocaleString('es-VE')} · Folio ${folio}`, 14, H - 8);
  doc.text('Innova Group POS', W - 14, H - 8, { align: 'right' });

  const safeName = params.localName.replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_') || 'Cliente';
  doc.save(`Contrato_Renovacion_Membresia_${safeName}.pdf`);
  return true;
}

export function generateInvoicePDF(
  sale: SaleTransaction,
  localName: string,
  invoiceConfig?: Partial<TenantInvoiceConfig> | null,
  tenantMeta?: TenantMetaForReceipt
): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' }) as JsPDFWithAutoTable;
  const W = doc.internal.pageSize.getWidth();
  const parseHexRgb = (hex?: string): [number, number, number] | null => {
    if (!hex || !/^#([0-9a-fA-F]{6})$/.test(hex.trim())) return null;
    const h = hex.trim().slice(1);
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  };
  const customRgb = parseHexRgb(invoiceConfig?.color_factura);
  const navy: [number, number, number] = customRgb || [12, 74, 110];
  const accent: [number, number, number] = customRgb
    ? [Math.min(255, customRgb[0] + 35), Math.min(255, customRgb[1] + 45), Math.min(255, customRgb[2] + 55)]
    : [14, 165, 233];
  const ink: [number, number, number] =
    invoiceConfig?.intensidad_impresion === 'extra_oscura'
      ? [0, 0, 0]
      : invoiceConfig?.intensidad_impresion === 'oscura'
      ? [15, 23, 42]
      : [30, 41, 59];
  const pdfFont =
    invoiceConfig?.fuente === 'serif'
      ? 'times'
      : invoiceConfig?.fuente === 'mono'
      ? 'courier'
      : 'helvetica';

  const isSeniat = Boolean(tenantMeta?.seniatLegal?.activo);
  const facNum = String(sale.timestamp).slice(-8);
  const prefFac = tenantMeta?.seniatLegal?.prefijoFactura?.trim() || 'FAC-';
  const prefCtrl = tenantMeta?.seniatLegal?.prefijoControl?.trim() || '00-';
  const invoiceCode = sale.numero_factura || tenantMeta?.seniatLegal?.facturaNum || `${prefFac}${facNum}`;
  const controlNum = sale.numero_control || tenantMeta?.seniatLegal?.controlNum || `${prefCtrl}${facNum.padStart(8, '0')}`;
  const maquinaFiscal = tenantMeta?.seniatLegal?.maquinaFiscal?.trim() || '';

  // Header
  doc.setFillColor(...navy);
  doc.rect(0, 0, W, isSeniat ? 40 : 34, 'F');
  doc.setFillColor(...accent);
  doc.rect(0, isSeniat ? 40 : 34, W, 1.5, 'F');
  drawTenantLogoOrMark(doc, 14, 7, 20, invoiceConfig);

  if (isSeniat) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(125, 211, 252);
    doc.text('SENIAT · REPÚBLICA BOLIVARIANA DE VENEZUELA · FACTURA FISCAL LEGAL', 38, 10);
  }

  doc.setFont(pdfFont, 'bold');
  doc.setFontSize(16);
  doc.setTextColor(255, 255, 255);
  doc.text((localName || 'INNOVA GRUP').toUpperCase(), 38, isSeniat ? 17 : 15);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.8);
  doc.setTextColor(203, 213, 225);
  const fiscalParts = [
    isSeniat && tenantMeta?.razonSocial ? tenantMeta.razonSocial : '',
    (isSeniat || invoiceConfig?.mostrar_rif !== false) && tenantMeta?.rif ? `RIF: ${tenantMeta.rif}` : '',
    (isSeniat || invoiceConfig?.mostrar_telefono !== false) && tenantMeta?.telefono ? `Tel: ${tenantMeta.telefono}` : '',
  ].filter(Boolean);
  doc.text(
    fiscalParts.length > 0
      ? fiscalParts.join('  ·  ').slice(0, 92)
      : `Comprobante de Venta / Factura  |  Método: ${sale.metodo_pago}`,
    38,
    isSeniat ? 23.5 : 22
  );
  if ((isSeniat || invoiceConfig?.mostrar_direccion !== false) && tenantMeta?.direccion) {
    doc.setFontSize(8);
    doc.text(tenantMeta.direccion.slice(0, 88), 38, isSeniat ? 30 : 28);
  }
  if (isSeniat && maquinaFiscal) {
    doc.setFontSize(7.5);
    doc.setTextColor(186, 230, 253);
    doc.text(`Máquina Fiscal / Serie: ${maquinaFiscal}`, 38, 35.5);
  }

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(invoiceCode, W - 14, 14, { align: 'right' });
  if (isSeniat) {
    doc.setFontSize(8.5);
    doc.setTextColor(186, 230, 253);
    doc.text(`N° Control: ${controlNum}`, W - 14, 20.5, { align: 'right' });
  }
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`${sale.fecha} · ${sale.hora}`, W - 14, isSeniat ? 27 : 21, { align: 'right' });

  // Meta bar
  const hasCustomer = Boolean(sale.cliente_nombre || sale.cliente_cedula || isSeniat);
  const hasRef = Boolean(sale.referencia_pago);
  const metaStartY = isSeniat ? 46 : 40;
  const metaHeight = 16 + (hasCustomer ? 6 : 0) + (hasRef ? 6 : 0);
  doc.setFillColor(244, 246, 251);
  doc.roundedRect(14, metaStartY, W - 28, metaHeight, 2.5, 2.5, 'F');
  doc.setTextColor(...ink);
  doc.setFontSize(9);
  doc.text(`Cajero: ${sale.cajero_nombre || sale.usuario || 'Caja'}`, 18, metaStartY + 6.5);
  doc.text(`Tasa Oficial BCV: ${Number(sale.tasa_bcv_momento || 0).toFixed(2)} Bs`, 18, metaStartY + 12.5);
  doc.text(`Canal de Pago: ${sale.metodo_pago}`, W - 18, metaStartY + 6.5, { align: 'right' });
  doc.text(
    `IVA: ${sale.iva_aplicado ? `${sale.iva_porcentaje || 16}% aplicado` : 'Exento (E) / 0%'}`,
    W - 18,
    metaStartY + 12.5,
    { align: 'right' }
  );
  let nextMetaY = metaStartY + 18.5;
  if (hasRef) {
    doc.setFont('helvetica', 'bold');
    doc.text(`Ref. Pago Móvil: ${sale.referencia_pago}`, 18, nextMetaY);
    doc.setFont('helvetica', 'normal');
    nextMetaY += 6;
  }
  if (hasCustomer) {
    doc.setFont('helvetica', 'bold');
    doc.text(
      `Cliente: ${sale.cliente_nombre || 'Consumidor Final'}${
        sale.cliente_cedula ? `   ·   C.I./RIF: ${sale.cliente_cedula}` : isSeniat ? '   ·   C.I./RIF: N/A' : ''
      }`,
      18,
      nextMetaY
    );
    doc.setFont('helvetica', 'normal');
  }

  const items: SaleItem[] = Array.isArray(sale.items)
    ? sale.items
    : sale.items
    ? Object.values(sale.items as Record<string, SaleItem>)
    : [];

  autoTable(doc, {
    startY: metaStartY + metaHeight + 5,
    margin: { left: 14, right: 14 },
    theme: 'striped',
    head: [['Cant.', 'Artículo / Repuesto', 'Unit. Bs', 'Unit. USD', 'Subtotal Bs']],
    body: items.map((it) => {
      const q = Math.round((Number(it.cantidad) || 0) * 100) / 100;
      const unitBs = Number(it.precio_unitario_bs) || 0;
      const unitUsd = Number(it.precio_unitario_usd) || 0;
      return [
        String(q),
        String(it.id || 'Producto'),
        `${formatMoney(unitBs)} Bs`,
        `$${unitUsd.toFixed(2)}`,
        `${formatMoney(unitBs * q)} Bs`,
      ];
    }),
    headStyles: { fillColor: navy, textColor: [255, 255, 255], fontStyle: 'bold' },
    styles: { fontSize: 9.5, cellPadding: 2.5, textColor: ink },
    columnStyles: {
      0: { halign: 'center', cellWidth: 18 },
      2: { halign: 'right' },
      3: { halign: 'right' },
      4: { halign: 'right', fontStyle: 'bold' },
    },
  });

  const y = (doc.lastAutoTable?.finalY || 70) + 8;
  const boxW = 92;
  const boxX = W - 14 - boxW;
  const isCashea = sale.metodo_pago === 'Cashea' && sale.cashea_total_venta_ves !== undefined;
  const fullTotalBs = isCashea ? Number(sale.cashea_total_venta_ves) || 0 : Number(sale.monto_total_ves) || 0;
  const fullTotalUsd = isCashea
    ? Number(sale.cashea_total_venta_usd) || 0
    : Number(sale.monto_total_usd_bcv) || 0;
  const subtotalBs = Math.max(0, fullTotalBs - (Number(sale.monto_iva_ves) || 0));

  if (Array.isArray(sale.pagos_mixtos) && sale.pagos_mixtos.length > 0) {
    const splitBoxW = W - 28 - boxW - 6;
    const splitH = Math.max(24, 11 + sale.pagos_mixtos.length * 6);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(14, y, splitBoxW, splitH, 2.5, 2.5, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(...navy);
    doc.text('DESGLOSE PAGO FRACCIONADO', 18, y + 6.5);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(...ink);
    sale.pagos_mixtos.forEach((leg, idx) => {
      doc.text(
        `• ${leg.metodo}: ${formatMoney(leg.monto_ves)} Bs ($${Number(leg.monto_usd || 0).toFixed(2)})${
          leg.referencia ? ` [Ref: ${leg.referencia}]` : ''
        }`,
        18,
        y + 12.5 + idx * 5.5
      );
    });
  }

  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(boxX, y, boxW, isCashea ? 46 : 32, 2.5, 2.5, 'FD');

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...ink);
  doc.text('Subtotal:', boxX + 5, y + 7);
  doc.text(`${formatMoney(subtotalBs)} Bs`, boxX + boxW - 5, y + 7, { align: 'right' });

  doc.text(`IVA (${sale.iva_aplicado ? sale.iva_porcentaje || 16 : 0}%):`, boxX + 5, y + 13);
  doc.text(`${formatMoney(sale.monto_iva_ves || 0)} Bs`, boxX + boxW - 5, y + 13, { align: 'right' });

  if (isCashea) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(...navy);
    doc.text('TOTAL COMPRA:', boxX + 5, y + 20);
    doc.text(
      `${formatMoney(fullTotalBs)} Bs ($${fullTotalUsd.toFixed(2)})`,
      boxX + boxW - 5,
      y + 20,
      { align: 'right' }
    );

    doc.setTextColor(5, 150, 105);
    doc.text('INICIAL PAGADA (Cashea):', boxX + 5, y + 27);
    doc.text(
      `${formatMoney(sale.cashea_inicial_ves ?? sale.monto_total_ves)} Bs ($${Number(
        sale.cashea_inicial_usd ?? sale.monto_total_usd_bcv ?? 0
      ).toFixed(2)})`,
      boxX + boxW - 5,
      y + 27,
      { align: 'right' }
    );

    doc.setFontSize(9);
    doc.setTextColor(180, 83, 9);
    doc.text(`RESTANTE (${sale.cashea_cuotas || 3} cuotas):`, boxX + 5, y + 34);
    doc.text(
      `${formatMoney(sale.cashea_restante_ves || 0)} Bs ($${Number(sale.cashea_restante_usd || 0).toFixed(2)})`,
      boxX + boxW - 5,
      y + 34,
      { align: 'right' }
    );

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(
      `Cuota estimada: $${Number(sale.cashea_cuota_usd || 0).toFixed(2)} c/u${
        sale.cashea_nivel && sale.cashea_nivel !== 'Manual' ? ` · ${sale.cashea_nivel}` : ''
      }`,
      boxX + 5,
      y + 41
    );
  } else {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(...navy);
    doc.text('TOTAL VES:', boxX + 5, y + 21);
    doc.text(`${formatMoney(sale.monto_total_ves)} Bs`, boxX + boxW - 5, y + 21, { align: 'right' });

    doc.setFontSize(10);
    doc.setTextColor(5, 150, 105);
    doc.text('EQUIV. USD:', boxX + 5, y + 28);
    doc.text(`$${Number(sale.monto_total_usd_bcv || 0).toFixed(2)}`, boxX + boxW - 5, y + 28, {
      align: 'right',
    });
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  const footerBaseY = y + (isCashea ? 41 : 28);
  doc.text(
    invoiceConfig?.pie_pagina || 'Gracias por su preferencia · Emitido por Innova Grup POS',
    14,
    footerBaseY
  );
  if (isSeniat) {
    const prov =
      tenantMeta?.seniatLegal?.providencia?.trim() ||
      'Providencia Administrativa SNAT/2011/00071 · SENIAT Venezuela';
    const pieLegal =
      tenantMeta?.seniatLegal?.pieLegal?.trim() ||
      'Documento fiscal emitido conforme a las regulaciones vigentes del SENIAT · República Bolivariana de Venezuela';
    doc.setFillColor(240, 249, 255);
    doc.setDrawColor(186, 230, 253);
    doc.roundedRect(14, footerBaseY + 5, W - 28, 15, 2, 2, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(12, 74, 110);
    doc.text(`RESPALDO FISCAL SENIAT VENEZUELA · ${prov}`, 18, footerBaseY + 10.5);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(51, 65, 85);
    doc.text(pieLegal.slice(0, 130), 18, footerBaseY + 16);
  }

  doc.save(`Factura_${invoiceCode}.pdf`);
  return true;
}

export interface RateSignPdfOptions {
  localName: string;
  razonSocial?: string;
  rif?: string;
  direccion?: string;
  telefono?: string;
  tasaBcv: number;
  tasaSecundaria?: number;
  tasaTerciaria?: number;
  showParalelo?: boolean;
  nota?: string;
  theme?: 'clasico' | 'moderno' | 'minimal';
}

export function generateRateSignPDF(opts: RateSignPdfOptions): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const dark = opts.theme === 'moderno';
  const navy: [number, number, number] = [15, 23, 42];
  const accent: [number, number, number] = [2, 132, 199];

  if (dark) {
    doc.setFillColor(15, 23, 42);
    doc.rect(12, 14, W - 24, 260, 'F');
  } else {
    doc.setDrawColor(15, 23, 42);
    doc.setLineWidth(1.2);
    doc.roundedRect(12, 14, W - 24, 260, 6, 6, 'S');
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(26);
  doc.setTextColor(dark ? 255 : navy[0], dark ? 255 : navy[1], dark ? 255 : navy[2]);
  doc.text((opts.localName || 'MI COMERCIO').toUpperCase(), W / 2, 42, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(dark ? 203 : 71, dark ? 213 : 85, dark ? 225 : 105);
  let metaY = 52;
  if (opts.razonSocial) {
    doc.text(opts.razonSocial, W / 2, metaY, { align: 'center' });
    metaY += 6;
  }
  if (opts.rif) {
    doc.text(`RIF: ${opts.rif}`, W / 2, metaY, { align: 'center' });
    metaY += 6;
  }
  if (opts.direccion) {
    const dirLines = doc.splitTextToSize(opts.direccion, 150);
    doc.text(dirLines, W / 2, metaY, { align: 'center' });
    metaY += dirLines.length * 5.5;
  }
  if (opts.telefono) {
    doc.text(`Tel: ${opts.telefono}`, W / 2, metaY, { align: 'center' });
    metaY += 8;
  }

  const boxY = Math.max(metaY + 10, 92);
  doc.setFillColor(dark ? 30 : 240, dark ? 41 : 249, dark ? 59 : 255);
  doc.setDrawColor(...accent);
  doc.setLineWidth(0.8);
  doc.roundedRect(24, boxY, W - 48, 72, 5, 5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(...accent);
  doc.text('TASA OFICIAL BCV DEL DÍA', W / 2, boxY + 18, { align: 'center' });

  doc.setFontSize(46);
  doc.setTextColor(dark ? 255 : 12, dark ? 255 : 74, dark ? 255 : 110);
  doc.text(`${Number(opts.tasaBcv || 0).toFixed(2)} Bs`, W / 2, boxY + 46, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(12);
  doc.setTextColor(dark ? 203 : 51, dark ? 213 : 65, dark ? 225 : 85);
  doc.text(`1 USD ($) = ${Number(opts.tasaBcv || 0).toFixed(2)} Bolívares`, W / 2, boxY + 60, { align: 'center' });

  if (opts.showParalelo && ((opts.tasaSecundaria || 0) > 0 || (opts.tasaTerciaria || 0) > 0)) {
    const parY = boxY + 84;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    const items: string[] = [];
    if ((opts.tasaSecundaria || 0) > 0) items.push(`Referencia 1: ${Number(opts.tasaSecundaria).toFixed(2)} Bs`);
    if ((opts.tasaTerciaria || 0) > 0) items.push(`Referencia 2: ${Number(opts.tasaTerciaria).toFixed(2)} Bs`);
    doc.text(items.join('    |    '), W / 2, parY, { align: 'center' });
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10.5);
  doc.setTextColor(dark ? 148 : 100, dark ? 163 : 116, dark ? 184 : 139);
  doc.text(opts.nota || 'Precios calculados a la tasa oficial vigente.', W / 2, 245, { align: 'center' });
  doc.text(`Emitido: ${new Date().toLocaleString('es-VE')}`, W / 2, 254, { align: 'center' });

  const safe = (opts.localName || 'Local').replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_');
  doc.save(`Cartel_Tasa_BCV_${safe}.pdf`);
  return true;
}

export interface LabelPdfItem {
  nombre: string;
  barcode: string;
  categoria?: string;
  priceUsd: number;
  priceBs: number;
}

export interface LabelsPdfOptions {
  localName: string;
  format: 'gondola-50x30' | 'termica-58' | 'mini-40x20' | 'carta-grid';
  design: 'clasica' | 'dual' | 'compacta' | 'oferta';
  showStoreName: boolean;
  showCategory: boolean;
  showUsd: boolean;
  showBcvBs: boolean;
  showBarcode: boolean;
  labels: LabelPdfItem[];
}

function renderBarcodePngDataUrl(code: string): string | null {
  const clean = String(code || '').trim();
  if (!clean) return null;
  try {
    const canvas = document.createElement('canvas');
    JsBarcode(canvas, clean, {
      format: 'CODE128',
      displayValue: true,
      height: 28,
      width: 1.5,
      margin: 2,
      fontSize: 10,
      background: '#ffffff',
      lineColor: '#0f172a',
    });
    return canvas.toDataURL('image/png');
  } catch {
    return null;
  }
}

export function generateLabelsPDF(opts: LabelsPdfOptions): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const cols = opts.format === 'mini-40x20' ? 4 : opts.format === 'termica-58' ? 2 : 3;
  const cardW = opts.format === 'mini-40x20' ? 44 : opts.format === 'termica-58' ? 62 : 58;
  const cardH = opts.format === 'mini-40x20' ? 26 : 36;
  const gapX = 5;
  const gapY = 5;
  const marginX = (210 - (cols * cardW + (cols - 1) * gapX)) / 2;
  const marginY = 12;
  const rowsPerPage = Math.floor((297 - marginY * 2) / (cardH + gapY));

  let col = 0;
  let row = 0;

  opts.labels.forEach((lb, index) => {
    if (index > 0 && row >= rowsPerPage) {
      doc.addPage();
      row = 0;
      col = 0;
    }
    const x = marginX + col * (cardW + gapX);
    const y = marginY + row * (cardH + gapY);

    if (opts.design === 'oferta') {
      doc.setDrawColor(220, 38, 38);
      doc.setLineWidth(0.6);
    } else if (opts.design === 'dual') {
      doc.setDrawColor(2, 132, 199);
      doc.setLineWidth(0.45);
    } else {
      doc.setDrawColor(100, 116, 139);
      doc.setLineWidth(0.3);
    }
    doc.roundedRect(x, y, cardW, cardH, 1.5, 1.5, 'S');

    let cy = y + 4;
    if (opts.showStoreName) {
      if (opts.design === 'oferta' || opts.design === 'dual') {
        doc.setFillColor(opts.design === 'oferta' ? 220 : 15, opts.design === 'oferta' ? 38 : 23, opts.design === 'oferta' ? 38 : 42);
        doc.rect(x, y, cardW, 4.8, 'F');
        doc.setTextColor(255, 255, 255);
      } else {
        doc.setTextColor(71, 85, 105);
      }
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.text((opts.localName || 'TIENDA').slice(0, 26).toUpperCase(), x + cardW / 2, y + 3.4, { align: 'center' });
      cy = y + 8;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(opts.format === 'mini-40x20' ? 7 : 8.5);
    doc.setTextColor(15, 23, 42);
    const nameLines = doc.splitTextToSize(lb.nombre, cardW - 4).slice(0, 2);
    doc.text(nameLines, x + cardW / 2, cy, { align: 'center' });
    cy += nameLines.length * 3.5;

    if (opts.showCategory && lb.categoria) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.setTextColor(100, 116, 139);
      doc.text(lb.categoria.slice(0, 24), x + cardW / 2, cy, { align: 'center' });
      cy += 3;
    }

    const priceParts: string[] = [];
    if (opts.showUsd) priceParts.push(`$${lb.priceUsd.toFixed(2)}`);
    if (opts.showBcvBs) priceParts.push(`${formatMoney(lb.priceBs)} Bs`);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(opts.format === 'mini-40x20' ? 8.5 : 10.5);
    doc.setTextColor(12, 74, 110);
    doc.text(priceParts.join('  ·  '), x + cardW / 2, cy + 2.5, { align: 'center' });

    if (opts.showBarcode && lb.barcode) {
      const png = renderBarcodePngDataUrl(lb.barcode);
      if (png) {
        const imgH = opts.format === 'mini-40x20' ? 7.5 : 10.5;
        const imgW = cardW - 8;
        doc.addImage(png, 'PNG', x + 4, y + cardH - imgH - 1.2, imgW, imgH);
      }
    }

    col++;
    if (col >= cols) {
      col = 0;
      row++;
    }
  });

  doc.save(`Etiquetas_Precios_${Date.now()}.pdf`);
  return true;
}

export function generateSupplierPurchasePDF(purchase: SupplierPurchaseRecord, localName: string): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' }) as JsPDFWithAutoTable;
  const W = doc.internal.pageSize.getWidth();
  const navy: [number, number, number] = [12, 74, 110];

  doc.setFillColor(...navy);
  doc.rect(0, 0, W, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(`${localName || 'INNOVA GRUP'} · FACTURA DE COMPRA A PROVEEDOR`, 14, 14);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text(
    `Factura Nro: ${purchase.numero_factura}   |   Fecha: ${purchase.fecha}   |   Estado: ${purchase.estado_pago.toUpperCase()}`,
    14,
    22
  );

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(10);
  doc.text(`Proveedor: ${purchase.providerNombre}${purchase.providerRif ? ` (RIF: ${purchase.providerRif})` : ''}`, 14, 40);
  doc.text(`Método de Pago: ${purchase.metodo_pago || 'No especificado'}   |   Stock actualizado: ${purchase.actualizar_stock ? 'Sí' : 'No'}`, 14, 46);

  autoTable(doc, {
    startY: 54,
    head: [['Cant.', 'Artículo / Descripción', 'Costo Unit. USD', 'Subtotal USD']],
    body: purchase.items.map((it) => [
      String(it.cantidad),
      it.nombre,
      `$${Number(it.costo_unitario_usd).toFixed(2)}`,
      `$${Number(it.subtotal_usd).toFixed(2)}`,
    ]),
    headStyles: { fillColor: navy },
    columnStyles: { 0: { halign: 'center' }, 2: { halign: 'right' }, 3: { halign: 'right' } },
  });

  const y = (doc.lastAutoTable?.finalY || 70) + 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(`TOTAL FACTURA: $${Number(purchase.total_usd).toFixed(2)} USD  (${formatMoney(purchase.total_bs)} Bs)`, 14, y);
  if (purchase.nota) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Nota: ${purchase.nota}`, 14, y + 7);
  }
  doc.save(`Compra_Proveedor_${purchase.numero_factura}.pdf`);
  return true;
}

export interface MembershipRenewalReceiptParams {
  localName: string;
  rif?: string;
  email: string;
  planName: string;
  meses: number;
  bonusMeses?: number;
  usd: number;
  bs: number;
  tasa?: number;
  refNumber: string;
  prevDate: string;
  newDate: string;
  approvedBy: string;
  verificacionIa?: PagoMovilVerificationResult;
}

export function generateMembershipRenewalReceiptPDF(
  params: MembershipRenewalReceiptParams
): boolean {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const navy: [number, number, number] = [12, 74, 110];
  const emerald: [number, number, number] = [5, 150, 105];
  const ink: [number, number, number] = [30, 41, 59];
  const mute: [number, number, number] = [100, 116, 139];

  const folio = `COMP-MEM-${Date.now().toString().slice(-6)}`;
  const emitDate = new Date().toLocaleString('es-VE');

  // Header
  doc.setFillColor(...navy);
  doc.rect(0, 0, W, 34, 'F');
  doc.setFillColor(...emerald);
  doc.rect(0, 34, W, 1.8, 'F');
  drawInnovaMark(doc, 14, 7, 20);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14.5);
  doc.setTextColor(255, 255, 255);
  doc.text('COMPROBANTE OFICIAL DE RENOVACIÓN DE MEMBRESÍA', 38, 14);
  doc.setFontSize(9.5);
  doc.setTextColor(167, 243, 208);
  doc.text('PAGO MÓVIL VERIFICADO Y APROBADO · INNOVA GRUP POS', 38, 21);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`Folio: ${folio}   |   Emitido: ${emitDate}`, 38, 28);

  // Approved stamp badge
  doc.setFillColor(236, 253, 245);
  doc.setDrawColor(...emerald);
  doc.setLineWidth(0.6);
  doc.roundedRect(14, 42, W - 28, 16, 3, 3, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(6, 95, 70);
  doc.text('ESTADO DEL PAGO: APROBADO Y LICENCIA ACTIVADA', W / 2, 52, { align: 'center' });

  // Client Details Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 64, W - 28, 34, 3, 3, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(...navy);
  doc.text('1. DATOS DEL COMERCIO TITULAR', 18, 71);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(...ink);
  doc.text(`Local / Comercio: ${params.localName}`, 18, 79);
  doc.text(`RIF / Doc. Fiscal: ${params.rif || 'No especificado'}`, 18, 86);
  doc.text(`Correo Cuenta: ${params.email}`, 18, 93);

  // Plan & Payment Summary Box
  const totalMeses = (Number(params.meses) || 1) + (Number(params.bonusMeses) || 0);
  doc.setFillColor(240, 249, 255);
  doc.setDrawColor(186, 230, 253);
  doc.roundedRect(14, 104, W - 28, 56, 3, 3, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(...navy);
  doc.text('2. DETALLE DE PLAN Y PAGO MÓVIL APROBADO', 18, 111);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(...ink);
  doc.text(`Plan Contratado: ${params.planName}`, 18, 119);
  doc.text(
    `Vigencia Agregada: ${params.meses} mes(es)${
      params.bonusMeses ? ` + ${params.bonusMeses} mes(es) bono = ${totalMeses} mes(es)` : ''
    }`,
    18,
    126
  );
  doc.text(`Referencia Pago Móvil: ${params.refNumber || '-'}`, 18, 133);
  doc.text(`Vencimiento Anterior: ${params.prevDate}`, 18, 140);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...emerald);
  doc.text(`Nuevo Vencimiento Activo: ${params.newDate}`, 18, 148);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...ink);
  doc.text(`Monto USD: $${Number(params.usd || 0).toFixed(2)}`, W - 18, 119, { align: 'right' });
  doc.text(`Monto Bolívares: ${formatMoney(params.bs || 0)} Bs`, W - 18, 126, { align: 'right' });
  if (params.tasa) {
    doc.text(`Tasa Referencia: ${Number(params.tasa).toFixed(2)} Bs/$`, W - 18, 133, { align: 'right' });
  }
  doc.text(`Aprobado por: ${params.approvedBy}`, W - 18, 140, { align: 'right' });

  // AI Verification box if present
  let y = 170;
  if (params.verificacionIa) {
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(14, y, W - 28, 30, 3, 3, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(...navy);
    doc.text('3. REGISTRO DE VERIFICACIÓN AUTOMÁTICA DE COMPROBANTE', 18, y + 7);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(...ink);
    const v = params.verificacionIa;
    const summaryText = doc.splitTextToSize(
      `Resultado: ${v.es_comprobante_valido ? 'Validado' : 'Aprobado manualmente'} (${Math.round(
        v.confianza || 0
      )}%) · Ref detectada: ${v.referencia_detectada || params.refNumber} · Monto detectado: ${
        v.monto_detectado_bs ? `${formatMoney(v.monto_detectado_bs)} Bs` : 'N/D'
      } · Banco: ${v.banco_detectado || 'N/D'}. ${v.resumen || ''}`,
      W - 36
    );
    doc.text(summaryText, 18, y + 14);
    y += 38;
  }

  // Legal note
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(...mute);
  const note = doc.splitTextToSize(
    'Este documento certifica que el pago de renovación de membresía fue verificado y aprobado por la administración maestra de Innova Grup POS, acreditando de forma inmediata el periodo contratado en el nodo privado del comercio.',
    W - 28
  );
  doc.text(note, 14, y + 4);

  // Signatures
  const sigY = 248;
  doc.setDrawColor(148, 163, 184);
  doc.line(18, sigY, 92, sigY);
  doc.line(W - 92, sigY, W - 18, sigY);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...navy);
  doc.text('VALIDADO POR INNOVA GROUP', 55, sigY + 5, { align: 'center' });
  doc.text('COMERCIO BENEFICIARIO', W - 55, sigY + 5, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(...mute);
  doc.text(params.approvedBy, 55, sigY + 10, { align: 'center' });
  doc.text(params.localName, W - 55, sigY + 10, { align: 'center' });

  doc.setDrawColor(226, 232, 240);
  doc.line(14, H - 14, W - 14, H - 14);
  doc.text(`Folio ${folio} · Generado automáticamente el ${emitDate}`, 14, H - 8);
  doc.text('Innova Grup POS', W - 14, H - 8, { align: 'right' });

  const safeName = params.localName.replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_') || 'Cliente';
  doc.save(`Comprobante_Renovacion_${safeName}_${folio}.pdf`);
  return true;
}



