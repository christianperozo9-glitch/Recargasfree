import React, { useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { doc, writeBatch } from 'firebase/firestore';
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  Layers,
  Upload,
  X,
  AlertTriangle,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType, sanitizeFirestoreId, stripUndefined } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import { round2 } from '../utils/format';

interface BulkImportModalProps {
  open: boolean;
  onClose: () => void;
}

type FieldKey =
  | 'nombre'
  | 'barcode'
  | 'categoria'
  | 'price'
  | 'cost'
  | 'stock'
  | 'fraccionable'
  | 'iva';

interface ColumnMapping {
  nombre: string;
  barcode: string;
  categoria: string;
  price: string;
  cost: string;
  stock: string;
  fraccionable: string;
  iva: string;
}

const DEFAULT_MAPPING: ColumnMapping = {
  nombre: '',
  barcode: '',
  categoria: '',
  price: '',
  cost: '',
  stock: '',
  fraccionable: '',
  iva: '',
};

function normalizeHeader(h: string): string {
  return String(h || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');
}

function autoDetectMapping(headers: string[]): ColumnMapping {
  const map: ColumnMapping = { ...DEFAULT_MAPPING };
  const findCol = (patterns: RegExp[]) => {
    for (const p of patterns) {
      const hit = headers.find((h) => p.test(normalizeHeader(h)));
      if (hit) return hit;
    }
    return '';
  };

  map.nombre = findCol([
    /^nombre$/,
    /producto/,
    /descripcion/,
    /articulo/,
    /^item$/,
    /^title$/,
    /^name$/,
  ]);
  map.barcode = findCol([
    /barcode/,
    /codigobarra/,
    /^codigo$/,
    /^sku$/,
    /^ean$/,
    /^upc$/,
    /^ref/,
  ]);
  map.categoria = findCol([/categoria/, /rubro/, /linea/, /departamento/, /grupo/, /category/]);
  map.price = findCol([
    /preciousd/,
    /precioventa/,
    /^precio$/,
    /pvp/,
    /^price$/,
    /venta/,
    /monto/,
  ]);
  map.cost = findCol([/costousd/, /^costo$/, /^cost$/, /compra/]);
  map.stock = findCol([/^stock$/, /existencia/, /cantidad/, /inventario/, /^qty$/, /disponible/]);
  map.fraccionable = findCol([/fraccion/, /peso/, /granel/, /decimal/]);
  map.iva = findCol([/^iva/, /impuesto/, /tax/]);
  return map;
}

function parseNumberCell(val: unknown, fallback = 0): number {
  if (typeof val === 'number') return Number.isFinite(val) ? val : fallback;
  const raw = String(val ?? '')
    .trim()
    .replace(/[$BsUSD\s]/gi, '');
  if (!raw) return fallback;
  // Handle European comma decimal vs US dot decimal
  const normalized =
    raw.includes(',') && !raw.includes('.')
      ? raw.replace(',', '.')
      : raw.includes(',') && raw.includes('.')
      ? raw.replace(/,/g, '')
      : raw;
  const n = Number(normalized);
  return Number.isFinite(n) ? n : fallback;
}

function parseBoolCell(val: unknown): boolean {
  if (typeof val === 'boolean') return val;
  const s = String(val ?? '')
    .trim()
    .toLowerCase();
  return s === 'si' || s === 'sí' || s === 'true' || s === '1' || s === 'yes' || s === 'x';
}

export const BulkImportModal: React.FC<BulkImportModalProps> = ({ open, onClose }) => {
  const { activeTenantId, products, notifyToast, playBeep } = usePos();

  const [fileName, setFileName] = useState('');
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState('');
  const [rawRows, setRawRows] = useState<Record<string, unknown>[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ColumnMapping>(DEFAULT_MAPPING);
  const [duplicateMode, setDuplicateMode] = useState<'update' | 'skip'>('update');
  const [importing, setImporting] = useState(false);
  const [parseError, setParseError] = useState('');

  const loadSheetRows = (wb: XLSX.WorkBook, sheetName: string) => {
    const ws = wb.Sheets[sheetName];
    if (!ws) return;
    const jsonRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: '' });
    const detectedHeaders =
      jsonRows.length > 0 ? Object.keys(jsonRows[0]).filter((k) => !k.startsWith('__EMPTY')) : [];
    const fallbackHeaders =
      detectedHeaders.length > 0
        ? detectedHeaders
        : jsonRows.length > 0
        ? Object.keys(jsonRows[0])
        : [];
    setRawRows(jsonRows);
    setHeaders(fallbackHeaders);
    setMapping(autoDetectMapping(fallbackHeaders));
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setParseError('');
    setFileName(file.name);

    try {
      const lower = file.name.toLowerCase();
      if (lower.endsWith('.json')) {
        const text = await file.text();
        const parsed = JSON.parse(text);
        const list = Array.isArray(parsed)
          ? parsed
          : Array.isArray((parsed as { items?: unknown[] })?.items)
          ? (parsed as { items: Record<string, unknown>[] }).items
          : Object.values(parsed as Record<string, Record<string, unknown>>);
        const cleanRows = list.filter((r): r is Record<string, unknown> => Boolean(r && typeof r === 'object'));
        if (cleanRows.length === 0) {
          setParseError('El archivo JSON no contiene registros de productos válidos.');
          return;
        }
        const keys = Array.from(new Set(cleanRows.flatMap((r) => Object.keys(r))));
        setWorkbook(null);
        setSheetNames(['JSON']);
        setSelectedSheet('JSON');
        setRawRows(cleanRows);
        setHeaders(keys);
        setMapping(autoDetectMapping(keys));
        return;
      }

      if (lower.endsWith('.txt')) {
        const text = await file.text();
        const lines = text
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter(Boolean);
        if (lines.length === 0) {
          setParseError('El archivo de texto está vacío.');
          return;
        }
        const delimiter = lines[0].includes('\t')
          ? '\t'
          : lines[0].includes(';')
          ? ';'
          : lines[0].includes('|')
          ? '|'
          : ',';
        const wb = XLSX.read(lines.join('\n'), { type: 'string', FS: delimiter });
        setWorkbook(wb);
        setSheetNames(wb.SheetNames);
        const first = wb.SheetNames[0] || '';
        setSelectedSheet(first);
        loadSheetRows(wb, first);
        return;
      }

      // Excel (.xlsx, .xls, .ods) and .csv/.tsv
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      if (!wb.SheetNames.length) {
        setParseError('No se encontraron hojas legibles en el documento.');
        return;
      }
      setWorkbook(wb);
      setSheetNames(wb.SheetNames);
      const first = wb.SheetNames[0];
      setSelectedSheet(first);
      loadSheetRows(wb, first);
    } catch (err) {
      setParseError(
        `No se pudo leer el archivo: ${err instanceof Error ? err.message : 'formato incompatible'}`
      );
    }
  };

  const handleDownloadTemplate = () => {
    const sample = [
      {
        Nombre: 'Aceite Mineral 20W50 1L',
        Codigo: '759123400011',
        Categoria: 'Lubricantes',
        'Costo USD': 4.2,
        'Precio USD': 6.5,
        Stock: 24,
        Fraccionable: 'NO',
        IVA: 'NO',
      },
      {
        Nombre: 'Bujia Iridium Moto',
        Codigo: '759123400022',
        Categoria: 'Repuestos Motor',
        'Costo USD': 2.1,
        'Precio USD': 3.8,
        Stock: 40,
        Fraccionable: 'NO',
        IVA: 'SI',
      },
      {
        Nombre: 'Cable por Metro #12',
        Codigo: '759123400033',
        Categoria: 'Electricidad',
        'Costo USD': 0.65,
        'Precio USD': 1.25,
        Stock: 100,
        Fraccionable: 'SI',
        IVA: 'NO',
      },
    ];
    const ws = XLSX.utils.json_to_sheet(sample);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Productos');
    XLSX.writeFile(wb, 'Plantilla_Importacion_InnovaGrup.xlsx');
    notifyToast('Plantilla Excel descargada.', 'success');
  };

  const existingByBarcode = useMemo(() => {
    const m = new Map<string, typeof products[number]>();
    products.forEach((p) => {
      const bc = (p.barcode || '').trim().toLowerCase();
      if (bc) m.set(bc, p);
    });
    return m;
  }, [products]);

  const existingByName = useMemo(() => {
    const m = new Map<string, typeof products[number]>();
    products.forEach((p) => {
      m.set(p.id.trim().toLowerCase(), p);
    });
    return m;
  }, [products]);

  const parsedPreview = useMemo(() => {
    return rawRows.map((row, idx) => {
      const nombre = mapping.nombre ? String(row[mapping.nombre] ?? '').trim() : '';
      const barcode = mapping.barcode ? String(row[mapping.barcode] ?? '').trim() : '';
      const categoria = mapping.categoria ? String(row[mapping.categoria] ?? '').trim() : '';
      const price = mapping.price ? round2(parseNumberCell(row[mapping.price], 0)) : 0;
      const cost = mapping.cost ? round2(parseNumberCell(row[mapping.cost], 0)) : 0;
      const stock = mapping.stock ? round2(parseNumberCell(row[mapping.stock], 0)) : 0;
      const fraccionable = mapping.fraccionable ? parseBoolCell(row[mapping.fraccionable]) : false;
      const ivaIncluded = mapping.iva ? parseBoolCell(row[mapping.iva]) : false;

      const existingMatch =
        (barcode && existingByBarcode.get(barcode.toLowerCase())) ||
        (nombre && existingByName.get(nombre.toLowerCase())) ||
        undefined;

      const valid = Boolean(nombre && price > 0 && stock >= 0);
      const status: 'nuevo' | 'actualizar' | 'omitir' | 'invalido' = !valid
        ? 'invalido'
        : existingMatch
        ? duplicateMode === 'update'
          ? 'actualizar'
          : 'omitir'
        : 'nuevo';

      return {
        rowNum: idx + 1,
        nombre,
        barcode,
        categoria,
        price,
        cost,
        stock,
        fraccionable,
        ivaIncluded,
        existingKey: existingMatch?.key,
        status,
      };
    });
  }, [duplicateMode, existingByBarcode, existingByName, mapping, rawRows]);

  const stats = useMemo(() => {
    let nuevos = 0;
    let actualizar = 0;
    let omitir = 0;
    let invalidos = 0;
    parsedPreview.forEach((r) => {
      if (r.status === 'nuevo') nuevos++;
      else if (r.status === 'actualizar') actualizar++;
      else if (r.status === 'omitir') omitir++;
      else invalidos++;
    });
    return { nuevos, actualizar, omitir, invalidos };
  }, [parsedPreview]);

  const handleImport = async () => {
    if (!activeTenantId) {
      notifyToast('No hay un comercio activo para importar inventario.', 'error');
      return;
    }
    const actionable = parsedPreview.filter((r) => r.status === 'nuevo' || r.status === 'actualizar');
    if (actionable.length === 0) {
      notifyToast('No hay filas válidas listas para registrar.', 'warning');
      return;
    }

    setImporting(true);
    try {
      const now = Date.now();
      const CHUNK = 400;
      for (let i = 0; i < actionable.length; i += CHUNK) {
        const slice = actionable.slice(i, i + CHUNK);
        const batch = writeBatch(db);
        slice.forEach((item, localIdx) => {
          const docId =
            item.existingKey ||
            sanitizeFirestoreId(`${item.nombre}_${now}_${i + localIdx}`, 'prod');
          batch.set(
            doc(db, 'tenants', activeTenantId, 'products', docId),
            stripUndefined({
              nombre: item.nombre.slice(0, 180),
              barcode: item.barcode.slice(0, 80),
              categoria: item.categoria.slice(0, 80),
              precio: item.price,
              costo: item.cost,
              stock: item.stock,
              iva_incluido: item.ivaIncluded,
              iva_pct: item.ivaIncluded ? 16 : 0,
              fraccionable: item.fraccionable,
              updatedAt: now,
            }),
            { merge: true }
          );
        });
        await batch.commit();
      }
      playBeep('ok');
      notifyToast(
        `Importación completada: ${stats.nuevos} nuevo(s) y ${stats.actualizar} actualizado(s).`,
        'success'
      );
      onClose();
    } catch (err) {
      playBeep('err');
      handleFirestoreError(err, OperationType.WRITE, `tenants/${activeTenantId}/products`);
    } finally {
      setImporting(false);
    }
  };

  if (!open) return null;

  const mappingFields: Array<{ key: FieldKey; label: string; required?: boolean }> = [
    { key: 'nombre', label: 'Nombre del Producto *', required: true },
    { key: 'price', label: 'Precio Venta USD *', required: true },
    { key: 'stock', label: 'Stock / Existencia *', required: true },
    { key: 'barcode', label: 'Código / Barcode' },
    { key: 'categoria', label: 'Categoría' },
    { key: 'cost', label: 'Costo USD' },
    { key: 'fraccionable', label: 'Fraccionable (SI/NO)' },
    { key: 'iva', label: 'IVA Incluido (SI/NO)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between gap-3 px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900">
                Importación Masiva desde Excel y Documentos
              </h3>
              <p className="text-xs text-slate-500">
                Compatible con Excel (.xlsx, .xls, .ods), CSV, TSV, JSON y TXT delimitado
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4">
          {/* Upload + Template bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="md:col-span-2 flex items-center justify-center gap-3 p-4 rounded-2xl border-2 border-dashed border-sky-300 bg-sky-50/60 hover:bg-sky-50 cursor-pointer transition">
              <Upload className="w-5 h-5 text-sky-600 shrink-0" />
              <div className="text-left">
                <div className="text-sm font-extrabold text-slate-800">
                  {fileName ? `Archivo cargado: ${fileName}` : 'Seleccionar archivo Excel, CSV, TXT o JSON'}
                </div>
                <div className="text-xs text-slate-500">
                  Haz clic aquí para explorar tu equipo (.xlsx, .xls, .csv, .tsv, .ods, .txt, .json)
                </div>
              </div>
              <input
                type="file"
                accept=".xlsx,.xls,.csv,.tsv,.ods,.txt,.json"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>

            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-2xl bg-slate-900 text-white hover:bg-slate-800 transition text-center"
            >
              <Download className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-extrabold">Descargar Plantilla Excel</span>
              <span className="text-[11px] text-slate-300">Formato .xlsx listo para llenar</span>
            </button>
          </div>

          {parseError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-bold text-rose-700 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{parseError}</span>
            </div>
          )}

          {rawRows.length > 0 && (
            <>
              {/* Sheet selector + Duplicate mode */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div>
                  <label className="text-[11px] font-extrabold text-slate-500 uppercase flex items-center gap-1.5 mb-1">
                    <Layers className="w-3.5 h-3.5" /> Hoja / Origen de datos ({rawRows.length} filas)
                  </label>
                  <select
                    value={selectedSheet}
                    onChange={(e) => {
                      const next = e.target.value;
                      setSelectedSheet(next);
                      if (workbook) loadSheetRows(workbook, next);
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold"
                  >
                    {sheetNames.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-extrabold text-slate-500 uppercase flex items-center gap-1.5 mb-1">
                    <FileText className="w-3.5 h-3.5" /> Si el producto ya existe (por código o nombre)
                  </label>
                  <select
                    value={duplicateMode}
                    onChange={(e) => setDuplicateMode(e.target.value as 'update' | 'skip')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold"
                  >
                    <option value="update">Actualizar precio, costo, categoría y stock</option>
                    <option value="skip">Omitir existentes (solo registrar nuevos)</option>
                  </select>
                </div>
              </div>

              {/* Column mapping */}
              <div className="border border-slate-200 rounded-2xl p-4">
                <div className="text-xs font-extrabold text-slate-700 uppercase tracking-wider mb-3">
                  Mapeo de Columnas del Documento
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {mappingFields.map((f) => (
                    <div key={f.key}>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        {f.label}
                      </label>
                      <select
                        value={mapping[f.key]}
                        onChange={(e) => setMapping((prev) => ({ ...prev, [f.key]: e.target.value }))}
                        className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold"
                      >
                        <option value="">-- No asignar --</option>
                        {headers.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>

              {/* Summary metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                  <div className="text-[10px] font-extrabold uppercase text-emerald-700">Nuevos</div>
                  <div className="text-xl font-black font-mono tabular-nums text-emerald-900">
                    {stats.nuevos}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-sky-50 border border-sky-200">
                  <div className="text-[10px] font-extrabold uppercase text-sky-700">
                    A Actualizar
                  </div>
                  <div className="text-xl font-black font-mono tabular-nums text-sky-900">
                    {stats.actualizar}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] font-extrabold uppercase text-slate-500">
                    Omitidos
                  </div>
                  <div className="text-xl font-black font-mono tabular-nums text-slate-700">
                    {stats.omitir}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200">
                  <div className="text-[10px] font-extrabold uppercase text-rose-700">
                    Inválidos
                  </div>
                  <div className="text-xl font-black font-mono tabular-nums text-rose-900">
                    {stats.invalidos}
                  </div>
                </div>
              </div>

              {/* Preview Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden">
                <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 text-xs font-extrabold text-slate-600">
                  Vista previa (primeras {Math.min(100, parsedPreview.length)} filas de{' '}
                  {parsedPreview.length})
                </div>
                <div className="max-h-60 overflow-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 sticky top-0">
                      <tr className="text-left text-slate-500 border-b border-slate-200">
                        <th className="py-2 px-3">#</th>
                        <th className="py-2 px-3">Producto</th>
                        <th className="py-2 px-3">Código</th>
                        <th className="py-2 px-3">Categoría</th>
                        <th className="py-2 px-3 text-right">Costo</th>
                        <th className="py-2 px-3 text-right">Precio USD</th>
                        <th className="py-2 px-3 text-right">Stock</th>
                        <th className="py-2 px-3">Acción</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedPreview.slice(0, 100).map((r) => (
                        <tr key={r.rowNum} className="hover:bg-slate-50">
                          <td className="py-1.5 px-3 font-mono text-slate-400">{r.rowNum}</td>
                          <td className="py-1.5 px-3 font-bold text-slate-800">{r.nombre || '—'}</td>
                          <td className="py-1.5 px-3 font-mono text-slate-500">
                            {r.barcode || '—'}
                          </td>
                          <td className="py-1.5 px-3 text-slate-600">{r.categoria || '—'}</td>
                          <td className="py-1.5 px-3 text-right font-mono tabular-nums">
                            ${r.cost.toFixed(2)}
                          </td>
                          <td className="py-1.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                            ${r.price.toFixed(2)}
                          </td>
                          <td className="py-1.5 px-3 text-right font-mono tabular-nums">
                            {r.stock}
                          </td>
                          <td className="py-1.5 px-3 font-bold">
                            {r.status === 'nuevo' && (
                              <span className="text-emerald-700">Nuevo</span>
                            )}
                            {r.status === 'actualizar' && (
                              <span className="text-sky-700">Actualizar</span>
                            )}
                            {r.status === 'omitir' && (
                              <span className="text-slate-400">Omitir</span>
                            )}
                            {r.status === 'invalido' && (
                              <span className="text-rose-600">Inválido</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex flex-wrap items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700"
          >
            Cancelar
          </button>
          <button
            type="button"
            disabled={importing || stats.nuevos + stats.actualizar === 0}
            onClick={handleImport}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-extrabold whitespace-nowrap"
          >
            <CheckCircle2 className="w-4 h-4" />
            {importing
              ? 'Registrando en inventario...'
              : `Registrar ${stats.nuevos + stats.actualizar} Producto(s)`}
          </button>
        </div>
      </div>
    </div>
  );
};
