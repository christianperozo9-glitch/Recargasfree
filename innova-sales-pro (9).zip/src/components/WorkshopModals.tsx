import React, { useState } from 'react';
import { deleteDoc, doc, setDoc, writeBatch } from 'firebase/firestore';
import { Check, FileDown, Trash2, Wrench, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import type { TallerRepair } from '../types/pos';
import { formatDateVE, formatMoney, round2 } from '../utils/format';
import { generateTallerPDF } from '../utils/pdfGenerator';

interface MotorRepairModalProps {
  open: boolean;
  onClose: () => void;
}

export const MotorRepairModal: React.FC<MotorRepairModalProps> = ({ open, onClose }) => {
  const { activeTenantId, bcvRate, mechanics, notifyToast, playBeep } = usePos();
  const [mecanico, setMecanico] = useState(() => mechanics[0] || 'Otro');
  const [customMecanico, setCustomMecanico] = useState('');
  const [usd, setUsd] = useState('');
  const [metodo, setMetodo] = useState('Pago Móvil');
  const [descripcion, setDescripcion] = useState('Reparación de motor');
  const [saving, setSaving] = useState(false);

  React.useEffect(() => {
    if (!open) return;
    if (mecanico !== 'Otro' && !mechanics.includes(mecanico)) {
      setMecanico(mechanics[0] || 'Otro');
    }
  }, [mechanics, mecanico, open]);

  if (!open) return null;

  const usdVal = Number(usd) || 0;
  const bsVal = round2(usdVal * bcvRate);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId) {
      notifyToast('No hay comercio activo vinculado.', 'warning');
      return;
    }
    const finalMecanico = mecanico === 'Otro' ? customMecanico.trim() : mecanico;
    if (!finalMecanico || usdVal <= 0) {
      notifyToast('Indica el mecánico y un monto válido en USD.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const now = new Date();
      const ts = now.getTime();
      const payload: TallerRepair = {
        fecha: formatDateVE(now),
        hora: now.toLocaleTimeString('es-VE'),
        timestamp: ts,
        mecanico: finalMecanico,
        metodo_pago: metodo,
        usd: round2(usdVal),
        bs: bsVal,
        tasa: bcvRate,
        descripcion: descripcion.trim() || 'Reparación de motor',
      };
      const path = `tenants/${activeTenantId}/taller_pending/${ts}`;
      try {
        await setDoc(doc(db, 'tenants', activeTenantId, 'taller_pending', String(ts)), payload);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
      setUsd('');
      playBeep('ok');
      notifyToast(
        `Reparación de ${finalMecanico} ($${usdVal.toFixed(2)}) registrada en taller.`,
        'success'
      );
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const mechanicOptions = [...mechanics, 'Otro'];

  return (
    <div className="fixed inset-0 z-[155] bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4">
      <form
        onSubmit={handleSave}
        className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl"
      >
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wrench className="w-4 h-4 text-sky-600" />
            <h3 className="text-sm font-bold text-slate-900">Registrar Reparación de Motor</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-3.5 text-xs">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-semibold text-slate-700">Mecánico responsable</label>
              <span className="text-[10px] text-slate-400">Editable en Panel Admin</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {mechanicOptions.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMecanico(m)}
                  className={`py-2 px-2 rounded-xl border font-semibold truncate cursor-pointer ${
                    mecanico === m
                      ? 'bg-sky-600 border-sky-600 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                  title={m}
                >
                  {m}
                </button>
              ))}
            </div>
            {mecanico === 'Otro' && (
              <input
                type="text"
                value={customMecanico}
                onChange={(e) => setCustomMecanico(e.target.value)}
                placeholder="Nombre del mecánico"
                className="w-full mt-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Monto USD *</label>
              <input
                type="number"
                step="0.01"
                value={usd}
                onChange={(e) => setUsd(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Equivalente Bs</label>
              <div className="px-3 py-2 text-sm font-mono font-bold bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl">
                {formatMoney(bsVal)} Bs
              </div>
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Método de pago</label>
            <select
              value={metodo}
              onChange={(e) => setMetodo(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            >
              <option value="Pago Móvil">Pago Móvil</option>
              <option value="Efectivo Bs">Efectivo Bs</option>
              <option value="Efectivo Dolar">Efectivo Dólar</option>
              <option value="Débito">Débito</option>
              <option value="Biopago">Biopago</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Detalle del servicio</label>
            <input
              type="text"
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>
        </div>

        <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
          >
            {saving ? 'Guardando...' : 'Registrar Servicio'}
          </button>
        </div>
      </form>
    </div>
  );
};

interface TallerModalProps {
  open: boolean;
  onClose: () => void;
}

export const TallerModal: React.FC<TallerModalProps> = ({ open, onClose }) => {
  const { activeTenantId, tallerPendientes, localName, notifyToast, playBeep } = usePos();
  const [closing, setClosing] = useState(false);
  const [confirmCloseOpen, setConfirmCloseOpen] = useState(false);

  if (!open) return null;

  const totalUsd = tallerPendientes.reduce((s, r) => s + Number(r.usd || 0), 0);
  const totalBs = tallerPendientes.reduce((s, r) => s + Number(r.bs || 0), 0);

  const handleRemoveRepair = async (key: string) => {
    if (!activeTenantId) return;
    try {
      await deleteDoc(doc(db, 'tenants', activeTenantId, 'taller_pending', key));
      playBeep('tick');
      notifyToast('Servicio eliminado del taller.', 'info');
    } catch (err) {
      playBeep('err');
      notifyToast('No se pudo eliminar el registro de taller. Verifica permisos o conexión.', 'error');
      console.error('Taller delete error:', err);
    }
  };

  const handleCloseTaller = () => {
    if (!activeTenantId) return;
    if (tallerPendientes.length === 0) {
      notifyToast('No hay reparaciones pendientes en taller.', 'info');
      return;
    }
    setConfirmCloseOpen(true);
  };

  const executeCloseTaller = async () => {
    if (!activeTenantId) return;
    setConfirmCloseOpen(false);
    setClosing(true);
    try {
      generateTallerPDF(localName, tallerPendientes);
      const ts = Date.now();
      const map: Record<string, TallerRepair> = {};
      const batch = writeBatch(db);
      tallerPendientes.forEach((r, idx) => {
        const k = r.key || `${ts}_${idx}`;
        map[k] = r;
        if (r.key) {
          batch.delete(doc(db, 'tenants', activeTenantId, 'taller_pending', r.key));
        }
      });
      batch.set(doc(db, 'tenants', activeTenantId, 'taller_closures', String(ts)), {
        timestamp: ts,
        reparaciones: map,
      });
      await batch.commit();
      playBeep('ok');
      notifyToast('Cierre de taller completado y PDF descargado.', 'success');
      onClose();
    } catch (err) {
      playBeep('err');
      notifyToast('No se pudo archivar el cierre de taller en la nube. Intenta nuevamente.', 'error');
      console.error('Taller close error:', err);
    } finally {
      setClosing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[155] bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Control de Taller Mecánico</h3>
            <p className="text-xs text-slate-500">
              {tallerPendientes.length} servicio(s) activo(s) · Total ${totalUsd.toFixed(2)} (
              {formatMoney(totalBs)} Bs)
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {tallerPendientes.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No hay reparaciones activas en este turno.
            </div>
          ) : (
            tallerPendientes.map((r) => (
              <div
                key={r.key || r.timestamp}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <p className="font-bold text-slate-900">
                    {r.mecanico} · <span className="font-normal text-slate-600">{r.descripcion}</span>
                  </p>
                  <p className="text-[11px] font-mono text-slate-500">
                    {r.fecha} {r.hora} · {r.metodo_pago}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right font-mono">
                    <p className="font-bold text-emerald-700">${Number(r.usd).toFixed(2)}</p>
                    <p className="text-[11px] text-slate-500">{formatMoney(r.bs)} Bs</p>
                  </div>
                  {r.key && (
                    <button
                      type="button"
                      onClick={() => void handleRemoveRepair(r.key!)}
                      className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Cerrar
          </button>
          <button
            type="button"
            disabled={tallerPendientes.length === 0}
            onClick={() => generateTallerPDF(localName, tallerPendientes)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <FileDown className="w-3.5 h-3.5 text-rose-600" /> Solo PDF
          </button>
          <button
            type="button"
            disabled={closing || tallerPendientes.length === 0}
            onClick={handleCloseTaller}
            className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            {closing ? 'Cerrando...' : 'Cerrar Turno Taller y Archivar'}
          </button>
        </div>
      </div>

      {confirmCloseOpen && (
        <div className="fixed inset-0 z-[170] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <h4 className="font-bold text-sm text-slate-900">Confirmar Cierre de Taller</h4>
            <p className="text-xs text-slate-600">
              ¿Cerrar turno del taller, descargar el reporte PDF y archivar {tallerPendientes.length} reparación(es)?
            </p>
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setConfirmCloseOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => void executeCloseTaller()}
                className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
              >
                Sí, cerrar taller
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
