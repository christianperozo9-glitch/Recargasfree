import React, { useMemo, useState } from 'react';
import {
  Check,
  ClipboardPaste,
  Contrast,
  Image as ImageIcon,
  Palette,
  Printer,
  RotateCcw,
  Save,
  Trash2,
  Type,
  Upload,
  X,
} from 'lucide-react';
import type { SaleTransaction, TenantInvoiceConfig, TenantRecord } from '../types/pos';
import { compressImageFile } from '../utils/format';
import {
  buildThermalReceiptHtml,
  DEFAULT_TENANT_INVOICE_CONFIG,
  mergeInvoiceConfig,
  printBrowserReceiptHtml,
} from '../utils/thermalPrinter';

interface OwnerClientInvoiceModalProps {
  client: TenantRecord;
  bcvRate: number;
  onClose: () => void;
  onSave: (client: TenantRecord, nextConfig: TenantInvoiceConfig) => Promise<void>;
  onNotify: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

const PRINTER_PRESETS: Array<{
  label: string;
  nombre: string;
  ancho: '58mm' | '80mm';
  tipo: TenantInvoiceConfig['impresora_predeterminada'];
}> = [
  {
    label: 'Epson TM-T20III (80mm)',
    nombre: 'Epson TM-T20III 80mm',
    ancho: '80mm',
    tipo: 'navegador',
  },
  {
    label: 'Xprinter XP-58 (58mm)',
    nombre: 'Xprinter XP-58 USB 58mm',
    ancho: '58mm',
    tipo: 'usb',
  },
  {
    label: 'Xprinter XP-80C (80mm)',
    nombre: 'Xprinter XP-80C Térmica 80mm',
    ancho: '80mm',
    tipo: 'usb',
  },
  {
    label: 'Bixolon SRP-350 (Serial/USB)',
    nombre: 'Bixolon SRP-350III 80mm',
    ancho: '80mm',
    tipo: 'serial',
  },
  {
    label: 'Bluetooth / Navegador 58mm',
    nombre: 'Impresora Térmica Portátil 58mm',
    ancho: '58mm',
    tipo: 'navegador',
  },
];

export const OwnerClientInvoiceModal: React.FC<OwnerClientInvoiceModalProps> = ({
  client,
  bcvRate,
  onClose,
  onSave,
  onNotify,
}) => {
  const initialCfg = useMemo(() => {
    const merged = mergeInvoiceConfig(client.invoice_config);
    if (!merged.logo_data_url && client.logo_url) {
      merged.logo_data_url = client.logo_url;
    }
    return merged;
  }, [client]);

  const [draft, setDraft] = useState<TenantInvoiceConfig>(initialCfg);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [saving, setSaving] = useState(false);

  const sampleSale = useMemo<SaleTransaction>(() => {
    const rate = bcvRate > 0 ? bcvRate : 50;
    const totalUsd = 24.5;
    const totalBs = Number((totalUsd * rate).toFixed(2));
    const now = new Date();
    return {
      key: 'preview-001',
      numero_factura: 'FAC-000128',
      fecha: now.toLocaleDateString('es-VE'),
      hora: now.toLocaleTimeString('es-VE', { hour: '2-digit', minute: '2-digit' }),
      timestamp: now.getTime(),
      usuario: 'Cajero Principal',
      cajero_nombre: 'Cajero Principal',
      cliente_nombre: 'Carlos Pérez',
      cliente_cedula: 'V-18.456.789',
      items: [
        {
          key: 'p1',
          id: 'Aceite Sintético 20W50 1L',
          nombre: 'Aceite Sintético 20W50 1L',
          cantidad: 2,
          precio_unitario_usd: 8.5,
          precio_unitario_bs: Number((8.5 * rate).toFixed(2)),
          costo_unitario_usd: 5.5,
          tasa_label: 'BCV',
        },
        {
          key: 'p2',
          id: 'Filtro de Aceite Universal',
          nombre: 'Filtro de Aceite Universal',
          cantidad: 1,
          precio_unitario_usd: 7.5,
          precio_unitario_bs: Number((7.5 * rate).toFixed(2)),
          costo_unitario_usd: 4.0,
          tasa_label: 'BCV',
        },
      ],
      metodo_pago: 'Pago Móvil',
      referencia_pago: '48291035',
      monto_total_ves: totalBs,
      monto_total_usd_bcv: totalUsd,
      tasa_bcv_momento: rate,
      iva_aplicado: false,
    };
  }, [bcvRate]);

  const tenantMeta = useMemo(
    () => ({
      rif: client.rif || 'J-00000000-0',
      direccion: client.direccion_fiscal || 'Av. Principal, Local Comercial',
      telefono: client.telefono || '+58 412-0000000',
    }),
    [client]
  );

  const previewHtml = useMemo(
    () => buildThermalReceiptHtml(sampleSale, client.nombre_local, draft, tenantMeta),
    [sampleSale, client.nombre_local, draft, tenantMeta]
  );

  const processLogoBlob = async (file: File) => {
    setUploadingLogo(true);
    try {
      const dataUrl = await compressImageFile(file, 360, 0.85);
      setDraft((prev) => ({
        ...prev,
        logo_data_url: dataUrl,
        mostrar_logo: true,
      }));
      onNotify('Logotipo cargado y optimizado para impresión térmica y PDF.', 'success');
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'No se pudo procesar la imagen del logotipo.',
        'error'
      );
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleLogoFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processLogoBlob(file);
    e.target.value = '';
  };

  const handlePasteLogo = async (e: React.ClipboardEvent<HTMLDivElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          await processLogoBlob(file);
          return;
        }
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSave(client, draft);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[180] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4">
      <form
        onSubmit={handleSave}
        className="bg-white rounded-3xl border border-slate-200 max-w-5xl w-full max-h-[94vh] flex flex-col overflow-hidden shadow-2xl"
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-sky-50 via-white to-cyan-50 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-sky-100 border border-sky-200 text-sky-700 flex items-center justify-center shrink-0">
              <Printer className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
                Factura Térmica, Logotipo e Impresora · {client.nombre_local}
              </h3>
              <p className="text-xs text-slate-500 truncate">
                Personaliza tamaño de papel, modelo, tipografía, logotipo del local e impresora predeterminada para este cliente
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer shrink-0"
            aria-label="Cerrar configurador"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body: Left Controls + Right Live Thermal Preview */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          {/* Controls Column */}
          <div className="lg:col-span-7 p-4 sm:p-5 space-y-5 text-xs">
            {/* 1. Store Logo */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-sky-600" />
                  1. Logotipo del Local para Factura Térmica y PDF
                </h4>
                <label className="inline-flex items-center gap-1.5 font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={draft.mostrar_logo}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, mostrar_logo: e.target.checked }))
                    }
                    className="w-4 h-4 accent-sky-600"
                  />
                  Imprimir Logo
                </label>
              </div>

              <div
                onPaste={(e) => void handlePasteLogo(e)}
                tabIndex={0}
                className="flex flex-wrap items-center gap-3 p-2.5 rounded-xl bg-white border-2 border-dashed border-sky-200 focus:border-sky-500 focus:outline-none transition-colors"
              >
                {/* Small Thermal Printer Logo Preview Box */}
                <div
                  className="w-24 h-20 rounded-xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center overflow-hidden shrink-0 p-1.5 relative"
                  title="Recuadro de logotipo para impresora térmica (puedes pegar con Ctrl+V aquí)"
                >
                  {draft.logo_data_url ? (
                    <img
                      src={draft.logo_data_url}
                      alt={`Logo ${client.nombre_local}`}
                      className="max-w-full max-h-full object-contain"
                    />
                  ) : (
                    <div className="flex flex-col items-center text-slate-400 text-center">
                      <ClipboardPaste className="w-4 h-4 mb-0.5 text-sky-500" />
                      <span className="text-[9px] font-semibold leading-tight">
                        Pega logo (Ctrl+V)
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-[200px] space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <label className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      {uploadingLogo
                        ? 'Procesando...'
                        : draft.logo_data_url
                        ? 'Cambiar Logotipo'
                        : 'Subir Logotipo'}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleLogoFile}
                        disabled={uploadingLogo}
                        className="hidden"
                      />
                    </label>
                    {draft.logo_data_url && (
                      <button
                        type="button"
                        onClick={() =>
                          setDraft((prev) => ({ ...prev, logo_data_url: '' }))
                        }
                        className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Quitar Logo
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Haz clic en el recuadro y presiona <b>Ctrl+V</b> para pegar el logo del local directamente, o súbelo desde tu equipo. Se imprime en térmica ESC/POS y PDF.
                  </p>
                </div>
              </div>
            </div>

            {/* 2. Format, Paper Size, Model & Typography */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <Type className="w-4 h-4 text-sky-600" />
                2. Formato Térmico, Modelo y Escritura
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Ancho de Papel Térmico
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['58mm', '80mm'] as const).map((w) => (
                      <button
                        key={w}
                        type="button"
                        onClick={() => setDraft((prev) => ({ ...prev, ancho_papel: w }))}
                        className={`py-2 rounded-xl border font-bold cursor-pointer ${
                          draft.ancho_papel === w
                            ? 'bg-sky-600 border-sky-600 text-white'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {w === '58mm' ? '58 mm (Portátil)' : '80 mm (Estándar)'}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Modelo de Factura
                  </label>
                  <select
                    value={draft.modelo}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        modelo: e.target.value as TenantInvoiceConfig['modelo'],
                      }))
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                  >
                    <option value="clasico">Clásico (Líneas punteadas)</option>
                    <option value="moderno">Moderno (Encabezado limpio y badges)</option>
                    <option value="compacto">Compacto (Ahorro de papel)</option>
                    <option value="detallado">Detallado (Desglose completo + firma)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Tipo de Letra / Escritura
                  </label>
                  <select
                    value={draft.fuente}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        fuente: e.target.value as TenantInvoiceConfig['fuente'],
                      }))
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                  >
                    <option value="mono">Monoespaciada Térmica (Courier)</option>
                    <option value="sans">Sans-Serif Moderna (Clean)</option>
                    <option value="serif">Clásica Serif (Editorial)</option>
                    <option value="condensada">Condensada (Más caracteres/línea)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Tamaño de Letra
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(
                      [
                        { id: 'pequena', label: 'Pequeña' },
                        { id: 'normal', label: 'Normal' },
                        { id: 'grande', label: 'Grande' },
                      ] as const
                    ).map((sz) => (
                      <button
                        key={sz.id}
                        type="button"
                        onClick={() => setDraft((prev) => ({ ...prev, tamano_letra: sz.id }))}
                        className={`py-2 rounded-xl border font-semibold cursor-pointer ${
                          draft.tamano_letra === sz.id
                            ? 'bg-sky-600 border-sky-600 text-white'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {sz.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Invoice Color & Print Intensity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="font-semibold text-slate-700 flex items-center gap-1 mb-1">
                    <Palette className="w-3.5 h-3.5 text-sky-600" />
                    Color de Factura (Encabezado / PDF)
                  </label>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {[
                      { hex: '#0f172a', label: 'Negro Térmico' },
                      { hex: '#0369a1', label: 'Azul Corporativo' },
                      { hex: '#047857', label: 'Verde Esmeralda' },
                      { hex: '#b45309', label: 'Ámbar' },
                      { hex: '#6d28d9', label: 'Púrpura' },
                      { hex: '#be123c', label: 'Carmesí' },
                    ].map((sw) => (
                      <button
                        key={sw.hex}
                        type="button"
                        title={sw.label}
                        onClick={() => setDraft((prev) => ({ ...prev, color_factura: sw.hex }))}
                        className={`w-7 h-7 rounded-lg border-2 cursor-pointer transition-transform ${
                          (draft.color_factura || '#0f172a').toLowerCase() === sw.hex
                            ? 'border-sky-500 scale-110 ring-2 ring-sky-200'
                            : 'border-white shadow-xs'
                        }`}
                        style={{ backgroundColor: sw.hex }}
                      />
                    ))}
                    <label
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-white border border-slate-200 cursor-pointer text-[11px] font-mono text-slate-600"
                      title="Color personalizado"
                    >
                      <input
                        type="color"
                        value={draft.color_factura || '#0f172a'}
                        onChange={(e) =>
                          setDraft((prev) => ({ ...prev, color_factura: e.target.value }))
                        }
                        className="w-4 h-4 border-0 bg-transparent p-0 cursor-pointer"
                      />
                      <span>{draft.color_factura || '#0f172a'}</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 flex items-center gap-1 mb-1">
                    <Contrast className="w-3.5 h-3.5 text-slate-700" />
                    Intensidad de Impresión / Tinta
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {(
                      [
                        { id: 'suave', label: 'Suave' },
                        { id: 'normal', label: 'Normal' },
                        { id: 'oscura', label: 'Oscura' },
                        { id: 'extra_oscura', label: 'Extra' },
                      ] as const
                    ).map((lvl) => (
                      <button
                        key={lvl.id}
                        type="button"
                        onClick={() =>
                          setDraft((prev) => ({ ...prev, intensidad_impresion: lvl.id }))
                        }
                        className={`py-2 rounded-xl border text-[11px] font-bold cursor-pointer ${
                          (draft.intensidad_impresion || 'normal') === lvl.id
                            ? 'bg-slate-900 border-slate-900 text-white'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {lvl.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Texto Encabezado Extra (Opcional)
                  </label>
                  <input
                    type="text"
                    value={draft.encabezado_extra || ''}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, encabezado_extra: e.target.value }))
                    }
                    placeholder="Ej: Sucursal Centro · Instagram @milocal"
                    maxLength={140}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Mensaje de Pie de Factura
                  </label>
                  <input
                    type="text"
                    value={draft.pie_pagina || ''}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, pie_pagina: e.target.value }))
                    }
                    placeholder="¡Gracias por su compra! Sin cambio después de 48h."
                    maxLength={180}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-3 pt-1">
                {(
                  [
                    { key: 'mostrar_rif', label: 'Mostrar RIF' },
                    { key: 'mostrar_direccion', label: 'Mostrar Dirección' },
                    { key: 'mostrar_telefono', label: 'Mostrar Teléfono' },
                    { key: 'mostrar_tasa', label: 'Mostrar Tasa BCV' },
                    { key: 'mostrar_cajero', label: 'Mostrar Cajero' },
                  ] as const
                ).map(({ key, label }) => (
                  <label
                    key={key}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(draft[key])}
                      onChange={(e) =>
                        setDraft((prev) => ({ ...prev, [key]: e.target.checked }))
                      }
                      className="w-3.5 h-3.5 accent-sky-600"
                    />
                    <span className="font-medium text-slate-700">{label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* 3. Default Customizable Printer */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <Printer className="w-4 h-4 text-emerald-600" />
                3. Impresora Predeterminada Personalizable para {client.nombre_local}
              </h4>

              <div className="flex flex-wrap gap-1.5">
                {PRINTER_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() =>
                      setDraft((prev) => ({
                        ...prev,
                        impresora_nombre: preset.nombre,
                        ancho_papel: preset.ancho,
                        impresora_predeterminada: preset.tipo,
                      }))
                    }
                    className="px-2.5 py-1 rounded-lg bg-white hover:bg-sky-50 border border-slate-200 hover:border-sky-300 text-[11px] font-semibold text-slate-700 cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Modo de Conexión / Impresión Predeterminado
                  </label>
                  <select
                    value={draft.impresora_predeterminada}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        impresora_predeterminada: e.target
                          .value as TenantInvoiceConfig['impresora_predeterminada'],
                      }))
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                  >
                    <option value="navegador">
                      Impresora Térmica del Sistema / Navegador (Windows, Android, Bluetooth)
                    </option>
                    <option value="usb">Térmica Directa WebUSB (ESC/POS + Logo Raster)</option>
                    <option value="serial">Térmica Directa Puerto Serial COM (ESC/POS)</option>
                    <option value="pdf">Descargar Factura PDF Automática</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Nombre / Modelo de Impresora Asignada
                  </label>
                  <input
                    type="text"
                    value={draft.impresora_nombre || ''}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, impresora_nombre: e.target.value }))
                    }
                    placeholder="Ej: Epson TM-T20III Caja 1"
                    maxLength={80}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <label className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={draft.auto_imprimir}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, auto_imprimir: e.target.checked }))
                    }
                    className="w-3.5 h-3.5 accent-emerald-600"
                  />
                  <span className="font-medium text-slate-700">Auto-imprimir al cobrar</span>
                </label>
                <label className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={draft.corte_automatico}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, corte_automatico: e.target.checked }))
                    }
                    className="w-3.5 h-3.5 accent-emerald-600"
                  />
                  <span className="font-medium text-slate-700">Corte automático de papel</span>
                </label>
                <label className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={draft.abrir_gaveta}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, abrir_gaveta: e.target.checked }))
                    }
                    className="w-3.5 h-3.5 accent-emerald-600"
                  />
                  <span className="font-medium text-slate-700">Abrir gaveta de dinero</span>
                </label>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200">
                  <span className="font-medium text-slate-700">Copias:</span>
                  {([1, 2] as const).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setDraft((prev) => ({ ...prev, copias: c }))}
                      className={`px-2 py-0.5 rounded-md font-bold cursor-pointer ${
                        draft.copias === c
                          ? 'bg-sky-600 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Live Thermal Ticket Preview Column */}
          <div className="lg:col-span-5 p-4 sm:p-5 bg-slate-100/70 flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wide">
                  Vista Previa Térmica ({draft.ancho_papel})
                </h4>
                <p className="text-[11px] text-slate-500">
                  {draft.impresora_nombre || 'Impresora Térmica'} · {draft.modelo} · {draft.fuente}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  printBrowserReceiptHtml(sampleSale, client.nombre_local, draft, tenantMeta)
                }
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-sky-50 border border-slate-200 text-sky-700 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" /> Imprimir Prueba
              </button>
            </div>

            <div className="flex-1 flex items-start justify-center overflow-auto py-2">
              <div
                className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden transition-all"
                style={{
                  width: draft.ancho_papel === '58mm' ? '260px' : '340px',
                }}
              >
                <iframe
                  title="Vista previa factura térmica"
                  srcDoc={previewHtml}
                  className="w-full h-[520px] border-0 bg-white"
                  sandbox="allow-same-origin"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={() =>
              setDraft({
                ...DEFAULT_TENANT_INVOICE_CONFIG,
                logo_data_url: draft.logo_data_url,
              })
            }
            className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Restablecer Formato
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              {saving ? (
                'Guardando...'
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <Check className="w-3.5 h-3.5" /> Guardar Logo, Formato e Impresora
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
