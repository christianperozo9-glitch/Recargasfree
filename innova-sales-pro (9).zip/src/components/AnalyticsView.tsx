import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  Calendar,
  Download,
  Eye,
  FileDown,
  Package,
  Printer,
  Target,
  Trash2,
  TrendingUp,
  Wallet,
  X,
} from 'lucide-react';
import {
  Area,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { usePos } from '../context/PosContext';
import type { CierreProductoSummary, CierreRecord, SaleItem } from '../types/pos';
import { downloadCSV, formatMoney, round2 } from '../utils/format';
import { generateCierrePDF } from '../utils/pdfGenerator';

function toSafeArray<T>(val: unknown): T[] {
  if (Array.isArray(val)) return val as T[];
  if (val && typeof val === 'object') return Object.values(val as Record<string, T>);
  return [];
}

type DateRangeKey = 'today' | '7d' | '30d' | 'all';
type DailyCurrencyMode = 'usd' | 'ves';
type TopProductMetric = 'revUsd' | 'qty';

const METHOD_COLORS = [
  '#0284c7',
  '#059669',
  '#6366f1',
  '#d97706',
  '#0891b2',
  '#e11d48',
  '#475569',
  '#7c3aed',
];

const PRODUCT_BAR_COLORS = [
  '#0284c7',
  '#0369a1',
  '#0891b2',
  '#0d9488',
  '#059669',
  '#4f46e5',
  '#6366f1',
  '#64748b',
];

interface DailyPoint {
  dateKey: string;
  label: string;
  usd: number;
  ves: number;
  profitUsd: number;
  profitVes: number;
  txCount: number;
  ts: number;
}

interface TopProductPoint {
  name: string;
  shortName: string;
  qty: number;
  revUsd: number;
  revVes: number;
  profitUsd: number;
}

interface AnalyticsViewProps {
  compact?: boolean;
}

const truncateLabel = (label: string, maxLen = 22) => {
  const clean = label.trim();
  return clean.length > maxLen ? `${clean.slice(0, maxLen - 1)}…` : clean;
};

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ compact = false }) => {
  const {
    liveSales,
    savedCierres,
    products,
    fiados,
    tallerPendientes,
    bcvRate,
    config,
    localName,
    reprintSavedCierre,
    deleteSavedCierre,
  } = usePos();

  const [range, setRange] = useState<DateRangeKey>('30d');
  const [dailyCurrency, setDailyCurrency] = useState<DailyCurrencyMode>('usd');
  const [topMetric, setTopMetric] = useState<TopProductMetric>('revUsd');
  const [selectedCierre, setSelectedCierre] = useState<CierreRecord | null>(null);
  const [confirmDeleteCierre, setConfirmDeleteCierre] = useState<CierreRecord | null>(null);

  const rangeCutoff = useMemo(() => {
    const now = new Date();
    if (range === 'today') {
      return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    }
    if (range === '7d') return Date.now() - 7 * 86_400_000;
    if (range === '30d') return Date.now() - 30 * 86_400_000;
    return 0;
  }, [range]);

  const analytics = useMemo(() => {
    const prodCostMap = new Map<string, number>();
    products.forEach((p) => {
      prodCostMap.set(p.id.toLowerCase(), Number(p.cost) || 0);
    });

    let totalUsd = 0;
    let totalBs = 0;
    let totalProfitUsd = 0;
    let totalIvaBs = 0;
    let totalTxCount = 0;
    let pendingCasheaUsd = 0;

    const methodTotalsUsd: Record<string, number> = {};
    const productStats: Record<string, { name: string; qty: number; revUsd: number; profitUsd: number }> = {};
    const dailyTotals: Record<string, DailyPoint> = {};

    const addDailyPoint = (ts: number, usd: number, ves: number, profitUsd: number, txAdd: number) => {
      const d = new Date(ts || Date.now());
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
        d.getDate()
      ).padStart(2, '0')}`;
      const label = d.toLocaleDateString('es-VE', { day: '2-digit', month: 'short' });
      const dayTs = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
      if (!dailyTotals[key]) {
        dailyTotals[key] = {
          dateKey: key,
          label,
          usd: 0,
          ves: 0,
          profitUsd: 0,
          profitVes: 0,
          txCount: 0,
          ts: dayTs,
        };
      }
      dailyTotals[key].usd = round2(dailyTotals[key].usd + usd);
      dailyTotals[key].ves = round2(dailyTotals[key].ves + ves);
      dailyTotals[key].profitUsd = round2(dailyTotals[key].profitUsd + profitUsd);
      const effectiveRate = usd > 0 ? ves / usd : bcvRate || 1;
      dailyTotals[key].profitVes = round2(dailyTotals[key].profitVes + profitUsd * effectiveRate);
      dailyTotals[key].txCount += txAdd;
    };

    // Active shift sales
    liveSales.forEach((sale) => {
      const ts = Number(sale.timestamp) || Date.now();
      if (rangeCutoff > 0 && ts < rangeCutoff) return;

      const sUsd = Number(sale.monto_total_usd_bcv) || 0;
      const sBs = Number(sale.monto_total_ves) || 0;
      const rate = Number(sale.tasa_bcv_momento) || bcvRate || 1;
      let saleProfit = 0;

      totalUsd += sUsd;
      totalBs += sBs;
      totalIvaBs += Number(sale.monto_iva_ves) || 0;
      totalTxCount++;
      pendingCasheaUsd += Number(sale.cashea_restante_usd) || 0;

      const method = sale.metodo_pago || 'Otro';
      methodTotalsUsd[method] = (methodTotalsUsd[method] || 0) + sUsd;

      const items = toSafeArray<SaleItem>(sale.items);
      items.forEach((it) => {
        if (!it || typeof it !== 'object') return;
        const qty = Number(it.cantidad) || 0;
        const unitUsd = Number(it.precio_unitario_usd) || (Number(it.precio_unitario_bs) || 0) / rate;
        const unitCost =
          it.costo_unitario_usd !== undefined
            ? Number(it.costo_unitario_usd)
            : prodCostMap.get(String(it.id || '').toLowerCase()) || 0;
        const rev = unitUsd * qty;
        const profit = sale.mecanico ? rev : Math.max(0, (unitUsd - unitCost) * qty);
        saleProfit += profit;

        const pName = String(it.id || 'Producto');
        if (!productStats[pName]) {
          productStats[pName] = { name: pName, qty: 0, revUsd: 0, profitUsd: 0 };
        }
        productStats[pName].qty += qty;
        productStats[pName].revUsd += rev;
        productStats[pName].profitUsd += profit;
      });

      totalProfitUsd += saleProfit;
      addDailyPoint(ts, sUsd, sBs, saleProfit, 1);
    });

    // Historical saved closures
    const filteredCierres = savedCierres.filter((c) => (c.timestamp || 0) >= rangeCutoff);
    filteredCierres.forEach((c) => {
      const cUsd = Number(c.total_general_usd) || 0;
      const cBs = Number(c.total_general_ves) || 0;
      const cTx = Number(c.cantidad_ventas) || 0;
      totalUsd += cUsd;
      totalBs += cBs;
      totalIvaBs += Number(c.total_iva_ves) || 0;
      totalTxCount += cTx;
      pendingCasheaUsd += Number(c.cashea_pendiente_usd) || 0;

      const metodosUsd =
        c.totales_metodos_usd && typeof c.totales_metodos_usd === 'object' ? c.totales_metodos_usd : {};
      Object.entries(metodosUsd).forEach(([m, v]) => {
        methodTotalsUsd[m] = (methodTotalsUsd[m] || 0) + (Number(v) || 0);
      });

      let cierreProfit = 0;
      const cierreProds = toSafeArray<CierreProductoSummary>(c.productos_vendidos);
      cierreProds.forEach((p) => {
        if (!p || typeof p !== 'object') return;
        const pName = String(p.nombre || 'Producto');
        const qty = Number(p.cantidad) || 0;
        const revUsd = Number(p.total_usd) || 0;
        const unitCost = prodCostMap.get(pName.toLowerCase()) || 0;
        const estCost = unitCost * qty;
        const profit = unitCost > 0 ? Math.max(0, revUsd - estCost) : revUsd * 0.25;
        cierreProfit += profit;

        if (!productStats[pName]) {
          productStats[pName] = { name: pName, qty: 0, revUsd: 0, profitUsd: 0 };
        }
        productStats[pName].qty += qty;
        productStats[pName].revUsd += revUsd;
        productStats[pName].profitUsd += profit;
      });

      totalProfitUsd += cierreProfit;
      addDailyPoint(c.timestamp || Date.now(), cUsd, cBs, cierreProfit, cTx);
    });

    // Receivables total
    let pendingFiadosUsd = 0;
    Object.values(fiados).forEach((byTs) => {
      Object.values(byTs || {}).forEach((f) => {
        const items = toSafeArray<{ usd?: number; cant?: number }>(f.items);
        const tot = items.reduce((s, i) => s + Number(i.usd || 0) * Number(i.cant || 0), 0) * (Number(f.iva) || 1);
        const paid = Object.values(f.abonos || {}).reduce((s, a) => s + Number(a.usd || 0), 0);
        pendingFiadosUsd += Math.max(0, tot - paid);
      });
    });

    const workshopPendingUsd = tallerPendientes.reduce((s, t) => s + Number(t.usd || 0), 0);

    const chartPoints = Object.values(dailyTotals)
      .sort((a, b) => a.ts - b.ts)
      .slice(-14);

    const allProductsList: TopProductPoint[] = Object.values(productStats).map((p) => ({
      name: p.name,
      shortName: truncateLabel(p.name, 20),
      qty: round2(p.qty),
      revUsd: round2(p.revUsd),
      revVes: round2(p.revUsd * (bcvRate || 1)),
      profitUsd: round2(p.profitUsd),
    }));

    const topProducts = [...allProductsList]
      .sort((a, b) => b.revUsd - a.revUsd)
      .slice(0, 10);

    const topProductsByQty = [...allProductsList]
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 8);

    const methodsList = Object.entries(methodTotalsUsd)
      .map(([name, usd], idx) => ({
        name: name === 'Cashea' ? 'Cashea (Iniciales)' : name,
        rawName: name,
        usd: round2(usd),
        pct: totalUsd > 0 ? round2((usd / totalUsd) * 100) : 0,
        color: METHOD_COLORS[idx % METHOD_COLORS.length],
      }))
      .sort((a, b) => b.usd - a.usd);

    const avgTicketUsd = totalTxCount > 0 ? totalUsd / totalTxCount : 0;
    const marginPct = totalUsd > 0 ? (totalProfitUsd / totalUsd) * 100 : 0;

    return {
      totalUsd: round2(totalUsd),
      totalBs: round2(totalBs),
      totalProfitUsd: round2(totalProfitUsd),
      totalIvaBs: round2(totalIvaBs),
      totalTxCount,
      avgTicketUsd: round2(avgTicketUsd),
      marginPct: round2(marginPct),
      pendingFiadosUsd: round2(pendingFiadosUsd),
      pendingCasheaUsd: round2(pendingCasheaUsd),
      workshopPendingUsd: round2(workshopPendingUsd),
      chartPoints,
      topProducts,
      topProductsByQty,
      methodsList,
      filteredCierres,
    };
  }, [bcvRate, fiados, liveSales, products, rangeCutoff, savedCierres, tallerPendientes]);

  const goalUsd = Number(config.meta_usd) || 0;
  const goalPct = goalUsd > 0 ? Math.min(100, (analytics.totalUsd / goalUsd) * 100) : 0;

  const topChartData = useMemo(
    () => (topMetric === 'qty' ? analytics.topProductsByQty : analytics.topProducts.slice(0, 8)),
    [analytics.topProducts, analytics.topProductsByQty, topMetric]
  );

  const handleExportReportCSV = () => {
    downloadCSV(
      `Reporte_Ventas_${localName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`,
      ['Producto', 'Cantidad Vendida', 'Ingresos USD', 'Ganancia Est. USD'],
      analytics.topProducts.map((p) => [
        p.name,
        round2(p.qty),
        round2(p.revUsd),
        round2(p.profitUsd),
      ])
    );
  };

  return (
    <div className="space-y-5">
      {/* Header & Range Selector */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-sky-600" />
            Dashboard de Ventas y Analíticas
          </h3>
          <p className="text-xs text-slate-500">
            Consolidado en tiempo real de ventas diarias, productos más vendidos, márgenes y cierres
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            {(
              [
                { id: 'today', label: 'Hoy' },
                { id: '7d', label: '7 días' },
                { id: '30d', label: '30 días' },
                { id: 'all', label: 'Todo' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setRange(opt.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors whitespace-nowrap ${
                  range === opt.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleExportReportCSV}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" /> Exportar CSV
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs font-medium text-slate-500 block">Ingresos totales</span>
          <span className="text-xl font-mono tabular-nums font-bold text-slate-900 mt-1 block">
            ${analytics.totalUsd.toFixed(2)}
          </span>
          <span className="text-xs font-mono tabular-nums text-emerald-700 block">
            {formatMoney(analytics.totalBs)} Bs
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs font-medium text-slate-500 block">Ganancia neta est.</span>
          <span className="text-xl font-mono tabular-nums font-bold text-emerald-700 mt-1 block">
            ${analytics.totalProfitUsd.toFixed(2)}
          </span>
          <span className="text-xs font-mono tabular-nums text-slate-500 block">
            Margen bruto: {analytics.marginPct.toFixed(1)}%
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs font-medium text-slate-500 block">Ticket promedio</span>
          <span className="text-xl font-mono tabular-nums font-bold text-sky-700 mt-1 block">
            ${analytics.avgTicketUsd.toFixed(2)}
          </span>
          <span className="text-xs font-mono tabular-nums text-slate-500 block">
            {analytics.totalTxCount} transacciones
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs font-medium text-slate-500 block">Por cobrar (Fiados)</span>
          <span className="text-xl font-mono tabular-nums font-bold text-rose-600 mt-1 block">
            ${analytics.pendingFiadosUsd.toFixed(2)}
          </span>
          <span className="text-xs font-mono tabular-nums text-slate-500 block">
            Taller activo: ${analytics.workshopPendingUsd.toFixed(2)}
          </span>
          {analytics.pendingCasheaUsd > 0 && (
            <span className="text-[11px] font-mono tabular-nums font-semibold text-amber-700 block mt-0.5">
              Pendiente Cashea: ${analytics.pendingCasheaUsd.toFixed(2)}
            </span>
          )}
        </div>
      </div>

      {/* Goal Progress Bar */}
      {goalUsd > 0 && (
        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-800 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-sky-600" /> Meta de Ventas ({goalUsd.toFixed(2)} USD)
            </span>
            <span className="font-mono tabular-nums font-bold text-sky-700">{goalPct.toFixed(1)}%</span>
          </div>
          <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-sky-500 to-emerald-500 rounded-full transition-all"
              style={{ width: `${goalPct}%` }}
            />
          </div>
        </div>
      )}

      {/* Primary Visual Chart: Ventas Diarias (Recharts ComposedChart) */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-sky-600" />
              Ventas Diarias y Ganancia Estimada
            </h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {analytics.chartPoints.length > 0
                ? `Últimos ${analytics.chartPoints.length} días con actividad · Haz hover o toca una barra para ver el detalle`
                : 'Se actualizará automáticamente al registrar ventas en caja'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-3 text-[11px] text-slate-600">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-sky-600 inline-block" /> Ventas
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-emerald-600 inline-block" /> Ganancia est.
              </span>
            </div>
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg text-[11px]">
              <button
                type="button"
                onClick={() => setDailyCurrency('usd')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer transition-colors ${
                  dailyCurrency === 'usd'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                USD
              </button>
              <button
                type="button"
                onClick={() => setDailyCurrency('ves')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer transition-colors ${
                  dailyCurrency === 'ves'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Bs
              </button>
            </div>
          </div>
        </div>

        {analytics.chartPoints.length === 0 ? (
          <div className="h-60 flex flex-col items-center justify-center text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/50 p-4">
            <TrendingUp className="w-6 h-6 text-slate-300 mb-2" />
            <p className="font-semibold text-slate-600">Sin ventas registradas en este período</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Cambia el rango de fechas o registra una venta en el punto de venta para visualizar la curva diaria.
            </p>
          </div>
        ) : (
          <div className="w-full h-64 sm:h-72">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={analytics.chartPoints}
                margin={{ top: 10, right: 12, left: 0, bottom: 4 }}
              >
                <defs>
                  <linearGradient id="dailySalesAreaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.28} />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={false}
                  tickLine={false}
                  width={dailyCurrency === 'ves' ? 66 : 52}
                  tickFormatter={(v: number) =>
                    dailyCurrency === 'usd'
                      ? `$${v >= 1000 ? `${(v / 1000).toFixed(1)}k` : v}`
                      : v >= 1_000_000
                      ? `${(v / 1_000_000).toFixed(1)}M`
                      : v >= 1000
                      ? `${(v / 1000).toFixed(0)}k`
                      : `${v}`
                  }
                />
                <Tooltip
                  cursor={{ fill: 'rgba(2, 132, 199, 0.06)' }}
                  content={({ active, payload }) => {
                    if (!active || !payload || !payload.length) return null;
                    const pt = payload[0]?.payload as DailyPoint | undefined;
                    if (!pt) return null;
                    return (
                      <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-3 text-xs space-y-1 min-w-[180px]">
                        <div className="font-bold text-slate-900 border-b border-slate-100 pb-1 flex items-center justify-between gap-2">
                          <span>{pt.label}</span>
                          <span className="font-mono text-[11px] font-normal text-slate-500">
                            {pt.txCount} {pt.txCount === 1 ? 'venta' : 'ventas'}
                          </span>
                        </div>
                        <div className="flex justify-between gap-4 font-mono tabular-nums">
                          <span className="text-slate-600 font-sans">Ventas USD:</span>
                          <span className="font-bold text-sky-700">${pt.usd.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between gap-4 font-mono tabular-nums">
                          <span className="text-slate-600 font-sans">Ventas Bs:</span>
                          <span className="font-semibold text-slate-800">{formatMoney(pt.ves)} Bs</span>
                        </div>
                        <div className="flex justify-between gap-4 font-mono tabular-nums pt-1 border-t border-slate-100">
                          <span className="text-slate-600 font-sans">Ganancia est.:</span>
                          <span className="font-bold text-emerald-700">+${pt.profitUsd.toFixed(2)}</span>
                        </div>
                      </div>
                    );
                  }}
                />
                {analytics.chartPoints.length > 1 && (
                  <Area
                    type="monotone"
                    dataKey={dailyCurrency === 'usd' ? 'usd' : 'ves'}
                    stroke="#0284c7"
                    strokeWidth={2.2}
                    fill="url(#dailySalesAreaGrad)"
                    activeDot={{ r: 5, fill: '#0284c7', stroke: '#ffffff', strokeWidth: 2 }}
                  />
                )}
                <Bar
                  dataKey={dailyCurrency === 'usd' ? 'usd' : 'ves'}
                  fill="#0284c7"
                  fillOpacity={analytics.chartPoints.length === 1 ? 0.9 : 0.22}
                  radius={[6, 6, 0, 0]}
                  maxBarSize={36}
                />
                <Bar
                  dataKey={dailyCurrency === 'usd' ? 'profitUsd' : 'profitVes'}
                  fill="#059669"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={24}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Secondary Row: Top Selling Products (Recharts Horizontal BarChart) + Payment Methods Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Top Products Horizontal Bar Chart */}
        <div className="lg:col-span-7 bg-white p-4 sm:p-5 rounded-xl border border-slate-200 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Package className="w-4 h-4 text-sky-600" />
                Productos Más Vendidos
              </h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Top {topChartData.length} artículos por {topMetric === 'revUsd' ? 'ingresos generados (USD)' : 'unidades vendidas'}
              </p>
            </div>
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg text-[11px]">
              <button
                type="button"
                onClick={() => setTopMetric('revUsd')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer transition-colors whitespace-nowrap ${
                  topMetric === 'revUsd'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Ingresos ($)
              </button>
              <button
                type="button"
                onClick={() => setTopMetric('qty')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer transition-colors whitespace-nowrap ${
                  topMetric === 'qty'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Unidades
              </button>
            </div>
          </div>

          {topChartData.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/50 p-4">
              <Package className="w-6 h-6 text-slate-300 mb-2" />
              <p className="font-semibold text-slate-600">Sin productos vendidos en este rango</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Aquí aparecerá el ranking gráfico de tus productos con mayor salida.
              </p>
            </div>
          ) : (
            <div className="w-full h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={topChartData}
                  layout="vertical"
                  margin={{ top: 4, right: 20, left: 4, bottom: 4 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
                  <XAxis
                    type="number"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={{ stroke: '#e2e8f0' }}
                    tickLine={false}
                    tickFormatter={(v: number) => (topMetric === 'revUsd' ? `$${v}` : `${v}`)}
                  />
                  <YAxis
                    type="category"
                    dataKey="shortName"
                    width={132}
                    tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    cursor={{ fill: 'rgba(14, 165, 233, 0.06)' }}
                    content={({ active, payload }) => {
                      if (!active || !payload || !payload.length) return null;
                      const prod = payload[0]?.payload as TopProductPoint | undefined;
                      if (!prod) return null;
                      return (
                        <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-3 text-xs space-y-1 max-w-[240px]">
                          <p className="font-bold text-slate-900 leading-snug border-b border-slate-100 pb-1">
                            {prod.name}
                          </p>
                          <div className="flex justify-between gap-4 font-mono tabular-nums">
                            <span className="text-slate-600 font-sans">Unidades:</span>
                            <span className="font-bold text-slate-900">{prod.qty}</span>
                          </div>
                          <div className="flex justify-between gap-4 font-mono tabular-nums">
                            <span className="text-slate-600 font-sans">Ingresos USD:</span>
                            <span className="font-bold text-sky-700">${prod.revUsd.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between gap-4 font-mono tabular-nums">
                            <span className="text-slate-600 font-sans">Ganancia est.:</span>
                            <span className="font-bold text-emerald-700">+${prod.profitUsd.toFixed(2)}</span>
                          </div>
                        </div>
                      );
                    }}
                  />
                  <Bar
                    dataKey={topMetric}
                    radius={[0, 6, 6, 0]}
                    barSize={20}
                  >
                    {topChartData.map((entry, idx) => (
                      <Cell
                        key={entry.name}
                        fill={PRODUCT_BAR_COLORS[idx % PRODUCT_BAR_COLORS.length]}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Payment Methods Donut Chart */}
        <div className="lg:col-span-5 bg-white p-4 sm:p-5 rounded-xl border border-slate-200 flex flex-col justify-between space-y-3">
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Wallet className="w-4 h-4 text-emerald-600" />
              Distribución por Método de Pago
            </h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Participación porcentual en dólares equivalentes
            </p>
          </div>

          {analytics.methodsList.length === 0 ? (
            <div className="flex-1 min-h-[220px] flex flex-col items-center justify-center text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/50 p-4">
              <Wallet className="w-6 h-6 text-slate-300 mb-2" />
              <p className="font-semibold text-slate-600">Sin datos de pago</p>
            </div>
          ) : (
            <div className="flex flex-col gap-3 flex-1 justify-between">
              <div className="w-full h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={analytics.methodsList}
                      dataKey="usd"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={44}
                      outerRadius={72}
                      paddingAngle={2}
                      stroke="#ffffff"
                      strokeWidth={2}
                    >
                      {analytics.methodsList.map((m) => (
                        <Cell key={m.name} fill={m.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload || !payload.length) return null;
                        const item = payload[0]?.payload as { name: string; usd: number; pct: number } | undefined;
                        if (!item) return null;
                        return (
                          <div className="bg-white border border-slate-200 rounded-xl shadow-lg px-3 py-2 text-xs">
                            <p className="font-bold text-slate-900">{item.name}</p>
                            <p className="font-mono tabular-nums text-sky-700 font-bold mt-0.5">
                              ${item.usd.toFixed(2)} ({item.pct.toFixed(1)}%)
                            </p>
                          </div>
                        );
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="divide-y divide-slate-100 border-t border-slate-100 pt-1 max-h-40 overflow-y-auto">
                {analytics.methodsList.map((m) => (
                  <div key={m.name} className="py-1.5 flex items-center justify-between gap-2 text-xs">
                    <span className="flex items-center gap-2 min-w-0 text-slate-700 font-medium">
                      <span
                        className="w-2.5 h-2.5 rounded-xs shrink-0"
                        style={{ backgroundColor: m.color }}
                      />
                      <span className="truncate">{m.name}</span>
                    </span>
                    <span className="font-mono tabular-nums font-bold text-slate-900 shrink-0">
                      ${m.usd.toFixed(2)}{' '}
                      <span className="text-slate-500 font-normal">({m.pct.toFixed(0)}%)</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Top Products Detailed Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-800">Detalle de Productos con Mayor Desempeño</h4>
          <span className="text-[11px] font-mono tabular-nums text-slate-500">
            Top {analytics.topProducts.length}
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Producto</th>
                <th className="py-2.5 px-4 font-semibold text-right">Unidades</th>
                <th className="py-2.5 px-4 font-semibold text-right">Ingresos USD</th>
                <th className="py-2.5 px-4 font-semibold text-right">Ganancia Est.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {analytics.topProducts.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-400">
                    No hay ventas registradas en el período seleccionado.
                  </td>
                </tr>
              ) : (
                analytics.topProducts.map((p) => (
                  <tr key={p.name} className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-semibold text-slate-800">{p.name}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">{round2(p.qty)}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums font-bold text-slate-900">
                      ${p.revUsd.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums font-bold text-emerald-700">
                      +${p.profitUsd.toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Saved Closures History Table */}
      {!compact && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-sky-600" /> Historial de Cierres de Caja
            </h4>
            <span className="text-[11px] font-mono tabular-nums text-slate-500">
              {analytics.filteredCierres.length} cierres
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-4 font-semibold">Fecha y Hora</th>
                  <th className="py-2.5 px-4 font-semibold">Operador</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Ventas</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Total Bs</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Total USD</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {analytics.filteredCierres.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      Sin cierres en este período.
                    </td>
                  </tr>
                ) : (
                  analytics.filteredCierres.slice(0, 40).map((c) => (
                    <tr key={c.key || c.timestamp} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-mono tabular-nums text-slate-800">
                        {c.fecha} · {c.hora}
                      </td>
                      <td className="py-2.5 px-4 text-slate-700">{c.cerrado_por}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{c.cantidad_ventas}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-bold text-emerald-700">
                        {formatMoney(c.total_general_ves)} Bs
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-bold text-sky-700">
                        ${Number(c.total_general_usd).toFixed(2)}
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setSelectedCierre(c)}
                            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-700 cursor-pointer"
                            title="Ver detalle"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => void reprintSavedCierre(c, 'auto')}
                            className="p-1.5 rounded-lg hover:bg-sky-50 text-sky-600 cursor-pointer"
                            title="Reimprimir copia"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => generateCierrePDF(c, localName)}
                            className="p-1.5 rounded-lg hover:bg-emerald-50 text-emerald-600 cursor-pointer"
                            title="Descargar PDF"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                          </button>
                          {c.key && (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteCierre(c)}
                              className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                              title="Borrar cierre"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Cierre Detail Modal */}
      {selectedCierre && (
        <div className="fixed inset-0 z-[175] bg-slate-950/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[85vh] flex flex-col overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h4 className="font-bold text-sm text-slate-900">
                Detalle de Cierre · {selectedCierre.fecha} {selectedCierre.hora}
              </h4>
              <button
                type="button"
                onClick={() => setSelectedCierre(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-3 font-mono text-xs">
              <p>
                <b>Cerrado por:</b> {selectedCierre.cerrado_por}
              </p>
              <p>
                <b>Transacciones:</b> {selectedCierre.cantidad_ventas}
              </p>
              <div className="border-t border-slate-200 pt-2 space-y-1">
                <p className="font-bold text-slate-600">Métodos de Pago:</p>
                {Object.entries(selectedCierre.totales_metodos_ves || {}).map(([m, bs]) => (
                  <div key={m} className="flex justify-between">
                    <span>{m === 'Cashea' ? 'Cashea (Inicial aprobada)' : m}</span>
                    <span>
                      {formatMoney(bs)} Bs (${(selectedCierre.totales_metodos_usd?.[m] || 0).toFixed(2)})
                    </span>
                  </div>
                ))}
              </div>
              {(selectedCierre.cashea_pendiente_usd || 0) > 0 && (
                <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 space-y-1">
                  <div className="flex justify-between font-bold">
                    <span>Inicial Cashea aprobada:</span>
                    <span>
                      ${Number(selectedCierre.cashea_inicial_total_usd || 0).toFixed(2)} (
                      {formatMoney(selectedCierre.cashea_inicial_total_ves || 0)} Bs)
                    </span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Pendiente Cashea (No sumado al cierre):</span>
                    <span>
                      ${Number(selectedCierre.cashea_pendiente_usd || 0).toFixed(2)} (
                      {formatMoney(selectedCierre.cashea_pendiente_ves || 0)} Bs)
                    </span>
                  </div>
                </div>
              )}
              {toSafeArray<CierreProductoSummary>(selectedCierre.productos_vendidos).length > 0 && (
                <div className="border-t border-slate-200 pt-2 space-y-1">
                  <p className="font-bold text-slate-600">Productos Vendidos:</p>
                  {toSafeArray<CierreProductoSummary>(selectedCierre.productos_vendidos).map((p, idx) => (
                    <div key={`${p.nombre}_${idx}`} className="flex justify-between">
                      <span>
                        {p.nombre} × {p.cantidad}
                      </span>
                      <span>{formatMoney(p.total_ves)} Bs</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="border-t border-slate-200 pt-2 font-bold text-sm flex justify-between">
                <span>TOTAL VES:</span>
                <span className="text-emerald-700">{formatMoney(selectedCierre.total_general_ves)} Bs</span>
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => void reprintSavedCierre(selectedCierre, 'auto')}
                className="flex-1 py-2 px-3 rounded-xl bg-sky-600 text-white text-xs font-semibold cursor-pointer inline-flex items-center justify-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" /> Reimprimir Copia
              </button>
              <button
                type="button"
                onClick={() => generateCierrePDF(selectedCierre, localName)}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-600 text-white text-xs font-semibold cursor-pointer"
              >
                Descargar PDF
              </button>
              <button
                type="button"
                onClick={() => setSelectedCierre(null)}
                className="py-2 px-4 rounded-xl border border-slate-200 bg-white text-xs font-semibold cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Closure Confirmation Modal */}
      {confirmDeleteCierre && (
        <div className="fixed inset-0 z-[185] bg-slate-950/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <h4 className="font-extrabold text-sm text-slate-900">Eliminar Cierre Guardado</h4>
            <p className="text-xs text-slate-600">
              ¿Eliminar permanentemente el cierre del{' '}
              <b>
                {confirmDeleteCierre.fecha} · {confirmDeleteCierre.hora}
              </b>{' '}
              por {formatMoney(confirmDeleteCierre.total_general_ves)} Bs?
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteCierre(null)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const key = confirmDeleteCierre.key;
                  setConfirmDeleteCierre(null);
                  if (key) void deleteSavedCierre(key);
                }}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold cursor-pointer"
              >
                Borrar Cierre
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
