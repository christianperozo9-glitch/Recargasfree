import React, { useMemo, useState } from 'react';
import { deleteDoc, doc, setDoc, updateDoc } from 'firebase/firestore';
import {
  Building2,
  CheckCircle2,
  Edit3,
  FileDown,
  KeyRound,
  Lock,
  Mail,
  PauseCircle,
  PlayCircle,
  Plus,
  Receipt,
  Shield,
  Sliders,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  createPinCredentials,
  db,
  handleFirestoreError,
  hashPin,
  OperationType,
  sanitizeFirestoreId,
  sendPasswordRecoveryEmail,
} from '../lib/firebase';
import {
  createCashierRecord,
  DEFAULT_CASHIER_PERMISSIONS,
  removeCashierRecord,
  usePos,
} from '../context/PosContext';
import type {
  CashierPermissions,
  CashierRecord,
  ProviderRecord,
  SupplierPurchaseItem,
} from '../types/pos';
import { formatMoney, round2 } from '../utils/format';
import { generateSupplierPurchasePDF } from '../utils/pdfGenerator';

const CASHIER_PERMISSION_ITEMS: Array<{
  key: keyof CashierPermissions;
  label: string;
  hint: string;
}> = [
  { key: 'aplicar_rebajas', label: 'Aplicar rebajas / descuentos', hint: 'Descuento por producto o venta' },
  { key: 'fiados', label: 'Fiados / Cuentas por cobrar', hint: 'Abrir panel de créditos y abonos' },
  { key: 'motor', label: 'Módulo Motor / Mecánicos', hint: 'Asignar mecánicos y ver motor' },
  { key: 'taller', label: 'Módulo Taller', hint: 'Registrar reparaciones y cierres taller' },
  { key: 'editar_tasas', label: 'Editar tasas de cambio', hint: 'Modificar tasas BCV / Paralelo' },
  { key: 'cerrar_caja', label: 'Botón Cerrar Turno', hint: 'Requiere clave o PIN Admin para confirmar' },
  { key: 'anular_factura', label: 'Anular Facturas', hint: 'Requiere clave o PIN Admin para autorizar' },
  { key: 'herramientas', label: 'Herramientas y Extras', hint: 'Presupuesto, calculadora, música, periféricos' },
];

const normalizeCashierPerms = (p?: CashierPermissions): Required<CashierPermissions> => ({
  aplicar_rebajas: p?.aplicar_rebajas === true,
  fiados: p?.fiados === true,
  motor: p?.motor === true,
  taller: p?.taller === true,
  editar_tasas: p?.editar_tasas === true,
  cerrar_caja: p?.cerrar_caja === true,
  anular_factura: p?.anular_factura === true,
  herramientas: p?.herramientas === true,
});

interface UserManagementTabProps {
  isOwnerView?: boolean;
}

export const UserManagementTab: React.FC<UserManagementTabProps> = ({ isOwnerView = false }) => {
  const {
    activeTenantId,
    activeTenant,
    authUser,
    cashiers,
    systemUsers,
    providers,
    supplierPurchases,
    products,
    bcvRate,
    localName,
    operatorEmail,
    isMobileLayout,
    notifyToast,
    playBeep,
    saveProvider,
    deleteProvider,
    registerSupplierPurchase,
    updateSupplierPurchaseStatus,
    deleteSupplierPurchase,
    updateTenantRecord,
  } = usePos();

  const [sectionTab, setSectionTab] = useState<'users' | 'suppliers'>('users');

  // New Cashier form state (strictly POS-only by default; Admin enables extra modules)
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState(activeTenant?.email || authUser?.email || operatorEmail || '');
  const [telefono, setTelefono] = useState('');
  const [turno, setTurno] = useState('Mañana');
  const [pin, setPin] = useState('');
  const [newPerms, setNewPerms] = useState<Required<CashierPermissions>>({
    ...DEFAULT_CASHIER_PERMISSIONS,
  });
  const [creating, setCreating] = useState(false);

  // Full Edit Cashier Modal (Credentials, PIN & Granular Permissions)
  const [editCashier, setEditCashier] = useState<CashierRecord | null>(null);
  const [editNombre, setEditNombre] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editTelefono, setEditTelefono] = useState('');
  const [editTurno, setEditTurno] = useState('Mañana');
  const [editPinVal, setEditPinVal] = useState('');
  const [editPerms, setEditPerms] = useState<Required<CashierPermissions>>({
    ...DEFAULT_CASHIER_PERMISSIONS,
  });
  const [savingCashierEdit, setSavingCashierEdit] = useState(false);

  // Tenant Access Credentials Editor (Admin PIN & Default Caja PIN)
  const [tenantAdminPin, setTenantAdminPin] = useState('');
  const [tenantCajaPin, setTenantCajaPin] = useState('');
  const [savingTenantCreds, setSavingTenantCreds] = useState(false);

  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    message: string;
    onConfirm: () => Promise<void>;
  } | null>(null);

  // New System User Registration (metadata directory)
  const [sysName, setSysName] = useState('');
  const [sysEmail, setSysEmail] = useState('');
  const [sysRole] = useState<'admin'>('admin');

  // Suppliers state
  const [editingProvKey, setEditingProvKey] = useState<string | null>(null);
  const [provNombre, setProvNombre] = useState('');
  const [provRif, setProvRif] = useState('');
  const [provContacto, setProvContacto] = useState('');
  const [provTel, setProvTel] = useState('');
  const [provEmail, setProvEmail] = useState('');
  const [provCat, setProvCat] = useState('');
  const [provDir, setProvDir] = useState('');
  const [provNota, setProvNota] = useState('');
  const [savingProv, setSavingProv] = useState(false);

  // Supplier Purchase Invoice state
  const [invNumber, setInvNumber] = useState('');
  const [invProviderId, setInvProviderId] = useState('');
  const [invDate, setInvDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [invStatus, setInvStatus] = useState<'pagada' | 'pendiente'>('pagada');
  const [invMethod, setInvMethod] = useState('Transferencia / Divisas');
  const [invUpdateStock, setInvUpdateStock] = useState(true);
  const [invNota, setInvNota] = useState('');
  const [invItems, setInvItems] = useState<SupplierPurchaseItem[]>([]);
  const [lineProductKey, setLineProductKey] = useState('');
  const [lineCustomName, setLineCustomName] = useState('');
  const [lineQty, setLineQty] = useState('1');
  const [lineCostUsd, setLineCostUsd] = useState('');
  const [savingInv, setSavingInv] = useState(false);

  const handleCreateCashier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId) {
      notifyToast('Selecciona primero un nodo de cliente para registrar cajeros.', 'warning');
      return;
    }
    const targetEmail = (email || activeTenant?.email || authUser?.email || '').trim().toLowerCase();
    if (!nombre.trim()) {
      notifyToast('Escribe el nombre completo del cajero.', 'warning');
      return;
    }
    if (!targetEmail || !targetEmail.includes('@')) {
      notifyToast('Ingresa el correo del comercio con el que ingresará el cajero.', 'warning');
      return;
    }
    if (!/^\d{4,8}$/.test(pin)) {
      notifyToast('El PIN debe tener entre 4 y 8 dígitos numéricos.', 'warning');
      return;
    }

    setCreating(true);
    try {
      for (const c of cashiers) {
        if ((c.email || '').toLowerCase() === targetEmail) {
          const h = await hashPin(c.salt, pin);
          if (h === c.hash) {
            notifyToast('Ese PIN ya está asignado a otro cajero de este correo.', 'warning');
            playBeep('err');
            setCreating(false);
            return;
          }
        }
      }

      await createCashierRecord(activeTenantId, {
        nombre,
        email: targetEmail,
        pin,
        telefono,
        turno,
        permisos: { ...newPerms },
      });
      setNombre('');
      setTelefono('');
      setPin('');
      setNewPerms({ ...DEFAULT_CASHIER_PERMISSIONS });
      playBeep('ok');
      notifyToast(`Cajero "${nombre}" registrado correctamente.`, 'success');
    } catch (err) {
      playBeep('err');
      notifyToast(
        'Error al registrar cajero: ' + (err instanceof Error ? err.message : 'desconocido'),
        'error'
      );
    } finally {
      setCreating(false);
    }
  };

  const openEditCashierModal = (c: CashierRecord) => {
    setEditCashier(c);
    setEditNombre(c.nombre || '');
    setEditEmail(c.email || activeTenant?.email || authUser?.email || '');
    setEditTelefono(c.telefono || '');
    setEditTurno(c.turno || 'Mañana');
    setEditPinVal('');
    setEditPerms(normalizeCashierPerms(c.permisos));
  };

  const submitCashierEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId || !editCashier) return;

    const cleanNombre = editNombre.trim();
    const cleanEmail = (editEmail || activeTenant?.email || authUser?.email || '')
      .trim()
      .toLowerCase();
    const cleanPin = editPinVal.trim();

    if (!cleanNombre) {
      notifyToast('El nombre del cajero es obligatorio.', 'warning');
      return;
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      notifyToast('Ingresa un correo electrónico válido para el cajero.', 'warning');
      return;
    }
    if (cleanPin && !/^\d{4,8}$/.test(cleanPin)) {
      notifyToast('El nuevo PIN debe tener entre 4 y 8 dígitos numéricos.', 'warning');
      return;
    }

    setSavingCashierEdit(true);
    try {
      if (cleanPin) {
        for (const other of cashiers) {
          if (other.key !== editCashier.key && (other.email || '').toLowerCase() === cleanEmail) {
            const h = await hashPin(other.salt, cleanPin);
            if (h === other.hash) {
              notifyToast('Ese PIN ya está asignado a otro cajero de este correo.', 'warning');
              playBeep('err');
              setSavingCashierEdit(false);
              return;
            }
          }
        }
      }

      const payload: Record<string, unknown> = {
        nombre: cleanNombre,
        email: cleanEmail,
        telefono: editTelefono.trim(),
        turno: editTurno || 'Mañana',
        activo: editCashier.activo !== false,
        permisos: { ...editPerms },
      };

      if (cleanPin) {
        const creds = await createPinCredentials(cleanPin);
        payload.salt = creds.salt;
        payload.hash = creds.hash;
      }

      await updateDoc(doc(db, 'tenants', activeTenantId, 'cashiers', editCashier.key), payload);
      playBeep('ok');
      notifyToast(
        cleanPin
          ? `Credenciales, PIN y permisos actualizados para ${cleanNombre}.`
          : `Datos y permisos actualizados para ${cleanNombre}.`,
        'success'
      );
      setEditCashier(null);
      setEditPinVal('');
    } catch (err) {
      playBeep('err');
      notifyToast(
        'Error al actualizar cajero: ' + (err instanceof Error ? err.message : 'verifica permisos'),
        'error'
      );
    } finally {
      setSavingCashierEdit(false);
    }
  };

  const handleSaveTenantCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId) return;
    const cleanAdminPin = tenantAdminPin.trim();
    const cleanCajaPin = tenantCajaPin.trim();
    if (!cleanAdminPin && !cleanCajaPin) {
      notifyToast('Ingresa al menos un nuevo PIN Administrativo o PIN de Caja.', 'warning');
      return;
    }
    if (cleanAdminPin && !/^\d{4,12}$/.test(cleanAdminPin)) {
      notifyToast('El PIN Administrativo debe tener entre 4 y 12 dígitos numéricos.', 'warning');
      return;
    }
    if (cleanCajaPin && !/^\d{4,12}$/.test(cleanCajaPin)) {
      notifyToast('El PIN de Caja debe tener entre 4 y 12 dígitos numéricos.', 'warning');
      return;
    }
    setSavingTenantCreds(true);
    try {
      const patch: Record<string, unknown> = {};
      if (cleanAdminPin) {
        const c = await createPinCredentials(cleanAdminPin);
        patch.admin_pin_salt = c.salt;
        patch.admin_pin_hash = c.hash;
      }
      if (cleanCajaPin) {
        const c = await createPinCredentials(cleanCajaPin);
        patch.caja_pin_salt = c.salt;
        patch.caja_pin_hash = c.hash;
      }
      await updateTenantRecord(activeTenantId, patch);
      setTenantAdminPin('');
      setTenantCajaPin('');
      playBeep('ok');
      notifyToast('Credenciales de acceso (PIN) actualizadas correctamente.', 'success');
    } catch (err) {
      playBeep('err');
      notifyToast(
        'No se pudieron actualizar las credenciales: ' +
          (err instanceof Error ? err.message : 'error'),
        'error'
      );
    } finally {
      setSavingTenantCreds(false);
    }
  };

  const handleToggleCashier = async (key: string, currentActive: boolean) => {
    if (!activeTenantId) return;
    const path = `tenants/${activeTenantId}/cashiers/${key}`;
    try {
      await updateDoc(doc(db, 'tenants', activeTenantId, 'cashiers', key), {
        activo: !currentActive,
      });
      notifyToast(currentActive ? 'Cajero pausado.' : 'Cajero activado.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const handleDeleteCashier = (key: string, cName: string) => {
    if (!activeTenantId) return;
    setConfirmModal({
      title: 'Eliminar Cajero',
      message: `¿Eliminar permanentemente al cajero "${cName}"?`,
      onConfirm: async () => {
        await removeCashierRecord(activeTenantId, key);
        notifyToast('Cajero eliminado.', 'info');
      },
    });
  };

  const handleRegisterSystemUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId) {
      notifyToast('Selecciona primero un nodo de cliente.', 'warning');
      return;
    }
    const cleanEmail = sysEmail.trim().toLowerCase();
    if (!sysName.trim() || !cleanEmail.includes('@')) {
      notifyToast('Ingresa nombre y correo electrónico válido.', 'warning');
      return;
    }
    const safeKey = sanitizeFirestoreId(cleanEmail, 'usr');
    const path = `tenants/${activeTenantId}/users/${safeKey}`;
    try {
      await setDoc(
        doc(db, 'tenants', activeTenantId, 'users', safeKey),
        {
          nombre: sysName.trim(),
          email: cleanEmail,
          rol: sysRole,
          activo: true,
          creado: Date.now(),
        },
        { merge: true }
      );
      setSysName('');
      setSysEmail('');
      playBeep('ok');
      notifyToast(`Usuario ${cleanEmail} registrado en el directorio.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const handleToggleSystemUser = async (key: string, currentActive: boolean) => {
    if (!activeTenantId) return;
    const path = `tenants/${activeTenantId}/users/${key}`;
    try {
      await updateDoc(doc(db, 'tenants', activeTenantId, 'users', key), {
        activo: !currentActive,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const handleDeleteSystemUser = (key: string, targetEmail: string) => {
    if (!activeTenantId) return;
    setConfirmModal({
      title: 'Remover Usuario del Directorio',
      message: `¿Remover a ${targetEmail} del directorio administrativo?`,
      onConfirm: async () => {
        const path = `tenants/${activeTenantId}/users/${key}`;
        try {
          await deleteDoc(doc(db, 'tenants', activeTenantId, 'users', key));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, path);
        }
      },
    });
  };

  const handleResetPasswordForUser = async (targetEmail: string) => {
    try {
      await sendPasswordRecoveryEmail(targetEmail);
      playBeep('ok');
      notifyToast(`Correo de restablecimiento enviado a ${targetEmail}`, 'success');
    } catch (err) {
      notifyToast(
        'No se pudo enviar recuperación: ' + (err instanceof Error ? err.message : 'error'),
        'error'
      );
    }
  };

  // === Suppliers Handlers ===
  const resetProviderForm = () => {
    setEditingProvKey(null);
    setProvNombre('');
    setProvRif('');
    setProvContacto('');
    setProvTel('');
    setProvEmail('');
    setProvCat('');
    setProvDir('');
    setProvNota('');
  };

  const startEditProvider = (p: ProviderRecord) => {
    setEditingProvKey(p.key);
    setProvNombre(p.nombre);
    setProvRif(p.rif || '');
    setProvContacto(p.contacto || '');
    setProvTel(p.telefono || '');
    setProvEmail(p.email || '');
    setProvCat(p.categoria || '');
    setProvDir(p.direccion || '');
    setProvNota(p.nota || '');
  };

  const handleSaveProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!provNombre.trim()) {
      notifyToast('Ingresa el nombre o razón social del proveedor.', 'warning');
      return;
    }
    setSavingProv(true);
    try {
      await saveProvider(
        {
          nombre: provNombre,
          rif: provRif,
          contacto: provContacto,
          telefono: provTel,
          email: provEmail,
          categoria: provCat,
          direccion: provDir,
          nota: provNota,
          activo: true,
        },
        editingProvKey || undefined
      );
      resetProviderForm();
    } finally {
      setSavingProv(false);
    }
  };

  const handleAddPurchaseLine = () => {
    const qty = round2(Number(lineQty) || 0);
    const costUsd = round2(Number(lineCostUsd) || 0);
    const chosenProd = lineProductKey ? products.find((p) => p.key === lineProductKey) : undefined;
    const itemName = chosenProd ? chosenProd.id : lineCustomName.trim();
    if (!itemName) {
      notifyToast('Selecciona un producto o escribe la descripción del renglón.', 'warning');
      return;
    }
    if (qty <= 0 || costUsd < 0) {
      notifyToast('Ingresa una cantidad mayor a 0 y costo válido.', 'warning');
      return;
    }
    setInvItems((prev) => [
      ...prev,
      {
        productKey: chosenProd?.key,
        nombre: itemName,
        barcode: chosenProd?.barcode || '',
        cantidad: qty,
        costo_unitario_usd: costUsd,
        subtotal_usd: round2(qty * costUsd),
      },
    ]);
    setLineProductKey('');
    setLineCustomName('');
    setLineQty('1');
    setLineCostUsd('');
  };

  const invTotalUsd = useMemo(
    () => round2(invItems.reduce((acc, it) => acc + it.subtotal_usd, 0)),
    [invItems]
  );

  const handleSavePurchaseInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    const prov = providers.find((p) => p.key === invProviderId);
    if (!prov) {
      notifyToast('Selecciona un proveedor registrado.', 'warning');
      return;
    }
    if (!invNumber.trim()) {
      notifyToast('Ingresa el número de factura o nota de entrega.', 'warning');
      return;
    }
    if (invItems.length === 0) {
      notifyToast('Agrega al menos un artículo a la factura de compra.', 'warning');
      return;
    }
    setSavingInv(true);
    try {
      await registerSupplierPurchase({
        numero_factura: invNumber,
        providerId: prov.key,
        providerNombre: prov.nombre,
        providerRif: prov.rif,
        fecha: invDate,
        items: invItems,
        estado_pago: invStatus,
        metodo_pago: invMethod,
        actualizar_stock: invUpdateStock,
        nota: invNota,
      });
      setInvNumber('');
      setInvNota('');
      setInvItems([]);
    } finally {
      setSavingInv(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation between Users/Cashiers and Suppliers/Purchases */}
      <div className="flex flex-wrap items-center gap-2 bg-white rounded-2xl border border-slate-200 p-2">
        <button
          type="button"
          onClick={() => setSectionTab('users')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition ${
            sectionTab === 'users'
              ? 'bg-sky-600 text-white shadow'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          Cajeros y Usuarios ({cashiers.length})
        </button>
        <button
          type="button"
          onClick={() => setSectionTab('suppliers')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition ${
            sectionTab === 'suppliers'
              ? 'bg-sky-600 text-white shadow'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          Proveedores y Compras / Facturas ({providers.length} · {supplierPurchases.length})
        </button>
      </div>

      {sectionTab === 'users' ? (
        <>
          {/* Register New Cashier Card */}
          <form
            onSubmit={handleCreateCashier}
            className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-sky-600" />
                  Registrar Nuevo Cajero
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Los cajeros acceden con el correo del comercio y su PIN personal en el portal de inicio.
                </p>
              </div>
              <span className="text-xs font-mono font-semibold text-slate-500">
                {cashiers.length} cajero(s)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <input
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Nombre del cajero *"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Correo de acceso *"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <input
                type="tel"
                value={telefono}
                onChange={(e) => setTelefono(e.target.value)}
                placeholder="Teléfono (opcional)"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <select
                value={turno}
                onChange={(e) => setTurno(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              >
                <option value="Mañana">Turno Mañana</option>
                <option value="Tarde">Turno Tarde</option>
                <option value="Completo">Turno Completo</option>
              </select>
              <input
                type="password"
                inputMode="numeric"
                maxLength={8}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                placeholder="PIN (4-8 dígitos) *"
                className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div className="space-y-3 pt-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-[11px] font-bold text-slate-600 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-sky-600" />
                  Permisos del Cajero (Por defecto: Solo POS de Ventas — activa lo que desees otorgar):
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setNewPerms({ ...DEFAULT_CASHIER_PERMISSIONS })}
                    className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    Solo POS Ventas
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    type="button"
                    onClick={() =>
                      setNewPerms({
                        aplicar_rebajas: true,
                        fiados: true,
                        motor: true,
                        taller: true,
                        editar_tasas: true,
                        cerrar_caja: true,
                        anular_factura: true,
                        herramientas: true,
                      })
                    }
                    className="text-[11px] font-semibold text-sky-700 hover:underline cursor-pointer"
                  >
                    Marcar todos
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                {CASHIER_PERMISSION_ITEMS.map((perm) => (
                  <label
                    key={perm.key}
                    className={`flex items-start gap-2 p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                      newPerms[perm.key]
                        ? 'bg-sky-50 border-sky-300 text-sky-950'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={newPerms[perm.key]}
                      onChange={(e) =>
                        setNewPerms((prev) => ({ ...prev, [perm.key]: e.target.checked }))
                      }
                      className="rounded border-slate-300 mt-0.5"
                    />
                    <span className="leading-tight">
                      <span className="font-semibold block">{perm.label}</span>
                      <span className="text-[10px] text-slate-500">{perm.hint}</span>
                    </span>
                  </label>
                ))}
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={creating}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  {creating ? 'Registrando...' : 'Guardar Cajero'}
                </button>
              </div>
            </div>
          </form>

          {/* Cashiers List */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <Users className="w-4 h-4 text-sky-600" /> Cajeros Registrados y Permisos
              </h4>
            </div>

            {isMobileLayout ? (
              <div className="divide-y divide-slate-100">
                {cashiers.length === 0 ? (
                  <p className="py-8 text-center text-xs text-slate-400">
                    Aún no hay cajeros registrados en el sistema.
                  </p>
                ) : (
                  cashiers.map((c) => {
                    const active = c.activo !== false;
                    const p = normalizeCashierPerms(c.permisos);
                    const activePermCount = Object.values(p).filter(Boolean).length;
                    return (
                      <div key={c.key} className="p-4 space-y-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-sm font-bold text-slate-900 truncate">{c.nombre}</p>
                            <p className="text-xs font-mono text-slate-500 truncate">{c.email}</p>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              Turno {c.turno || 'General'} ·{' '}
                              <span
                                className={
                                  active
                                    ? 'text-emerald-700 font-semibold'
                                    : 'text-rose-600 font-semibold'
                                }
                              >
                                {active ? 'Activo' : 'Pausado'}
                              </span>
                              {' · '}
                              <span className="font-semibold text-sky-700">
                                {activePermCount === 0
                                  ? 'Solo POS Ventas'
                                  : `POS + ${activePermCount} permiso(s)`}
                              </span>
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => openEditCashierModal(c)}
                            className="flex-1 min-h-[40px] rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <KeyRound className="w-3.5 h-3.5" /> Editar PIN y Permisos
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleToggleCashier(c.key, active)}
                            className="min-h-[40px] min-w-[40px] rounded-xl border border-slate-200 hover:bg-slate-50 flex items-center justify-center cursor-pointer"
                            title={active ? 'Pausar cajero' : 'Activar cajero'}
                          >
                            {active ? (
                              <PauseCircle className="w-4 h-4 text-amber-600" />
                            ) : (
                              <PlayCircle className="w-4 h-4 text-emerald-600" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteCashier(c.key, c.nombre)}
                            className="min-h-[40px] min-w-[40px] rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center cursor-pointer"
                            title="Eliminar cajero"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Nombre</th>
                      <th className="py-2.5 px-4 font-semibold">Correo acceso</th>
                      <th className="py-2.5 px-4 font-semibold">Turno</th>
                      <th className="py-2.5 px-4 font-semibold">Permisos activos</th>
                      <th className="py-2.5 px-4 font-semibold">Estado</th>
                      <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {cashiers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-400">
                          Aún no hay cajeros registrados en el sistema.
                        </td>
                      </tr>
                    ) : (
                      cashiers.map((c) => {
                        const active = c.activo !== false;
                        const p = normalizeCashierPerms(c.permisos);
                        const grantedLabels = CASHIER_PERMISSION_ITEMS.filter(
                          (item) => p[item.key]
                        ).map((item) => item.label.split(' ')[0]);
                        return (
                          <tr key={c.key} className="hover:bg-slate-50">
                            <td className="py-2.5 px-4 font-bold text-slate-900">
                              <div>{c.nombre}</div>
                              {c.ultimo_acceso && (
                                <div className="text-[10px] font-mono text-slate-400 font-normal">
                                  Últ.: {new Date(c.ultimo_acceso).toLocaleString('es-VE')}
                                </div>
                              )}
                            </td>
                            <td className="py-2.5 px-4 font-mono text-slate-600">{c.email}</td>
                            <td className="py-2.5 px-4 text-slate-600">{c.turno || 'General'}</td>
                            <td className="py-2.5 px-4">
                              {grantedLabels.length === 0 ? (
                                <span className="text-[11px] font-semibold text-slate-600">
                                  Solo POS Ventas
                                </span>
                              ) : (
                                <span className="text-[11px] font-semibold text-sky-700">
                                  POS + {grantedLabels.slice(0, 3).join(', ')}
                                  {grantedLabels.length > 3
                                    ? ` (+${grantedLabels.length - 3})`
                                    : ''}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-4">
                              <span
                                className={`font-semibold ${
                                  active ? 'text-emerald-700' : 'text-rose-600'
                                }`}
                              >
                                {active ? 'Activo' : 'Pausado'}
                              </span>
                            </td>
                            <td className="py-2.5 px-4 text-right">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => openEditCashierModal(c)}
                                  className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                  title="Editar datos, PIN y permisos"
                                >
                                  <Edit3 className="w-3 h-3" /> Editar / PIN
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void handleToggleCashier(c.key, active)}
                                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-700 cursor-pointer"
                                  title={active ? 'Pausar cajero' : 'Activar cajero'}
                                >
                                  {active ? (
                                    <PauseCircle className="w-4 h-4 text-amber-600" />
                                  ) : (
                                    <PlayCircle className="w-4 h-4 text-emerald-600" />
                                  )}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteCashier(c.key, c.nombre)}
                                  className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                                  title="Eliminar cajero"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Tenant Access Credentials Management (Admin & Owner) */}
          {activeTenantId && (
            <form
              onSubmit={handleSaveTenantCredentials}
              className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Lock className="w-4 h-4 text-amber-600" />
                    Credenciales de Acceso del Comercio (PIN Admin / PIN Caja y Contraseña)
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Actualiza el PIN Administrativo (para cierres y anulaciones), el PIN de Caja por defecto o envía un enlace de cambio de clave al correo del comercio.
                  </p>
                </div>
                {activeTenant?.email && (
                  <button
                    type="button"
                    onClick={() => void handleResetPasswordForUser(activeTenant.email)}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Mail className="w-3.5 h-3.5 text-sky-600" /> Resetear Clave ({activeTenant.email})
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Nuevo PIN Administrativo ({activeTenant?.admin_pin_hash ? 'Configurado' : 'Sin definir'})
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={12}
                    value={tenantAdminPin}
                    onChange={(e) => setTenantAdminPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="4-12 dígitos (opcional)"
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Nuevo PIN de Caja por defecto ({activeTenant?.caja_pin_hash ? 'Configurado' : 'Sin definir'})
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={12}
                    value={tenantCajaPin}
                    onChange={(e) => setTenantCajaPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="4-12 dígitos (opcional)"
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <button
                  type="submit"
                  disabled={savingTenantCreds}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  {savingTenantCreds ? 'Actualizando...' : 'Guardar Credenciales PIN'}
                </button>
              </div>
            </form>
          )}

          {/* System Users Management (Owner View) */}
          {isOwnerView && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-indigo-600" />
                    Usuarios Administrativos del Comercio (Firebase Auth)
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Control de cuentas administrativas del nodo activo, recuperación de contraseña y estado.
                  </p>
                </div>
                <span className="text-xs font-mono text-slate-500">
                  {systemUsers.length} usuario(s)
                </span>
              </div>

              <form
                onSubmit={handleRegisterSystemUser}
                className="grid grid-cols-1 sm:grid-cols-4 gap-2.5"
              >
                <input
                  type="text"
                  value={sysName}
                  onChange={(e) => setSysName(e.target.value)}
                  placeholder="Nombre completo"
                  className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
                <input
                  type="email"
                  value={sysEmail}
                  onChange={(e) => setSysEmail(e.target.value)}
                  placeholder="Correo Firebase"
                  className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
                <div className="px-3 py-2 text-xs bg-slate-100 border border-slate-200 rounded-xl font-semibold text-slate-700 flex items-center">
                  Rol: Administrador
                </div>
                <button
                  type="submit"
                  className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Añadir al Directorio
                </button>
              </form>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Nombre</th>
                      <th className="py-2.5 px-4 font-semibold">Correo</th>
                      <th className="py-2.5 px-4 font-semibold">Rol</th>
                      <th className="py-2.5 px-4 font-semibold">Último acceso</th>
                      <th className="py-2.5 px-4 font-semibold">Estado</th>
                      <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {systemUsers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-6 text-center text-slate-400">
                          Los administradores aparecerán automáticamente al iniciar sesión o al añadirlos arriba.
                        </td>
                      </tr>
                    ) : (
                      systemUsers.map((u) => (
                        <tr key={u.key} className="hover:bg-slate-50">
                          <td className="py-2.5 px-4 font-bold text-slate-900">{u.nombre}</td>
                          <td className="py-2.5 px-4 font-mono text-slate-600">{u.email}</td>
                          <td className="py-2.5 px-4 capitalize font-semibold text-indigo-700">
                            {u.rol}
                          </td>
                          <td className="py-2.5 px-4 font-mono text-slate-500">
                            {u.ultimo_acceso
                              ? new Date(u.ultimo_acceso).toLocaleString('es-VE')
                              : '-'}
                          </td>
                          <td className="py-2.5 px-4">
                            <span
                              className={`inline-flex items-center gap-1 font-semibold ${
                                u.activo !== false ? 'text-emerald-700' : 'text-rose-600'
                              }`}
                            >
                              {u.activo !== false ? (
                                <>
                                  <CheckCircle2 className="w-3.5 h-3.5" /> Activo
                                </>
                              ) : (
                                'Suspendido'
                              )}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => void handleResetPasswordForUser(u.email)}
                                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                              >
                                <Mail className="w-3 h-3" /> Reset clave
                              </button>
                              <button
                                type="button"
                                onClick={() => void handleToggleSystemUser(u.key, u.activo !== false)}
                                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-700 cursor-pointer"
                                title="Activar/Suspender"
                              >
                                <UserCheck className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteSystemUser(u.key, u.email)}
                                className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                                title="Eliminar"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="space-y-6">
          {/* Register / Edit Supplier */}
          <form
            onSubmit={handleSaveProvider}
            className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-sky-600" />
                  {editingProvKey ? 'Editar Proveedor' : 'Registrar Nuevo Proveedor'}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Directorio de distribuidores y fabricantes para compras y reposición de stock.
                </p>
              </div>
              {editingProvKey && (
                <button
                  type="button"
                  onClick={resetProviderForm}
                  className="text-xs font-bold text-slate-500 hover:text-slate-800"
                >
                  Cancelar edición
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <input
                value={provNombre}
                onChange={(e) => setProvNombre(e.target.value)}
                placeholder="Nombre / Razón social *"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              />
              <input
                value={provRif}
                onChange={(e) => setProvRif(e.target.value)}
                placeholder="RIF (J-00000000-0)"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
              <input
                value={provContacto}
                onChange={(e) => setProvContacto(e.target.value)}
                placeholder="Persona de contacto"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <input
                value={provTel}
                onChange={(e) => setProvTel(e.target.value)}
                placeholder="Teléfono / WhatsApp"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
              <input
                type="email"
                value={provEmail}
                onChange={(e) => setProvEmail(e.target.value)}
                placeholder="Correo electrónico"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <input
                value={provCat}
                onChange={(e) => setProvCat(e.target.value)}
                placeholder="Rubro / Categoría"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <input
                value={provDir}
                onChange={(e) => setProvDir(e.target.value)}
                placeholder="Dirección"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <input
                value={provNota}
                onChange={(e) => setProvNota(e.target.value)}
                placeholder="Nota / Días de crédito"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={savingProv}
                className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer"
              >
                {savingProv
                  ? 'Guardando...'
                  : editingProvKey
                  ? 'Actualizar Proveedor'
                  : 'Guardar Proveedor'}
              </button>
            </div>
          </form>

          {/* Suppliers List */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800">Proveedores Registrados</h4>
              <span className="text-xs font-mono text-slate-500">{providers.length}</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4 font-semibold">Proveedor</th>
                    <th className="py-2.5 px-4 font-semibold">RIF</th>
                    <th className="py-2.5 px-4 font-semibold">Contacto / Tel.</th>
                    <th className="py-2.5 px-4 font-semibold">Rubro</th>
                    <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {providers.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-400">
                        Sin proveedores registrados todavía.
                      </td>
                    </tr>
                  ) : (
                    providers.map((p) => (
                      <tr key={p.key} className="hover:bg-slate-50">
                        <td className="py-2.5 px-4 font-bold text-slate-900">{p.nombre}</td>
                        <td className="py-2.5 px-4 font-mono text-slate-600">{p.rif || '—'}</td>
                        <td className="py-2.5 px-4 text-slate-600">
                          {p.contacto || '—'} {p.telefono ? `· ${p.telefono}` : ''}
                        </td>
                        <td className="py-2.5 px-4 text-slate-600">{p.categoria || '—'}</td>
                        <td className="py-2.5 px-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => startEditProvider(p)}
                              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                            >
                              Editar
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmModal({
                                  title: 'Eliminar Proveedor',
                                  message: `¿Eliminar al proveedor "${p.nombre}" del directorio?`,
                                  onConfirm: () => deleteProvider(p.key),
                                })
                              }
                              className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Register Purchase Invoice */}
          <form
            onSubmit={handleSavePurchaseInvoice}
            className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
          >
            <div>
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-600" />
                Registrar Factura / Compra a Proveedor
              </h4>
              <p className="text-xs text-slate-500 mt-0.5">
                Registra facturas de mercancía y actualiza automáticamente el stock y costo de inventario.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <select
                value={invProviderId}
                onChange={(e) => setInvProviderId(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              >
                <option value="">-- Seleccionar Proveedor * --</option>
                {providers.map((p) => (
                  <option key={p.key} value={p.key}>
                    {p.nombre} {p.rif ? `(${p.rif})` : ''}
                  </option>
                ))}
              </select>
              <input
                value={invNumber}
                onChange={(e) => setInvNumber(e.target.value)}
                placeholder="N° Factura / Nota *"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
              />
              <input
                type="date"
                value={invDate}
                onChange={(e) => setInvDate(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
              <select
                value={invStatus}
                onChange={(e) => setInvStatus(e.target.value as 'pagada' | 'pendiente')}
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              >
                <option value="pagada">Factura Pagada</option>
                <option value="pendiente">Por Pagar (Crédito)</option>
              </select>
              <input
                value={invMethod}
                onChange={(e) => setInvMethod(e.target.value)}
                placeholder="Método de pago"
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            {/* Line item builder */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="text-[11px] font-extrabold text-slate-600 uppercase">
                Agregar Artículo a la Factura
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                <select
                  value={lineProductKey}
                  onChange={(e) => {
                    const k = e.target.value;
                    setLineProductKey(k);
                    const found = products.find((p) => p.key === k);
                    if (found && !lineCostUsd) {
                      setLineCostUsd(String(found.cost || found.price || ''));
                    }
                  }}
                  className="sm:col-span-4 px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="">-- Producto de inventario (opcional) --</option>
                  {products.map((p) => (
                    <option key={p.key} value={p.key}>
                      {p.id} (Stock: {p.stock})
                    </option>
                  ))}
                </select>
                <input
                  value={lineCustomName}
                  onChange={(e) => setLineCustomName(e.target.value)}
                  disabled={Boolean(lineProductKey)}
                  placeholder={lineProductKey ? 'Usando producto seleccionado' : 'O escribe descripción manual'}
                  className="sm:col-span-3 px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl disabled:opacity-60"
                />
                <input
                  type="number"
                  step="any"
                  min="0.01"
                  value={lineQty}
                  onChange={(e) => setLineQty(e.target.value)}
                  placeholder="Cant."
                  className="sm:col-span-2 px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl font-mono"
                />
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={lineCostUsd}
                  onChange={(e) => setLineCostUsd(e.target.value)}
                  placeholder="Costo Unit. $"
                  className="sm:col-span-2 px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl font-mono"
                />
                <button
                  type="button"
                  onClick={handleAddPurchaseLine}
                  className="sm:col-span-1 flex items-center justify-center py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer"
                  title="Agregar renglón"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {invItems.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500">
                      <tr>
                        <th className="py-1.5 px-3 text-left">Artículo</th>
                        <th className="py-1.5 px-3 text-right">Cant.</th>
                        <th className="py-1.5 px-3 text-right">Costo Unit.</th>
                        <th className="py-1.5 px-3 text-right">Subtotal</th>
                        <th className="py-1.5 px-3"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {invItems.map((it, idx) => (
                        <tr key={`${it.nombre}_${idx}`}>
                          <td className="py-1.5 px-3 font-semibold text-slate-800">
                            {it.nombre}
                            {it.productKey && (
                              <span className="ml-1.5 text-[10px] text-emerald-700 font-bold">
                                (Vinculado al stock)
                              </span>
                            )}
                          </td>
                          <td className="py-1.5 px-3 text-right font-mono">{it.cantidad}</td>
                          <td className="py-1.5 px-3 text-right font-mono">
                            ${it.costo_unitario_usd.toFixed(2)}
                          </td>
                          <td className="py-1.5 px-3 text-right font-mono font-bold">
                            ${it.subtotal_usd.toFixed(2)}
                          </td>
                          <td className="py-1.5 px-3 text-right">
                            <button
                              type="button"
                              onClick={() =>
                                setInvItems((prev) => prev.filter((_, i) => i !== idx))
                              }
                              className="text-rose-600 hover:text-rose-800"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <label className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={invUpdateStock}
                    onChange={(e) => setInvUpdateStock(e.target.checked)}
                  />
                  Sumar cantidades al stock de inventario y actualizar costo unitario
                </label>
                <input
                  value={invNota}
                  onChange={(e) => setInvNota(e.target.value)}
                  placeholder="Observaciones de factura (opcional)"
                  className="block w-full sm:w-80 px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right font-mono tabular-nums">
                  <div className="text-xs font-bold text-slate-500">TOTAL FACTURA</div>
                  <div className="text-base font-black text-slate-900">
                    ${invTotalUsd.toFixed(2)} USD ({formatMoney(invTotalUsd * bcvRate)} Bs)
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={savingInv}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-xs font-extrabold cursor-pointer whitespace-nowrap"
                >
                  {savingInv ? 'Registrando...' : 'Guardar Factura de Compra'}
                </button>
              </div>
            </div>
          </form>

          {/* Purchase Invoices History */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800">
                Historial de Compras y Facturas a Proveedores
              </h4>
              <span className="text-xs font-mono text-slate-500">{supplierPurchases.length}</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4 font-semibold">Factura</th>
                    <th className="py-2.5 px-4 font-semibold">Fecha</th>
                    <th className="py-2.5 px-4 font-semibold">Proveedor</th>
                    <th className="py-2.5 px-4 font-semibold text-right">Items</th>
                    <th className="py-2.5 px-4 font-semibold text-right">Total USD</th>
                    <th className="py-2.5 px-4 font-semibold">Estado</th>
                    <th className="py-2.5 px-4 font-semibold text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {supplierPurchases.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-slate-400">
                        Sin facturas de compra registradas.
                      </td>
                    </tr>
                  ) : (
                    supplierPurchases.map((inv) => (
                      <tr key={inv.key} className="hover:bg-slate-50">
                        <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                          {inv.numero_factura}
                        </td>
                        <td className="py-2.5 px-4 font-mono text-slate-600">{inv.fecha}</td>
                        <td className="py-2.5 px-4 font-semibold text-slate-800">
                          {inv.providerNombre}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono">{inv.items.length}</td>
                        <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900">
                          ${Number(inv.total_usd).toFixed(2)}
                        </td>
                        <td className="py-2.5 px-4">
                          <button
                            type="button"
                            onClick={() =>
                              void updateSupplierPurchaseStatus(
                                inv.key,
                                inv.estado_pago === 'pagada' ? 'pendiente' : 'pagada'
                              )
                            }
                            className={`font-extrabold cursor-pointer ${
                              inv.estado_pago === 'pagada' ? 'text-emerald-700' : 'text-amber-600'
                            }`}
                          >
                            {inv.estado_pago === 'pagada' ? 'Pagada' : 'Pendiente'}
                          </button>
                        </td>
                        <td className="py-2.5 px-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => generateSupplierPurchasePDF(inv, localName)}
                              className="p-1.5 rounded-lg hover:bg-sky-50 text-sky-600 cursor-pointer"
                              title="Descargar comprobante PDF"
                            >
                              <FileDown className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmModal({
                                  title: 'Eliminar Factura de Compra',
                                  message: `¿Eliminar la factura #${inv.numero_factura} del historial?`,
                                  onConfirm: () => deleteSupplierPurchase(inv.key),
                                })
                              }
                              className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                              title="Eliminar factura"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Full Edit Cashier Credentials, PIN & Permissions Modal */}
      {editCashier && (
        <div className="fixed inset-0 z-[180] bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={submitCashierEdit}
            className="bg-white rounded-2xl border border-slate-200 p-5 max-w-xl w-full max-h-[90vh] overflow-y-auto space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-sky-600" />
                  Editar Cajero, PIN y Permisos
                </h4>
                <p className="text-[11px] text-slate-500">
                  Deja el PIN en blanco si solo deseas cambiar datos o permisos.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditCashier(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Nombre del cajero *
                </label>
                <input
                  type="text"
                  value={editNombre}
                  onChange={(e) => setEditNombre(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Correo de acceso *
                </label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Teléfono
                </label>
                <input
                  type="tel"
                  value={editTelefono}
                  onChange={(e) => setEditTelefono(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Turno
                </label>
                <select
                  value={editTurno}
                  onChange={(e) => setEditTurno(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="Mañana">Turno Mañana</option>
                  <option value="Tarde">Turno Tarde</option>
                  <option value="Completo">Turno Completo</option>
                </select>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 space-y-1.5">
              <label className="block text-xs font-bold text-amber-950">
                Nuevo PIN de acceso (opcional · 4 a 8 dígitos numéricos)
              </label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={8}
                value={editPinVal}
                onChange={(e) => setEditPinVal(e.target.value.replace(/\D/g, ''))}
                placeholder="Escribe solo si deseas cambiar el PIN actual"
                className="w-full px-3 py-2 text-center font-mono text-sm bg-white border border-amber-300 rounded-xl"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-slate-800">
                  Permisos otorgados (sin marcar = Solo POS Ventas):
                </p>
                <button
                  type="button"
                  onClick={() => setEditPerms({ ...DEFAULT_CASHIER_PERMISSIONS })}
                  className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Restablecer Solo POS
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CASHIER_PERMISSION_ITEMS.map((perm) => (
                  <label
                    key={perm.key}
                    className={`flex items-start gap-2 p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                      editPerms[perm.key]
                        ? 'bg-sky-50 border-sky-300 text-sky-950'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={editPerms[perm.key]}
                      onChange={(e) =>
                        setEditPerms((prev) => ({ ...prev, [perm.key]: e.target.checked }))
                      }
                      className="rounded border-slate-300 mt-0.5"
                    />
                    <span className="leading-tight">
                      <span className="font-semibold block">{perm.label}</span>
                      <span className="text-[10px] text-slate-500">{perm.hint}</span>
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditCashier(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={savingCashierEdit}
                className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-bold cursor-pointer"
              >
                {savingCashierEdit ? 'Guardando...' : 'Guardar Cambios'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Generic In-App Confirm Modal */}
      {confirmModal && (
        <div className="fixed inset-0 z-[180] bg-slate-950/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <h4 className="font-extrabold text-sm text-slate-900">{confirmModal.title}</h4>
            <p className="text-xs text-slate-600">{confirmModal.message}</p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-bold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const fn = confirmModal.onConfirm;
                  setConfirmModal(null);
                  void fn();
                }}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
