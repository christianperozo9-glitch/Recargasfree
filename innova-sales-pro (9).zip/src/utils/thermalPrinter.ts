import type { SaleItem, SaleTransaction, TenantInvoiceConfig } from '../types/pos';
import { formatMoney } from './format';

export type InvoiceMode = 'auto' | 'pdf' | 'printer' | 'none';

export interface TenantMetaForReceipt {
  razonSocial?: string;
  rif?: string;
  direccion?: string;
  telefono?: string;
  seniatLegal?: {
    activo: boolean;
    providencia?: string;
    pieLegal?: string;
    prefijoFactura?: string;
    facturaNum?: string;
    prefijoControl?: string;
    controlNum?: string;
    maquinaFiscal?: string;
    ivaPorcentaje?: number;
  };
}

export const DEFAULT_TENANT_INVOICE_CONFIG: TenantInvoiceConfig = {
  ancho_papel: '80mm',
  modelo: 'clasico',
  fuente: 'mono',
  tamano_letra: 'normal',
  color_factura: '#0f172a',
  intensidad_impresion: 'normal',
  mostrar_logo: true,
  logo_data_url: '',
  encabezado_extra: '',
  pie_pagina: '¡Gracias por su compra!',
  mostrar_rif: true,
  mostrar_direccion: true,
  mostrar_telefono: true,
  mostrar_tasa: true,
  mostrar_cajero: true,
  impresora_predeterminada: 'navegador',
  impresora_nombre: 'Impresora Térmica Estándar',
  auto_imprimir: false,
  corte_automatico: true,
  abrir_gaveta: false,
  copias: 1,
};

export function mergeInvoiceConfig(
  cfg?: Partial<TenantInvoiceConfig> | null
): TenantInvoiceConfig {
  return {
    ...DEFAULT_TENANT_INVOICE_CONFIG,
    ...(cfg || {}),
  };
}

export interface SerialPortLike {
  readable?: unknown;
  writable?: WritableStream<Uint8Array> | null;
  open: (options: { baudRate: number }) => Promise<void>;
  close?: () => Promise<void>;
  getInfo: () => { usbVendorId?: number; usbProductId?: number };
}

export interface USBEndpointLike {
  endpointNumber: number;
  direction: 'in' | 'out';
}

export interface USBInterfaceLike {
  interfaceNumber: number;
  alternates: Array<{
    endpoints: USBEndpointLike[];
  }>;
}

export interface USBDeviceLike {
  productName?: string;
  manufacturerName?: string;
  vendorId?: number;
  productId?: number;
  opened: boolean;
  configuration?: {
    interfaces: USBInterfaceLike[];
  } | null;
  open: () => Promise<void>;
  close?: () => Promise<void>;
  selectConfiguration: (configValue: number) => Promise<void>;
  claimInterface: (interfaceNumber: number) => Promise<void>;
  transferOut: (endpointNumber: number, data: BufferSource) => Promise<{ status: string }>;
}

export interface ConnectedPrinterInfo {
  id: string;
  name: string;
  kind: 'serial' | 'usb';
  port?: SerialPortLike;
  device?: USBDeviceLike;
}

function asciiSafe(input: string): string {
  return String(input || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x20-\x7E\n]/g, ' ');
}

function padRight(str: string, len: number): string {
  const s = asciiSafe(str);
  return s.length >= len ? s.slice(0, len) : s + ' '.repeat(len - s.length);
}

function padLeft(str: string, len: number): string {
  const s = asciiSafe(str);
  return s.length >= len ? s.slice(0, len) : ' '.repeat(len - s.length) + s;
}

function rowCols(left: string, right: string, cols = 32): string {
  const r = asciiSafe(right);
  const maxL = Math.max(4, cols - r.length - 1);
  const l = padRight(left, maxL);
  const gap = Math.max(1, cols - l.length - r.length);
  return `${l}${' '.repeat(gap)}${r}\n`;
}

function row32(left: string, right: string): string {
  return rowCols(left, right, 32);
}

// Convert base64 store logo to ESC/POS GS v 0 monochrome raster bytes for thermal printers
export async function buildEscPosRasterLogoAsync(
  logoDataUrl: string,
  paperWidth: '58mm' | '80mm' = '80mm',
  intensity: TenantInvoiceConfig['intensidad_impresion'] = 'normal'
): Promise<Uint8Array | null> {
  if (!logoDataUrl || typeof window === 'undefined') return null;
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('logo load failed'));
      el.src = logoDataUrl;
    });
    const maxWidth = paperWidth === '58mm' ? 240 : 320;
    const scale = Math.min(1, maxWidth / Math.max(1, img.width), 110 / Math.max(1, img.height));
    const width = Math.max(16, Math.floor((img.width * scale) / 8) * 8);
    const height = Math.max(16, Math.round(img.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);
    const pixels = ctx.getImageData(0, 0, width, height).data;
    const bytesPerRow = width / 8;
    const lumThreshold =
      intensity === 'extra_oscura'
        ? 200
        : intensity === 'oscura'
        ? 182
        : intensity === 'suave'
        ? 140
        : 165;
    const out: number[] = [
      0x1b, 0x61, 0x01, // Center
      0x1d, 0x76, 0x30, 0x00, // GS v 0 normal mode
      bytesPerRow & 0xff,
      (bytesPerRow >> 8) & 0xff,
      height & 0xff,
      (height >> 8) & 0xff,
    ];
    for (let y = 0; y < height; y++) {
      for (let bx = 0; bx < bytesPerRow; bx++) {
        let byte = 0;
        for (let bit = 0; bit < 8; bit++) {
          const x = bx * 8 + bit;
          const idx = (y * width + x) * 4;
          const r = pixels[idx];
          const g = pixels[idx + 1];
          const b = pixels[idx + 2];
          const a = pixels[idx + 3];
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          if (a > 128 && lum < lumThreshold) {
            byte |= 1 << (7 - bit);
          }
        }
        out.push(byte);
      }
    }
    out.push(0x0a);
    return new Uint8Array(out);
  } catch {
    return null;
  }
}

export function buildEscPosSaleTicket(
  sale: SaleTransaction,
  localName: string,
  rawConfig?: Partial<TenantInvoiceConfig> | null,
  tenantMeta?: TenantMetaForReceipt,
  logoBytes?: Uint8Array | null
): Uint8Array {
  const cfg = mergeInvoiceConfig(rawConfig);
  const cols = cfg.ancho_papel === '80mm' ? 42 : 32;
  const sep = (cfg.modelo === 'moderno' ? '=' : '-').repeat(cols) + '\n';
  const row = (l: string, r: string) => rowCols(l, r, cols);

  const encoder = new TextEncoder();
  const buildSingleCopy = (): number[] => {
    const chunks: number[] = [];
    const pushBytes = (...bytes: number[]) => chunks.push(...bytes);
    const pushText = (txt: string) => {
      const encoded = encoder.encode(asciiSafe(txt));
      encoded.forEach((b) => chunks.push(b));
    };

    // ESC @ (Initialize)
    pushBytes(0x1b, 0x40);
    // Print intensity: ESC G (double-strike) + ESC E (emphasized) for oscura/extra_oscura
    if (cfg.intensidad_impresion === 'extra_oscura') {
      pushBytes(0x1b, 0x47, 0x01, 0x1b, 0x45, 0x01);
    } else if (cfg.intensidad_impresion === 'oscura') {
      pushBytes(0x1b, 0x47, 0x01);
    }
    // Font size selector (ESC M: 0 = Font A normal, 1 = Font B small/condensed)
    if (cfg.tamano_letra === 'pequena' || cfg.fuente === 'condensada') {
      pushBytes(0x1b, 0x4d, 0x01);
    } else {
      pushBytes(0x1b, 0x4d, 0x00);
    }

    if (cfg.mostrar_logo && logoBytes && logoBytes.length > 0) {
      logoBytes.forEach((b) => chunks.push(b));
    }

    const isSeniat = Boolean(tenantMeta?.seniatLegal?.activo);
    const facShort = String(sale.timestamp).slice(-8);
    const prefFac = tenantMeta?.seniatLegal?.prefijoFactura?.trim() || 'FAC-';
    const prefCtrl = tenantMeta?.seniatLegal?.prefijoControl?.trim() || '00-';
    const invoiceDisplay = sale.numero_factura || tenantMeta?.seniatLegal?.facturaNum || `${prefFac}${facShort}`;
    const controlNum = sale.numero_control || tenantMeta?.seniatLegal?.controlNum || `${prefCtrl}${facShort.padStart(8, '0')}`;
    const maquinaFiscal = tenantMeta?.seniatLegal?.maquinaFiscal?.trim() || '';

    // Center align + bold + double height
    pushBytes(0x1b, 0x61, 0x01, 0x1b, 0x45, 0x01);
    if (isSeniat) {
      pushText(`SENIAT - FACTURA FISCAL\n`);
      pushText(`REPUBLICA BOLIVARIANA DE VENEZUELA\n`);
    }
    pushBytes(0x1d, 0x21, cfg.tamano_letra === 'grande' ? 0x11 : 0x01);
    pushText(`${localName || 'INNOVA GRUP'}\n`);
    pushBytes(0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00);

    if (isSeniat && tenantMeta?.razonSocial && tenantMeta.razonSocial.trim().toLowerCase() !== (localName || '').trim().toLowerCase()) {
      pushText(`${tenantMeta.razonSocial.trim()}\n`);
    }
    if ((isSeniat || cfg.mostrar_rif) && tenantMeta?.rif) {
      pushText(`RIF: ${tenantMeta.rif}\n`);
    } else if (isSeniat) {
      pushText(`RIF: CONTRIBUYENTE REGISTRADO\n`);
    }
    if ((isSeniat || cfg.mostrar_direccion) && tenantMeta?.direccion) {
      pushText(`${tenantMeta.direccion.slice(0, cols * 2)}\n`);
    }
    if ((isSeniat || cfg.mostrar_telefono) && tenantMeta?.telefono) {
      pushText(`Tel: ${tenantMeta.telefono}\n`);
    }
    if (cfg.encabezado_extra?.trim()) {
      pushText(`${cfg.encabezado_extra.trim()}\n`);
    }

    pushText(`FACTURA Nro: ${invoiceDisplay}\n`);
    if (isSeniat) {
      pushText(`Nro CONTROL: ${controlNum}\n`);
      if (maquinaFiscal) {
        pushText(`MAQ. FISCAL: ${maquinaFiscal}\n`);
      }
    }
    pushText(`Fecha: ${sale.fecha}  Hora: ${sale.hora}\n`);
    pushText(sep);

    // Left align
    pushBytes(0x1b, 0x61, 0x00);
    if (cfg.mostrar_cajero) {
      pushText(`Cajero: ${sale.cajero_nombre || sale.usuario || 'Caja'}\n`);
    }
    if (sale.cliente_nombre || sale.cliente_cedula) {
      pushText(`Cliente: ${asciiSafe(sale.cliente_nombre || 'Cliente')}\n`);
      if (sale.cliente_cedula) pushText(`CI/RIF: ${asciiSafe(sale.cliente_cedula)}\n`);
    } else if (isSeniat) {
      pushText(`Cliente: CONSUMIDOR FINAL\n`);
      pushText(`CI/RIF: N/A\n`);
    }
    pushText(`Metodo: ${sale.metodo_pago}\n`);
    if (sale.referencia_pago) {
      pushText(`Ref. Pago: ${sale.referencia_pago}\n`);
    }
    if (Array.isArray(sale.pagos_mixtos) && sale.pagos_mixtos.length > 0) {
      sale.pagos_mixtos.forEach((leg) => {
        const refTag = leg.referencia ? ` #${leg.referencia}` : '';
        pushText(row(`  ${asciiSafe(leg.metodo + refTag).slice(0, cols - 16)}:`, `${formatMoney(leg.monto_ves)} Bs`));
      });
    }
    if (isSeniat || cfg.mostrar_tasa) {
      pushText(`Tasa Oficial BCV: ${Number(sale.tasa_bcv_momento || 0).toFixed(2)} Bs\n`);
    }
    pushText(sep);
    pushText(row('CANT  DESCRIPCION', 'TOTAL'));
    pushText(sep);

    const items: SaleItem[] = Array.isArray(sale.items)
      ? sale.items
      : sale.items
      ? Object.values(sale.items as Record<string, SaleItem>)
      : [];

    items.forEach((it) => {
      const q = Math.round((Number(it.cantidad) || 0) * 100) / 100;
      const subBs = (Number(it.precio_unitario_bs) || 0) * q;
      const lineName = asciiSafe(it.id || 'Item').slice(0, cols - 8);
      if (cfg.modelo === 'compacto') {
        pushText(row(`${q}x ${lineName}`, `${formatMoney(subBs)}`));
      } else {
        pushText(`${padRight(String(q), 5)} ${lineName}\n`);
        const detailLeft =
          cfg.modelo === 'detallado'
            ? `  @${formatMoney(it.precio_unitario_bs)} Bs ($${Number(it.precio_unitario_usd || 0).toFixed(2)})`
            : `  @${formatMoney(it.precio_unitario_bs)} Bs`;
        pushText(row(detailLeft, `${formatMoney(subBs)} Bs`));
      }
    });

    pushText(sep);
    const totalSaleBs = Number(sale.monto_total_ves) || 0;
    const ivaBs = sale.iva_aplicado ? Number(sale.monto_iva_ves) || 0 : 0;
    const baseImpBs = Math.max(0, totalSaleBs - ivaBs);
    if (isSeniat) {
      if (ivaBs > 0) {
        pushText(row('BASE IMPONIBLE (G):', `${formatMoney(baseImpBs)} Bs`));
        pushText(row(`IVA (${sale.iva_porcentaje || 16}%):`, `${formatMoney(ivaBs)} Bs`));
      } else {
        pushText(row('VENTAS EXENTAS (E):', `${formatMoney(totalSaleBs)} Bs`));
        pushText(row('IVA (0%):', '0,00 Bs'));
      }
    } else if (sale.iva_aplicado && (sale.monto_iva_ves || 0) > 0) {
      pushText(row(`IVA (${sale.iva_porcentaje || 16}%):`, `${formatMoney(sale.monto_iva_ves || 0)} Bs`));
    }
    if (sale.metodo_pago === 'Cashea' && sale.cashea_total_venta_ves !== undefined) {
      pushText(row('TOTAL COMPRA:', `${formatMoney(sale.cashea_total_venta_ves)} Bs`));
      pushText(row('COMPRA USD:', `$${Number(sale.cashea_total_venta_usd || 0).toFixed(2)}`));
      pushBytes(0x1b, 0x45, 0x01);
      pushText(row('INICIAL PAGADA:', `${formatMoney(sale.cashea_inicial_ves ?? sale.monto_total_ves)} Bs`));
      pushText(row('INICIAL USD:', `$${Number(sale.cashea_inicial_usd ?? sale.monto_total_usd_bcv ?? 0).toFixed(2)}`));
      pushBytes(0x1b, 0x45, 0x00);
      pushText(row('PENDIENTE CASHEA:', `$${Number(sale.cashea_restante_usd || 0).toFixed(2)}`));
      pushText(
        `Cuotas: ${sale.cashea_cuotas || 3} x $${Number(sale.cashea_cuota_usd || 0).toFixed(2)}${
          sale.cashea_nivel && sale.cashea_nivel !== 'Manual' ? ` (${sale.cashea_nivel})` : ''
        }\n`
      );
    } else {
      pushBytes(0x1b, 0x45, 0x01);
      if (cfg.tamano_letra === 'grande') pushBytes(0x1d, 0x21, 0x01);
      pushText(row('TOTAL VES:', `${formatMoney(sale.monto_total_ves)} Bs`));
      pushText(row('EQUIV. USD (BCV):', `$${Number(sale.monto_total_usd_bcv || 0).toFixed(2)}`));
      pushBytes(0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00);
    }
    pushText(sep);

    // Center footer
    pushBytes(0x1b, 0x61, 0x01);
    if (isSeniat) {
      const prov =
        tenantMeta?.seniatLegal?.providencia?.trim() ||
        'Providencia Adm. SNAT/2011/00071 - SENIAT';
      const pieLegal =
        tenantMeta?.seniatLegal?.pieLegal?.trim() ||
        'Documento fiscal emitido conforme a normativa SENIAT Venezuela';
      pushText(`${prov}\n`);
      pushText(`${pieLegal}\n`);
    }
    pushText(`${cfg.pie_pagina?.trim() || 'Gracias por su compra!'}\n`);
    pushText(`Innova Grup POS\n\n\n`);

    if (cfg.abrir_gaveta) {
      pushBytes(0x1b, 0x70, 0x00, 0x19, 0xfa);
    }
    if (cfg.corte_automatico) {
      pushBytes(0x1d, 0x56, 0x41, 0x03);
    }
    return chunks;
  };

  const totalCopies = cfg.copias === 2 ? 2 : 1;
  const allBytes: number[] = [];
  for (let c = 0; c < totalCopies; c++) {
    allBytes.push(...buildSingleCopy());
  }
  return new Uint8Array(allBytes);
}

export function buildEscPosTestTicket(
  localName: string,
  rawConfig?: Partial<TenantInvoiceConfig> | null,
  rasterLogo?: Uint8Array | null
): Uint8Array {
  const cfg = mergeInvoiceConfig(rawConfig);
  const cols = cfg.ancho_papel === '80mm' ? 42 : 32;
  const encoder = new TextEncoder();
  const chunks: number[] = [];
  const pushBytes = (...bytes: number[]) => chunks.push(...bytes);
  const pushText = (txt: string) => {
    const encoded = encoder.encode(asciiSafe(txt));
    encoded.forEach((b) => chunks.push(b));
  };

  pushBytes(0x1b, 0x40, 0x1b, 0x61, 0x01);
  if (rasterLogo && rasterLogo.length > 0) {
    rasterLogo.forEach((b) => chunks.push(b));
    pushText('\n');
  }
  pushBytes(0x1b, 0x45, 0x01);
  pushText(`${localName || 'INNOVA GRUP'}\n`);
  pushBytes(0x1b, 0x45, 0x00);
  pushText(`PRUEBA DE IMPRESORA TERMICA (${cfg.ancho_papel})\n`);
  if (cfg.impresora_nombre) pushText(`${cfg.impresora_nombre}\n`);
  pushText(`${new Date().toLocaleString('es-VE')}\n`);
  pushText(`${'-'.repeat(cols)}\n`);
  pushText(`Modelo: ${cfg.modelo} | Fuente: ${cfg.fuente}\n`);
  pushText(`Conexion verificada correctamente\n\n\n`);
  if (cfg.corte_automatico) {
    pushBytes(0x1d, 0x56, 0x41, 0x03);
  }

  return new Uint8Array(chunks);
}

export async function detectAuthorizedPrinters(): Promise<ConnectedPrinterInfo[]> {
  const found: ConnectedPrinterInfo[] = [];
  const nav = navigator as unknown as {
    serial?: { getPorts?: () => Promise<SerialPortLike[]> };
    usb?: { getDevices?: () => Promise<USBDeviceLike[]> };
  };

  if (nav.serial?.getPorts) {
    try {
      const ports = await nav.serial.getPorts();
      ports.forEach((port, idx) => {
        const info = port.getInfo?.() || {};
        found.push({
          id: `serial_${info.usbVendorId || 'p'}_${info.usbProductId || idx}`,
          name: info.usbVendorId
            ? `Impresora Serial (VID ${info.usbVendorId.toString(16).toUpperCase()})`
            : `Puerto Serial #${idx + 1}`,
          kind: 'serial',
          port,
        });
      });
    } catch {
      // ignore permission errors on passive scan
    }
  }

  if (nav.usb?.getDevices) {
    try {
      const devices = await nav.usb.getDevices();
      devices.forEach((device, idx) => {
        found.push({
          id: `usb_${device.vendorId || 'u'}_${device.productId || idx}`,
          name: device.productName || device.manufacturerName || `Impresora USB #${idx + 1}`,
          kind: 'usb',
          device,
        });
      });
    } catch {
      // ignore
    }
  }

  return found;
}

export async function writeBytesToPrinter(
  printer: ConnectedPrinterInfo,
  bytes: Uint8Array
): Promise<boolean> {
  if (printer.kind === 'serial' && printer.port) {
    const port = printer.port;
    if (!port.writable) {
      await port.open({ baudRate: 9600 });
    }
    if (!port.writable) {
      throw new Error('Puerto serial sin canal de escritura disponible.');
    }
    const writer = port.writable.getWriter();
    try {
      await writer.write(bytes);
    } finally {
      writer.releaseLock();
    }
    return true;
  }

  if (printer.kind === 'usb' && printer.device) {
    const dev = printer.device;
    if (!dev.opened) {
      await dev.open();
    }
    if (!dev.configuration) {
      await dev.selectConfiguration(1);
    }
    const ifaces = dev.configuration?.interfaces || [];
    for (const iface of ifaces) {
      for (const alt of iface.alternates || []) {
        const outEp = (alt.endpoints || []).find((ep) => ep.direction === 'out');
        if (outEp) {
          await dev.claimInterface(iface.interfaceNumber);
          const buffer = new Uint8Array(bytes).buffer;
          const res = await dev.transferOut(outEp.endpointNumber, buffer);
          return res.status === 'ok';
        }
      }
    }
    throw new Error('No se encontró endpoint de salida USB en la impresora.');
  }

  return false;
}

export function buildThermalReceiptHtml(
  sale: SaleTransaction,
  localName: string,
  rawConfig?: Partial<TenantInvoiceConfig> | null,
  tenantMeta?: TenantMetaForReceipt
): string {
  const cfg = mergeInvoiceConfig(rawConfig);
  const esc = (s?: string | null) => String(s || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const items: SaleItem[] = Array.isArray(sale.items)
    ? sale.items
    : sale.items
    ? Object.values(sale.items as Record<string, SaleItem>)
    : [];

  const paperWidthMm = cfg.ancho_papel === '58mm' ? '54mm' : '74mm';
  const fontFamily =
    cfg.fuente === 'sans'
      ? 'system-ui, -apple-system, "Segoe UI", sans-serif'
      : cfg.fuente === 'serif'
      ? 'Georgia, "Times New Roman", serif'
      : cfg.fuente === 'condensada'
      ? '"Arial Narrow", "Roboto Condensed", ui-monospace, monospace'
      : 'ui-monospace, "Courier New", monospace';

  const baseFontPx =
    cfg.tamano_letra === 'pequena'
      ? cfg.ancho_papel === '58mm'
        ? 10
        : 10.5
      : cfg.tamano_letra === 'grande'
      ? cfg.ancho_papel === '58mm'
        ? 12.5
        : 13.5
      : cfg.ancho_papel === '58mm'
      ? 11
      : 12;

  const isModerno = cfg.modelo === 'moderno';
  const isCompacto = cfg.modelo === 'compacto';
  const isDetallado = cfg.modelo === 'detallado';
  const accentColor =
    cfg.color_factura && /^#[0-9a-fA-F]{3,8}$/.test(cfg.color_factura.trim())
      ? cfg.color_factura.trim()
      : '#0f172a';
  const intensity = cfg.intensidad_impresion || 'normal';
  const intensityStyles =
    intensity === 'extra_oscura'
      ? { weight: 700, contrast: 'contrast(1.38)', color: '#000000', mute: '#111111' }
      : intensity === 'oscura'
      ? { weight: 600, contrast: 'contrast(1.2)', color: '#09090b', mute: '#1f2937' }
      : intensity === 'suave'
      ? { weight: 400, contrast: 'contrast(0.88)', color: '#334155', mute: '#64748b' }
      : { weight: 500, contrast: 'contrast(1)', color: '#111827', mute: '#334155' };

  const rowsHtml = items
    .map((it) => {
      const q = Math.round((Number(it.cantidad) || 0) * 100) / 100;
      const unitBs = Number(it.precio_unitario_bs) || 0;
      const unitUsd = Number(it.precio_unitario_usd) || 0;
      const subBs = unitBs * q;
      const detailSub = isDetallado
        ? `<div style="font-size:${Math.max(8.5, baseFontPx - 2)}px;color:${intensityStyles.mute};">@${formatMoney(unitBs)} Bs · $${unitUsd.toFixed(2)}</div>`
        : '';
      return `<tr>
        <td style="padding:${isCompacto ? '1.5px 0' : '3px 0'};vertical-align:top;">${q}x ${esc(it.id)}${detailSub}</td>
        <td style="text-align:right;padding:${isCompacto ? '1.5px 0' : '3px 0'};font-family:ui-monospace,monospace;white-space:nowrap;vertical-align:top;">${formatMoney(subBs)} Bs</td>
      </tr>`;
    })
    .join('');

  const logoBlock =
    cfg.mostrar_logo && cfg.logo_data_url
      ? `<div style="text-align:center;margin-bottom:5px;"><img src="${cfg.logo_data_url}" alt="Logo" style="max-width:${
          cfg.ancho_papel === '58mm' ? '36mm' : '46mm'
        };max-height:18mm;object-fit:contain;margin:0 auto;display:block;filter:${intensityStyles.contrast};" /></div>`
      : '';

  const headerDivider = isModerno
    ? `border-top:2px solid ${accentColor};margin:6px 0;`
    : `border-top:1px dashed ${accentColor};margin:6px 0;opacity:0.75;`;

  const isSeniat = Boolean(tenantMeta?.seniatLegal?.activo);
  const facShort = String(sale.timestamp).slice(-8);
  const prefFac = tenantMeta?.seniatLegal?.prefijoFactura?.trim() || 'FAC-';
  const prefCtrl = tenantMeta?.seniatLegal?.prefijoControl?.trim() || '00-';
  const invoiceDisplay = sale.numero_factura || tenantMeta?.seniatLegal?.facturaNum || `${prefFac}${facShort}`;
  const controlNum = sale.numero_control || tenantMeta?.seniatLegal?.controlNum || `${prefCtrl}${facShort.padStart(8, '0')}`;
  const maquinaFiscal = tenantMeta?.seniatLegal?.maquinaFiscal?.trim() || '';
  const totalSaleBs = Number(sale.monto_total_ves) || 0;
  const ivaBs = sale.iva_aplicado ? Number(sale.monto_iva_ves) || 0 : 0;
  const baseImpBs = Math.max(0, totalSaleBs - ivaBs);
  const seniatProvidencia =
    tenantMeta?.seniatLegal?.providencia?.trim() ||
    'Providencia Administrativa SNAT/2011/00071 · SENIAT Venezuela';
  const seniatPie =
    tenantMeta?.seniatLegal?.pieLegal?.trim() ||
    'Documento fiscal emitido conforme a las regulaciones del SENIAT · República Bolivariana de Venezuela';

  const bodyBlock = `
    <div class="ticket">
      ${logoBlock}
      ${
        isSeniat
          ? `<div class="c" style="font-weight:800;font-size:${Math.max(9, baseFontPx - 1)}px;color:${accentColor};border:1px solid ${accentColor};padding:2px 4px;margin-bottom:4px;letter-spacing:0.04em;">SENIAT · FACTURA LEGAL VENEZUELA</div>`
          : ''
      }
      <h2 style="margin:0 0 2px;text-align:center;font-size:${baseFontPx + 3}px;color:${accentColor};letter-spacing:${
    isModerno ? '0.04em' : '0'
  };text-transform:${isModerno ? 'uppercase' : 'none'};">${esc(localName || 'INNOVA GRUP')}</h2>
      ${
        isSeniat && tenantMeta?.razonSocial && tenantMeta.razonSocial.trim().toLowerCase() !== (localName || '').trim().toLowerCase()
          ? `<div class="c" style="font-weight:700;">${esc(tenantMeta.razonSocial.trim())}</div>`
          : ''
      }
      ${(isSeniat || cfg.mostrar_rif) && tenantMeta?.rif ? `<div class="c"><b>RIF:</b> ${esc(tenantMeta.rif)}</div>` : ''}
      ${(isSeniat || cfg.mostrar_direccion) && tenantMeta?.direccion ? `<div class="c">${esc(tenantMeta.direccion)}</div>` : ''}
      ${(isSeniat || cfg.mostrar_telefono) && tenantMeta?.telefono ? `<div class="c">Tel: ${esc(tenantMeta.telefono)}</div>` : ''}
      ${cfg.encabezado_extra?.trim() ? `<div class="c" style="margin-top:2px;">${esc(cfg.encabezado_extra.trim())}</div>` : ''}
      <div class="c" style="margin-top:3px;color:${accentColor};"><b>FACTURA N° ${esc(invoiceDisplay)}</b></div>
      ${isSeniat ? `<div class="c" style="font-family:monospace;font-weight:700;">N° DE CONTROL: ${esc(controlNum)}</div>` : ''}
      ${isSeniat && maquinaFiscal ? `<div class="c" style="font-family:monospace;font-size:${Math.max(8.5, baseFontPx - 1.5)}px;">MÁQUINA FISCAL / SERIE: ${esc(maquinaFiscal)}</div>` : ''}
      <div class="c">${esc(sale.fecha)} · ${esc(sale.hora)}</div>
      <hr style="${headerDivider}" />
      ${cfg.mostrar_cajero ? `<div>Cajero: ${esc(sale.cajero_nombre || sale.usuario || 'Caja')}</div>` : ''}
      ${
        sale.cliente_nombre || sale.cliente_cedula
          ? `<div>Cliente: ${esc(sale.cliente_nombre || 'Cliente')}${
              sale.cliente_cedula ? ` · CI/RIF: ${esc(sale.cliente_cedula)}` : ''
            }</div>`
          : isSeniat
          ? `<div>Cliente: <b>Consumidor Final</b> · CI/RIF: N/A</div>`
          : ''
      }
      <div>Método: <b style="color:${accentColor};">${esc(sale.metodo_pago)}</b></div>
      ${sale.referencia_pago ? `<div>Ref. Pago Móvil: <span style="font-family:monospace;font-weight:700;">${esc(sale.referencia_pago)}</span></div>` : ''}
      ${
        Array.isArray(sale.pagos_mixtos) && sale.pagos_mixtos.length > 0
          ? `<div style="font-size:${Math.max(9, baseFontPx - 1)}px;margin:2px 0;">${sale.pagos_mixtos
              .map(
                (l) =>
                  `• ${esc(l.metodo)}${l.referencia ? ` (Ref: ${esc(l.referencia)})` : ''}: ${formatMoney(
                    l.monto_ves
                  )} Bs ($${Number(l.monto_usd || 0).toFixed(2)})`
              )
              .join('<br/>')}</div>`
          : ''
      }
      ${isSeniat || cfg.mostrar_tasa ? `<div>Tasa Oficial BCV: ${Number(sale.tasa_bcv_momento || 0).toFixed(2)} Bs</div>` : ''}
      <hr style="${headerDivider}" />
      <table>${rowsHtml}</table>
      <hr style="${headerDivider}" />
      <table>
        ${
          isSeniat
            ? ivaBs > 0
              ? `<tr><td>Base Imponible (G):</td><td style="text-align:right;">${formatMoney(baseImpBs)} Bs</td></tr>
                 <tr><td>IVA (${sale.iva_porcentaje || 16}%):</td><td style="text-align:right;">${formatMoney(ivaBs)} Bs</td></tr>`
              : `<tr><td>Ventas Exentas (E):</td><td style="text-align:right;">${formatMoney(totalSaleBs)} Bs</td></tr>
                 <tr><td>IVA (0%):</td><td style="text-align:right;">0,00 Bs</td></tr>`
            : sale.iva_aplicado && (sale.monto_iva_ves || 0) > 0
            ? `<tr><td>IVA (${sale.iva_porcentaje || 16}%):</td><td style="text-align:right;">${formatMoney(sale.monto_iva_ves || 0)} Bs</td></tr>`
            : ''
        }
        ${
          sale.metodo_pago === 'Cashea' && sale.cashea_total_venta_ves !== undefined
            ? `
              <tr><td>TOTAL COMPRA:</td><td style="text-align:right;">${formatMoney(sale.cashea_total_venta_ves)} Bs ($${Number(sale.cashea_total_venta_usd || 0).toFixed(2)})</td></tr>
              <tr class="tot"><td>INICIAL PAGADA:</td><td style="text-align:right;">${formatMoney(sale.cashea_inicial_ves ?? sale.monto_total_ves)} Bs ($${Number(sale.cashea_inicial_usd ?? sale.monto_total_usd_bcv ?? 0).toFixed(2)})</td></tr>
              <tr><td>PENDIENTE CASHEA:</td><td style="text-align:right;">${formatMoney(sale.cashea_restante_ves || 0)} Bs ($${Number(sale.cashea_restante_usd || 0).toFixed(2)})</td></tr>
              <tr><td colspan="2" style="font-size:${Math.max(9, baseFontPx - 1)}px;">${sale.cashea_cuotas || 3} cuotas de $${Number(sale.cashea_cuota_usd || 0).toFixed(2)}${sale.cashea_nivel && sale.cashea_nivel !== 'Manual' ? ` · ${esc(sale.cashea_nivel)}` : ''}</td></tr>
            `
            : `
              <tr class="tot"><td>TOTAL VES:</td><td style="text-align:right;">${formatMoney(sale.monto_total_ves)} Bs</td></tr>
              <tr><td><b>EQUIV. USD (BCV):</b></td><td style="text-align:right;"><b style="color:${accentColor};">$${Number(sale.monto_total_usd_bcv || 0).toFixed(2)}</b></td></tr>
            `
        }
      </table>
      <hr style="${headerDivider}" />
      ${
        isSeniat
          ? `<div class="c" style="font-size:${Math.max(8, baseFontPx - 2.5)}px;font-weight:700;margin-bottom:2px;">${esc(seniatProvidencia)}</div>
             <div class="c" style="font-size:${Math.max(7.5, baseFontPx - 3)}px;margin-bottom:3px;">${esc(seniatPie)}</div>`
          : ''
      }
      <div class="c">${esc(cfg.pie_pagina?.trim() || '¡Gracias por su compra!')}</div>
      <div class="c" style="font-size:${Math.max(8.5, baseFontPx - 2)}px;opacity:0.75;">Innova Grup POS</div>
    </div>
  `;

  const copiesHtml =
    cfg.copias === 2
      ? `${bodyBlock}<div style="page-break-before:always;margin-top:12px;border-top:1px dotted #999;padding-top:10px;">${bodyBlock}</div>`
      : bodyBlock;

  return `<!doctype html><html><head><meta charset="utf-8"><title>Factura ${sale.timestamp}</title>
  <style>
    @page { margin: 2.5mm; size: ${cfg.ancho_papel} auto; }
    body { font-family: ${fontFamily}; width: ${paperWidthMm}; margin: 0 auto; font-size: ${baseFontPx}px; font-weight: ${intensityStyles.weight}; line-height: 1.32; color: ${intensityStyles.color}; background: #fff; filter: ${intensityStyles.contrast}; }
    .c { text-align: center; font-size: ${Math.max(9, baseFontPx - 1)}px; color: ${intensityStyles.mute}; }
    hr { border: none; }
    table { width: 100%; border-collapse: collapse; }
    .tot { font-weight: 800; font-size: ${baseFontPx + 2}px; color: ${accentColor}; }
  </style></head><body>${copiesHtml}</body></html>`;
}

export function printBrowserReceiptHtml(
  sale: SaleTransaction,
  localName: string,
  rawConfig?: Partial<TenantInvoiceConfig> | null,
  tenantMeta?: TenantMetaForReceipt
): void {
  const html = buildThermalReceiptHtml(sale, localName, rawConfig, tenantMeta);
  triggerIframePrint(html);
}

export function buildEscPosCierreTicket(cierre: import('../types/pos').CierreRecord, localName: string): Uint8Array {
  const encoder = new TextEncoder();
  const chunks: number[] = [];
  const pushBytes = (...bytes: number[]) => chunks.push(...bytes);
  const pushText = (txt: string) => {
    const encoded = encoder.encode(asciiSafe(txt));
    encoded.forEach((b) => chunks.push(b));
  };

  pushBytes(0x1b, 0x40, 0x1b, 0x61, 0x01, 0x1b, 0x45, 0x01, 0x1d, 0x21, 0x01);
  pushText(`${localName || 'INNOVA GRUP'}\n`);
  pushBytes(0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00);
  pushText(`CIERRE DE CAJA DETALLADO\n`);
  pushText(`${cierre.fecha || ''} ${cierre.hora || ''}\n`);
  pushText(`--------------------------------\n`);

  pushBytes(0x1b, 0x61, 0x00);
  pushText(`Autorizado/Operador:\n  ${asciiSafe(cierre.cerrado_por || 'Admin').slice(0, 28)}\n`);
  pushText(row32('Transacciones:', String(cierre.cantidad_ventas || 0)));
  pushText(`--------------------------------\n`);
  pushBytes(0x1b, 0x45, 0x01);
  pushText(`DESGLOSE POR METODO\n`);
  pushBytes(0x1b, 0x45, 0x00);

  const mBs = cierre.totales_metodos_ves || {};
  const mUsd = cierre.totales_metodos_usd || {};
  Object.keys(mBs).forEach((m) => {
    const label = m === 'Cashea' ? 'Cashea (Inicial)' : m;
    pushText(row32(label.slice(0, 18), `${formatMoney(mBs[m])} Bs`));
    pushText(row32('', `$${Number(mUsd[m] || 0).toFixed(2)} USD`));
  });

  const prods = Array.isArray(cierre.productos_vendidos)
    ? cierre.productos_vendidos
    : cierre.productos_vendidos
    ? Object.values(cierre.productos_vendidos as Record<string, import('../types/pos').CierreProductoSummary>)
    : [];

  if (prods.length > 0) {
    pushText(`--------------------------------\n`);
    pushBytes(0x1b, 0x45, 0x01);
    pushText(`PRODUCTOS VENDIDOS (${prods.length})\n`);
    pushBytes(0x1b, 0x45, 0x00);
    prods.slice(0, 80).forEach((p) => {
      const q = Math.round((Number(p.cantidad) || 0) * 100) / 100;
      pushText(`${q}x ${asciiSafe(p.nombre).slice(0, 24)}\n`);
      pushText(row32('', `${formatMoney(p.total_ves)} Bs`));
    });
  }

  pushText(`--------------------------------\n`);
  if ((cierre.total_iva_ves || 0) > 0) {
    pushText(row32('IVA Recaudado:', `${formatMoney(cierre.total_iva_ves)} Bs`));
  }
  if ((cierre.cashea_pendiente_usd || 0) > 0) {
    pushText(row32('Pendiente Cashea:', `$${Number(cierre.cashea_pendiente_usd).toFixed(2)}`));
  }
  pushBytes(0x1b, 0x45, 0x01, 0x1d, 0x21, 0x01);
  pushText(row32('TOTAL BS:', `${formatMoney(cierre.total_general_ves)}`));
  pushText(row32('TOTAL USD:', `$${Number(cierre.total_general_usd || 0).toFixed(2)}`));
  pushBytes(0x1d, 0x21, 0x00, 0x1b, 0x45, 0x00);
  pushText(`--------------------------------\n`);
  pushBytes(0x1b, 0x61, 0x01);
  pushText(`Cierre verificado en sistema\nInnova Grup POS\n\n\n`);
  pushBytes(0x1d, 0x56, 0x41, 0x03);
  return new Uint8Array(chunks);
}

function triggerIframePrint(html: string) {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(html);
    doc.close();
    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      } finally {
        setTimeout(() => iframe.remove(), 2500);
      }
    }, 300);
  } else {
    iframe.remove();
  }
}

export function printBrowserCierreHtml(
  cierre: import('../types/pos').CierreRecord,
  localName: string,
  rawConfig?: Partial<TenantInvoiceConfig> | null
): void {
  const cfg = mergeInvoiceConfig(rawConfig);
  const paperWidthMm = cfg.ancho_papel === '58mm' ? '54mm' : '74mm';
  const mBs = cierre.totales_metodos_ves || {};
  const mUsd = cierre.totales_metodos_usd || {};
  const methodsHtml = Object.keys(mBs)
    .map(
      (m) => `<tr>
        <td style="padding:3px 0;">${String(m === 'Cashea' ? 'Cashea (Inicial)' : m).replace(/</g, '&lt;')}</td>
        <td style="text-align:right;font-family:monospace;">${formatMoney(mBs[m])} Bs ($${Number(mUsd[m] || 0).toFixed(2)})</td>
      </tr>`
    )
    .join('');

  const prods = Array.isArray(cierre.productos_vendidos)
    ? cierre.productos_vendidos
    : cierre.productos_vendidos
    ? Object.values(cierre.productos_vendidos as Record<string, import('../types/pos').CierreProductoSummary>)
    : [];
  const prodsHtml = prods
    .map((p) => {
      const q = Math.round((Number(p.cantidad) || 0) * 100) / 100;
      return `<tr>
        <td style="padding:2px 0;">${q}x ${String(p.nombre).replace(/</g, '&lt;')}</td>
        <td style="text-align:right;font-family:monospace;">${formatMoney(p.total_ves)} Bs</td>
      </tr>`;
    })
    .join('');

  const logoBlock =
    cfg.mostrar_logo && cfg.logo_data_url
      ? `<div style="text-align:center;margin-bottom:5px;"><img src="${cfg.logo_data_url}" alt="Logo" style="max-width:40mm;max-height:16mm;object-fit:contain;margin:0 auto;display:block;" /></div>`
      : '';

  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Cierre ${cierre.fecha}</title>
  <style>
    @page { margin: 3mm; size: ${cfg.ancho_papel} auto; }
    body { font-family: monospace; width: ${paperWidthMm}; margin: 0 auto; font-size: 11.5px; color: #111; }
    h2 { margin: 0 0 4px; text-align: center; font-size: 15px; }
    .c { text-align: center; font-size: 11px; color: #444; }
    hr { border: none; border-top: 1px dashed #666; margin: 6px 0; }
    table { width: 100%; border-collapse: collapse; }
    .tot { font-weight: bold; font-size: 13.5px; }
  </style></head><body>
    ${logoBlock}
    <h2>${String(localName || 'INNOVA GRUP').replace(/</g, '&lt;')}</h2>
    <div class="c"><b>CIERRE DE CAJA DETALLADO</b></div>
    <div class="c">${cierre.fecha || ''} · ${cierre.hora || ''}</div>
    <hr />
    <div>Operador: ${String(cierre.cerrado_por || 'Admin').replace(/</g, '&lt;')}</div>
    <div>Transacciones: ${cierre.cantidad_ventas || 0}</div>
    <hr />
    <div><b>DESGLOSE POR METODO</b></div>
    <table>${methodsHtml || '<tr><td>Sin movimientos</td></tr>'}</table>
    ${
      prodsHtml
        ? `<hr /><div><b>PRODUCTOS VENDIDOS</b></div><table>${prodsHtml}</table>`
        : ''
    }
    <hr />
    <table>
      ${(cierre.total_iva_ves || 0) > 0 ? `<tr><td>IVA Total:</td><td style="text-align:right;">${formatMoney(cierre.total_iva_ves)} Bs</td></tr>` : ''}
      ${(cierre.cashea_pendiente_usd || 0) > 0 ? `<tr><td>Pendiente Cashea:</td><td style="text-align:right;">$${Number(cierre.cashea_pendiente_usd).toFixed(2)}</td></tr>` : ''}
      <tr class="tot"><td>TOTAL VES:</td><td style="text-align:right;">${formatMoney(cierre.total_general_ves)} Bs</td></tr>
      <tr class="tot"><td>EQUIV. USD:</td><td style="text-align:right;">$${Number(cierre.total_general_usd || 0).toFixed(2)}</td></tr>
    </table>
    <hr />
    <div class="c">Copia de Cierre · Innova Grup POS</div>
  </body></html>`;
  triggerIframePrint(html);
}

export interface RateSignPrintOptions {
  localName: string;
  razonSocial?: string;
  rif?: string;
  direccion?: string;
  telefono?: string;
  tasaBcv: number;
  tasaSecundaria?: number;
  tasaTerciaria?: number;
  showParalelo?: boolean;
  nota?: string;
  theme?: 'clasico' | 'moderno' | 'minimal';
}

export function printRateSignHtml(opts: RateSignPrintOptions): void {
  const esc = (s?: string) => String(s || '').replace(/</g, '&lt;');
  const isDark = opts.theme === 'moderno';
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Tasa BCV - ${esc(opts.localName)}</title>
  <style>
    @page { size: A4; margin: 12mm; }
    body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 24px; color: #0f172a; }
    .card { border: 3px solid #0f172a; border-radius: 20px; padding: 36px; text-align: center; background: ${isDark ? '#0f172a' : '#ffffff'}; color: ${isDark ? '#f8fafc' : '#0f172a'}; }
    .store { font-size: 34px; font-weight: 900; letter-spacing: -0.02em; margin-bottom: 6px; }
    .meta { font-size: 14px; opacity: 0.78; margin-bottom: 24px; line-height: 1.5; }
    .rate-box { border: 2px dashed ${isDark ? '#38bdf8' : '#0284c7'}; border-radius: 18px; padding: 28px 20px; margin: 20px auto; max-width: 520px; background: ${isDark ? 'rgba(56,189,248,0.1)' : '#f0f9ff'}; }
    .label { font-size: 16px; font-weight: 800; letter-spacing: 0.14em; text-transform: uppercase; color: ${isDark ? '#38bdf8' : '#0369a1'}; }
    .value { font-family: ui-monospace, monospace; font-size: 68px; font-weight: 900; margin: 10px 0; color: ${isDark ? '#ffffff' : '#0c4a6e'}; }
    .sub { font-size: 15px; font-weight: 600; opacity: 0.85; }
    .par-grid { display: flex; justify-content: center; gap: 20px; margin-top: 20px; }
    .par-box { border: 1px solid ${isDark ? '#334155' : '#cbd5e1'}; border-radius: 12px; padding: 12px 24px; }
    .foot { margin-top: 26px; font-size: 13px; opacity: 0.72; }
  </style></head><body>
    <div class="card">
      <div class="store">${esc(opts.localName || 'MI COMERCIO')}</div>
      <div class="meta">
        ${opts.razonSocial ? `<div><b>${esc(opts.razonSocial)}</b></div>` : ''}
        ${opts.rif ? `<div>RIF: ${esc(opts.rif)}</div>` : ''}
        ${opts.direccion ? `<div>${esc(opts.direccion)}</div>` : ''}
        ${opts.telefono ? `<div>Tel: ${esc(opts.telefono)}</div>` : ''}
      </div>
      <div class="rate-box">
        <div class="label">TASA OFICIAL BCV DEL DÍA</div>
        <div class="value">${Number(opts.tasaBcv || 0).toFixed(2)} Bs</div>
        <div class="sub">1 USD ($) = ${Number(opts.tasaBcv || 0).toFixed(2)} Bolívares</div>
      </div>
      ${
        opts.showParalelo && ((opts.tasaSecundaria || 0) > 0 || (opts.tasaTerciaria || 0) > 0)
          ? `<div class="par-grid">
              ${(opts.tasaSecundaria || 0) > 0 ? `<div class="par-box"><div style="font-size:11px;font-weight:700;">TASA REFERENCIA 1</div><div style="font-size:22px;font-weight:800;font-family:monospace;">${Number(opts.tasaSecundaria).toFixed(2)} Bs</div></div>` : ''}
              ${(opts.tasaTerciaria || 0) > 0 ? `<div class="par-box"><div style="font-size:11px;font-weight:700;">TASA REFERENCIA 2</div><div style="font-size:22px;font-weight:800;font-family:monospace;">${Number(opts.tasaTerciaria).toFixed(2)} Bs</div></div>` : ''}
            </div>`
          : ''
      }
      <div class="foot">
        <div>${esc(opts.nota || 'Precios calculados a la tasa oficial vigente.')}</div>
        <div style="margin-top:6px;">Fecha de emisión: ${new Date().toLocaleDateString('es-VE')} · ${new Date().toLocaleTimeString('es-VE', { hour: '2-digit', minute: '2-digit' })}</div>
      </div>
    </div>
  </body></html>`;
  triggerIframePrint(html);
}

export interface PrintableLabelEntry {
  nombre: string;
  barcode: string;
  categoria?: string;
  priceUsd: number;
  priceBs: number;
  priceAltBs?: number;
  svgBarcode?: string;
}

export interface LabelsPrintOptions {
  localName: string;
  format: 'gondola-50x30' | 'termica-58' | 'mini-40x20' | 'carta-grid';
  design: 'clasica' | 'dual' | 'compacta' | 'oferta';
  showStoreName: boolean;
  showCategory: boolean;
  showUsd: boolean;
  showBcvBs: boolean;
  showBarcode: boolean;
  labels: PrintableLabelEntry[];
}

export function printLabelsHtml(opts: LabelsPrintOptions): void {
  const esc = (s?: string) => String(s || '').replace(/</g, '&lt;');
  const dims =
    opts.format === 'termica-58'
      ? { w: '54mm', h: '34mm', cols: 'repeat(1, 54mm)' }
      : opts.format === 'mini-40x20'
      ? { w: '40mm', h: '22mm', cols: 'repeat(4, 40mm)' }
      : opts.format === 'carta-grid'
      ? { w: '62mm', h: '34mm', cols: 'repeat(3, 62mm)' }
      : { w: '50mm', h: '30mm', cols: 'repeat(3, 50mm)' };

  const cardsHtml = opts.labels
    .map((lb) => {
      const borderStyle =
        opts.design === 'oferta'
          ? '2px solid #dc2626'
          : opts.design === 'dual'
          ? '1.5px solid #0284c7'
          : '1px solid #334155';
      const headerBg = opts.design === 'oferta' ? '#dc2626' : opts.design === 'dual' ? '#0f172a' : 'transparent';
      const headerColor = opts.design === 'oferta' || opts.design === 'dual' ? '#ffffff' : '#334155';
      return `<div class="lbl" style="border:${borderStyle};">
        ${
          opts.showStoreName
            ? `<div class="hdr" style="background:${headerBg};color:${headerColor};">${esc(opts.localName)}</div>`
            : ''
        }
        <div class="name">${esc(lb.nombre)}</div>
        ${opts.showCategory && lb.categoria ? `<div class="cat">${esc(lb.categoria)}</div>` : ''}
        <div class="prices">
          ${opts.showUsd ? `<span class="usd">$${lb.priceUsd.toFixed(2)}</span>` : ''}
          ${opts.showBcvBs ? `<span class="bs">${formatMoney(lb.priceBs)} Bs</span>` : ''}
        </div>
        ${opts.showBarcode && lb.svgBarcode ? `<div class="bc">${lb.svgBarcode}</div>` : ''}
      </div>`;
    })
    .join('');

  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Etiquetas - ${esc(opts.localName)}</title>
  <style>
    @page { margin: ${opts.format === 'termica-58' ? '2mm' : '8mm'}; }
    body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 0; color: #0f172a; }
    .grid { display: grid; grid-template-columns: ${dims.cols}; gap: ${opts.format === 'termica-58' ? '3mm' : '4mm'}; justify-content: center; }
    .lbl { width: ${dims.w}; min-height: ${dims.h}; box-sizing: border-box; padding: 2mm; border-radius: 3px; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; break-inside: avoid; page-break-inside: avoid; }
    .hdr { font-size: 7.5px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; padding: 1px 4px; border-radius: 2px; text-align: center; margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .name { font-size: ${opts.format === 'mini-40x20' ? '8.5px' : '10px'}; font-weight: 800; line-height: 1.15; max-height: 2.3em; overflow: hidden; text-align: center; }
    .cat { font-size: 7px; color: #64748b; text-align: center; }
    .prices { display: flex; align-items: baseline; justify-content: center; gap: 6px; margin: 2px 0; }
    .usd { font-family: ui-monospace, monospace; font-size: ${opts.format === 'mini-40x20' ? '11px' : '14px'}; font-weight: 900; color: #0f172a; }
    .bs { font-family: ui-monospace, monospace; font-size: ${opts.format === 'mini-40x20' ? '9px' : '11px'}; font-weight: 700; color: #0369a1; }
    .bc { text-align: center; line-height: 0; }
    .bc svg { max-width: 100%; height: ${opts.format === 'mini-40x20' ? '18px' : '24px'}; }
  </style></head><body><div class="grid">${cardsHtml}</div></body></html>`;
  triggerIframePrint(html);
}

export { padLeft };
