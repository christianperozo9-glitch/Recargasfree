import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  initializeFirestore,
  doc,
  getDocFromServer,
  type Firestore,
} from 'firebase/firestore';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendEmailVerification,
  signOut,
  sendPasswordResetEmail,
  EmailAuthProvider,
  reauthenticateWithCredential,
  multiFactor,
  TotpMultiFactorGenerator,
  getMultiFactorResolver,
  type MultiFactorResolver,
  type TotpSecret,
  type User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export const MASTER_OWNER_EMAIL = 'christianperozo9@gmail.com';
export const FIREBASE_PROJECT_ID = firebaseConfig.projectId;
export const FIRESTORE_DATABASE_ID = firebaseConfig.firestoreDatabaseId;

export const firebaseApp: FirebaseApp =
  getApps().find((a) => a.name === '[DEFAULT]') || initializeApp(firebaseConfig);

function createResilientFirestore(): Firestore {
  try {
    return initializeFirestore(
      firebaseApp,
      { experimentalAutoDetectLongPolling: true },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    return getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
  }
}

export const db: Firestore = createResilientFirestore();
export const auth = getAuth(firebaseApp);

// Secondary app instance so Master Owner can register new client auth accounts
// without signing out of their own Master Owner session.
const PROVISIONING_APP_NAME = 'tenant-provisioner';
function getProvisioningAuth() {
  const existing = getApps().find((a) => a.name === PROVISIONING_APP_NAME);
  const app = existing || initializeApp(firebaseConfig, PROVISIONING_APP_NAME);
  return getAuth(app);
}

// Validate Firestore connection on initial boot
async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
if (typeof window !== 'undefined') {
  void testConnection();
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function buildFirestoreErrorInfo(
  error: unknown,
  operationType: OperationType,
  path: string | null
): FirestoreErrorInfo {
  return {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
}

export function logFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): void {
  const errInfo = buildFirestoreErrorInfo(error, operationType, path);
  // Suppress noisy permission errors during intentional logout transitions
  if (!auth.currentUser && /permission-denied|insufficient permissions/i.test(errInfo.error)) {
    return;
  }
  console.warn('Firestore Listener Warning:', JSON.stringify(errInfo));
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo = buildFirestoreErrorInfo(error, operationType, path);
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function sanitizeFirestoreId(raw: string, fallbackPrefix = 'id'): string {
  const cleaned = String(raw || '')
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .replace(/_+/g, '_')
    .slice(0, 120);
  if (!cleaned) return `${fallbackPrefix}_${Date.now()}`;
  return cleaned;
}

export function stripUndefined<T extends Record<string, unknown>>(obj: T): T {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) {
      out[k] = v;
    }
  }
  return out as T;
}

export async function hashPin(salt: string, pin: string): Promise<string> {
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const buf = await window.crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(`${salt}:${pin}`)
    );
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  let h = 5381;
  const input = salt + pin;
  for (let i = 0; i < input.length; i++) {
    h = ((h * 33) ^ input.charCodeAt(i)) >>> 0;
  }
  return 'x' + h;
}

export async function createPinCredentials(pin: string): Promise<{ salt: string; hash: string }> {
  const salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
  const hash = await hashPin(salt, pin);
  return { salt, hash };
}

export async function sendPasswordRecoveryEmail(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

export async function loginWithEmail(email: string, password: string): Promise<User> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
  return cred.user;
}

export async function loginWithGoogle(): Promise<User> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  const cred = await signInWithPopup(auth, provider);
  return cred.user;
}

export interface RegisterAuthResult {
  uid: string | null;
  authCreated: boolean;
  providerDisabled?: boolean;
  warning?: string;
}

export async function registerClientAuthAccount(
  email: string,
  password: string,
  displayName: string
): Promise<RegisterAuthResult> {
  const provAuth = getProvisioningAuth();
  try {
    const cred = await createUserWithEmailAndPassword(provAuth, email.trim().toLowerCase(), password);
    if (displayName.trim()) {
      await updateProfile(cred.user, { displayName: displayName.trim() }).catch(() => {});
    }
    await sendEmailVerification(cred.user).catch(() => {});
    const uid = cred.user.uid;
    await signOut(provAuth).catch(() => {});
    return { uid, authCreated: true };
  } catch (err) {
    const fbErr = err as { code?: string; message?: string };
    await signOut(provAuth).catch(() => {});
    if (fbErr?.code === 'auth/operation-not-allowed') {
      return {
        uid: null,
        authCreated: false,
        providerDisabled: true,
        warning:
          'El método Correo/Contraseña aún no está habilitado en Firebase Authentication. El cliente se guardó como pendiente y podrá ingresar con Google o tras habilitar Correo/Contraseña.',
      };
    }
    throw err;
  }
}

export async function logoutFirebase(): Promise<void> {
  await signOut(auth);
}

export async function reauthenticateCurrentUser(email: string, password: string): Promise<void> {
  const user = auth.currentUser;
  if (!user) throw new Error('No hay una sesión Firebase activa.');
  const credential = EmailAuthProvider.credential(email.trim(), password);
  await reauthenticateWithCredential(user, credential);
}

export async function verifyPasswordForEmail(email: string, password: string): Promise<boolean> {
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail || !password) return false;
  if (auth.currentUser?.email?.toLowerCase() === cleanEmail) {
    try {
      await reauthenticateCurrentUser(cleanEmail, password);
      return true;
    } catch {
      return false;
    }
  }
  const provAuth = getProvisioningAuth();
  try {
    await signInWithEmailAndPassword(provAuth, cleanEmail, password);
    await signOut(provAuth).catch(() => {});
    return true;
  } catch {
    await signOut(provAuth).catch(() => {});
    return false;
  }
}

export async function startTotpEnrollment(
  user: User,
  displayName = 'Innova Grup POS'
): Promise<{
  secret: TotpSecret;
  qrUri: string;
  secretKey: string;
}> {
  const session = await multiFactor(user).getSession();
  const secret = await TotpMultiFactorGenerator.generateSecret(session);
  const qrUri = secret.generateQrCodeUrl(user.email || 'usuario@innovagrup.com', displayName);
  return { secret, qrUri, secretKey: secret.secretKey };
}

export async function finalizeTotpEnrollment(
  user: User,
  secret: TotpSecret,
  verificationCode: string,
  factorDisplayName = 'App Autenticadora (TOTP)'
): Promise<void> {
  const assertion = TotpMultiFactorGenerator.assertionForEnrollment(secret, verificationCode.trim());
  await multiFactor(user).enroll(assertion, factorDisplayName);
}

export async function unenrollMfaFactor(user: User, factorUid: string): Promise<void> {
  await multiFactor(user).unenroll(factorUid);
}

export function extractMfaResolver(error: unknown): MultiFactorResolver | null {
  const err = error as { code?: string };
  if (err?.code === 'auth/multi-factor-auth-required') {
    return getMultiFactorResolver(auth, error as Parameters<typeof getMultiFactorResolver>[1]);
  }
  return null;
}

export async function resolveTotpMfaSignIn(
  resolver: MultiFactorResolver,
  factorUid: string,
  verificationCode: string
): Promise<User> {
  const assertion = TotpMultiFactorGenerator.assertionForSignIn(factorUid, verificationCode.trim());
  const cred = await resolver.resolveSignIn(assertion);
  return cred.user;
}
