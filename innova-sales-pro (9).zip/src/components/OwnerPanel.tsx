import React, { useEffect, useMemo, useState } from 'react';
import { doc, setDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import {
  AlertTriangle,
  BarChart3,
  Bell,
  BellRing,
  Bot,
  Building2,
  CheckCircle2,
  ClipboardCheck,
  ClipboardPaste,
  Clock,
  Copy,
  CreditCard,
  Crown,
  Database,
  ExternalLink,
  Eye,
  EyeOff,
  FileCheck2,
  FileText,
  Gift,
  KeyRound,
  LifeBuoy,
  Lock,
  LogOut,
  MessageCircle,
  MessageSquare,
  Package,
  Pause,
  Pencil,
  Phone,
  Play,
  Plus,
  Printer,
  RefreshCw,
  RotateCw,
  Scale,
  Search,
  Send,
  Settings2,
  Shield,
  Sliders,
  Snowflake,
  Sparkles,
  Store,
  Trash2,
  Upload,
  UserCheck,
  UserPlus,
  Users,
  Volume2,
  Wrench,
  X,
  XCircle,
} from 'lucide-react';
import {
  createPinCredentials,
  db,
  handleFirestoreError,
  MASTER_OWNER_EMAIL,
  OperationType,
  sendPasswordRecoveryEmail,
  stripUndefined,
} from '../lib/firebase';
import { DEFAULT_SCHEDULED_NOTICES, usePos } from '../context/PosContext';
import type {
  BroadcastConfig,
  MembershipPayment,
  MembershipPaymentMethod,
  MembershipPlan,
  PromoRecord,
  SupportTicket,
  TenantInvoiceConfig,
  TenantRecord,
} from '../types/pos';
import { compressImageFile, formatMoney, round2 } from '../utils/format';
import { formatRateNumber } from '../utils/currencies';
import { CurrencyRateManager } from './CurrencyRateManager';
import {
  generateContractPDF,
  generateDatabaseAuthorizationPDF,
  generateMembershipRenewalContractPDF,
  generateMembershipRenewalReceiptPDF,
  generateRenewalPDF,
} from '../utils/pdfGenerator';
import {
  bonusMonthsWithPromos,
  defaultPlans,
  describePromo,
  effectiveDiscountWithPromos,
} from '../utils/promotions';
import { AnalyticsView } from './AnalyticsView';
import { OwnerAiChatTab } from './OwnerAiChatTab';
import { OwnerClientInvoiceModal } from './OwnerClientInvoiceModal';
import { OwnerDailySalesChart } from './OwnerDailySalesChart';
import { OwnerPreRegistrationsTab } from './OwnerPreRegistrationsTab';
import { OwnerSeniatTab } from './OwnerSeniatTab';
import { OwnerVerificationModal } from './OwnerVerificationModal';
import { ProductThumb } from './ProductThumb';
import { PWAInstallButton } from './PWAInstallButton';
import { UserManagementTab } from './UserManagementTab';
import { ViewModeToggle } from './ViewModeToggle';
import { buildDefaultVerificationRequisitos } from '../constants/verificationRequirements';

interface OwnerPanelProps {
  onOpenSecurity: () => void;
  onEnterPos: () => void;
}

type OwnerTab =
  | 'overview'
  | 'clients'
  | 'seniat'
  | 'preregistrations'
  | 'aichat'
  | 'analytics'
  | 'users'
  | 'notifications'
  | 'inventory'
  | 'membership'
  | 'support';

type ClientFilter = 'all' | 'active' | 'expiring' | 'expired';

export const OwnerPanel: React.FC<OwnerPanelProps> = ({ onOpenSecurity, onEnterPos }) => {
  const {
    tenants,
    preRegistrations,
    activeTenantId,
    setActiveTenantId,
    activeTenant,
    platformConfig,
    updatePlatformConfig,
    updateTenantSettings,
    updateTenantRecord,
    registerNewTenantClient,
    deleteTenantNode,
    saveTenantVerificationConfig,
    reviewTenantVerificationDoc,
    localName,
    config,
    bcvRate,
    secondaryRate,
    localCurrency,
    localCurrencyCode,
    products,
    liveSales,
    cashiers,
    systemUsers,
    tickets,
    membership,
    membershipExpired,
    avisoMembresia,
    plans,
    planLinks,
    promos,
    pagoMovil,
    metodosPagoMembresia,
    membershipPayments,
    notificationHistory,
    adminAccessBlocked,
    userFrozen,
    maintenanceMode,
    globalMaintenance,
    maintenanceMessage,
    voiceSettings,
    operatorEmail,
    viewMode,
    isMobileLayout,
    isWideViewport,
    pushSupported,
    pushPermission,
    pushEnabled,
    togglePushNotifications,
    sendTestPushNotification,
    syncAllRates,
    ratesSyncing,
    syncBcvRate,
    syncUsdtRate,
    speakText,
    notifyToast,
    playBeep,
    logout,
  } = usePos();

  const [tab, setTab] = useState<OwnerTab>('overview');

  // Client Directory Filters & Modals
  const [clientSearch, setClientSearch] = useState('');
  const [clientFilter, setClientFilter] = useState<ClientFilter>('all');
  const [showNewClientModal, setShowNewClientModal] = useState(false);
  const [creatingClient, setCreatingClient] = useState(false);
  const [newCliEmail, setNewCliEmail] = useState('');
  const [newCliPass, setNewCliPass] = useState('');
  const [showNewCliPass, setShowNewCliPass] = useState(false);
  const [newCliLocal, setNewCliLocal] = useState('');
  const [newCliRazon, setNewCliRazon] = useState('');
  const [newCliRif, setNewCliRif] = useState('');
  const [newCliDir, setNewCliDir] = useState('');
  const [newCliTel, setNewCliTel] = useState('');
  const [newCliContacto, setNewCliContacto] = useState('');
  const [newCliAdminPin, setNewCliAdminPin] = useState('1234');
  const [newCliCajaPin, setNewCliCajaPin] = useState('0000');
  const [newCliCajeroName, setNewCliCajeroName] = useState('Cajero Principal');
  const [newCliPlan, setNewCliPlan] = useState<string>(Object.keys(plans)[0] || 'p1');
  const [newCliMetaUsd, setNewCliMetaUsd] = useState('500');
  const [providerWarning, setProviderWarning] = useState<string | null>(null);

  // Edit Client Fiscal & Credentials Modal
  const [editingClient, setEditingClient] = useState<TenantRecord | null>(null);
  const [editCliEmail, setEditCliEmail] = useState('');
  const [editCliAdminPin, setEditCliAdminPin] = useState('');
  const [editCliCajaPin, setEditCliCajaPin] = useState('');
  const [editCliLocal, setEditCliLocal] = useState('');
  const [editCliRazon, setEditCliRazon] = useState('');
  const [editCliRif, setEditCliRif] = useState('');
  const [editCliDir, setEditCliDir] = useState('');
  const [editCliTel, setEditCliTel] = useState('');
  const [editCliContacto, setEditCliContacto] = useState('');
  const [editCliActivo, setEditCliActivo] = useState(true);
  const [savingEditClient, setSavingEditClient] = useState(false);

  // Generic In-App Confirm Modal (replaces browser confirm())
  const [ownerConfirm, setOwnerConfirm] = useState<{
    title: string;
    message: string;
    confirmLabel?: string;
    danger?: boolean;
    onConfirm: () => Promise<void>;
  } | null>(null);
  const [runningOwnerConfirm, setRunningOwnerConfirm] = useState(false);

  // Global System Maintenance controls (Owner Panel NEVER goes into maintenance)
  const [globalMaintMsgDraft, setGlobalMaintMsgDraft] = useState(maintenanceMessage);
  const [savingGlobalMaint, setSavingGlobalMaint] = useState(false);

  // Global SENIAT Venezuela Legal Invoicing controls (applies to ALL clients)
  const seniatLegalActivo = platformConfig.seniat_legal_activo === true;
  const [seniatProvidenciaDraft, setSeniatProvidenciaDraft] = useState(
    platformConfig.seniat_providencia || 'Providencia Administrativa SNAT/2011/00071'
  );
  const [seniatPieLegalDraft, setSeniatPieLegalDraft] = useState(
    platformConfig.seniat_pie_legal ||
      'DOCUMENTO EMITIDO BAJO NORMATIVA FISCAL SENIAT — REPÚBLICA BOLIVARIANA DE VENEZUELA'
  );
  const [savingSeniat, setSavingSeniat] = useState(false);

  const pendingPreRegsCount = useMemo(
    () => preRegistrations.filter((p) => p.estado === 'pendiente').length,
    [preRegistrations]
  );

  useEffect(() => {
    setGlobalMaintMsgDraft(maintenanceMessage);
  }, [maintenanceMessage]);

  useEffect(() => {
    if (platformConfig.seniat_providencia) {
      setSeniatProvidenciaDraft(platformConfig.seniat_providencia);
    }
    if (platformConfig.seniat_pie_legal) {
      setSeniatPieLegalDraft(platformConfig.seniat_pie_legal);
    }
  }, [platformConfig.seniat_providencia, platformConfig.seniat_pie_legal]);

  // Store & Goal editors (scoped to activeTenantId)
  const [storeNameDraft, setStoreNameDraft] = useState(localName);
  const [metaUsdDraft, setMetaUsdDraft] = useState(String(config.meta_usd || 0));

  // Broadcast composer
  const [bcTitle, setBcTitle] = useState('Aviso de Gerencia');
  const [bcText, setBcText] = useState('');
  const [bcType, setBcType] = useState<BroadcastConfig['tipo']>('info');
  const [bcAudience, setBcAudience] = useState<'all' | 'cashier' | 'admin'>('all');
  const [bcVoice, setBcVoice] = useState(true);
  const [sendingBc, setSendingBc] = useState(false);

  // Membership warning (aviso_membresia) editor
  const [avDias, setAvDias] = useState(String(avisoMembresia.dias));
  const [avTitulo, setAvTitulo] = useState(avisoMembresia.titulo);
  const [avMsg, setAvMsg] = useState(avisoMembresia.msg);
  const [avActivo, setAvActivo] = useState(avisoMembresia.activo);
  const [newNoticeHora, setNewNoticeHora] = useState('14:00');
  const [newNoticeMsg, setNewNoticeMsg] = useState('');

  // Membership manual adjustments & Pago Móvil
  const [daysInput, setDaysInput] = useState('30');
  const [clientDaysDrafts, setClientDaysDrafts] = useState<Record<string, string>>({});
  const [selectedPlanToApply, setSelectedPlanToApply] = useState<string>(Object.keys(plans)[0] || 'p1');
  const [waMembresia, setWaMembresia] = useState(config.whatsapp_membresia || '');
  const [pmBanco, setPmBanco] = useState(pagoMovil?.banco || '');
  const [pmTel, setPmTel] = useState(pagoMovil?.tel || '');
  const [pmCi, setPmCi] = useState(pagoMovil?.ci || '');
  const [pmTitular, setPmTitular] = useState(pagoMovil?.titular || '');
  const [previewCaptura, setPreviewCaptura] = useState<string | null>(null);

  // Plans & Payment Links CRUD
  const [editingPlanKey, setEditingPlanKey] = useState<string | null>(null);
  const [planNameDraft, setPlanNameDraft] = useState('');
  const [planMesesDraft, setPlanMesesDraft] = useState('1');
  const [planPrecioDraft, setPlanPrecioDraft] = useState('10');
  const [planOfertaDraft, setPlanOfertaDraft] = useState('0');
  const [planLinkDraft, setPlanLinkDraft] = useState('');

  // Additional Membership Payment Methods CRUD
  const [editingMethodId, setEditingMethodId] = useState<string | null>(null);
  const [methodTipo, setMethodTipo] = useState<MembershipPaymentMethod['tipo']>('zelle');
  const [methodTitulo, setMethodTitulo] = useState('');
  const [methodDetalle, setMethodDetalle] = useState('');
  const [methodTitular, setMethodTitular] = useState('');
  const [methodDoc, setMethodDoc] = useState('');
  const [methodActivo, setMethodActivo] = useState(true);

  // Per-client Membership Renewal Contract Modal (requires selecting plan before PDF)
  const [renewalContractClient, setRenewalContractClient] = useState<TenantRecord | null>(null);
  const [renewalContractPlanKey, setRenewalContractPlanKey] = useState('');
  const [renewalContractApplyPlan, setRenewalContractApplyPlan] = useState(false);
  const [generatingContractPdf, setGeneratingContractPdf] = useState(false);

  // Per-client Thermal Invoice Format, Store Logo & Default Printer Configurator
  const [invoiceConfigClient, setInvoiceConfigClient] = useState<TenantRecord | null>(null);

  // Per-client Data Verification & Update Request Modal
  const [verificationClient, setVerificationClient] = useState<TenantRecord | null>(null);

  // New Client initial logo & invoice format drafts
  const [newCliLogoUrl, setNewCliLogoUrl] = useState('');
  const [newCliPaperWidth, setNewCliPaperWidth] = useState<'58mm' | '80mm'>('80mm');
  const [newCliInvoiceFont, setNewCliInvoiceFont] = useState<TenantInvoiceConfig['fuente']>('mono');
  const [newCliInvoiceColor, setNewCliInvoiceColor] = useState('#0f172a');
  const [newCliIntensity, setNewCliIntensity] =
    useState<NonNullable<TenantInvoiceConfig['intensidad_impresion']>>('normal');
  const [uploadingNewCliLogo, setUploadingNewCliLogo] = useState(false);

  // Owner Editable Support WhatsApp Numbers & Schedule (used by AI Support Assistant escalation)
  const [waSoporteDraft, setWaSoporteDraft] = useState(config.whatsapp_soporte || '');
  const [waSoporteSecDraft, setWaSoporteSecDraft] = useState(
    config.whatsapp_soporte_secundario || ''
  );
  const [soporteHorarioDraft, setSoporteHorarioDraft] = useState(
    config.soporte_horario || 'Lunes a Sábado · 8:00 AM - 7:00 PM'
  );
  const [savingSupportNums, setSavingSupportNums] = useState(false);

  // Sync controlled drafts whenever active tenant or platform config updates
  useEffect(() => {
    setStoreNameDraft(localName);
  }, [localName]);

  useEffect(() => {
    setMetaUsdDraft(String(config.meta_usd ?? 0));
  }, [config.meta_usd]);

  useEffect(() => {
    if (config.whatsapp_membresia !== undefined) setWaMembresia(config.whatsapp_membresia);
  }, [config.whatsapp_membresia]);

  useEffect(() => {
    setWaSoporteDraft(config.whatsapp_soporte || '');
    setWaSoporteSecDraft(config.whatsapp_soporte_secundario || '');
    setSoporteHorarioDraft(config.soporte_horario || 'Lunes a Sábado · 8:00 AM - 7:00 PM');
  }, [config.whatsapp_soporte, config.whatsapp_soporte_secundario, config.soporte_horario]);

  useEffect(() => {
    if (pagoMovil) {
      setPmBanco(pagoMovil.banco || '');
      setPmTel(pagoMovil.tel || '');
      setPmCi(pagoMovil.ci || '');
      setPmTitular(pagoMovil.titular || '');
    }
  }, [pagoMovil]);

  useEffect(() => {
    setAvDias(String(avisoMembresia.dias));
    setAvTitulo(avisoMembresia.titulo);
    setAvMsg(avisoMembresia.msg);
    setAvActivo(avisoMembresia.activo);
  }, [avisoMembresia]);

  // Promo builder (Create & Edit)
  const [editingPromoId, setEditingPromoId] = useState<string | null>(null);
  const [promoName, setPromoName] = useState('');
  const [promoType, setPromoType] = useState<PromoRecord['tipo']>('pct');
  const [promoVal, setPromoVal] = useState('20');
  const [promoX, setPromoX] = useState('2');
  const [promoY, setPromoY] = useState('3');
  const [promoRepeat, setPromoRepeat] = useState(false);
  const [promoActive, setPromoActive] = useState(true);
  const [promoDesde, setPromoDesde] = useState('');
  const [promoHasta, setPromoHasta] = useState('');
  const [promoAplicaAll, setPromoAplicaAll] = useState(true);
  const [promoAplicaMeses, setPromoAplicaMeses] = useState<number[]>([1, 3, 6, 12]);

  // Support replies
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});

  // Inventory filter inside Owner oversight
  const [invSearch, setInvSearch] = useState('');

  const openTicketsCount = useMemo(
    () => tickets.filter((t) => t.estado !== 'resuelto').length,
    [tickets]
  );
  const pendingPaymentsCount = useMemo(
    () => membershipPayments.filter((p) => p.estado === 'pendiente').length,
    [membershipPayments]
  );

  const liveShiftUsd = useMemo(
    () => liveSales.reduce((s, v) => s + (Number(v.monto_total_usd_bcv) || 0), 0),
    [liveSales]
  );

  const criticalProducts = useMemo(() => {
    const q = invSearch.trim().toLowerCase();
    return products.filter(
      (p) => !q || (p.id || '').toLowerCase().includes(q) || (p.barcode || '').toLowerCase().includes(q)
    );
  }, [invSearch, products]);

  // Client directory KPIs & filtering
  const clientStats = useMemo(() => {
    const now = Date.now();
    let active = 0;
    let expiring = 0;
    let expired = 0;
    tenants.forEach((t) => {
      const m = t.membresia;
      const isSuspOrExp =
        t.activo === false ||
        t.congelado === true ||
        m?.estado === 'suspendida' ||
        !m?.vence ||
        m.vence <= now;
      if (isSuspOrExp) {
        expired++;
      } else {
        active++;
        const daysLeft = Math.ceil((m.vence - now) / 86_400_000);
        if (daysLeft <= 5) expiring++;
      }
    });
    return { total: tenants.length, active, expiring, expired };
  }, [tenants]);

  const filteredClients = useMemo(() => {
    const q = clientSearch.trim().toLowerCase();
    const now = Date.now();
    return tenants.filter((t) => {
      const m = t.membresia;
      const isExp =
        t.activo === false ||
        t.congelado === true ||
        m?.estado === 'suspendida' ||
        !m?.vence ||
        m.vence <= now;
      const daysLeft = m?.vence ? Math.ceil((m.vence - now) / 86_400_000) : 0;

      if (clientFilter === 'active' && isExp) return false;
      if (clientFilter === 'expiring' && (isExp || daysLeft > 5)) return false;
      if (clientFilter === 'expired' && !isExp) return false;

      if (!q) return true;
      return (
        t.nombre_local.toLowerCase().includes(q) ||
        t.email.toLowerCase().includes(q) ||
        (t.rif || '').toLowerCase().includes(q) ||
        (t.razon_social || '').toLowerCase().includes(q) ||
        (t.contacto_nombre || '').toLowerCase().includes(q) ||
        t.id.toLowerCase().includes(q)
      );
    });
  }, [clientFilter, clientSearch, tenants]);

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#';
    let pass = 'IG';
    for (let i = 0; i < 8; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewCliPass(pass);
    setShowNewCliPass(true);
  };

  const handleRegisterNewClient = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = newCliEmail.trim().toLowerCase();
    const cleanLocal = newCliLocal.trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      notifyToast('Ingresa un correo electrónico válido para el cliente.', 'warning');
      return;
    }
    if (newCliPass.length < 6) {
      notifyToast('La contraseña debe tener al menos 6 caracteres.', 'warning');
      return;
    }
    if (!cleanLocal) {
      notifyToast('Ingresa el nombre comercial del negocio.', 'warning');
      return;
    }
    if (newCliAdminPin.trim() && (newCliAdminPin.trim().length < 4 || newCliAdminPin.trim().length > 8)) {
      notifyToast('El PIN Administrativo debe tener entre 4 y 8 dígitos.', 'warning');
      return;
    }
    if (newCliCajaPin.trim() && (newCliCajaPin.trim().length < 4 || newCliCajaPin.trim().length > 8)) {
      notifyToast('El PIN de Caja debe tener entre 4 y 8 dígitos.', 'warning');
      return;
    }

    setCreatingClient(true);
    try {
      const { tenant, authResult } = await registerNewTenantClient({
        email: cleanEmail,
        password: newCliPass,
        nombre_local: cleanLocal,
        razon_social: newCliRazon.trim(),
        rif: newCliRif.trim(),
        direccion_fiscal: newCliDir.trim(),
        telefono: newCliTel.trim(),
        contacto_nombre: newCliContacto.trim(),
        admin_pin: newCliAdminPin.trim(),
        caja_pin: newCliCajaPin.trim(),
        cajero_nombre: newCliCajeroName.trim(),
        plan_key: newCliPlan,
        meta_usd: Number(newCliMetaUsd) || 500,
        logo_url: newCliLogoUrl || undefined,
        invoice_config: {
          ancho_papel: newCliPaperWidth,
          fuente: newCliInvoiceFont,
          color_factura: newCliInvoiceColor,
          intensidad_impresion: newCliIntensity,
          mostrar_logo: Boolean(newCliLogoUrl),
          logo_data_url: newCliLogoUrl || '',
        },
      });

      if (authResult.providerDisabled && authResult.warning) {
        setProviderWarning(authResult.warning);
      }

      playBeep('ok');
      notifyToast(
        `Cliente "${tenant.nombre_local}" registrado en nodo aislado (${tenant.id}).`,
        'success'
      );
      setShowNewClientModal(false);
      setNewCliEmail('');
      setNewCliPass('');
      setNewCliLocal('');
      setNewCliRazon('');
      setNewCliRif('');
      setNewCliDir('');
      setNewCliTel('');
      setNewCliContacto('');
      setNewCliLogoUrl('');
      setNewCliPaperWidth('80mm');
      setNewCliInvoiceFont('mono');
      setNewCliInvoiceColor('#0f172a');
      setNewCliIntensity('normal');
      setTab('clients');
    } catch (err) {
      playBeep('err');
      const fbErr = err as { code?: string; message?: string };
      if (fbErr?.code === 'auth/email-already-in-use') {
        notifyToast('Ese correo ya tiene una cuenta registrada en Firebase Auth.', 'error');
      } else {
        notifyToast(err instanceof Error ? err.message : 'Error registrando cliente.', 'error');
      }
    } finally {
      setCreatingClient(false);
    }
  };

  const openEditClientModal = (t: TenantRecord) => {
    setEditingClient(t);
    setEditCliEmail(t.email || '');
    setEditCliAdminPin('');
    setEditCliCajaPin('');
    setEditCliLocal(t.nombre_local || '');
    setEditCliRazon(t.razon_social || '');
    setEditCliRif(t.rif || '');
    setEditCliDir(t.direccion_fiscal || '');
    setEditCliTel(t.telefono || '');
    setEditCliContacto(t.contacto_nombre || '');
    setEditCliActivo(t.activo !== false);
  };

  const handleSaveEditClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClient) return;
    const cleanEmail = editCliEmail.trim().toLowerCase();
    const cleanAdminPin = editCliAdminPin.trim();
    const cleanCajaPin = editCliCajaPin.trim();
    if (!editCliLocal.trim()) {
      notifyToast('El nombre comercial es obligatorio.', 'warning');
      return;
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      notifyToast('Ingresa un correo electrónico válido para el cliente.', 'warning');
      return;
    }
    if (cleanAdminPin && !/^\d{4,12}$/.test(cleanAdminPin)) {
      notifyToast('El nuevo PIN Administrativo debe tener entre 4 y 12 dígitos numéricos.', 'warning');
      return;
    }
    if (cleanCajaPin && !/^\d{4,12}$/.test(cleanCajaPin)) {
      notifyToast('El nuevo PIN de Caja debe tener entre 4 y 12 dígitos numéricos.', 'warning');
      return;
    }
    setSavingEditClient(true);
    try {
      const patch: Partial<TenantRecord> = {
        email: cleanEmail,
        nombre_local: editCliLocal.trim(),
        razon_social: editCliRazon.trim(),
        rif: editCliRif.trim(),
        direccion_fiscal: editCliDir.trim(),
        telefono: editCliTel.trim(),
        contacto_nombre: editCliContacto.trim(),
        activo: editCliActivo,
      };
      if (cleanAdminPin) {
        const c = await createPinCredentials(cleanAdminPin);
        patch.admin_pin_salt = c.salt;
        patch.admin_pin_hash = c.hash;
      }
      if (cleanCajaPin) {
        const c = await createPinCredentials(cleanCajaPin);
        patch.caja_pin_salt = c.salt;
        patch.caja_pin_hash = c.hash;
      }
      await updateTenantRecord(editingClient.id, patch);
      await updateTenantSettings(
        { nombre_local: editCliLocal.trim() },
        editingClient.id
      );
      playBeep('ok');
      notifyToast(
        cleanAdminPin || cleanCajaPin
          ? `Datos fiscales y credenciales de "${editCliLocal.trim()}" actualizados.`
          : `Datos fiscales de "${editCliLocal.trim()}" actualizados.`,
        'success'
      );
      setEditingClient(null);
    } finally {
      setSavingEditClient(false);
    }
  };

  const handleQuickAdjustTenantDays = async (t: TenantRecord, deltaDays: number) => {
    const now = Date.now();
    const currentVence = t.membresia?.vence || now;
    const nextExp =
      deltaDays >= 0
        ? Math.max(now, currentVence) + deltaDays * 86_400_000
        : Math.max(now - 1000, currentVence + deltaDays * 86_400_000);
    await updateTenantRecord(t.id, {
      membresia: {
        plan: t.membresia?.plan || 'manual',
        nombre: t.membresia?.nombre || 'Membresía Activa',
        vence: nextExp,
        estado: 'activa',
      },
      congelado: false,
    });
    playBeep('ok');
    notifyToast(
      `${t.nombre_local}: ${deltaDays > 0 ? '+' : ''}${deltaDays} días aplicados.`,
      'success'
    );
  };

  const handleSetTenantZeroDays = async (t: TenantRecord) => {
    await updateTenantRecord(t.id, {
      membresia: {
        plan: t.membresia?.plan || 'manual',
        nombre: t.membresia?.nombre || 'Membresía Vencida',
        vence: Date.now() - 1000,
        estado: 'activa',
      },
    });
    playBeep('tick');
    notifyToast(`${t.nombre_local}: Membresía puesta en 0 días (acceso bloqueado).`, 'warning');
  };

  const handleGenerateClientDbAuthPdf = (t: TenantRecord) => {
    generateDatabaseAuthorizationPDF({
      tenantId: t.id,
      localName: t.nombre_local,
      razonSocial: t.razon_social,
      rif: t.rif,
      email: t.email,
      telefono: t.telefono,
      contactoNombre: t.contacto_nombre,
      direccionFiscal: t.direccion_fiscal,
      ownerEmail: operatorEmail || MASTER_OWNER_EMAIL,
      planName: t.membresia?.nombre || 'Estándar',
      validUntil: t.membresia?.vence
        ? new Date(t.membresia.vence).toLocaleDateString('es-VE')
        : 'Activa',
    });
    playBeep('ok');
    notifyToast(
      `Contrato de autorización de acceso a BD generado para "${t.nombre_local}".`,
      'success'
    );
  };

  const openRenewalContractModal = (t: TenantRecord) => {
    setRenewalContractClient(t);
    setRenewalContractPlanKey('');
    setRenewalContractApplyPlan(false);
  };

  const handleConfirmGenerateRenewalContractPdf = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renewalContractClient) return;
    const plan = plans[renewalContractPlanKey];
    if (!plan) {
      notifyToast('Debes seleccionar el plan que contrató antes de generar el contrato.', 'warning');
      return;
    }

    setGeneratingContractPdf(true);
    try {
      const bonus = bonusMonthsWithPromos(plan, promos);
      const effPct = effectiveDiscountWithPromos(plan, promos);
      const finalUsd = round2(plan.precio * (1 - effPct / 100));
      const now = Date.now();
      const currentVence = renewalContractClient.membresia?.vence || 0;
      const prevDate = currentVence
        ? new Date(currentVence).toLocaleDateString('es-VE')
        : 'Sin membresía previa';

      const baseMs =
        currentVence > now && renewalContractClient.membresia?.estado !== 'suspendida'
          ? currentVence
          : now;
      const nextDateObj = new Date(baseMs);
      nextDateObj.setMonth(nextDateObj.getMonth() + (Number(plan.meses) || 1) + bonus);

      const effectiveNewDate = renewalContractApplyPlan
        ? nextDateObj.toLocaleDateString('es-VE')
        : currentVence
        ? new Date(currentVence).toLocaleDateString('es-VE')
        : nextDateObj.toLocaleDateString('es-VE');

      if (renewalContractApplyPlan) {
        await updateTenantRecord(renewalContractClient.id, {
          membresia: {
            plan: renewalContractPlanKey,
            nombre: plan.nombre,
            vence: nextDateObj.getTime(),
            estado: 'activa',
          },
          congelado: false,
        });
      }

      generateMembershipRenewalContractPDF({
        tenantId: renewalContractClient.id,
        localName: renewalContractClient.nombre_local,
        razonSocial: renewalContractClient.razon_social,
        rif: renewalContractClient.rif,
        email: renewalContractClient.email,
        telefono: renewalContractClient.telefono,
        planName: plan.nombre,
        planMonths: Number(plan.meses) || 1,
        bonusMonths: bonus,
        baseUsd: Number(plan.precio) || 0,
        discountPct: round2(effPct),
        finalUsd,
        bcvRate,
        prevDate,
        newDate: effectiveNewDate,
        ownerEmail: operatorEmail || MASTER_OWNER_EMAIL,
        active:
          renewalContractApplyPlan ||
          (currentVence > now && renewalContractClient.membresia?.estado !== 'suspendida'),
      });

      playBeep('ok');
      notifyToast(
        renewalContractApplyPlan
          ? `Plan "${plan.nombre}" aplicado y contrato PDF generado para "${renewalContractClient.nombre_local}".`
          : `Contrato de renovación (${plan.nombre}) generado en PDF automáticamente.`,
        'success'
      );
      setRenewalContractClient(null);
    } finally {
      setGeneratingContractPdf(false);
    }
  };

  const handleDeleteClient = (t: TenantRecord) => {
    setOwnerConfirm({
      title: 'Eliminar Nodo de Cliente',
      message: `¿Eliminar permanentemente el nodo "${t.nombre_local}" (${t.email}) y TODOS sus productos, ventas, fiados y cierres? Esta acción es irreversible.`,
      confirmLabel: 'Sí, eliminar nodo',
      danger: true,
      onConfirm: async () => {
        await deleteTenantNode(t.id);
        playBeep('ok');
        notifyToast(`Nodo "${t.nombre_local}" eliminado.`, 'info');
      },
    });
  };

  const handleSendClientReset = async (email: string) => {
    try {
      await sendPasswordRecoveryEmail(email);
      playBeep('ok');
      notifyToast(`Correo de restablecimiento enviado a ${email}.`, 'success');
    } catch (err) {
      notifyToast(
        err instanceof Error ? err.message : 'No se pudo enviar el correo de recuperación.',
        'error'
      );
    }
  };

  const handleSaveGeneral = async () => {
    if (!activeTenantId) {
      notifyToast('Selecciona o registra primero un cliente.', 'warning');
      return;
    }
    const cleanName = storeNameDraft.trim() || 'Innova Grup';
    await updateTenantSettings({
      nombre_local: cleanName,
      meta_usd: round2(Number(metaUsdDraft) || 0),
    });
    await updateTenantRecord(activeTenantId, { nombre_local: cleanName });
    playBeep('ok');
    notifyToast('Configuración general guardada.', 'success');
  };

  const handleToggleGlobalMaintenance = async (enabled: boolean) => {
    setSavingGlobalMaint(true);
    try {
      await updatePlatformConfig({
        mantenimiento_global: enabled,
        mantenimiento_mensaje: globalMaintMsgDraft.trim(),
      });
      playBeep(enabled ? 'tick' : 'ok');
      notifyToast(
        enabled
          ? 'Mantenimiento global ACTIVADO en todos los sistemas de clientes (el Panel Propietario permanece operativo).'
          : 'Mantenimiento global DESACTIVADO. Todos los comercios operan con normalidad.',
        enabled ? 'warning' : 'success'
      );
    } finally {
      setSavingGlobalMaint(false);
    }
  };

  const handleSaveGlobalMaintenanceMsg = async () => {
    setSavingGlobalMaint(true);
    try {
      await updatePlatformConfig({
        mantenimiento_global: globalMaintenance,
        mantenimiento_mensaje: globalMaintMsgDraft.trim(),
      });
      notifyToast('Mensaje de mantenimiento global actualizado.', 'success');
    } finally {
      setSavingGlobalMaint(false);
    }
  };

  const handleToggleSeniatLegal = async (enabled: boolean) => {
    setSavingSeniat(true);
    try {
      await updatePlatformConfig({
        seniat_legal_activo: enabled,
        seniat_providencia:
          seniatProvidenciaDraft.trim() || 'Providencia Administrativa SNAT/2011/00071',
        seniat_pie_legal:
          seniatPieLegalDraft.trim() ||
          'DOCUMENTO EMITIDO BAJO NORMATIVA FISCAL SENIAT — REPÚBLICA BOLIVARIANA DE VENEZUELA',
      });
      playBeep('ok');
      notifyToast(
        enabled
          ? 'Facturación Legal SENIAT Venezuela ACTIVADA para todos los clientes.'
          : 'Facturación Legal SENIAT Venezuela desactivada (modo recibo estándar).',
        enabled ? 'success' : 'info'
      );
    } finally {
      setSavingSeniat(false);
    }
  };

  const handleSaveSeniatTexts = async () => {
    setSavingSeniat(true);
    try {
      await updatePlatformConfig({
        seniat_legal_activo: seniatLegalActivo,
        seniat_providencia:
          seniatProvidenciaDraft.trim() || 'Providencia Administrativa SNAT/2011/00071',
        seniat_pie_legal:
          seniatPieLegalDraft.trim() ||
          'DOCUMENTO EMITIDO BAJO NORMATIVA FISCAL SENIAT — REPÚBLICA BOLIVARIANA DE VENEZUELA',
      });
      notifyToast('Textos legales SENIAT actualizados para todos los clientes.', 'success');
    } finally {
      setSavingSeniat(false);
    }
  };

  const handleQuickToggleVerification = async (clientRec: TenantRecord) => {
    const existing = clientRec.verificacion_datos;
    const nextActive = !(existing?.activo === true);
    const defaultReqs = buildDefaultVerificationRequisitos();
    const currentReqs = existing?.requisitos || {
      ...defaultReqs,
      datos_fiscales: true,
      verificacion_rif: true,
    };
    const hasAnyPreset = Object.values(currentReqs).some(Boolean);
    const hasAnyCustom = (existing?.requisitos_personalizados || []).some((c) => c.activo !== false);
    const finalReqs =
      hasAnyPreset || hasAnyCustom
        ? currentReqs
        : { ...defaultReqs, datos_fiscales: true, verificacion_rif: true };

    await saveTenantVerificationConfig(
      clientRec.id,
      {
        activo: nextActive,
        mensaje:
          existing?.mensaje ||
          'Por seguridad y cumplimiento normativo, requerimos actualizar y verificar tus documentos con foto.',
        requisitos: finalReqs,
        requisitos_foto: existing?.requisitos_foto || {
          datos_fiscales: true,
          verificacion_rif: true,
        },
        requisitos_personalizados: existing?.requisitos_personalizados || [],
        activado_en: nextActive ? Date.now() : existing?.activado_en || 0,
        updatedAt: Date.now(),
      },
      nextActive
    );
    notifyToast(
      nextActive
        ? `Actualización de Datos ACTIVADA para ${clientRec.nombre_local}. El cliente ya puede enviar fotos.`
        : `Actualización de Datos desactivada para ${clientRec.nombre_local}.`,
      nextActive ? 'success' : 'info'
    );
  };

  const toggleFlag = async (
    field: 'admin_bloqueado' | 'usuario_congelado' | 'mantenimiento',
    val: boolean
  ) => {
    if (!activeTenantId) {
      notifyToast('Selecciona primero un nodo cliente.', 'warning');
      return;
    }
    const targetField = field === 'usuario_congelado' ? 'congelado' : field;
    await updateTenantRecord(activeTenantId, { [targetField]: val });
    notifyToast('Estado de control actualizado.', 'info');
  };

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTenantId) {
      notifyToast('Selecciona un cliente para enviarle la notificación.', 'warning');
      return;
    }
    if (!bcText.trim()) {
      notifyToast('Escribe el contenido del aviso.', 'warning');
      return;
    }
    setSendingBc(true);
    try {
      const ts = Date.now();
      const payload: BroadcastConfig = {
        id: ts,
        titulo: bcTitle.trim() || 'Aviso de Gerencia',
        texto: bcText.trim(),
        tipo: bcType,
        audiencia: bcAudience,
        con_voz: bcVoice,
        timestamp: ts,
        enviado_por: operatorEmail || 'Propietario',
      };
      await updateTenantSettings({ broadcast: payload });
      const notifPath = `tenants/${activeTenantId}/notifications/${ts}`;
      try {
        await setDoc(doc(db, 'tenants', activeTenantId, 'notifications', String(ts)), payload);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, notifPath);
      }
      setBcText('');
      playBeep('ok');
      notifyToast('Notificación enviada en tiempo real.', 'success');
    } finally {
      setSendingBc(false);
    }
  };

  const handleClearBroadcast = async () => {
    if (!activeTenantId) return;
    await updateTenantSettings({ broadcast: null });
    notifyToast('Aviso activo limpiado.', 'info');
  };

  const handleResendHistoryNotification = async (n: BroadcastConfig & { key?: string }) => {
    if (!activeTenantId) return;
    const { key: _omitKey, ...clean } = n;
    await updateTenantSettings({
      broadcast: stripUndefined({
        ...clean,
        id: Date.now(),
        timestamp: Date.now(),
      }),
    });
    notifyToast('Notificación reenviada.', 'success');
  };

  const handleDeleteHistoryNotification = async (notifKey: string) => {
    if (!activeTenantId) return;
    const path = `tenants/${activeTenantId}/notifications/${notifKey}`;
    try {
      await deleteDoc(doc(db, 'tenants', activeTenantId, 'notifications', notifKey));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  const handleUpdateNotice = async (
    key: string,
    field: 'hora' | 'msg' | 'activo',
    val: string | boolean
  ) => {
    if (!activeTenantId) return;
    const current = config.avisos || DEFAULT_SCHEDULED_NOTICES;
    const item = current[key] || { hora: '08:00', msg: '', activo: true };
    await updateTenantSettings({
      avisos: {
        ...current,
        [key]: { ...item, [field]: val },
      },
    });
  };

  const handleDeleteNotice = async (key: string) => {
    if (!activeTenantId) return;
    const current = { ...(config.avisos || DEFAULT_SCHEDULED_NOTICES) };
    delete current[key];
    await updateTenantSettings({ avisos: current });
  };

  const handleAddNotice = async () => {
    if (!activeTenantId || !newNoticeMsg.trim()) return;
    const key = `a_${Date.now()}`;
    const current = config.avisos || DEFAULT_SCHEDULED_NOTICES;
    await updateTenantSettings({
      avisos: {
        ...current,
        [key]: {
          hora: newNoticeHora,
          msg: newNoticeMsg.trim(),
          activo: true,
        },
      },
    });
    setNewNoticeMsg('');
    notifyToast('Recordatorio añadido.', 'success');
  };

  const handleUpdateVoice = async (patch: Partial<typeof voiceSettings>) => {
    const nextVoice = { ...voiceSettings, ...patch };
    await updatePlatformConfig({ voz: nextVoice });
    if (activeTenantId) {
      await updateTenantSettings({ voz: nextVoice });
    }
  };

  const handleAdjustDays = async (deltaDays: number) => {
    if (!activeTenantId) {
      notifyToast('Selecciona primero un nodo cliente.', 'warning');
      return;
    }
    const now = Date.now();
    const currentVence = membership?.vence || now;
    const nextExp =
      deltaDays >= 0
        ? Math.max(now, currentVence) + deltaDays * 86_400_000
        : Math.max(now - 1000, currentVence + deltaDays * 86_400_000);
    await updateTenantRecord(activeTenantId, {
      membresia: {
        plan: membership?.plan || 'manual',
        nombre: membership?.nombre || 'Membresía Activa',
        vence: nextExp,
        estado: 'activa',
      },
      congelado: false,
    });
    playBeep('ok');
    notifyToast(`Vigencia actualizada (${deltaDays > 0 ? '+' : ''}${deltaDays} días).`, 'success');
  };

  const handleSetActiveTenantZeroDays = async () => {
    if (!activeTenantId) {
      notifyToast('Selecciona primero un nodo cliente.', 'warning');
      return;
    }
    await updateTenantRecord(activeTenantId, {
      membresia: {
        plan: membership?.plan || 'manual',
        nombre: membership?.nombre || 'Membresía Vencida',
        vence: Date.now() - 1000,
        estado: 'activa',
      },
    });
    playBeep('tick');
    notifyToast(`${localName}: Vigencia puesta en 0 días (bloqueada).`, 'warning');
  };

  const handleToggleMembershipSuspend = async () => {
    if (!activeTenantId) return;
    const nextEstado = membership?.estado === 'suspendida' ? 'activa' : 'suspendida';
    await updateTenantRecord(activeTenantId, {
      membresia: {
        plan: membership?.plan || 'manual',
        nombre: membership?.nombre || 'Membresía Activa',
        vence: membership?.vence || Date.now(),
        estado: nextEstado,
      },
    });
    notifyToast(nextEstado === 'suspendida' ? 'Membresía suspendida.' : 'Membresía reactivada.', 'info');
  };

  const handleUpdatePaymentStatus = async (
    p: MembershipPayment,
    nextStatus: 'aprobado' | 'en_revision' | 'rechazado'
  ) => {
    const targetTenantId = p.tenantId || activeTenantId;
    const targetTenant = tenants.find((t) => t.id === targetTenantId) || activeTenant;
    const batch = writeBatch(db);
    const now = Date.now();

    batch.update(doc(db, 'platform_payments', p.key), {
      estado: nextStatus,
    });

    if (targetTenantId) {
      batch.set(
        doc(db, 'tenants', targetTenantId, 'membership_payments', p.key),
        { estado: nextStatus },
        { merge: true }
      );
    }

    if (nextStatus === 'aprobado') {
      const totalMonths = (Number(p.meses) || 1) + (Number(p.bonus) || 0);
      const currentVence = targetTenant?.membresia?.vence || 0;
      const prevDate = currentVence ? new Date(currentVence).toLocaleDateString('es-VE') : 'N/A';
      const baseMs = Math.max(now, currentVence || now);
      const nextDate = new Date(baseMs);
      nextDate.setMonth(nextDate.getMonth() + totalMonths);
      const nextMs = nextDate.getTime();

      if (targetTenantId) {
        batch.update(doc(db, 'tenants', targetTenantId), {
          membresia: {
            plan: p.plan,
            nombre: p.nombre,
            vence: nextMs,
            estado: 'activa',
          },
          congelado: false,
          updatedAt: now,
        });
      }

      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `platform_payments/${p.key}`);
      }

      generateMembershipRenewalReceiptPDF({
        localName: p.tenantName || targetTenant?.nombre_local || localName,
        rif: targetTenant?.rif,
        email: targetTenant?.email || p.usuario || '',
        planName: p.nombre,
        meses: Number(p.meses) || 1,
        bonusMeses: Number(p.bonus) || 0,
        usd: Number(p.usd) || 0,
        bs: Number(p.bs) || 0,
        tasa: Number(p.tasa) || bcvRate,
        refNumber: p.ref,
        prevDate,
        newDate: nextDate.toLocaleDateString('es-VE'),
        approvedBy: operatorEmail || MASTER_OWNER_EMAIL,
        verificacionIa: p.verificacion_ia || undefined,
      });
      playBeep('ok');
      notifyToast(
        `Pago aprobado, plan activado (+${totalMonths} mes/es) y comprobante PDF generado automáticamente.`,
        'success'
      );
    } else {
      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `platform_payments/${p.key}`);
      }
      playBeep('tick');
      notifyToast(
        nextStatus === 'en_revision'
          ? 'Pago colocado En Revisión.'
          : 'Pago marcado como rechazado.',
        'info'
      );
    }
  };

  const handleDeleteMembershipPayment = (p: MembershipPayment) => {
    setOwnerConfirm({
      title: 'Eliminar Comprobante de Pago Móvil',
      message: `¿Seguro que deseas eliminar permanentemente el reporte de pago "${p.nombre}" (Ref: ${p.ref}) de ${p.tenantName || p.usuario}? Esta acción no se puede deshacer.`,
      confirmLabel: 'Sí, Eliminar Comprobante',
      danger: true,
      onConfirm: async () => {
        const targetTenantId = p.tenantId || activeTenantId;
        const batch = writeBatch(db);
        batch.delete(doc(db, 'platform_payments', p.key));
        if (targetTenantId) {
          batch.delete(doc(db, 'tenants', targetTenantId, 'membership_payments', p.key));
        }
        try {
          await batch.commit();
          notifyToast('Comprobante de pago eliminado.', 'info');
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `platform_payments/${p.key}`);
        }
      },
    });
  };

  const handleSaveClientInvoiceConfig = async (
    client: TenantRecord,
    nextConfig: TenantInvoiceConfig
  ) => {
    const cleanConfig = stripUndefined({ ...nextConfig });
    const logoUrl = nextConfig.logo_data_url || '';
    await updateTenantRecord(client.id, {
      logo_url: logoUrl,
      invoice_config: cleanConfig,
    });
    try {
      await setDoc(
        doc(db, 'tenants', client.id, 'settings', 'config'),
        stripUndefined({
          logo_url: logoUrl,
          invoice_config: cleanConfig,
          updatedAt: Date.now(),
        }),
        { merge: true }
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tenants/${client.id}/settings/config`);
    }
    playBeep('ok');
    notifyToast(
      `Formato térmico, logotipo e impresora guardados para ${client.nombre_local}.`,
      'success'
    );
  };

  const handleSaveSupportNumbers = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSupportNums(true);
    try {
      await updatePlatformConfig({
        whatsapp_soporte: waSoporteDraft.replace(/[^\d+]/g, '').trim(),
        whatsapp_soporte_secundario: waSoporteSecDraft.replace(/[^\d+]/g, '').trim(),
        soporte_horario: soporteHorarioDraft.trim() || 'Lunes a Sábado · 8:00 AM - 7:00 PM',
      });
      playBeep('ok');
      notifyToast('Números de soporte WhatsApp actualizados para todos los clientes.', 'success');
    } finally {
      setSavingSupportNums(false);
    }
  };

  const handleApplyOrRenewPlan = async (downloadPdf: boolean) => {
    if (!activeTenantId) {
      notifyToast('Selecciona primero un cliente.', 'warning');
      return;
    }
    const p = plans[selectedPlanToApply];
    if (!p) return;
    const bonus = bonusMonthsWithPromos(p, promos);
    const prevDate = membership?.vence
      ? new Date(membership.vence).toLocaleDateString('es-VE')
      : 'Sin membresía previa';
    const isActive =
      membership?.vence && membership.vence > Date.now() && membership.estado !== 'suspendida';
    const nextDate = new Date(isActive ? membership!.vence : Date.now());
    nextDate.setMonth(nextDate.getMonth() + (Number(p.meses) || 1) + bonus);

    await updateTenantRecord(activeTenantId, {
      membresia: {
        plan: selectedPlanToApply,
        nombre: p.nombre,
        vence: nextDate.getTime(),
        estado: 'activa',
      },
      congelado: false,
    });

    if (downloadPdf) {
      const effPct = effectiveDiscountWithPromos(p, promos);
      const finalUsd = round2(p.precio * (1 - effPct / 100));
      generateRenewalPDF(
        localName,
        p.nombre,
        `$${finalUsd.toFixed(2)} USD`,
        prevDate,
        nextDate.toLocaleDateString('es-VE'),
        bonus
      );
    }
    playBeep('ok');
    notifyToast(
      downloadPdf
        ? `Renovado "${p.nombre}" y constancia PDF descargada.`
        : `Plan "${p.nombre}" aplicado.`,
      'success'
    );
  };

  const handleResetMembership = () => {
    if (!activeTenantId) return;
    setOwnerConfirm({
      title: 'Restablecer Membresía',
      message: `¿Restablecer la membresía de ${localName}? Quedará sin plan (vence ahora) y se descongela el usuario.`,
      confirmLabel: 'Restablecer',
      danger: true,
      onConfirm: async () => {
        await updateTenantRecord(activeTenantId, {
          membresia: { plan: null, nombre: 'Sin plan', vence: Date.now(), estado: 'activa' },
          congelado: false,
        });
        notifyToast('Membresía restablecida.', 'info');
      },
    });
  };

  const handleSaveWarningConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    await updatePlatformConfig({
      aviso_membresia: {
        dias: Math.max(1, Number(avDias) || 5),
        titulo: avTitulo.trim() || 'Tu membresía está por vencer',
        msg:
          avMsg.trim() ||
          'Te quedan {dias} día(s) de membresía. Renueva a tiempo para no perder el acceso al sistema.',
        activo: avActivo,
      },
    });
    playBeep('ok');
    notifyToast('Advertencia global de vencimiento guardada.', 'success');
  };

  const resetPromoForm = () => {
    setEditingPromoId(null);
    setPromoName('');
    setPromoType('pct');
    setPromoVal('20');
    setPromoX('2');
    setPromoY('3');
    setPromoRepeat(false);
    setPromoActive(true);
    setPromoDesde('');
    setPromoHasta('');
    setPromoAplicaAll(true);
    setPromoAplicaMeses([1, 3, 6, 12]);
  };

  const handleStartEditPromo = (pr: PromoRecord) => {
    setEditingPromoId(pr.id);
    setPromoName(pr.nombre || '');
    setPromoType(pr.tipo || 'pct');
    setPromoVal(String(pr.valor ?? 0));
    setPromoX(String(pr.x ?? 2));
    setPromoY(String(pr.y ?? 3));
    setPromoRepeat(Boolean(pr.repetir));
    setPromoActive(pr.activo !== false);
    setPromoDesde(pr.desde || '');
    setPromoHasta(pr.hasta || '');
    if (Array.isArray(pr.aplica) && pr.aplica.length > 0) {
      setPromoAplicaAll(false);
      setPromoAplicaMeses(pr.aplica);
    } else {
      setPromoAplicaAll(true);
      setPromoAplicaMeses([1, 3, 6, 12]);
    }
  };

  const handleSavePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoName.trim()) {
      notifyToast('Escribe el nombre de la promoción.', 'warning');
      return;
    }
    const id = editingPromoId || `pr_${Date.now()}`;
    const existing = editingPromoId ? promos.find((p) => p.id === editingPromoId) : null;
    const currentPromos = { ...(platformConfig.promos || {}) };
    currentPromos[id] = {
      id,
      nombre: promoName.trim(),
      tipo: promoType,
      valor: Number(promoVal) || 0,
      x: Number(promoX) || 2,
      y: Number(promoY) || 3,
      repetir: promoRepeat,
      activo: promoActive,
      aplica: promoAplicaAll ? 'all' : promoAplicaMeses.length > 0 ? promoAplicaMeses : 'all',
      desde: promoDesde || '',
      hasta: promoHasta || '',
      creado: existing?.creado || Date.now(),
    };
    await updatePlatformConfig({ promos: currentPromos });
    playBeep('ok');
    notifyToast(
      editingPromoId ? 'Promoción actualizada correctamente.' : 'Promoción creada y publicada.',
      'success'
    );
    resetPromoForm();
  };

  const handleTogglePromoActive = async (pr: PromoRecord) => {
    const currentPromos = { ...(platformConfig.promos || {}) };
    currentPromos[pr.id] = { ...pr, activo: !pr.activo };
    await updatePlatformConfig({ promos: currentPromos });
    notifyToast(`Promoción "${pr.nombre}" ${!pr.activo ? 'activada' : 'pausada'}.`, 'info');
  };

  const handleDeletePromo = async (pr: PromoRecord) => {
    if (editingPromoId === pr.id) resetPromoForm();
    const currentPromos = { ...(platformConfig.promos || {}) };
    delete currentPromos[pr.id];
    await updatePlatformConfig({ promos: currentPromos });
    notifyToast(`Promoción "${pr.nombre}" eliminada.`, 'info');
  };

  const handleSaveReceiptContact = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanWa = waMembresia.replace(/\D/g, '');
    if (cleanWa.length < 10) {
      notifyToast('Ingresa un número válido con código de país (ej: 584245655395).', 'warning');
      return;
    }
    await updatePlatformConfig({ whatsapp_membresia: cleanWa });
    setWaMembresia(cleanWa);
    playBeep('ok');
    notifyToast('Número de contacto para comprobantes actualizado.', 'success');
  };

  const handleSavePagoMovil = async () => {
    const cleanTel = pmTel.replace(/\D/g, '');
    if (cleanTel.length < 10) {
      notifyToast('Ingresa un teléfono Pago Móvil válido (mínimo 10 dígitos).', 'warning');
      return;
    }
    await updatePlatformConfig({
      whatsapp_membresia: waMembresia.replace(/\D/g, '') || waMembresia.trim(),
      pago_movil: {
        banco: pmBanco.trim(),
        tel: cleanTel,
        ci: pmCi.trim(),
        titular: pmTitular.trim(),
        activo: pagoMovil?.activo !== false,
      },
    });
    playBeep('ok');
    notifyToast('Datos bancarios y Pago Móvil guardados.', 'success');
  };

  const handleTogglePagoMovilActive = async () => {
    const currentlyActive = pagoMovil?.activo !== false;
    const nextActive = !currentlyActive;
    await updatePlatformConfig({
      pago_movil: {
        banco: (pagoMovil?.banco ?? pmBanco).trim(),
        tel: (pagoMovil?.tel ?? pmTel).replace(/\D/g, ''),
        ci: (pagoMovil?.ci ?? pmCi).trim(),
        titular: (pagoMovil?.titular ?? pmTitular).trim(),
        activo: nextActive,
      },
    });
    playBeep('ok');
    notifyToast(
      nextActive
        ? 'Datos de Pago Móvil ACTIVADOS para los clientes.'
        : 'Datos de Pago Móvil DESACTIVADOS (ocultos para los clientes).',
      'info'
    );
  };

  const resetPlanForm = () => {
    setEditingPlanKey(null);
    setPlanNameDraft('');
    setPlanMesesDraft('1');
    setPlanPrecioDraft('10');
    setPlanOfertaDraft('0');
    setPlanLinkDraft('');
  };

  const handleStartEditPlan = (key: string, pl: MembershipPlan) => {
    setEditingPlanKey(key);
    setPlanNameDraft(pl.nombre);
    setPlanMesesDraft(String(pl.meses));
    setPlanPrecioDraft(String(pl.precio));
    setPlanOfertaDraft(String(pl.oferta || 0));
    setPlanLinkDraft(planLinks[key] || '');
  };

  const handleSavePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    const meses = Math.max(1, Math.round(Number(planMesesDraft) || 1));
    const precio = Math.max(0, round2(Number(planPrecioDraft) || 0));
    const oferta = Math.min(100, Math.max(0, round2(Number(planOfertaDraft) || 0)));
    const nombre = planNameDraft.trim() || `${meses} ${meses === 1 ? 'mes' : 'meses'}`;
    const cleanLink = planLinkDraft.trim();
    if (cleanLink && !/^https?:\/\//i.test(cleanLink)) {
      notifyToast('El enlace de pago debe comenzar con https:// o http://', 'warning');
      return;
    }
    const key = editingPlanKey || `p_${Date.now()}`;
    const nextPlans = { ...plans, [key]: { nombre, meses, precio, oferta } };
    const nextLinks = { ...planLinks };
    if (cleanLink) {
      nextLinks[key] = cleanLink;
    } else {
      delete nextLinks[key];
    }
    await updatePlatformConfig({ planes: nextPlans, planes_links: nextLinks });
    playBeep('ok');
    notifyToast(
      editingPlanKey ? `Plan "${nombre}" actualizado.` : `Plan "${nombre}" agregado.`,
      'success'
    );
    resetPlanForm();
  };

  const handleDeletePlan = (key: string) => {
    if (Object.keys(plans).length <= 1) {
      notifyToast('Debe existir al menos un plan activo.', 'warning');
      return;
    }
    const deletedName = plans[key]?.nombre || key;
    setOwnerConfirm({
      title: 'Eliminar Plan de Membresía',
      message: `¿Eliminar el plan publicado "${deletedName}"? Dejará de aparecer inmediatamente para todos los clientes.`,
      confirmLabel: 'Sí, eliminar plan',
      danger: true,
      onConfirm: async () => {
        const nextPlans = { ...plans };
        delete nextPlans[key];
        const nextLinks = { ...planLinks };
        delete nextLinks[key];
        await updatePlatformConfig({ planes: nextPlans, planes_links: nextLinks });
        if (editingPlanKey === key) resetPlanForm();
        if (selectedPlanToApply === key) {
          setSelectedPlanToApply(Object.keys(nextPlans)[0] || '');
        }
        playBeep('ok');
        notifyToast(`Plan "${deletedName}" eliminado correctamente.`, 'success');
      },
    });
  };

  const handleRestoreDefaultPlans = async () => {
    await updatePlatformConfig({ planes: defaultPlans() });
    resetPlanForm();
    playBeep('ok');
    notifyToast('Planes base restaurados.', 'success');
  };

  const resetMethodForm = () => {
    setEditingMethodId(null);
    setMethodTipo('zelle');
    setMethodTitulo('');
    setMethodDetalle('');
    setMethodTitular('');
    setMethodDoc('');
    setMethodActivo(true);
  };

  const handleStartEditMethod = (m: MembershipPaymentMethod) => {
    setEditingMethodId(m.id);
    setMethodTipo(m.tipo);
    setMethodTitulo(m.titulo);
    setMethodDetalle(m.detalle);
    setMethodTitular(m.titular || '');
    setMethodDoc(m.documento || '');
    setMethodActivo(m.activo !== false);
  };

  const handleSaveMethod = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!methodTitulo.trim() || !methodDetalle.trim()) {
      notifyToast('Completa el título y el dato de pago (correo, teléfono, wallet o cuenta).', 'warning');
      return;
    }
    const id = editingMethodId || `pm_${Date.now()}`;
    const entry: MembershipPaymentMethod = {
      id,
      tipo: methodTipo,
      titulo: methodTitulo.trim(),
      detalle: methodDetalle.trim(),
      titular: methodTitular.trim(),
      documento: methodDoc.trim(),
      activo: methodActivo,
    };
    const nextList = editingMethodId
      ? metodosPagoMembresia.map((m) => (m.id === editingMethodId ? entry : m))
      : [...metodosPagoMembresia, entry];
    await updatePlatformConfig({ metodos_pago_membresia: nextList });
    playBeep('ok');
    notifyToast(
      editingMethodId ? 'Método de pago actualizado.' : 'Método de pago agregado.',
      'success'
    );
    resetMethodForm();
  };

  const handleToggleMethodActive = async (m: MembershipPaymentMethod) => {
    const nextActive = m.activo === false;
    const nextList = metodosPagoMembresia.map((item) =>
      item.id === m.id ? { ...item, activo: nextActive } : item
    );
    await updatePlatformConfig({ metodos_pago_membresia: nextList });
    playBeep('ok');
    notifyToast(
      nextActive
        ? `Método "${m.titulo}" activado para los clientes.`
        : `Método "${m.titulo}" desactivado (oculto para los clientes).`,
      'info'
    );
  };

  const handleDeleteMethod = async (id: string) => {
    const nextList = metodosPagoMembresia.filter((m) => m.id !== id);
    await updatePlatformConfig({ metodos_pago_membresia: nextList });
    if (editingMethodId === id) resetMethodForm();
    notifyToast('Método de pago eliminado.', 'info');
  };

  const handleResolveTicket = async (t: SupportTicket) => {
    const batch = writeBatch(db);
    batch.update(doc(db, 'platform_tickets', t.key), { estado: 'resuelto' });
    if (t.tenantId) {
      batch.update(doc(db, 'tenants', t.tenantId, 'tickets', t.key), { estado: 'resuelto' });
    }
    try {
      await batch.commit();
      notifyToast('Ticket marcado como resuelto.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `platform_tickets/${t.key}`);
    }
  };

  const handleSendTicketReply = async (t: SupportTicket) => {
    const msg = (replyDrafts[t.key] || '').trim();
    if (!msg) return;
    const replyId = `r_${Date.now()}`;
    const replyEntry = {
      de: 'Propietario / Soporte',
      msg,
      t: Date.now(),
    };
    const batch = writeBatch(db);
    batch.update(doc(db, 'platform_tickets', t.key), {
      [`resp.${replyId}`]: replyEntry,
      estado: 'respondido',
    });
    if (t.tenantId) {
      batch.update(doc(db, 'tenants', t.tenantId, 'tickets', t.key), {
        [`resp.${replyId}`]: replyEntry,
        estado: 'respondido',
      });
    }
    try {
      await batch.commit();
      setReplyDrafts((prev) => ({ ...prev, [t.key]: '' }));
      playBeep('ok');
      notifyToast('Respuesta enviada al ticket.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `platform_tickets/${t.key}`);
    }
  };

  const scheduledNotices = config.avisos || DEFAULT_SCHEDULED_NOTICES;

  return (
    <div
      className={`min-h-screen bg-slate-50 flex flex-col ${
        viewMode === 'mobile' && isWideViewport
          ? 'max-w-[460px] mx-auto shadow-2xl border-x border-slate-200'
          : 'w-full'
      }`}
    >
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-xl border-b border-slate-200/80 sticky top-0 z-30 shadow-[0_6px_24px_-16px_rgba(14,116,144,0.16)]">
        <div className="h-[3px] w-full bg-gradient-to-r from-sky-400 via-cyan-400 to-emerald-400" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 min-h-16 py-2 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0">
              <Crown className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
                  Panel Maestro · {activeTenant ? activeTenant.nombre_local : 'Multi-Empresa'}
                </h1>
                <span
                  className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold border whitespace-nowrap shrink-0 bg-emerald-50 text-emerald-700 border-emerald-200/80"
                  title="Conectada al servidor en tiempo real"
                >
                  <span className="relative flex h-2 w-2 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                  </span>
                  <span>Conectada</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate max-w-[260px] sm:max-w-none">
                {operatorEmail || 'Propietario'} · {tenants.length} cliente(s) · Turno nodo: $
                {liveShiftUsd.toFixed(2)} USD
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {tenants.length > 0 && (
              <select
                value={activeTenantId || ''}
                onChange={(e) => setActiveTenantId(e.target.value || null)}
                className="px-2.5 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800 max-w-[200px] cursor-pointer"
                title="Seleccionar nodo de cliente activo"
              >
                {tenants.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.nombre_local} {t.rif ? `(${t.rif})` : ''}
                  </option>
                ))}
              </select>
            )}
            <button
              type="button"
              onClick={() => setShowNewClientModal(true)}
              className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 shadow-xs"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Registrar Nuevo Cliente</span>
            </button>
            <ViewModeToggle compact />
            <button
              type="button"
              onClick={() => {
                if (!activeTenantId) {
                  notifyToast('Registra o selecciona primero un cliente para abrir su POS.', 'warning');
                  setTab('clients');
                  return;
                }
                onEnterPos();
              }}
              className="px-3 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
            >
              Ir al POS
            </button>
            <PWAInstallButton compact />
            {pushSupported && (
              <button
                type="button"
                onClick={() => void togglePushNotifications()}
                className={`px-3 py-2 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                  pushEnabled && pushPermission === 'granted'
                    ? 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-800'
                    : 'bg-white hover:bg-sky-50 border-slate-200 text-slate-700'
                }`}
                title={
                  pushEnabled && pushPermission === 'granted'
                    ? 'Notificaciones Push activas (clic para silenciar)'
                    : 'Activar Notificaciones Push (Android y Web)'
                }
              >
                {pushEnabled && pushPermission === 'granted' ? (
                  <BellRing className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Bell className="w-3.5 h-3.5 text-sky-600" />
                )}
                <span className="hidden lg:inline">
                  {pushEnabled && pushPermission === 'granted' ? 'Push Activo' : 'Activar Push'}
                </span>
              </button>
            )}
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 cursor-pointer"
              title="Recargar página"
            >
              <RotateCw className="w-3.5 h-3.5 text-sky-600" />
              <span className="hidden md:inline">Recargar</span>
            </button>
            <button
              type="button"
              onClick={onOpenSecurity}
              className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5 text-sky-600" />
              <span className="hidden sm:inline">Seguridad / MFA</span>
            </button>
            <button
              type="button"
              onClick={logout}
              className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Salir</span>
            </button>
          </div>
        </div>

        {/* Navigation Strip */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-2.5 flex items-center gap-1.5 overflow-x-auto">
          {(
            [
              { id: 'overview', label: 'Control General', Icon: Sliders },
              { id: 'clients', label: `Clientes y Empresas (${tenants.length})`, Icon: Building2 },
              { id: 'seniat', label: 'Modo Fiscal SENIAT', Icon: Scale },
              {
                id: 'preregistrations',
                label: `Pre-Registros${pendingPreRegsCount ? ` (${pendingPreRegsCount})` : ''}`,
                Icon: UserCheck,
              },
              { id: 'aichat', label: 'Chat Innova Grup', Icon: Bot },
              { id: 'analytics', label: 'Analíticas y Reportes', Icon: BarChart3 },
              {
                id: 'users',
                label: `Usuarios y Cajeros (${cashiers.length + systemUsers.length})`,
                Icon: Users,
              },
              { id: 'notifications', label: 'Notificaciones y Advertencias', Icon: Bell },
              { id: 'inventory', label: `Inventario (${products.length})`, Icon: Package },
              {
                id: 'membership',
                label: `Membresía y Pagos${pendingPaymentsCount ? ` (${pendingPaymentsCount})` : ''}`,
                Icon: CreditCard,
              },
              {
                id: 'support',
                label: `Soporte${openTicketsCount ? ` (${openTicketsCount})` : ''}`,
                Icon: LifeBuoy,
              },
            ] as const
          ).map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-all btn-press ${
                tab === id
                  ? 'bg-gradient-to-r from-sky-500 to-cyan-500 text-white shadow-xs'
                  : 'bg-sky-50/70 text-slate-700 hover:bg-sky-100/80 hover:text-sky-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" /> {label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 space-y-6">
        {providerWarning && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start justify-between gap-3 text-xs text-amber-950">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Habilita Correo/Contraseña en Firebase Authentication</p>
                <p className="text-amber-800 mt-0.5">{providerWarning}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setProviderWarning(null)}
              className="text-amber-700 hover:text-amber-950 cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {tab === 'overview' && (
          <div className="space-y-6">
            {/* 7-Day Daily Sales Revenue Trend Bar Chart (Recharts) */}
            <OwnerDailySalesChart />

            {/* Global System Maintenance Panel (Owner Panel is ALWAYS exempt) */}
            <div
              className={`rounded-2xl border p-4 sm:p-5 space-y-3 ${
                globalMaintenance
                  ? 'bg-amber-50/90 border-amber-300'
                  : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
                      globalMaintenance
                        ? 'bg-amber-100 border-amber-300 text-amber-700'
                        : 'bg-slate-100 border-slate-200 text-slate-600'
                    }`}
                  >
                    <Wrench className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex flex-wrap items-center gap-2">
                      Mantenimiento Global de Sistemas
                      {globalMaintenance && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-600 text-white text-[10px] font-bold uppercase">
                          Activo
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Pone en mantenimiento todas las cajas, paneles administrativos y terminales de clientes. El{' '}
                      <b>Panel Propietario nunca entra en mantenimiento</b> y siempre permanece accesible.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={savingGlobalMaint}
                  onClick={() => void handleToggleGlobalMaintenance(!globalMaintenance)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer ${
                    globalMaintenance
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-amber-600 hover:bg-amber-700 text-white'
                  }`}
                >
                  {globalMaintenance
                    ? 'Desactivar Mantenimiento Global'
                    : 'Activar Mantenimiento Global'}
                </button>
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                <input
                  type="text"
                  value={globalMaintMsgDraft}
                  onChange={(e) => setGlobalMaintMsgDraft(e.target.value)}
                  placeholder="Mensaje personalizado para mostrar a los usuarios (ej: Actualizando servidores, volvemos en 15 minutos)..."
                  maxLength={180}
                  className="flex-1 min-w-[220px] px-3 py-2 bg-white border border-slate-200 rounded-xl"
                />
                <button
                  type="button"
                  disabled={savingGlobalMaint}
                  onClick={() => void handleSaveGlobalMaintenanceMsg()}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold whitespace-nowrap cursor-pointer"
                >
                  Guardar Mensaje
                </button>
              </div>
            </div>

            {/* Global SENIAT Venezuela Legal Invoicing Switch (ALL Clients) */}
            <div
              className={`rounded-2xl border p-4 sm:p-5 space-y-3 ${
                seniatLegalActivo
                  ? 'bg-emerald-50/80 border-emerald-300'
                  : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
                      seniatLegalActivo
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-700'
                        : 'bg-slate-100 border-slate-200 text-slate-600'
                    }`}
                  >
                    <Scale className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex flex-wrap items-center gap-2">
                      Facturación Legal SENIAT Venezuela (Todos los Clientes)
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                          seniatLegalActivo
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {seniatLegalActivo ? 'Activada' : 'Desactivada'}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Al activarlo, las facturas térmicas y PDF de <b>todos los comercios</b> se
                      imprimen bajo el formato legal del SENIAT Venezuela (Razón Social, RIF,
                      Domicilio Fiscal, N° de Control, Base Imponible/Exento, IVA 16%, Total Bs. +
                      Ref. BCV y Providencia Administrativa).
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={savingSeniat}
                  onClick={() => void handleToggleSeniatLegal(!seniatLegalActivo)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer ${
                    seniatLegalActivo
                      ? 'bg-rose-600 hover:bg-rose-700 text-white'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  }`}
                >
                  {seniatLegalActivo
                    ? 'Desactivar Respaldo SENIAT'
                    : 'Activar Facturación Legal SENIAT'}
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-2 text-xs">
                <input
                  type="text"
                  value={seniatProvidenciaDraft}
                  onChange={(e) => setSeniatProvidenciaDraft(e.target.value)}
                  placeholder="Providencia Administrativa SNAT/2011/00071"
                  maxLength={140}
                  className="md:col-span-5 px-3 py-2 bg-white border border-slate-200 rounded-xl"
                />
                <input
                  type="text"
                  value={seniatPieLegalDraft}
                  onChange={(e) => setSeniatPieLegalDraft(e.target.value)}
                  placeholder="Pie legal SENIAT en factura..."
                  maxLength={220}
                  className="md:col-span-5 px-3 py-2 bg-white border border-slate-200 rounded-xl"
                />
                <button
                  type="button"
                  disabled={savingSeniat}
                  onClick={() => void handleSaveSeniatTexts()}
                  className="md:col-span-2 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold whitespace-nowrap cursor-pointer"
                >
                  Guardar SENIAT
                </button>
              </div>
            </div>

            {!activeTenant ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto">
                  <Building2 className="w-7 h-7" />
                </div>
                <div className="max-w-md mx-auto space-y-1.5">
                  <h2 className="text-lg font-bold text-slate-900">
                    Aún no hay comercios registrados en esta base de datos
                  </h2>
                  <p className="text-xs text-slate-500">
                    Registra el primer cliente para crear su nodo individual aislado en Firestore con su propio inventario, ventas, fiados, cajeros y membresía.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowNewClientModal(true)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" /> Registrar Primer Cliente
                </button>
              </div>
            ) : (
              <>
                {/* Active Tenant Context Banner */}
                <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 flex items-center justify-center shrink-0">
                      <Store className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 truncate">
                        Nodo activo: {activeTenant.nombre_local}
                        {activeTenant.rif ? ` · RIF ${activeTenant.rif}` : ''}
                      </p>
                      <p className="text-[11px] font-mono text-slate-500 truncate">
                        {activeTenant.email} · ID: {activeTenant.id}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void handleQuickToggleVerification(activeTenant)}
                      className={`px-3 py-1.5 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer ${
                        activeTenant.verificacion_datos?.activo
                          ? 'bg-amber-500 hover:bg-amber-600 border-amber-600 text-white'
                          : 'bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800'
                      }`}
                      title="Activar o desactivar rápidamente la solicitud de actualización de datos con foto para este cliente"
                    >
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      {activeTenant.verificacion_datos?.activo
                        ? 'Actualiz. Datos: ACTIVA'
                        : 'Activar Actualiz. Datos'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setVerificationClient(activeTenant)}
                      className="px-3 py-1.5 rounded-xl border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-xs font-semibold text-indigo-800 cursor-pointer"
                    >
                      Requisitos y Fotos
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('clients')}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
                    >
                      Ver Todos ({tenants.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowNewClientModal(true)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Nuevo Cliente
                    </button>
                  </div>
                </div>

                {/* Quick KPIs */}
                <div
                  className={`grid gap-4 ${isMobileLayout ? 'grid-cols-2' : 'grid-cols-2 lg:grid-cols-4'}`}
                >
                  <div className="bg-white p-4 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500">Turno abierto</span>
                    <p className="text-2xl font-mono font-bold text-slate-900 mt-1">
                      ${liveShiftUsd.toFixed(2)}
                    </p>
                    <span className="text-xs text-emerald-700 font-mono">
                      {liveSales.length} venta(s) · {config.caja_abierta ? 'Caja Abierta' : 'Caja Cerrada'}
                    </span>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500">
                      Moneda activa (USD + {localCurrency.code})
                    </span>
                    <p className="text-xl font-mono font-bold text-sky-700 mt-1">
                      {localCurrency.rateLabel} {formatRateNumber(bcvRate, localCurrencyCode)}{' '}
                      {localCurrency.shortLabel}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-slate-500 font-mono">
                        {localCurrencyCode === 'VES' ? 'P1' : 'T2'}:{' '}
                        {formatRateNumber(secondaryRate, localCurrencyCode)}
                      </span>
                      <button
                        type="button"
                        disabled={ratesSyncing}
                        onClick={() => void syncAllRates(false)}
                        className="text-[11px] font-semibold text-sky-700 hover:underline disabled:opacity-50 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className={`w-3 h-3 ${ratesSyncing ? 'animate-spin' : ''}`} />{' '}
                        {ratesSyncing ? 'Sincronizando...' : 'Sincronizar'}
                      </button>
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500">Equipo operativo</span>
                    <p className="text-2xl font-mono font-bold text-slate-900 mt-1">
                      {cashiers.filter((c) => c.activo !== false).length} activos
                    </p>
                    <span className="text-xs text-slate-500">
                      {systemUsers.length} admin/owner registrados
                    </span>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500">Licencia / Membresía</span>
                    <p className="text-xl font-bold text-slate-900 mt-1">
                      {membershipExpired ? 'Vencida / Suspendida' : membership?.nombre || 'Activa'}
                    </p>
                    <span className="text-xs text-slate-500 font-mono">
                      {membership?.vence
                        ? `Vence: ${new Date(membership.vence).toLocaleDateString('es-VE')}`
                        : 'Sin fecha límite'}
                    </span>
                  </div>
                </div>

                {/* Multi-Currency Selector & Live Exchange Rate Manager for Active Store */}
                <CurrencyRateManager
                  mode="owner"
                  tenantLabel={activeTenant.nombre_local}
                />

                {/* Store settings & Remote switches */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Settings2 className="w-4 h-4 text-sky-600" /> Identidad Comercial y Meta
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-semibold text-slate-600 block mb-1">
                          Nombre del Comercio
                        </label>
                        <input
                          type="text"
                          value={storeNameDraft}
                          onChange={(e) => setStoreNameDraft(e.target.value)}
                          className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-semibold text-slate-600 block mb-1">
                          Meta de Ventas (USD)
                        </label>
                        <input
                          type="number"
                          step="1"
                          value={metaUsdDraft}
                          onChange={(e) => setMetaUsdDraft(e.target.value)}
                          className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleSaveGeneral}
                      className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      Guardar Cambios
                    </button>
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
                    <h3 className="text-sm font-bold text-slate-900">Interruptores de Control Remoto</h3>
                    {[
                      {
                        key: 'admin_bloqueado' as const,
                        label: 'Bloquear Panel de Administrador',
                        desc: 'Impide que el rol Admin de este nodo edite precios o inventario.',
                        val: adminAccessBlocked,
                      },
                      {
                        key: 'usuario_congelado' as const,
                        label: 'Congelar Terminal de Cajero',
                        desc: 'Muestra pantalla de bloqueo inmediato en cajas de este cliente.',
                        val: userFrozen,
                      },
                      {
                        key: 'mantenimiento' as const,
                        label: 'Modo Mantenimiento en Nodo',
                        desc: 'Detiene operaciones en caja y admin manteniendo acceso del Propietario.',
                        val: maintenanceMode,
                      },
                    ].map((sw) => (
                      <label
                        key={sw.key}
                        className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer"
                      >
                        <div>
                          <p className="text-xs font-bold text-slate-900">{sw.label}</p>
                          <p className="text-[11px] text-slate-500">{sw.desc}</p>
                        </div>
                        <input
                          type="checkbox"
                          checked={sw.val}
                          onChange={(e) => toggleFlag(sw.key, e.target.checked)}
                          className="w-4 h-4 accent-rose-600"
                        />
                      </label>
                    ))}
                  </div>
                </div>

                <AnalyticsView compact />
              </>
            )}
          </div>
        )}

        {tab === 'clients' && (
          <div className="space-y-5">
            {/* KPIs */}
            <div className={`grid gap-3 ${isMobileLayout ? 'grid-cols-2' : 'grid-cols-2 lg:grid-cols-4'}`}>
              <div className="bg-white rounded-2xl border border-slate-200 p-4">
                <span className="text-xs text-slate-500">Clientes Registrados</span>
                <p className="text-2xl font-mono font-bold text-slate-900 mt-1">{clientStats.total}</p>
                <span className="text-[11px] text-slate-500">Nodos individuales en Firestore</span>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 p-4">
                <span className="text-xs text-slate-500">Membresías Activas</span>
                <p className="text-2xl font-mono font-bold text-emerald-700 mt-1">{clientStats.active}</p>
                <span className="text-[11px] text-emerald-700">Operando sin restricciones</span>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 p-4">
                <span className="text-xs text-slate-500">Por Vencer (≤ 5 días)</span>
                <p className="text-2xl font-mono font-bold text-amber-600 mt-1">{clientStats.expiring}</p>
                <span className="text-[11px] text-amber-700">Requieren renovación pronto</span>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 p-4">
                <span className="text-xs text-slate-500">Vencidos / Congelados</span>
                <p className="text-2xl font-mono font-bold text-rose-600 mt-1">{clientStats.expired}</p>
                <span className="text-[11px] text-rose-600">Acceso suspendido</span>
              </div>
            </div>

            {/* Search & Filters */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2.5">
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={clientSearch}
                    onChange={(e) => setClientSearch(e.target.value)}
                    placeholder="Buscar por comercio, razón social, RIF, correo o ID de nodo..."
                    className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  {clientSearch && (
                    <button
                      type="button"
                      onClick={() => setClientSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setShowNewClientModal(true)}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" /> Registrar Nuevo Cliente
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: 'all', label: `Todos (${clientStats.total})` },
                    { id: 'active', label: `Activos (${clientStats.active})` },
                    { id: 'expiring', label: `Por vencer (${clientStats.expiring})` },
                    { id: 'expired', label: `Vencidos / Congelados (${clientStats.expired})` },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setClientFilter(f.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                      clientFilter === f.id
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Client List */}
            {filteredClients.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-3">
                <p className="text-xs text-slate-400">
                  {tenants.length === 0
                    ? 'No hay clientes registrados en el sistema todavía.'
                    : 'Ningún cliente coincide con el criterio de búsqueda.'}
                </p>
                {tenants.length === 0 && (
                  <button
                    type="button"
                    onClick={() => setShowNewClientModal(true)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5" /> Registrar Primer Cliente
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredClients.map((t) => {
                  const isCurrent = t.id === activeTenantId;
                  const now = Date.now();
                  const vence = t.membresia?.vence || 0;
                  const daysLeft = vence ? Math.ceil((vence - now) / 86_400_000) : 0;
                  const isExp =
                    t.activo === false ||
                    t.membresia?.estado === 'suspendida' ||
                    !vence ||
                    vence <= now;
                  const isPendingUid = String(t.ownerUid || '').startsWith('pending_');

                  return (
                    <div
                      key={t.id}
                      className={`bg-white rounded-2xl border p-4 space-y-3 transition-all ${
                        isCurrent ? 'border-sky-400 ring-2 ring-sky-100' : 'border-slate-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-extrabold text-slate-900">
                              {t.nombre_local}
                            </span>
                            {isCurrent && (
                              <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 text-[10px] font-bold">
                                NODO ACTIVO
                              </span>
                            )}
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                isExp
                                  ? 'bg-rose-100 text-rose-700'
                                  : daysLeft <= 5
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-emerald-100 text-emerald-700'
                              }`}
                            >
                              {isExp
                                ? t.membresia?.estado === 'suspendida'
                                  ? 'SUSPENDIDA'
                                  : 'VENCIDA'
                                : `${t.membresia?.nombre || 'Activa'} · ${daysLeft}d`}
                            </span>
                            {t.congelado && (
                              <span className="px-2 py-0.5 rounded-md bg-cyan-100 text-cyan-800 text-[10px] font-bold">
                                CONGELADO
                              </span>
                            )}
                            {t.admin_bloqueado && (
                              <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold">
                                ADMIN BLOQ.
                              </span>
                            )}
                            {t.mantenimiento && (
                              <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 text-[10px] font-bold">
                                MANTENIMIENTO
                              </span>
                            )}
                            {isPendingUid && (
                              <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-semibold">
                                Pendiente de primer acceso
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
                            <span>
                              <b>Correo:</b> <span className="font-mono">{t.email}</span>
                            </span>
                            {t.razon_social && (
                              <span>
                                <b>Razón Social:</b> {t.razon_social}
                              </span>
                            )}
                            {t.rif && (
                              <span>
                                <b>RIF:</b> <span className="font-mono">{t.rif}</span>
                              </span>
                            )}
                            {t.telefono && (
                              <span>
                                <b>Tel:</b> <span className="font-mono">{t.telefono}</span>
                              </span>
                            )}
                            {t.contacto_nombre && (
                              <span>
                                <b>Contacto:</b> {t.contacto_nombre}
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] font-mono text-slate-400">
                            Nodo Firestore: tenants/{t.id} · Vence:{' '}
                            {vence ? new Date(vence).toLocaleDateString('es-VE') : 'N/A'}
                            {t.direccion_fiscal ? ` · Dir: ${t.direccion_fiscal}` : ''}
                          </p>
                        </div>
                      </div>

                      {/* Administration Buttons & Per-Client Days Control */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100 text-xs">
                        <button
                          type="button"
                          onClick={() => {
                            setActiveTenantId(t.id);
                            setTab('overview');
                            notifyToast(`Administrando nodo de "${t.nombre_local}".`, 'info');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Sliders className="w-3.5 h-3.5" /> Administrar Nodo
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setActiveTenantId(t.id);
                            onEnterPos();
                          }}
                          className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Store className="w-3.5 h-3.5" /> Abrir POS
                        </button>

                        <button
                          type="button"
                          onClick={() => handleQuickAdjustTenantDays(t, 30)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold cursor-pointer whitespace-nowrap shrink-0"
                          title="Sumar 30 días de vigencia"
                        >
                          +30 Días
                        </button>

                        <button
                          type="button"
                          onClick={() => handleQuickAdjustTenantDays(t, -30)}
                          className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 font-semibold cursor-pointer whitespace-nowrap shrink-0"
                          title="Restar 30 días de vigencia"
                        >
                          -30 Días
                        </button>

                        {/* Editable Days + / - / 0 widget */}
                        <div className="inline-flex items-center rounded-xl border border-slate-200 bg-slate-50 overflow-hidden shrink-0">
                          <input
                            type="number"
                            min={1}
                            value={clientDaysDrafts[t.id] ?? '10'}
                            onChange={(e) =>
                              setClientDaysDrafts((prev) => ({ ...prev, [t.id]: e.target.value }))
                            }
                            aria-label={`Días editables para ${t.nombre_local}`}
                            className="w-12 px-1.5 py-1 text-center font-mono tabular-nums font-bold text-slate-900 bg-white border-r border-slate-200 outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const d = Math.max(1, Math.round(Number(clientDaysDrafts[t.id] ?? 10) || 10));
                              void handleQuickAdjustTenantDays(t, d);
                            }}
                            className="px-2 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
                            title="Sumar los días indicados"
                          >
                            +
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const d = Math.max(1, Math.round(Number(clientDaysDrafts[t.id] ?? 10) || 10));
                              void handleQuickAdjustTenantDays(t, -d);
                            }}
                            className="px-2 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer"
                            title="Restar los días indicados"
                          >
                            -
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleSetTenantZeroDays(t)}
                            className="px-2 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
                            title="Poner vigencia en 0 días (bloquear sistema)"
                          >
                            0
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() =>
                            updateTenantRecord(t.id, {
                              membresia: {
                                plan: t.membresia?.plan || 'manual',
                                nombre: t.membresia?.nombre || 'Membresía',
                                vence: t.membresia?.vence || Date.now(),
                                estado:
                                  t.membresia?.estado === 'suspendida' ? 'activa' : 'suspendida',
                              },
                            })
                          }
                          className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer whitespace-nowrap shrink-0"
                        >
                          {t.membresia?.estado === 'suspendida' ? 'Reactivar' : 'Suspender'}
                        </button>

                        <button
                          type="button"
                          onClick={() => updateTenantRecord(t.id, { congelado: !t.congelado })}
                          className={`px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0 ${
                            t.congelado
                              ? 'bg-cyan-600 text-white'
                              : 'bg-cyan-50 hover:bg-cyan-100 text-cyan-800'
                          }`}
                        >
                          <Snowflake className="w-3.5 h-3.5" />
                          {t.congelado ? 'Descongelar' : 'Congelar'}
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            updateTenantRecord(t.id, { admin_bloqueado: !t.admin_bloqueado })
                          }
                          className={`px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0 ${
                            t.admin_bloqueado
                              ? 'bg-amber-600 text-white'
                              : 'bg-amber-50 hover:bg-amber-100 text-amber-800'
                          }`}
                        >
                          <Lock className="w-3.5 h-3.5" />
                          {t.admin_bloqueado ? 'Desbloq. Admin' : 'Bloq. Admin'}
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            updateTenantRecord(t.id, { mantenimiento: !t.mantenimiento })
                          }
                          className={`px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0 ${
                            t.mantenimiento
                              ? 'bg-purple-600 text-white'
                              : 'bg-purple-50 hover:bg-purple-100 text-purple-800'
                          }`}
                        >
                          <Wrench className="w-3.5 h-3.5" />
                          {t.mantenimiento ? 'Salir Mant.' : 'Mantenimiento'}
                        </button>

                        <button
                          type="button"
                          onClick={() => setInvoiceConfigClient(t)}
                          className="px-2.5 py-1.5 rounded-xl border border-sky-200 bg-sky-50 hover:bg-sky-100 text-sky-800 font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                          title="Configurar logotipo, formato térmico, color, intensidad e impresora predeterminada para este cliente"
                        >
                          <Printer className="w-3.5 h-3.5" /> Logo y Factura
                        </button>

                        <button
                          type="button"
                          onClick={() => void handleQuickToggleVerification(t)}
                          className={`px-2.5 py-1.5 rounded-xl border font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0 ${
                            t.verificacion_datos?.activo
                              ? 'border-amber-500 bg-amber-500 hover:bg-amber-600 text-white'
                              : 'border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-800'
                          }`}
                          title="Activar o desactivar de inmediato la actualización de datos para este cliente"
                        >
                          <ClipboardCheck className="w-3.5 h-3.5" />
                          {t.verificacion_datos?.activo ? 'Actualiz. Datos: ON' : 'Activar Actualiz. Datos'}
                        </button>

                        <button
                          type="button"
                          onClick={() => setVerificationClient(t)}
                          className="px-2.5 py-1.5 rounded-xl border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                          title="Configurar requisitos personalizados, solicitar fotos y revisar recaudos enviados"
                        >
                          <ClipboardCheck className="w-3.5 h-3.5" />
                          Requisitos / Fotos
                        </button>

                        <button
                          type="button"
                          onClick={() => openEditClientModal(t)}
                          className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Pencil className="w-3.5 h-3.5" /> Editar Fiscal
                        </button>

                        <button
                          type="button"
                          onClick={() => handleSendClientReset(t.email)}
                          className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-sky-700 font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <KeyRound className="w-3.5 h-3.5" /> Reset Clave
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteClient(t)}
                          className="px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold inline-flex items-center gap-1 cursor-pointer ml-auto whitespace-nowrap shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Eliminar
                        </button>
                      </div>

                      {/* Per-Client Contracts & Authorization PDF Row */}
                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
                        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide mr-1">
                          Contratos PDF:
                        </span>
                        <button
                          type="button"
                          onClick={() => handleGenerateClientDbAuthPdf(t)}
                          className="px-3 py-1.5 rounded-xl border border-sky-200 bg-sky-50 hover:bg-sky-100 text-sky-900 font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                          title="Generar PDF de autorización de acceso a base de datos con consentimiento del propietario"
                        >
                          <Database className="w-3.5 h-3.5 text-sky-600" />
                          Autorización Acceso BD (Consentimiento Propietario)
                        </button>
                        <button
                          type="button"
                          onClick={() => openRenewalContractModal(t)}
                          className="px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                          title="Seleccionar el plan contratado y generar contrato de renovación de membresía en PDF"
                        >
                          <FileCheck2 className="w-3.5 h-3.5 text-emerald-600" />
                          Contrato Renovación Membresía (PDF)
                        </button>
                        {(t.logo_url || t.invoice_config?.logo_data_url || t.invoice_config?.impresora_nombre) && (
                          <span className="ml-auto inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-[11px] font-semibold text-slate-700">
                            <Printer className="w-3 h-3 text-sky-600" />
                            {t.invoice_config?.impresora_nombre || 'Impresora configurada'} ·{' '}
                            {t.invoice_config?.ancho_papel || '80mm'}
                            {(t.logo_url || t.invoice_config?.logo_data_url) && ' · Logo OK'}
                          </span>
                        )}
                      </div>

                      {/* Individual Pago Móvil / Membership Payments sent by this Client */}
                      {(() => {
                        const clientPayments = membershipPayments.filter((p) => p.tenantId === t.id);
                        if (clientPayments.length === 0) return null;
                        return (
                          <div className="pt-2 border-t border-slate-100 space-y-1.5">
                            <p className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                              <CreditCard className="w-3.5 h-3.5 text-sky-600" />
                              Pagos Móvil / Comprobantes enviados por {t.nombre_local} ({clientPayments.length})
                            </p>
                            <div className="space-y-1.5">
                              {clientPayments.slice(0, 6).map((p) => (
                                <div
                                  key={p.key}
                                  className={`p-2.5 rounded-xl border text-xs flex flex-wrap items-center justify-between gap-2 ${
                                    p.estado === 'pendiente'
                                      ? 'bg-amber-50/70 border-amber-200'
                                      : p.estado === 'en_revision'
                                      ? 'bg-sky-50/70 border-sky-200'
                                      : p.estado === 'aprobado'
                                      ? 'bg-emerald-50/50 border-emerald-200'
                                      : 'bg-rose-50/40 border-rose-200'
                                  }`}
                                >
                                  <div className="flex items-start gap-2.5 min-w-0 flex-1">
                                    {p.captura && (
                                      <button
                                        type="button"
                                        onClick={() => setPreviewCaptura(p.captura || null)}
                                        className="w-11 h-11 rounded-lg border border-slate-200 overflow-hidden bg-white shrink-0 cursor-pointer hover:ring-2 hover:ring-sky-400"
                                        title="Ver captura de Pago Móvil"
                                      >
                                        <img
                                          src={p.captura}
                                          alt="Captura Pago Móvil"
                                          className="w-full h-full object-cover"
                                        />
                                      </button>
                                    )}
                                    <div className="min-w-0">
                                      <p className="font-bold text-slate-900">
                                        {p.nombre} · Ref: <span className="font-mono">{p.ref}</span> ·{' '}
                                        <span className="font-mono text-sky-700">
                                          ${Number(p.usd).toFixed(2)}
                                        </span>{' '}
                                        ({formatMoney(p.bs)} Bs)
                                      </p>
                                      <p className="text-[11px] text-slate-500">
                                        Usuario: {p.usuario} ·{' '}
                                        {p.t ? new Date(p.t).toLocaleString('es-VE') : ''} · Estado:{' '}
                                        <b
                                          className={`uppercase ${
                                            p.estado === 'pendiente'
                                              ? 'text-amber-700'
                                              : p.estado === 'en_revision'
                                              ? 'text-sky-700'
                                              : p.estado === 'aprobado'
                                              ? 'text-emerald-700'
                                              : 'text-rose-700'
                                          }`}
                                        >
                                          {p.estado === 'en_revision' ? 'En Revisión' : p.estado}
                                        </b>
                                      </p>
                                      {p.verificacion_ia && (
                                        <p
                                          className={`text-[11px] mt-0.5 font-medium ${
                                            p.verificacion_ia.es_comprobante_valido
                                              ? 'text-emerald-700'
                                              : 'text-amber-800'
                                          }`}
                                        >
                                          IA: {p.verificacion_ia.es_comprobante_valido ? 'Comprobante válido' : 'Revisar captura'}
                                          {p.verificacion_ia.referencia_detectada
                                            ? ` · Ref IA: ${p.verificacion_ia.referencia_detectada}`
                                            : ''}
                                          {p.verificacion_ia.monto_detectado_bs
                                            ? ` · Bs ${formatMoney(p.verificacion_ia.monto_detectado_bs)}`
                                            : ''}
                                          {p.verificacion_ia.resumen ? ` — ${p.verificacion_ia.resumen}` : ''}
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                                    {p.captura && (
                                      <button
                                        type="button"
                                        onClick={() => setPreviewCaptura(p.captura || null)}
                                        className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                      >
                                        <Eye className="w-3 h-3" /> Captura
                                      </button>
                                    )}
                                    {p.estado !== 'aprobado' && (
                                      <button
                                        type="button"
                                        onClick={() => void handleUpdatePaymentStatus(p, 'aprobado')}
                                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                        title="Aprobar plan comprado y generar PDF comprobante automáticamente"
                                      >
                                        <CheckCircle2 className="w-3 h-3" /> Aprobar + PDF
                                      </button>
                                    )}
                                    {p.estado !== 'en_revision' && p.estado !== 'aprobado' && (
                                      <button
                                        type="button"
                                        onClick={() => void handleUpdatePaymentStatus(p, 'en_revision')}
                                        className="px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                      >
                                        <Clock className="w-3 h-3" /> En Revisión
                                      </button>
                                    )}
                                    {p.estado !== 'rechazado' && p.estado !== 'aprobado' && (
                                      <button
                                        type="button"
                                        onClick={() => void handleUpdatePaymentStatus(p, 'rechazado')}
                                        className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                      >
                                        <XCircle className="w-3 h-3" /> Rechazar
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteMembershipPayment(p)}
                                      className="p-1.5 rounded-lg bg-white border border-rose-200 hover:bg-rose-50 text-rose-600 cursor-pointer"
                                      title="Eliminar reporte de pago"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {tab === 'analytics' && <AnalyticsView />}

        {tab === 'users' && <UserManagementTab isOwnerView />}

        {tab === 'notifications' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Targeted Broadcast Composer + Quick Presets + History */}
            <form
              onSubmit={handleSendBroadcast}
              className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Send className="w-4 h-4 text-sky-600" /> Enviar Notificación en Tiempo Real
                </h3>
                {config.broadcast && (
                  <button
                    type="button"
                    onClick={handleClearBroadcast}
                    className="text-xs font-semibold text-rose-600 hover:underline cursor-pointer"
                  >
                    Quitar aviso activo
                  </button>
                )}
              </div>

              {config.broadcast && (
                <div className="p-2.5 rounded-xl bg-sky-50 border border-sky-200 text-xs flex items-center justify-between gap-2">
                  <span className="truncate text-sky-900">
                    <b>Activo ahora:</b> {config.broadcast.titulo} — {config.broadcast.texto}
                  </span>
                  <button
                    type="button"
                    onClick={handleClearBroadcast}
                    className="text-rose-600 font-semibold shrink-0 cursor-pointer"
                  >
                    Desactivar
                  </button>
                </div>
              )}

              {/* Quick Templates */}
              <div className="flex flex-wrap gap-1.5 text-[11px]">
                {[
                  {
                    t: 'Revisión de tasas',
                    m: 'Por favor verificar y sincronizar la tasa BCV y Paralelo antes de facturar.',
                    tp: 'info' as const,
                  },
                  {
                    t: 'Cierre puntual',
                    m: 'Recuerden realizar el cierre de caja y taller antes de finalizar el turno.',
                    tp: 'warning' as const,
                  },
                  {
                    t: 'Aviso urgente',
                    m: 'Atención en caja: comunicarse con administración de inmediato.',
                    tp: 'critical' as const,
                  },
                ].map((tpl) => (
                  <button
                    key={tpl.t}
                    type="button"
                    onClick={() => {
                      setBcTitle(tpl.t);
                      setBcText(tpl.m);
                      setBcType(tpl.tp);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                  >
                    + {tpl.t}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <input
                  type="text"
                  value={bcTitle}
                  onChange={(e) => setBcTitle(e.target.value)}
                  placeholder="Título del aviso"
                  className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
                <select
                  value={bcType}
                  onChange={(e) => setBcType(e.target.value as BroadcastConfig['tipo'])}
                  className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="info">Informativo</option>
                  <option value="warning">Advertencia</option>
                  <option value="critical">Urgente / Crítico</option>
                  <option value="update">Actualización</option>
                </select>
                <select
                  value={bcAudience}
                  onChange={(e) => setBcAudience(e.target.value as 'all' | 'cashier' | 'admin')}
                  className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="all">Todos los usuarios</option>
                  <option value="cashier">Solo Cajeros</option>
                  <option value="admin">Solo Administradores</option>
                </select>
              </div>

              <textarea
                rows={3}
                value={bcText}
                onChange={(e) => setBcText(e.target.value)}
                placeholder="Escribe el mensaje que aparecerá de inmediato en las terminales..."
                className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl"
              />

              <div className="flex items-center justify-between">
                <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={bcVoice}
                    onChange={(e) => setBcVoice(e.target.checked)}
                    className="rounded border-slate-300"
                  />
                  Leer en voz alta al recibir
                </label>
                <button
                  type="submit"
                  disabled={sendingBc || !activeTenantId}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer"
                >
                  {sendingBc ? 'Enviando...' : 'Transmitir Ahora'}
                </button>
              </div>

              {/* Recent Notification History with Resend & Delete */}
              <div className="pt-3 border-t border-slate-200 space-y-2">
                <p className="text-xs font-bold text-slate-600">
                  Historial de Notificaciones ({notificationHistory.length})
                </p>
                <div className="max-h-56 overflow-y-auto space-y-1.5">
                  {notificationHistory.length === 0 ? (
                    <p className="text-xs text-slate-400">Aún no se han enviado comunicados.</p>
                  ) : (
                    notificationHistory.slice(0, 15).map((n) => (
                      <div
                        key={n.key}
                        className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                      >
                        <div className="flex items-center justify-between gap-2 font-bold text-slate-800">
                          <span className="truncate">{n.titulo}</span>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="font-mono text-[10px] text-slate-500">
                              {n.audiencia || 'all'} ·{' '}
                              {n.timestamp ? new Date(n.timestamp).toLocaleTimeString('es-VE') : ''}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleResendHistoryNotification(n)}
                              className="text-[11px] font-semibold text-sky-700 hover:underline cursor-pointer"
                            >
                              Reenviar
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteHistoryNotification(n.key)}
                              className="text-rose-600 hover:text-rose-800 cursor-pointer"
                              title="Eliminar del historial"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <p className="text-slate-600 mt-0.5">{n.texto}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </form>

            {/* Right Column: Membership Expiration Warnings + Voice + Scheduled Notices */}
            <div className="space-y-5">
              {/* Automatic Membership Warning Manager */}
              <form
                onSubmit={handleSaveWarningConfig}
                className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    Advertencia de Vencimiento de Membresía
                  </h3>
                  <label className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={avActivo}
                      onChange={(e) => setAvActivo(e.target.checked)}
                    />
                    Activa
                  </label>
                </div>
                <p className="text-[11px] text-slate-500">
                  Muestra una advertencia automática a Cajeros y Administradores cuando falten los días configurados. Usa{' '}
                  <code className="font-mono font-bold">{'{dias}'}</code> para insertar los días restantes.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  <div>
                    <label className="font-semibold text-slate-600 block mb-1">Días previos</label>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={avDias}
                      onChange={(e) => setAvDias(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="font-semibold text-slate-600 block mb-1">Título de advertencia</label>
                    <input
                      type="text"
                      value={avTitulo}
                      onChange={(e) => setAvTitulo(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                    />
                  </div>
                </div>

                <textarea
                  rows={2}
                  value={avMsg}
                  onChange={(e) => setAvMsg(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />

                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      notifyToast(
                        `${avTitulo}: ${avMsg.replace(/\{dias\}/g, avDias || '5')}`,
                        'warning'
                      )
                    }
                    className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer"
                  >
                    Vista previa
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    Guardar Advertencia
                  </button>
                </div>
              </form>

              {/* Voice & Sound Controls */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-emerald-600" /> Síntesis de Voz y Sonidos
                  </h3>
                  <button
                    type="button"
                    onClick={() => speakText('Prueba de audio de Innova Grup completada.', true)}
                    className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold cursor-pointer"
                  >
                    Probar Voz
                  </button>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-xs">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={voiceSettings.activa}
                      onChange={(e) => handleUpdateVoice({ activa: e.target.checked })}
                    />
                    Voz automática activa
                  </label>
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={voiceSettings.sonidos}
                      onChange={(e) => handleUpdateVoice({ sonidos: e.target.checked })}
                    />
                    Tonos de caja activos
                  </label>
                  <label className="inline-flex items-center gap-2">
                    Velocidad:
                    <select
                      value={String(voiceSettings.vel || 1)}
                      onChange={(e) => handleUpdateVoice({ vel: Number(e.target.value) })}
                      className="px-2 py-1 rounded-lg border border-slate-200 bg-slate-50 font-mono"
                    >
                      <option value="0.85">0.85x</option>
                      <option value="1">1.0x</option>
                      <option value="1.15">1.15x</option>
                      <option value="1.3">1.3x</option>
                    </select>
                  </label>
                </div>
                {typeof Notification !== 'undefined' && (
                  <button
                    type="button"
                    onClick={() => Notification.requestPermission()}
                    className="text-xs font-semibold text-sky-700 hover:underline cursor-pointer"
                  >
                    Solicitar permiso de notificaciones del navegador
                  </button>
                )}
              </div>

              {/* Scheduled Daily Notices */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
                <h3 className="text-sm font-bold text-slate-900">Recordatorios Programados Diarios</h3>
                <div className="space-y-2">
                  {Object.entries(scheduledNotices).map(([k, n]) => (
                    <div key={k} className="flex items-center gap-2 text-xs">
                      <input
                        type="checkbox"
                        checked={n.activo}
                        onChange={(e) => handleUpdateNotice(k, 'activo', e.target.checked)}
                      />
                      <input
                        type="time"
                        value={n.hora}
                        onChange={(e) => handleUpdateNotice(k, 'hora', e.target.value)}
                        className="px-2 py-1.5 border border-slate-200 rounded-lg font-mono bg-slate-50"
                      />
                      <input
                        type="text"
                        defaultValue={n.msg}
                        onBlur={(e) => handleUpdateNotice(k, 'msg', e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50"
                      />
                      <button
                        type="button"
                        onClick={() => handleDeleteNotice(k)}
                        className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600 cursor-pointer"
                        title="Eliminar recordatorio"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-xs">
                  <input
                    type="time"
                    value={newNoticeHora}
                    onChange={(e) => setNewNoticeHora(e.target.value)}
                    className="px-2 py-1.5 border border-slate-200 rounded-lg font-mono bg-slate-50"
                  />
                  <input
                    type="text"
                    value={newNoticeMsg}
                    onChange={(e) => setNewNoticeMsg(e.target.value)}
                    placeholder="Nuevo recordatorio automático..."
                    className="flex-1 px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50"
                  />
                  <button
                    type="button"
                    onClick={handleAddNotice}
                    className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-semibold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Añadir
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === 'inventory' && (
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-slate-900">
                Supervisión de Inventario en Tiempo Real · {localName} ({products.length})
              </h3>
              <input
                type="text"
                value={invSearch}
                onChange={(e) => setInvSearch(e.target.value)}
                placeholder="Filtrar producto o código..."
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl w-64"
              />
            </div>
            <div className="overflow-x-auto max-h-[62vh]">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="py-2.5 px-4 font-semibold">Producto</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Costo</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Precio BCV</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Stock</th>
                    <th className="py-2.5 px-4 font-semibold text-right">Valor Stock</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {criticalProducts.slice(0, 80).map((p) => (
                    <tr key={p.key} className="hover:bg-slate-50">
                      <td className="py-2 px-4">
                        <div className="flex items-center gap-2.5">
                          <ProductThumb name={p.id} image={p.image} className="w-8 h-8 text-[10px]" />
                          <div>
                            <p className="font-bold text-slate-900">{p.id}</p>
                            <p className="text-[11px] font-mono text-slate-400">{p.barcode || '-'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-2 px-3 text-right font-mono">${p.cost.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold">${p.price.toFixed(2)}</td>
                      <td
                        className={`py-2 px-3 text-right font-mono font-bold ${
                          p.stock <= 0 ? 'text-rose-600' : p.stock <= 5 ? 'text-amber-600' : 'text-emerald-700'
                        }`}
                      >
                        {p.stock}
                      </td>
                      <td className="py-2 px-4 text-right font-mono">
                        ${(p.cost * Math.max(0, p.stock)).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'membership' && (
          <div className="space-y-5">
            {/* Manual Controls + Pago Móvil + Contract */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                <h3 className="text-sm font-bold text-slate-900">
                  Control Manual de Vigencia y Planes · {localName}
                </h3>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    value={daysInput}
                    onChange={(e) => setDaysInput(e.target.value)}
                    className="w-24 px-3 py-2 text-xs font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => handleAdjustDays(Math.abs(Number(daysInput) || 30))}
                    className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    + Sumar días
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAdjustDays(-Math.abs(Number(daysInput) || 30))}
                    className="px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    - Restar días
                  </button>
                  <button
                    type="button"
                    onClick={handleSetActiveTenantZeroDays}
                    className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                    title="Poner en 0 días disponibles y bloquear acceso"
                  >
                    0 (Poner en 0)
                  </button>
                  <button
                    type="button"
                    onClick={handleToggleMembershipSuspend}
                    className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    {membership?.estado === 'suspendida' ? 'Reactivar' : 'Suspender'}
                  </button>
                </div>

                {/* Plan Apply & Renew */}
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <select
                    value={selectedPlanToApply}
                    onChange={(e) => setSelectedPlanToApply(e.target.value)}
                    className="flex-1 min-w-[160px] px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  >
                    {Object.entries(plans).map(([k, pl]) => {
                      const eff = effectiveDiscountWithPromos(pl, promos);
                      const usd = round2(pl.precio * (1 - eff / 100));
                      return (
                        <option key={k} value={k}>
                          {pl.nombre} · ${usd.toFixed(2)}
                        </option>
                      );
                    })}
                  </select>
                  <button
                    type="button"
                    onClick={() => handleApplyOrRenewPlan(false)}
                    className="px-3 py-2 rounded-xl bg-sky-600 text-white font-semibold cursor-pointer"
                  >
                    Aplicar Plan
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyOrRenewPlan(true)}
                    className="px-3 py-2 rounded-xl bg-emerald-600 text-white font-semibold cursor-pointer"
                  >
                    Renovar y PDF
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      generateContractPDF(
                        localName,
                        membership?.nombre || 'Estándar',
                        'Acuerdo comercial vigente',
                        membership?.vence
                          ? new Date(membership.vence).toLocaleDateString('es-VE')
                          : 'Indefinida',
                        !membershipExpired
                      )
                    }
                    className="px-3.5 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" /> Contrato PDF
                  </button>
                  <button
                    type="button"
                    onClick={handleResetMembership}
                    className="px-3.5 py-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold cursor-pointer"
                  >
                    Restablecer Membresía
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">
                      Datos Bancarios y Pago Móvil del Propietario
                    </h3>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                        pagoMovil?.activo !== false
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {pagoMovil?.activo !== false ? 'Activo' : 'Desactivado'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleTogglePagoMovilActive()}
                    className={`px-3 py-1.5 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                      pagoMovil?.activo !== false
                        ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {pagoMovil?.activo !== false ? (
                      <>
                        <Pause className="w-3.5 h-3.5" /> Desactivar Pago Móvil
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" /> Activar Pago Móvil
                      </>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  {pagoMovil?.activo !== false
                    ? 'Visible para los clientes en la pasarela de membresías. Puedes desactivarlo cuando prefieras cobrar solo por enlace de pago.'
                    : 'Desactivado: los datos de Pago Móvil están ocultos para los clientes hasta que vuelvas a activarlos.'}
                </p>

                {pagoMovil && (pagoMovil.banco || pagoMovil.tel || pagoMovil.ci || pagoMovil.titular) && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
                    {(
                      [
                        ['Banco', pagoMovil.banco],
                        ['Teléfono Pago Móvil', pagoMovil.tel],
                        ['Cédula / RIF', pagoMovil.ci],
                        ['Titular', pagoMovil.titular],
                      ] as Array<[string, string | undefined]>
                    ).map(([label, val]) => (
                      <div key={label} className="flex items-center justify-between gap-2">
                        <span className="text-slate-500">{label}:</span>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-slate-900">{val || '-'}</span>
                          {val && (
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard?.writeText(val);
                                notifyToast(`${label} copiado: ${val}`, 'info');
                              }}
                              className="px-1.5 py-0.5 rounded bg-white border border-slate-200 text-sky-700 hover:bg-sky-50 inline-flex items-center gap-1 text-[10px] font-semibold cursor-pointer"
                              title={`Copiar ${label}`}
                            >
                              <Copy className="w-2.5 h-2.5" /> Copiar
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(
                          `${pagoMovil.banco} | ${pagoMovil.tel} | ${pagoMovil.ci} | ${pagoMovil.titular}`
                        );
                        notifyToast('Datos bancarios copiados.', 'info');
                      }}
                      className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-sky-700 hover:underline cursor-pointer"
                    >
                      <Copy className="w-3 h-3" /> Copiar resumen bancario
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2.5 text-xs">
                  <input
                    type="text"
                    value={pmBanco}
                    onChange={(e) => setPmBanco(e.target.value)}
                    placeholder="Banco (ej. Banesco 0134)"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <input
                    type="tel"
                    value={pmTel}
                    onChange={(e) => setPmTel(e.target.value)}
                    placeholder="Teléfono (04121234567)"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                  <input
                    type="text"
                    value={pmCi}
                    onChange={(e) => setPmCi(e.target.value)}
                    placeholder="Cédula / RIF"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                  <input
                    type="text"
                    value={pmTitular}
                    onChange={(e) => setPmTitular(e.target.value)}
                    placeholder="Titular de la cuenta"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <input
                    type="text"
                    value={waMembresia}
                    onChange={(e) => setWaMembresia(e.target.value)}
                    placeholder="WhatsApp soporte/cobros (ej. 584245655395)"
                    className="col-span-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleSavePagoMovil}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Guardar Datos Bancarios y Pago Móvil
                </button>
              </div>
            </div>

            {/* Plans CRUD & Payment Links */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Crown className="w-4 h-4 text-amber-500" />
                    {editingPlanKey ? 'Editar Plan de Membresía' : 'Planes de Membresía, Montos, Meses y Enlaces de Pago'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Crea, edita o elimina los planes que ven tus clientes junto con su oferta individual y enlace de pago directo.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {editingPlanKey && (
                    <button
                      type="button"
                      onClick={resetPlanForm}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" /> Cancelar edición
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={handleRestoreDefaultPlans}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer"
                  >
                    Restaurar planes base
                  </button>
                </div>
              </div>

              <form
                onSubmit={handleSavePlan}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-xs"
              >
                <div className="grid grid-cols-1 sm:grid-cols-6 gap-2.5">
                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Nombre del plan
                    </label>
                    <input
                      type="text"
                      value={planNameDraft}
                      onChange={(e) => setPlanNameDraft(e.target.value)}
                      placeholder="Ej: 1 mes, Trimestral, Plan VIP"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Meses
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={planMesesDraft}
                      onChange={(e) => setPlanMesesDraft(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Monto (USD)
                    </label>
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={planPrecioDraft}
                      onChange={(e) => setPlanPrecioDraft(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono tabular-nums font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Oferta (%)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step="1"
                      value={planOfertaDraft}
                      onChange={(e) => setPlanOfertaDraft(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono tabular-nums"
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold cursor-pointer inline-flex items-center justify-center gap-1 whitespace-nowrap"
                    >
                      {editingPlanKey ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" /> Guardar
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" /> Añadir Plan
                        </>
                      )}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                    Enlace de pago para este plan (opcional — ej. Stripe, PayPal, MercadoPago, Binance Pay)
                  </label>
                  <input
                    type="url"
                    value={planLinkDraft}
                    onChange={(e) => setPlanLinkDraft(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </form>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {Object.entries(plans)
                  .sort(([, a], [, b]) => (Number(a.meses) || 0) - (Number(b.meses) || 0))
                  .map(([k, pl]) => {
                    const effPct = effectiveDiscountWithPromos(pl, promos);
                    const finalUsd = round2(pl.precio * (1 - effPct / 100));
                    const link = planLinks[k];
                    return (
                      <div
                        key={k}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between gap-2 text-xs"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="font-bold text-slate-900 truncate">{pl.nombre}</p>
                            <p className="text-[11px] text-slate-500 font-mono">
                              {pl.meses} {pl.meses === 1 ? 'mes' : 'meses'} · Base ${Number(pl.precio).toFixed(2)}
                              {pl.oferta > 0 ? ` (-${pl.oferta}% plan)` : ''}
                            </p>
                          </div>
                          <span className="font-mono tabular-nums font-extrabold text-sky-700 text-sm shrink-0">
                            ${finalUsd.toFixed(2)}
                          </span>
                        </div>

                        {link && (
                          <div className="flex items-center justify-between gap-1.5 px-2.5 py-1.5 rounded-lg bg-white border border-slate-200">
                            <span className="font-mono text-[11px] text-slate-600 truncate flex-1">
                              {link}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard?.writeText(link);
                                notifyToast(`Enlace del plan "${pl.nombre}" copiado.`, 'info');
                              }}
                              className="px-2 py-0.5 rounded bg-sky-50 text-sky-700 font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                            >
                              <Copy className="w-3 h-3" /> Copiar
                            </button>
                            <a
                              href={link}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1 text-slate-500 hover:text-sky-700 shrink-0"
                              title="Abrir enlace"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        )}

                        <div className="flex items-center justify-end gap-1.5 pt-1 border-t border-slate-200/70">
                          <button
                            type="button"
                            onClick={() => handleStartEditPlan(k, pl)}
                            className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-sky-700 hover:bg-sky-50 font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Pencil className="w-3 h-3" /> Editar
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeletePlan(k)}
                            className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" /> Eliminar
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* Additional Payment Methods CRUD (with Copy buttons) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    {editingMethodId
                      ? 'Editar Método de Pago para Membresías'
                      : 'Métodos de Pago Adicionales para Membresías'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Registra cuentas adicionales (Zelle, Binance Pay, Transferencia Bancaria u otro Pago Móvil) con botón Copiar visible para los clientes.
                  </p>
                </div>
                {editingMethodId && (
                  <button
                    type="button"
                    onClick={resetMethodForm}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" /> Cancelar edición
                  </button>
                )}
              </div>

              <form
                onSubmit={handleSaveMethod}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-6 gap-2.5 text-xs"
              >
                <select
                  value={methodTipo}
                  onChange={(e) =>
                    setMethodTipo(e.target.value as MembershipPaymentMethod['tipo'])
                  }
                  className="px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="zelle">Zelle</option>
                  <option value="binance">Binance Pay</option>
                  <option value="pago_movil">Pago Móvil</option>
                  <option value="transferencia">Transferencia</option>
                  <option value="otro">Otro</option>
                </select>
                <input
                  type="text"
                  value={methodTitulo}
                  onChange={(e) => setMethodTitulo(e.target.value)}
                  placeholder="Título (ej: Zelle Empresarial)"
                  className="sm:col-span-2 px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                />
                <input
                  type="text"
                  value={methodDetalle}
                  onChange={(e) => setMethodDetalle(e.target.value)}
                  placeholder="Correo / Teléfono / ID / Nro. Cuenta *"
                  className="sm:col-span-3 px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                />
                <input
                  type="text"
                  value={methodTitular}
                  onChange={(e) => setMethodTitular(e.target.value)}
                  placeholder="Titular (opcional)"
                  className="sm:col-span-2 px-3 py-2 bg-white border border-slate-200 rounded-xl"
                />
                <input
                  type="text"
                  value={methodDoc}
                  onChange={(e) => setMethodDoc(e.target.value)}
                  placeholder="Cédula / RIF / Banco (opcional)"
                  className="sm:col-span-2 px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                />
                <label className="inline-flex items-center gap-1.5 font-semibold text-slate-700 px-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={methodActivo}
                    onChange={(e) => setMethodActivo(e.target.checked)}
                  />
                  Visible
                </label>
                <button
                  type="submit"
                  className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer inline-flex items-center justify-center gap-1 whitespace-nowrap"
                >
                  {editingMethodId ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Guardar
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" /> Agregar
                    </>
                  )}
                </button>
              </form>

              {metodosPagoMembresia.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {metodosPagoMembresia.map((m) => (
                    <div
                      key={m.id}
                      className={`p-3 rounded-xl border text-xs space-y-2 ${
                        m.activo !== false
                          ? 'bg-slate-50 border-slate-200'
                          : 'bg-slate-50/50 border-slate-200 opacity-65'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="px-2 py-0.5 rounded bg-slate-900 text-white text-[10px] font-bold uppercase shrink-0">
                            {m.tipo.replace('_', ' ')}
                          </span>
                          <span className="font-bold text-slate-900 truncate">{m.titulo}</span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => void handleToggleMethodActive(m)}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 whitespace-nowrap cursor-pointer transition ${
                              m.activo !== false
                                ? 'bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700'
                                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            }`}
                            title={m.activo !== false ? 'Desactivar método de pago' : 'Activar método de pago'}
                          >
                            {m.activo !== false ? (
                              <>
                                <Pause className="w-3 h-3" /> Desactivar
                              </>
                            ) : (
                              <>
                                <Play className="w-3 h-3" /> Activar
                              </>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStartEditMethod(m)}
                            className="p-1.5 rounded-lg bg-white border border-slate-200 text-sky-700 hover:bg-sky-50 cursor-pointer"
                            title="Editar método"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteMethod(m.id)}
                            className="p-1.5 rounded-lg bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 cursor-pointer"
                            title="Eliminar método"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5">
                        <span className="font-mono font-bold text-slate-900 break-all">
                          {m.detalle}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(m.detalle);
                            notifyToast(`Copiado: ${m.detalle}`, 'info');
                          }}
                          className="px-2 py-0.5 rounded bg-sky-50 hover:bg-sky-100 text-sky-700 font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Copy className="w-3 h-3" /> Copiar
                        </button>
                      </div>

                      {(m.titular || m.documento) && (
                        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600">
                          <span>
                            {m.titular ? `Titular: ${m.titular}` : ''}{' '}
                            {m.documento ? `· ${m.documento}` : ''}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              const full = [m.titulo, m.detalle, m.titular, m.documento]
                                .filter(Boolean)
                                .join(' | ');
                              navigator.clipboard?.writeText(full);
                              notifyToast('Datos completos copiados.', 'info');
                            }}
                            className="text-sky-700 font-semibold inline-flex items-center gap-1 hover:underline cursor-pointer"
                          >
                            <Copy className="w-3 h-3" /> Copiar todo
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Dedicated Membership Receipt Contact Number Card */}
            <form
              onSubmit={handleSaveReceiptContact}
              className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-wrap items-end justify-between gap-4"
            >
              <div className="space-y-1 flex-1 min-w-[260px]">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-emerald-600" />
                  Número de Contacto para Envío de Comprobantes de Membresía
                </h3>
                <p className="text-[11px] text-slate-500">
                  Cuando los locales o administradores reporten el pago de su membresía, el comprobante se enviará por WhatsApp a este número. Incluye el código de país (ej.{' '}
                  <span className="font-mono font-semibold">584245655395</span>).
                </p>
                <div className="flex flex-wrap items-center gap-2 pt-1.5">
                  <div className="relative flex-1 min-w-[210px]">
                    <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={waMembresia}
                      onChange={(e) => setWaMembresia(e.target.value)}
                      placeholder="584245655395"
                      className="w-full pl-9 pr-3 py-2 text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  {waMembresia.replace(/\D/g, '').length >= 10 && (
                    <a
                      href={`https://wa.me/${waMembresia.replace(/\D/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-2 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <ExternalLink className="w-3.5 h-3.5" /> Probar WhatsApp
                    </a>
                  )}
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    Guardar Contacto
                  </button>
                </div>
              </div>
            </form>

            {/* Pending & Verified Membership Payments (Pago Móvil) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Verificador de Pagos Móvil y Comprobantes de Membresía ({membershipPayments.length})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Al aprobar un pago se activa el plan comprado y se genera automáticamente el comprobante PDF de renovación.
                  </p>
                </div>
              </div>
              {membershipPayments.length === 0 ? (
                <p className="text-xs text-slate-400">Sin comprobantes enviados.</p>
              ) : (
                <div className="space-y-2.5">
                  {membershipPayments.map((p) => (
                    <div
                      key={p.key}
                      className={`p-3.5 rounded-xl border flex flex-wrap items-center justify-between gap-3 text-xs ${
                        p.estado === 'pendiente'
                          ? 'bg-amber-50/60 border-amber-200'
                          : p.estado === 'en_revision'
                          ? 'bg-sky-50/70 border-sky-200'
                          : p.estado === 'aprobado'
                          ? 'bg-emerald-50/50 border-emerald-200'
                          : 'bg-rose-50/40 border-rose-200'
                      }`}
                    >
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        {p.captura && (
                          <button
                            type="button"
                            onClick={() => setPreviewCaptura(p.captura || null)}
                            className="w-14 h-14 rounded-xl border border-slate-200 overflow-hidden bg-white shrink-0 cursor-pointer hover:ring-2 hover:ring-sky-400"
                            title="Ampliar comprobante Pago Móvil"
                          >
                            <img
                              src={p.captura}
                              alt="Comprobante Pago Móvil"
                              className="w-full h-full object-cover"
                            />
                          </button>
                        )}
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900">
                            {p.tenantName ? `[${p.tenantName}] · ` : ''}
                            {p.nombre} · Ref: <span className="font-mono">{p.ref}</span>
                          </p>
                          <p className="text-slate-600">
                            ${Number(p.usd).toFixed(2)} ({formatMoney(p.bs)} Bs) · Usuario: {p.usuario} ·{' '}
                            {p.t ? new Date(p.t).toLocaleString('es-VE') : ''} · Estado:{' '}
                            <b
                              className={`uppercase ${
                                p.estado === 'aprobado'
                                  ? 'text-emerald-700'
                                  : p.estado === 'en_revision'
                                  ? 'text-sky-700'
                                  : p.estado === 'rechazado'
                                  ? 'text-rose-700'
                                  : 'text-amber-700'
                              }`}
                            >
                              {p.estado === 'en_revision' ? 'En Revisión' : p.estado}
                            </b>
                          </p>
                          {p.verificacion_ia && (
                            <div
                              className={`mt-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] ${
                                p.verificacion_ia.es_comprobante_valido
                                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                                  : 'bg-amber-50 border-amber-200 text-amber-900'
                              }`}
                            >
                              <b>Verificador IA ({p.verificacion_ia.es_comprobante_valido ? 'Coincide' : 'Revisar'}):</b>{' '}
                              {p.verificacion_ia.resumen}
                              {p.verificacion_ia.referencia_detectada && (
                                <span className="font-mono ml-1.5">
                                  · Ref: {p.verificacion_ia.referencia_detectada}
                                </span>
                              )}
                              {p.verificacion_ia.banco_detectado && (
                                <span className="ml-1.5">· Banco: {p.verificacion_ia.banco_detectado}</span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                        {p.captura && (
                          <button
                            type="button"
                            onClick={() => setPreviewCaptura(p.captura || null)}
                            className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" /> Captura
                          </button>
                        )}
                        {p.estado !== 'aprobado' && (
                          <button
                            type="button"
                            onClick={() => void handleUpdatePaymentStatus(p, 'aprobado')}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> Aprobar + PDF
                          </button>
                        )}
                        {p.estado !== 'en_revision' && p.estado !== 'aprobado' && (
                          <button
                            type="button"
                            onClick={() => void handleUpdatePaymentStatus(p, 'en_revision')}
                            className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Clock className="w-3.5 h-3.5" /> En Revisión
                          </button>
                        )}
                        {p.estado !== 'rechazado' && p.estado !== 'aprobado' && (
                          <button
                            type="button"
                            onClick={() => void handleUpdatePaymentStatus(p, 'rechazado')}
                            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" /> Rechazar
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDeleteMembershipPayment(p)}
                          className="px-2.5 py-1.5 rounded-lg bg-white border border-rose-200 hover:bg-rose-50 text-rose-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                          title="Eliminar pago"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Eliminar
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Promotions Builder (Add + Edit + Toggle + Delete) + Plan Preview */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Gift className="w-4 h-4 text-rose-600" />
                  {editingPromoId ? 'Editar Promoción de Membresía' : 'Promociones y Planes de Membresía'}
                </h3>
                {editingPromoId && (
                  <button
                    type="button"
                    onClick={resetPromoForm}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" /> Cancelar edición
                  </button>
                )}
              </div>

              <form
                onSubmit={handleSavePromo}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-xs"
              >
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                  <input
                    type="text"
                    value={promoName}
                    onChange={(e) => setPromoName(e.target.value)}
                    placeholder="Nombre promo (ej. Black Friday 20%)"
                    className="sm:col-span-2 px-3 py-2 bg-white border border-slate-200 rounded-xl font-semibold"
                  />
                  <select
                    value={promoType}
                    onChange={(e) => setPromoType(e.target.value as PromoRecord['tipo'])}
                    className="px-3 py-2 bg-white border border-slate-200 rounded-xl"
                  >
                    <option value="pct">% Descuento</option>
                    <option value="menos">Meses gratis menos</option>
                    <option value="regalo">+ Meses de regalo</option>
                    <option value="xy">Paga X lleva Y</option>
                  </select>
                  {promoType === 'xy' ? (
                    <div className="flex gap-1.5">
                      <input
                        type="number"
                        value={promoX}
                        onChange={(e) => setPromoX(e.target.value)}
                        placeholder="Paga"
                        className="w-1/2 px-2 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                      />
                      <input
                        type="number"
                        value={promoY}
                        onChange={(e) => setPromoY(e.target.value)}
                        placeholder="Lleva"
                        className="w-1/2 px-2 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                      />
                    </div>
                  ) : (
                    <input
                      type="number"
                      value={promoVal}
                      onChange={(e) => setPromoVal(e.target.value)}
                      placeholder="Valor"
                      className="px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                    />
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-center">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Vigente desde (opcional)
                    </label>
                    <input
                      type="date"
                      value={promoDesde}
                      onChange={(e) => setPromoDesde(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Vigente hasta (opcional)
                    </label>
                    <input
                      type="date"
                      value={promoHasta}
                      onChange={(e) => setPromoHasta(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl font-mono"
                    />
                  </div>
                  <div className="sm:col-span-2 flex flex-wrap items-center gap-3 pt-4 sm:pt-0">
                    <label className="inline-flex items-center gap-1.5 font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={promoRepeat}
                        onChange={(e) => setPromoRepeat(e.target.checked)}
                      />
                      Repetible
                    </label>
                    <label className="inline-flex items-center gap-1.5 font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={promoActive}
                        onChange={(e) => setPromoActive(e.target.checked)}
                      />
                      Activa al guardar
                    </label>
                    <label className="inline-flex items-center gap-1.5 font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={promoAplicaAll}
                        onChange={(e) => setPromoAplicaAll(e.target.checked)}
                      />
                      Todos los planes
                    </label>
                  </div>
                </div>

                {!promoAplicaAll && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[11px] font-semibold text-slate-600">Planes incluidos:</span>
                    {Array.from(
                      new Set([
                        1,
                        2,
                        3,
                        6,
                        12,
                        ...Object.values(plans).map((pl) => Number(pl.meses) || 1),
                      ])
                    )
                      .sort((a, b) => a - b)
                      .map((m) => {
                        const selected = promoAplicaMeses.includes(m);
                        return (
                          <button
                            key={m}
                            type="button"
                            onClick={() =>
                              setPromoAplicaMeses((prev) =>
                                selected ? prev.filter((x) => x !== m) : [...prev, m]
                              )
                            }
                            className={`px-2.5 py-1 rounded-lg border font-semibold cursor-pointer ${
                              selected
                                ? 'bg-slate-900 text-white border-slate-900'
                                : 'bg-white text-slate-700 border-slate-200'
                            }`}
                          >
                            {m} {m === 1 ? 'mes' : 'meses'}
                          </button>
                        );
                      })}
                  </div>
                )}

                <div className="flex justify-end gap-2">
                  {editingPromoId && (
                    <button
                      type="button"
                      onClick={resetPromoForm}
                      className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold cursor-pointer"
                    >
                      Cancelar
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold cursor-pointer inline-flex items-center gap-1.5"
                  >
                    {editingPromoId ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" /> Guardar Cambios
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" /> Añadir Promoción
                      </>
                    )}
                  </button>
                </div>
              </form>

              {promos.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {promos.map((pr) => (
                    <div
                      key={pr.id}
                      className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-2 ${
                        pr.activo
                          ? 'bg-rose-50/70 border-rose-200'
                          : 'bg-slate-50 border-slate-200 opacity-75'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 truncate">{pr.nombre}</span>
                          <span
                            className={`text-[10px] font-bold uppercase ${
                              pr.activo ? 'text-emerald-700' : 'text-slate-500'
                            }`}
                          >
                            {pr.activo ? 'Activa' : 'Pausada'}
                          </span>
                        </div>
                        <p className="text-rose-700 font-semibold">{describePromo(pr)}</p>
                        {(pr.desde || pr.hasta || Array.isArray(pr.aplica)) && (
                          <p className="text-[11px] text-slate-500 font-mono">
                            {pr.desde ? `Desde ${pr.desde}` : ''} {pr.hasta ? `Hasta ${pr.hasta}` : ''}{' '}
                            {Array.isArray(pr.aplica)
                              ? `· Planes: ${pr.aplica.join(', ')}m`
                              : '· Todos'}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleTogglePromoActive(pr)}
                          title={pr.activo ? 'Pausar promoción' : 'Activar promoción'}
                          className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
                        >
                          {pr.activo ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleStartEditPromo(pr)}
                          title="Editar promoción"
                          className="p-1.5 rounded-lg bg-white border border-slate-200 text-sky-700 hover:bg-sky-50 cursor-pointer"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeletePromo(pr)}
                          title="Eliminar promoción"
                          className="p-1.5 rounded-lg bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-2">
                {Object.entries(plans).map(([k, pl]) => {
                  const effPct = effectiveDiscountWithPromos(pl, promos);
                  const bonus = bonusMonthsWithPromos(pl, promos);
                  const finalUsd = round2(pl.precio * (1 - effPct / 100));
                  return (
                    <div key={k} className="p-3 rounded-xl border border-slate-200 bg-slate-50 text-xs">
                      <p className="font-bold text-slate-900">{pl.nombre}</p>
                      <p className="font-mono tabular-nums font-extrabold text-sky-700 text-sm">
                        ${finalUsd.toFixed(2)}
                      </p>
                      {effPct > 0 && (
                        <p className="text-[11px] font-semibold text-rose-600">-{effPct}% aplicado</p>
                      )}
                      {bonus > 0 && <p className="text-[11px] text-emerald-700">+{bonus} mes(es) regalo</p>}
                      {planLinks[k] && <p className="text-[10px] text-slate-400 truncate">Link pago activo</p>}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {tab === 'support' && (
          <div className="space-y-4">
            {/* Owner Support WhatsApp Numbers & Schedule Config */}
            <form
              onSubmit={handleSaveSupportNumbers}
              className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-emerald-600" />
                    Números de Soporte WhatsApp y Escalamiento del Asistente IA
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Cuando el Asistente IA de soporte no pueda resolver una incidencia, indicará al cliente que un agente lo contactará a estos números de WhatsApp o mediante el chat de soporte.
                  </p>
                </div>
                {pushSupported && (
                  <button
                    type="button"
                    onClick={() => void sendTestPushNotification()}
                    className="px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <BellRing className="w-3.5 h-3.5" /> Probar Alerta Push
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    WhatsApp Soporte Principal (con código de país)
                  </label>
                  <input
                    type="text"
                    value={waSoporteDraft}
                    onChange={(e) => setWaSoporteDraft(e.target.value)}
                    placeholder="Ej: 584121234567"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-semibold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    WhatsApp Soporte Secundario (Opcional)
                  </label>
                  <input
                    type="text"
                    value={waSoporteSecDraft}
                    onChange={(e) => setWaSoporteSecDraft(e.target.value)}
                    placeholder="Ej: 584241234567"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-semibold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Horario de Atención
                  </label>
                  <input
                    type="text"
                    value={soporteHorarioDraft}
                    onChange={(e) => setSoporteHorarioDraft(e.target.value)}
                    placeholder="Lunes a Sábado · 8:00 AM - 7:00 PM"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={savingSupportNums}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  {savingSupportNums ? 'Guardando...' : 'Guardar Números de Soporte'}
                </button>
              </div>
            </form>

            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-sky-600" /> Bandeja de Tickets de Soporte ({tickets.length})
            </h3>
            {tickets.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center text-xs text-slate-400">
                No hay tickets de soporte registrados.
              </div>
            ) : (
              tickets.map((t) => (
                <div key={t.key} className="bg-white rounded-2xl border border-slate-200 p-4 space-y-2.5 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-900">
                        {t.tenantName ? `[${t.tenantName}] · ` : ''}
                        {t.tipo}
                      </span>{' '}
                      · <span className="text-slate-600">{t.usuario} ({t.rol})</span> ·{' '}
                      <span className="font-mono text-slate-400">
                        {new Date(t.t).toLocaleString('es-VE')}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold uppercase text-sky-700">{t.estado}</span>
                      {t.estado !== 'resuelto' && (
                        <button
                          type="button"
                          onClick={() => handleResolveTicket(t)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-semibold cursor-pointer"
                        >
                          Marcar resuelto
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200">{t.msg}</p>

                  {t.resp && (
                    <div className="space-y-1 pl-3 border-l-2 border-sky-300">
                      {Object.values(t.resp).map((r, i) => (
                        <p key={i} className="text-slate-600">
                          <b>{r.de}:</b> {r.msg}
                        </p>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={replyDrafts[t.key] || ''}
                      onChange={(e) => setReplyDrafts((prev) => ({ ...prev, [t.key]: e.target.value }))}
                      placeholder="Responder al ticket..."
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => handleSendTicketReply(t)}
                      className="px-4 py-2 rounded-xl bg-sky-600 text-white font-semibold cursor-pointer"
                    >
                      Enviar
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
        {tab === 'preregistrations' && (
          <OwnerPreRegistrationsTab
            onOpenClient={(tid) => {
              setActiveTenantId(tid);
              setTab('clients');
            }}
          />
        )}

        {tab === 'seniat' && <OwnerSeniatTab />}

        {tab === 'aichat' && <OwnerAiChatTab />}
      </main>

      {/* Register New Client Modal */}
      {showNewClientModal && (
        <div className="fixed inset-0 z-[170] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <form
            onSubmit={handleRegisterNewClient}
            className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full max-h-[92vh] overflow-y-auto p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center">
                  <UserPlus className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Registrar Nuevo Cliente y Nodo Aislado
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Cada cliente obtiene su nodo independiente en Firestore con credenciales, inventario y ventas propias.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowNewClientModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Correo Electrónico de Acceso *
                </label>
                <input
                  type="email"
                  required
                  value={newCliEmail}
                  onChange={(e) => setNewCliEmail(e.target.value)}
                  placeholder="cliente@empresa.com"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700">Contraseña *</label>
                  <button
                    type="button"
                    onClick={generateRandomPassword}
                    className="text-[11px] font-semibold text-sky-700 hover:underline inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" /> Generar clave
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showNewCliPass ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={newCliPass}
                    onChange={(e) => setNewCliPass(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="w-full px-3 py-2 pr-9 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewCliPass((v) => !v)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showNewCliPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Nombre Comercial / Local *</label>
                <input
                  type="text"
                  required
                  value={newCliLocal}
                  onChange={(e) => setNewCliLocal(e.target.value)}
                  placeholder="Ej. Repuestos El Rayo"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Razón Social</label>
                <input
                  type="text"
                  value={newCliRazon}
                  onChange={(e) => setNewCliRazon(e.target.value)}
                  placeholder="Ej. Inversiones El Rayo C.A."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">RIF / Cédula Fiscal</label>
                <input
                  type="text"
                  value={newCliRif}
                  onChange={(e) => setNewCliRif(e.target.value)}
                  placeholder="J-12345678-9"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Teléfono / WhatsApp</label>
                <input
                  type="tel"
                  value={newCliTel}
                  onChange={(e) => setNewCliTel(e.target.value)}
                  placeholder="04121234567"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Nombre de Contacto / Titular</label>
                <input
                  type="text"
                  value={newCliContacto}
                  onChange={(e) => setNewCliContacto(e.target.value)}
                  placeholder="Nombre del encargado"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Dirección Fiscal</label>
                <input
                  type="text"
                  value={newCliDir}
                  onChange={(e) => setNewCliDir(e.target.value)}
                  placeholder="Av. Principal, Local 4..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">PIN Administrativo (4-8 díg.)</label>
                <input
                  type="text"
                  value={newCliAdminPin}
                  onChange={(e) => setNewCliAdminPin(e.target.value)}
                  placeholder="1234"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">PIN Cajero Inicial (4-8 díg.)</label>
                <input
                  type="text"
                  value={newCliCajaPin}
                  onChange={(e) => setNewCliCajaPin(e.target.value)}
                  placeholder="0000"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Nombre Cajero Inicial</label>
                <input
                  type="text"
                  value={newCliCajeroName}
                  onChange={(e) => setNewCliCajeroName(e.target.value)}
                  placeholder="Cajero Principal"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Plan de Membresía Inicial</label>
                <select
                  value={newCliPlan}
                  onChange={(e) => setNewCliPlan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  {Object.entries(plans).map(([k, pl]) => (
                    <option key={k} value={k}>
                      {pl.nombre} (${pl.precio.toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Meta de Ventas Diaria (USD)</label>
                <input
                  type="number"
                  value={newCliMetaUsd}
                  onChange={(e) => setNewCliMetaUsd(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
            </div>

            {/* New Client Store Logo & Initial Invoice Format */}
            <div
              onPaste={async (e) => {
                const items = e.clipboardData?.items;
                if (!items) return;
                for (let i = 0; i < items.length; i++) {
                  if (items[i].type.startsWith('image/')) {
                    const f = items[i].getAsFile();
                    if (f) {
                      e.preventDefault();
                      setUploadingNewCliLogo(true);
                      try {
                        const url = await compressImageFile(f, 360, 0.85);
                        setNewCliLogoUrl(url);
                        notifyToast('Logotipo pegado para el nuevo cliente.', 'success');
                      } catch {
                        notifyToast('No se pudo procesar el logo pegado.', 'error');
                      } finally {
                        setUploadingNewCliLogo(false);
                      }
                      return;
                    }
                  }
                }
              }}
              tabIndex={0}
              className="p-3.5 rounded-2xl bg-sky-50/50 border border-sky-200 space-y-3 text-xs focus:outline-none focus:border-sky-500"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Printer className="w-3.5 h-3.5 text-sky-600" />
                  Logotipo del Local y Formato de Factura (Opcional)
                </span>
                <span className="text-[10px] text-slate-500">Pega con Ctrl+V o sube archivo</span>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="w-20 h-16 rounded-xl bg-white border-2 border-dashed border-sky-200 flex items-center justify-center overflow-hidden p-1 shrink-0">
                  {newCliLogoUrl ? (
                    <img
                      src={newCliLogoUrl}
                      alt="Logo cliente"
                      className="max-w-full max-h-full object-contain"
                    />
                  ) : (
                    <div className="flex flex-col items-center text-slate-400 text-center">
                      <ClipboardPaste className="w-3.5 h-3.5 text-sky-500" />
                      <span className="text-[9px] font-semibold">Logo</span>
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-[200px] space-y-2">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <label className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold inline-flex items-center gap-1 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      {uploadingNewCliLogo ? 'Procesando...' : newCliLogoUrl ? 'Cambiar Logo' : 'Subir Logo'}
                      <input
                        type="file"
                        accept="image/*"
                        disabled={uploadingNewCliLogo}
                        onChange={async (e) => {
                          const f = e.target.files?.[0];
                          if (!f) return;
                          setUploadingNewCliLogo(true);
                          try {
                            const url = await compressImageFile(f, 360, 0.85);
                            setNewCliLogoUrl(url);
                            notifyToast('Logotipo listo para el nuevo local.', 'success');
                          } catch {
                            notifyToast('No se pudo cargar la imagen del logotipo.', 'error');
                          } finally {
                            setUploadingNewCliLogo(false);
                            e.target.value = '';
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                    {newCliLogoUrl && (
                      <button
                        type="button"
                        onClick={() => setNewCliLogoUrl('')}
                        className="px-2.5 py-1.5 rounded-xl bg-rose-50 text-rose-700 font-semibold cursor-pointer"
                      >
                        Quitar
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    <select
                      value={newCliPaperWidth}
                      onChange={(e) => setNewCliPaperWidth(e.target.value as '58mm' | '80mm')}
                      className="px-2 py-1.5 bg-white border border-slate-200 rounded-lg font-semibold text-[11px]"
                    >
                      <option value="80mm">Papel 80mm</option>
                      <option value="58mm">Papel 58mm</option>
                    </select>
                    <select
                      value={newCliInvoiceFont}
                      onChange={(e) =>
                        setNewCliInvoiceFont(e.target.value as TenantInvoiceConfig['fuente'])
                      }
                      className="px-2 py-1.5 bg-white border border-slate-200 rounded-lg font-semibold text-[11px]"
                    >
                      <option value="mono">Letra Térmica</option>
                      <option value="sans">Sans Moderna</option>
                      <option value="serif">Serif Clásica</option>
                      <option value="condensada">Condensada</option>
                    </select>
                    <select
                      value={newCliIntensity}
                      onChange={(e) =>
                        setNewCliIntensity(
                          e.target.value as NonNullable<TenantInvoiceConfig['intensidad_impresion']>
                        )
                      }
                      className="px-2 py-1.5 bg-white border border-slate-200 rounded-lg font-semibold text-[11px]"
                    >
                      <option value="suave">Tinta Suave</option>
                      <option value="normal">Tinta Normal</option>
                      <option value="oscura">Tinta Oscura</option>
                      <option value="extra_oscura">Extra Oscura</option>
                    </select>
                    <label className="inline-flex items-center justify-center gap-1 px-2 py-1 bg-white border border-slate-200 rounded-lg cursor-pointer text-[11px] font-mono">
                      <input
                        type="color"
                        value={newCliInvoiceColor}
                        onChange={(e) => setNewCliInvoiceColor(e.target.value)}
                        className="w-4 h-4 border-0 p-0 bg-transparent cursor-pointer"
                      />
                      <span>Color</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowNewClientModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={creatingClient}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer"
              >
                {creatingClient ? 'Creando nodo aislado...' : 'Registrar Cliente y Crear Nodo'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Edit Client Fiscal & Access Credentials Modal */}
      {editingClient && (
        <div className="fixed inset-0 z-[175] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <form
            onSubmit={handleSaveEditClient}
            className="bg-white rounded-2xl border border-slate-200 max-w-xl w-full max-h-[90vh] overflow-y-auto p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  Editar Cliente, Datos Fiscales y Credenciales
                </h4>
                <p className="text-[11px] font-mono text-slate-500">
                  Nodo: {editingClient.id}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingClient(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Nombre Comercial *</label>
                <input
                  type="text"
                  required
                  value={editCliLocal}
                  onChange={(e) => setEditCliLocal(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Razón Social</label>
                <input
                  type="text"
                  value={editCliRazon}
                  onChange={(e) => setEditCliRazon(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">RIF</label>
                <input
                  type="text"
                  value={editCliRif}
                  onChange={(e) => setEditCliRif(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Teléfono</label>
                <input
                  type="tel"
                  value={editCliTel}
                  onChange={(e) => setEditCliTel(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Contacto</label>
                <input
                  type="text"
                  value={editCliContacto}
                  onChange={(e) => setEditCliContacto(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Dirección Fiscal</label>
                <input
                  type="text"
                  value={editCliDir}
                  onChange={(e) => setEditCliDir(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
            </div>

            {/* Credentials Section */}
            <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-3 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-amber-950 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                  Credenciales de Acceso del Cliente
                </span>
                <button
                  type="button"
                  onClick={() => void handleSendClientReset(editCliEmail || editingClient.email)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 hover:bg-amber-100 text-amber-900 font-semibold cursor-pointer whitespace-nowrap"
                >
                  Enviar Reset de Contraseña
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div className="sm:col-span-3">
                  <label className="font-semibold text-slate-700 block mb-1">
                    Correo de Acceso (Firebase) *
                  </label>
                  <input
                    type="email"
                    required
                    value={editCliEmail}
                    onChange={(e) => setEditCliEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl font-mono"
                  />
                </div>
                <div className="sm:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Nuevo PIN Admin ({editingClient.admin_pin_hash ? 'Configurado' : 'Sin PIN'})
                    </label>
                    <input
                      type="password"
                      inputMode="numeric"
                      maxLength={12}
                      value={editCliAdminPin}
                      onChange={(e) => setEditCliAdminPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="Opcional (4-12 dígitos)"
                      className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl font-mono"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Nuevo PIN de Caja ({editingClient.caja_pin_hash ? 'Configurado' : 'Sin PIN'})
                    </label>
                    <input
                      type="password"
                      inputMode="numeric"
                      maxLength={12}
                      value={editCliCajaPin}
                      onChange={(e) => setEditCliCajaPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="Opcional (4-12 dígitos)"
                      className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={editCliActivo}
                onChange={(e) => setEditCliActivo(e.target.checked)}
              />
              Nodo de cliente activo
            </label>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingClient(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={savingEditClient}
                className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
              >
                {savingEditClient ? 'Guardando...' : 'Guardar Cambios'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Capture Image Preview Modal */}
      {previewCaptura && (
        <div
          className="fixed inset-0 z-[180] bg-slate-950/75 flex items-center justify-center p-4"
          onClick={() => setPreviewCaptura(null)}
        >
          <div className="relative max-w-2xl max-h-[88vh]" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              onClick={() => setPreviewCaptura(null)}
              className="absolute -top-3 -right-3 w-9 h-9 rounded-full bg-white text-slate-900 shadow-lg flex items-center justify-center hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar captura"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewCaptura}
              alt="Comprobante de pago"
              className="max-w-full max-h-[85vh] rounded-2xl shadow-2xl bg-white"
            />
          </div>
        </div>
      )}

      {/* Select Plan Modal Before Generating Membership Renewal Contract PDF */}
      {renewalContractClient && (
        <div className="fixed inset-0 z-[180] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <form
            onSubmit={handleConfirmGenerateRenewalContractPdf}
            className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-start justify-between gap-2 border-b border-slate-200 pb-3">
              <div className="min-w-0">
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <FileCheck2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  Contrato de Renovación de Membresía
                </h4>
                <p className="text-[11px] text-slate-500 truncate mt-0.5">
                  Cliente: <b>{renewalContractClient.nombre_local}</b> ({renewalContractClient.email})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setRenewalContractClient(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer shrink-0"
                aria-label="Cerrar"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600">
                Selecciona primero el <b>plan que contrató el cliente</b> para regenerar su contrato de renovación de membresía en PDF automáticamente.
              </p>

              <div>
                <label className="font-semibold text-slate-700 block mb-1.5">
                  Plan Contratado *
                </label>
                <select
                  required
                  value={renewalContractPlanKey}
                  onChange={(e) => setRenewalContractPlanKey(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900"
                >
                  <option value="">— Selecciona el plan contratado —</option>
                  {Object.entries(plans)
                    .sort(([, a], [, b]) => (Number(a.meses) || 0) - (Number(b.meses) || 0))
                    .map(([k, pl]) => {
                      const effPct = effectiveDiscountWithPromos(pl, promos);
                      const finalUsd = round2(pl.precio * (1 - effPct / 100));
                      const bonus = bonusMonthsWithPromos(pl, promos);
                      return (
                        <option key={k} value={k}>
                          {pl.nombre} ({pl.meses}m{bonus > 0 ? ` +${bonus}m regalo` : ''}) · $
                          {finalUsd.toFixed(2)} USD
                          {effPct > 0 ? ` (-${round2(effPct)}%)` : ''}
                        </option>
                      );
                    })}
                </select>
              </div>

              {renewalContractPlanKey && plans[renewalContractPlanKey] && (() => {
                const pl = plans[renewalContractPlanKey];
                const effPct = effectiveDiscountWithPromos(pl, promos);
                const finalUsd = round2(pl.precio * (1 - effPct / 100));
                const bonus = bonusMonthsWithPromos(pl, promos);
                return (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1 text-emerald-950">
                    <div className="flex items-center justify-between font-bold">
                      <span>Plan: {pl.nombre}</span>
                      <span className="font-mono tabular-nums text-emerald-700">
                        ${finalUsd.toFixed(2)} USD
                      </span>
                    </div>
                    <p className="text-[11px] text-emerald-800">
                      Duración: {pl.meses} mes(es){bonus > 0 ? ` + ${bonus} mes(es) bono` : ''} ·{' '}
                      {effPct > 0 ? `Descuento aplicado: ${round2(effPct)}%` : 'Tarifa estándar'}
                    </p>
                  </div>
                );
              })()}

              <label className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={renewalContractApplyPlan}
                  onChange={(e) => setRenewalContractApplyPlan(e.target.checked)}
                  className="mt-0.5"
                />
                <span>
                  <b className="text-slate-900 block">
                    Aplicar y extender también los días del cliente con este plan
                  </b>
                  <span className="text-[11px] text-slate-500">
                    Si lo desmarcas, solo se regenerará el contrato PDF sin alterar los días actuales del cliente.
                  </span>
                </span>
              </label>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setRenewalContractClient(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!renewalContractPlanKey || generatingContractPdf}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                {generatingContractPdf ? 'Generando PDF...' : 'Generar Contrato PDF'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Per-Client Thermal Invoice, Store Logo & Default Printer Configurator */}
      {invoiceConfigClient && (
        <OwnerClientInvoiceModal
          client={invoiceConfigClient}
          bcvRate={bcvRate}
          onClose={() => setInvoiceConfigClient(null)}
          onSave={handleSaveClientInvoiceConfig}
          onNotify={notifyToast}
        />
      )}

      {/* Per-Client Data Update & Verification Request Manager */}
      {verificationClient && (
        <OwnerVerificationModal
          client={tenants.find((x) => x.id === verificationClient.id) || verificationClient}
          onClose={() => setVerificationClient(null)}
          onSaveConfig={saveTenantVerificationConfig}
          onReviewDoc={reviewTenantVerificationDoc}
          onNotify={notifyToast}
        />
      )}

      {/* In-App Confirmation Modal for Owner Panel */}
      {ownerConfirm && (
        <div className="fixed inset-0 z-[195] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-5 space-y-4 shadow-2xl">
            <h4 className="font-bold text-sm text-slate-900">{ownerConfirm.title}</h4>
            <p className="text-xs text-slate-600 leading-relaxed">{ownerConfirm.message}</p>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                disabled={runningOwnerConfirm}
                onClick={() => setOwnerConfirm(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={runningOwnerConfirm}
                onClick={async () => {
                  const fn = ownerConfirm.onConfirm;
                  setRunningOwnerConfirm(true);
                  try {
                    await fn();
                    setOwnerConfirm(null);
                  } finally {
                    setRunningOwnerConfirm(false);
                  }
                }}
                className={`px-4 py-2 rounded-xl text-white text-xs font-semibold disabled:opacity-60 cursor-pointer ${
                  ownerConfirm.danger !== false
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-sky-600 hover:bg-sky-700'
                }`}
              >
                {runningOwnerConfirm ? 'Procesando...' : ownerConfirm.confirmLabel || 'Confirmar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
