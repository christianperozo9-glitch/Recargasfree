import type { MembershipPlan, PromoRecord } from '../types/pos';

export function promoAppliesToPlan(promo: PromoRecord, plan: MembershipPlan): boolean {
  if (!promo || promo.activo === false) return false;
  const now = Date.now();
  const months = Number(plan.meses) || 1;

  if (promo.hasta && now > new Date(`${promo.hasta}T23:59:59`).getTime()) return false;
  if (promo.desde && now < new Date(`${promo.desde}T00:00:00`).getTime()) return false;

  if (promo.aplica && promo.aplica !== 'all') {
    const allowed = Array.isArray(promo.aplica)
      ? promo.aplica.map(Number)
      : Object.values(promo.aplica as Record<string, number>).map(Number);
    if (!allowed.includes(months)) return false;
  }

  if (promo.tipo === 'pct') return Number(promo.valor) > 0;
  if (promo.tipo === 'menos') return Number(promo.valor) > 0 && Number(promo.valor) < months;
  if (promo.tipo === 'regalo') return Number(promo.valor) > 0;
  if (promo.tipo === 'xy') return Number(promo.x) > 0 && Number(promo.y) > Number(promo.x) && months >= Number(promo.x);
  return false;
}

export function effectiveDiscountWithPromos(plan: MembershipPlan, promos: PromoRecord[]): number {
  let mult = 1 - (Number(plan.oferta) || 0) / 100;
  const months = Number(plan.meses) || 1;
  promos.forEach((promo) => {
    if (!promoAppliesToPlan(promo, plan)) return;
    if (promo.tipo === 'pct') {
      mult *= 1 - Math.min(100, Number(promo.valor) || 0) / 100;
    } else if (promo.tipo === 'menos') {
      mult *= (months - (Number(promo.valor) || 0)) / months;
    }
  });
  return Number(((1 - mult) * 100).toFixed(4));
}

export function bonusMonthsWithPromos(plan: MembershipPlan, promos: PromoRecord[]): number {
  let bonus = 0;
  const months = Number(plan.meses) || 1;
  promos.forEach((promo) => {
    if (!promoAppliesToPlan(promo, plan)) return;
    if (promo.tipo === 'regalo') {
      bonus += Number(promo.valor) || 0;
    } else if (promo.tipo === 'xy') {
      const x = Number(promo.x) || 1;
      const y = Number(promo.y) || x;
      bonus += (y - x) * (promo.repetir ? Math.floor(months / x) : 1);
    }
  });
  return bonus;
}

export function describePromo(promo: PromoRecord): string {
  const val = Number(promo.valor) || 0;
  if (promo.tipo === 'pct') return `-${val}% OFF`;
  if (promo.tipo === 'menos') return `Pagas ${val} ${val > 1 ? 'meses' : 'mes'} menos`;
  if (promo.tipo === 'regalo') return `+${val} ${val > 1 ? 'meses' : 'mes'} gratis`;
  if (promo.tipo === 'xy') return `Paga ${promo.x} lleva ${promo.y}${promo.repetir ? ' (se repite)' : ''}`;
  return '';
}

export function defaultPlans(): Record<string, MembershipPlan> {
  const plans: Record<string, MembershipPlan> = {};
  const specs: Array<[number, string]> = [
    [1, '1 mes'],
    [2, '2 meses'],
    [3, '3 meses'],
    [4, '4 meses'],
    [5, '5 meses'],
    [6, '6 meses'],
    [12, '1 año'],
    [24, '2 años'],
    [36, '3 años'],
    [48, '4 años'],
  ];
  specs.forEach(([m, name]) => {
    plans[`p${m}`] = { nombre: name, meses: m, precio: m * 10, oferta: 0 };
  });
  return plans;
}
