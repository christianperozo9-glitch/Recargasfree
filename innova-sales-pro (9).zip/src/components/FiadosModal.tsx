import React, { useMemo, useState } from 'react';
import { doc, updateDoc, writeBatch } from 'firebase/firestore';
import {
  AlertTriangle,
  BookOpen,
  CalendarClock,
  CheckCircle2,
  FileDown,
  Lock,
  MessageCircle,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType, sanitizeFirestoreId } from '../lib/firebase';
import { usePos } from '../context/PosContext';
import type { FiadoAbono, FiadoItem, FiadoRecord } from '../types/pos';
import { round2 } from '../utils/format';
import { generateFiadoStatementPDF } from '../utils/pdfGenerator';

interface FiadosModalProps {
  open: boolean;
  onClose: () => void;
  embedded?: boolean;
}

type FiadoFilter = 'todos' | 'pendientes' | 'credito' | 'contado_pendiente' | 'vencidos' | 'pagados';

export const FiadosModal: React.FC<FiadosModalProps> = ({ open, onClose, embedded = false }) => {
  const {
    activeTenantId,
    fiados,
    products,
    bcvRate,
    localName,
    operatorName,
    authUser,
    notifyToast,
    playBeep,
    deleteFiadoInvoice,
    verifyAdminAuthorization,
  } = usePos();

  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FiadoFilter>('pendientes');
  const [addProdMap, setAddProdMap] = useState<Record<string, { prodName: string; qty: string }>>({});
  const [abonoModal, setAbonoModal] = useState<{
    fiado: FiadoRecord;
    remainingUsd: number;
    cuotaUsd: number;
  } | null>(null);
  const [abonoAmount, setAbonoAmount] = useState('');
  const [abonoMethod, setAbonoMethod] = useState('Pago Móvil');
  const [abonoRef, setAbonoRef] = useState('');
  const [abonoNote, setAbonoNote] = useState('');
  const [pendingRemoveItem, setPendingRemoveItem] = useState<{
    fiado: FiadoRecord;
    currentItems: FiadoItem[];
    idx: number;
    itemName: string;
  } | null>(null);

  // Admin-authorized Fiado Invoice Delete Modal state
  const [deleteTarget, setDeleteTarget] = useState<{
    fiado: FiadoRecord;
    isPaid: boolean;
  } | null>(null);
  const [deleteAuthMode, setDeleteAuthMode] = useState<'pin' | 'password'>('pin');
  const [deleteAuthSecret, setDeleteAuthSecret] = useState('');
  const [deleteRestoreStock, setDeleteRestoreStock] = useState(true);
  const [deleteAuthError, setDeleteAuthError] = useState('');
  const [deletingFiado, setDeletingFiado] = useState(false);

  const todayISO = new Date().toISOString().slice(0, 10);

  const enrichedList = useMemo(() => {
    const list: Array<{
      fiado: FiadoRecord;
      items: FiadoItem[];
      abonos: FiadoAbono[];
      totalUsd: number;
      paidUsd: number;
      remainingUsd: number;
      isOverdue: boolean;
      isPaid: boolean;
    }> = [];

    Object.entries(fiados || {}).forEach(([cedula, byTs]) => {
      if (!byTs || typeof byTs !== 'object') return;
      Object.entries(byTs).forEach(([ts, f]) => {
        if (!f || typeof f !== 'object') return;
        const items: FiadoItem[] = Array.isArray(f.items)
          ? f.items
          : f.items && typeof f.items === 'object'
          ? Object.values(f.items)
          : [];
        const totalUsd =
          items.reduce((sum, it) => {
            if (!it) return sum;
            const liveProd = products.find((p) => p.key === it.key);
            const liveUnit =
              Number(it.usd || 0) + (liveProd ? liveProd.price - Number(it.base ?? liveProd.price) : 0);
            return sum + Math.max(0, liveUnit) * Number(it.cant || 0);
          }, 0) * (Number(f.iva) || 1);

        const abonos = f.abonos && typeof f.abonos === 'object' ? Object.values(f.abonos) : [];
        const paidUsd = abonos.reduce((s, a) => s + (Number(a?.usd) || 0), 0);
        const remainingUsd = Math.max(0, round2(totalUsd - paidUsd));
        const isPaid = remainingUsd < 0.01;
        const isOverdue = !isPaid && Boolean(f.fecha_vencimiento && f.fecha_vencimiento < todayISO);

        list.push({
          fiado: { ...f, cedula, ts },
          items,
          abonos,
          totalUsd: round2(totalUsd),
          paidUsd: round2(paidUsd),
          remainingUsd,
          isOverdue,
          isPaid,
        });
      });
    });

    return list.sort((a, b) => Number(b.fiado.ts) - Number(a.fiado.ts));
  }, [fiados, products, todayISO]);

  const kpis = useMemo(() => {
    let totalPorCobrar = 0;
    let totalVencido = 0;
    let totalRecuperado = 0;
    const activeDebtors = new Set<string>();

    enrichedList.forEach((row) => {
      totalRecuperado += row.paidUsd;
      if (!row.isPaid) {
        totalPorCobrar += row.remainingUsd;
        activeDebtors.add(row.fiado.cedula);
        if (row.isOverdue) totalVencido += row.remainingUsd;
      }
    });

    return {
      totalPorCobrar: round2(totalPorCobrar),
      totalVencido: round2(totalVencido),
      totalRecuperado: round2(totalRecuperado),
      debtorsCount: activeDebtors.size,
    };
  }, [enrichedList]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return enrichedList.filter((row) => {
      const mod =
        row.fiado.modalidad || ((Number(row.fiado.cuotas) || 1) > 1 ? 'credito' : 'contado_pendiente');
      if (filter === 'pendientes' && row.isPaid) return false;
      if (filter === 'credito' && (row.isPaid || mod !== 'credito')) return false;
      if (filter === 'contado_pendiente' && (row.isPaid || mod !== 'contado_pendiente')) return false;
      if (filter === 'vencidos' && !row.isOverdue) return false;
      if (filter === 'pagados' && !row.isPaid) return false;
      if (!q) return true;
      return (
        String(row.fiado.cedula || '').toLowerCase().includes(q) ||
        String(row.fiado.cliente || '').toLowerCase().includes(q) ||
        String(row.fiado.numero_factura || '').toLowerCase().includes(q) ||
        (row.fiado.telefono ? String(row.fiado.telefono).toLowerCase().includes(q) : false)
      );
    });
  }, [enrichedList, filter, query]);

  if (!open && !embedded) return null;

  const collectorName = operatorName || authUser?.email || 'Cajero';
  const getFiadoDocId = (f: FiadoRecord) =>
    f.docKey || sanitizeFirestoreId(`${f.cedula}_${f.ts}`, 'fiado');

  const handleAddProductToFiado = async (fiado: FiadoRecord, currentItems: FiadoItem[]) => {
    if (!activeTenantId) return;
    const keyId = `${fiado.cedula}_${fiado.ts}`;
    const draft = addProdMap[keyId];
    if (!draft?.prodName) return;
    const prod = products.find(
      (p) => (p.id || '').toLowerCase() === draft.prodName.trim().toLowerCase()
    );
    if (!prod) {
      notifyToast('Selecciona un producto válido del catálogo.', 'warning');
      return;
    }
    const qty = Math.max(0.01, Number(draft.qty) || 1);
    if (qty > prod.stock) {
      notifyToast('Cantidad supera el stock disponible.', 'warning');
      return;
    }

    const updatedItems = [
      ...currentItems,
      { key: prod.key, nombre: prod.id, cant: qty, usd: prod.price, base: prod.price },
    ];
    const fiadoDocId = getFiadoDocId(fiado);
    const batch = writeBatch(db);
    batch.update(doc(db, 'tenants', activeTenantId, 'fiados', fiadoDocId), {
      items: updatedItems,
    });
    batch.update(doc(db, 'tenants', activeTenantId, 'products', prod.key), {
      stock: Math.max(0, round2(prod.stock - qty)),
      updatedAt: Date.now(),
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tenants/${activeTenantId}/fiados/${fiadoDocId}`);
    }
    setAddProdMap((prev) => ({ ...prev, [keyId]: { prodName: '', qty: '1' } }));
    playBeep('ok');
    notifyToast(`Producto agregado al fiado de ${fiado.cliente}.`, 'success');
  };

  const handleRemoveItem = (fiado: FiadoRecord, currentItems: FiadoItem[], idx: number) => {
    if (!activeTenantId) return;
    const item = currentItems[idx];
    if (!item) return;
    setPendingRemoveItem({ fiado, currentItems, idx, itemName: item.nombre });
  };

  const confirmRemoveItem = async () => {
    if (!activeTenantId || !pendingRemoveItem) return;
    const { fiado, currentItems, idx } = pendingRemoveItem;
    const item = currentItems[idx];
    setPendingRemoveItem(null);
    if (!item) return;
    const nextItems = currentItems.filter((_, i) => i !== idx);
    const prod = products.find((p) => p.key === item.key);
    const fiadoDocId = getFiadoDocId(fiado);
    const batch = writeBatch(db);
    batch.update(doc(db, 'tenants', activeTenantId, 'fiados', fiadoDocId), {
      items: nextItems,
    });
    if (prod) {
      batch.update(doc(db, 'tenants', activeTenantId, 'products', prod.key), {
        stock: round2(prod.stock + Number(item.cant || 0)),
        updatedAt: Date.now(),
      });
    }
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tenants/${activeTenantId}/fiados/${fiadoDocId}`);
    }
    notifyToast('Artículo removido y devuelto al stock.', 'info');
  };

  const handleSubmitAbono = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!abonoModal || !activeTenantId) return;
    const val = Math.min(abonoModal.remainingUsd, Number(abonoAmount) || 0);
    if (val <= 0) {
      notifyToast('Ingresa un monto de abono válido.', 'warning');
      return;
    }
    const ts = Date.now();
    const isNowPaid = abonoModal.remainingUsd - val < 0.01;
    const fiadoDocId = getFiadoDocId(abonoModal.fiado);
    const path = `tenants/${activeTenantId}/fiados/${fiadoDocId}`;
    const abonoEntry: Record<string, unknown> = {
      usd: round2(val),
      bs: round2(val * bcvRate),
      tasa: bcvRate,
      tipo: isNowPaid && abonoModal.fiado.modalidad === 'contado_pendiente' ? 'pago_unico' : 'abono',
      metodo: abonoMethod,
      fecha: new Date().toLocaleString('es-VE'),
      ts,
      cobrado_por: collectorName,
      nota: abonoNote.trim(),
    };
    if (abonoMethod === 'Pago Móvil' && abonoRef.trim()) {
      abonoEntry.referencia = abonoRef.trim().slice(0, 60);
    }
    try {
      await updateDoc(doc(db, 'tenants', activeTenantId, 'fiados', fiadoDocId), {
        [`abonos.${ts}`]: abonoEntry,
        estado: isNowPaid ? 'pagado' : 'abierto',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
    playBeep('ok');
    notifyToast(
      isNowPaid
        ? `Cuenta de ${abonoModal.fiado.cliente} saldada por completo.`
        : `Abono de $${val.toFixed(2)} registrado.`,
      'success'
    );
    setAbonoModal(null);
    setAbonoAmount('');
    setAbonoRef('');
    setAbonoNote('');
  };

  const handleConfirmDeleteFiado = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deleteTarget) return;
    setDeleteAuthError('');
    setDeletingFiado(true);
    try {
      const check = await verifyAdminAuthorization(deleteAuthSecret, deleteAuthMode);
      if (!check.ok) {
        setDeleteAuthError(check.error || 'Autorización administrativa denegada.');
        playBeep('err');
        return;
      }
      await deleteFiadoInvoice(deleteTarget.fiado, !deleteTarget.isPaid && deleteRestoreStock);
      setDeleteTarget(null);
      setDeleteAuthSecret('');
      setDeleteAuthError('');
    } finally {
      setDeletingFiado(false);
    }
  };

  const handleWhatsAppReminder = (fiado: FiadoRecord, remainingUsd: number) => {
    const phone = (fiado.telefono || '').replace(/\D/g, '');
    if (!phone) {
      notifyToast('Este cliente no tiene teléfono registrado.', 'warning');
      return;
    }
    const msg = `Hola ${fiado.cliente}, te saludamos de ${localName}. Tu saldo pendiente es de $${remainingUsd.toFixed(
      2
    )} (${(remainingUsd * bcvRate).toFixed(2)} Bs a tasa BCV).${
      fiado.fecha_vencimiento ? ` Vencimiento: ${fiado.fecha_vencimiento}.` : ''
    } Gracias por tu atención.`;
    const link = document.createElement('a');
    link.href = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div
      className={
        embedded
          ? 'w-full'
          : 'fixed inset-0 z-[150] bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4'
      }
    >
      <div
        className={
          embedded
            ? 'bg-white rounded-2xl border border-slate-200 shadow-xs w-full flex flex-col overflow-hidden'
            : 'bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full flex flex-col max-h-[92vh] overflow-hidden'
        }
      >
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-rose-600" />
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Cuentas por Cobrar y Control de Fiados
              </h3>
              <p className="text-xs text-slate-500">
                Búsqueda de clientes, cuentas a crédito por cuotas, facturas pendientes pago único, abonos y eliminación autorizada
              </p>
            </div>
          </div>
          {!embedded && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* KPIs Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 border-b border-slate-200">
          <div className="bg-white p-3 rounded-xl border border-slate-200">
            <span className="text-[11px] font-medium text-slate-500 block">Por cobrar total</span>
            <span className="text-lg font-mono font-bold text-rose-600">
              ${kpis.totalPorCobrar.toFixed(2)}
            </span>
            <span className="text-[11px] font-mono text-slate-500 block">
              {(kpis.totalPorCobrar * bcvRate).toFixed(2)} Bs
            </span>
          </div>
          <div className="bg-white p-3 rounded-xl border border-slate-200">
            <span className="text-[11px] font-medium text-slate-500 block">Saldo vencido</span>
            <span className="text-lg font-mono font-bold text-amber-700">
              ${kpis.totalVencido.toFixed(2)}
            </span>
            <span className="text-[11px] text-slate-500 block">Requiere gestión</span>
          </div>
          <div className="bg-white p-3 rounded-xl border border-slate-200">
            <span className="text-[11px] font-medium text-slate-500 block">Clientes deudores</span>
            <span className="text-lg font-mono font-bold text-slate-900">{kpis.debtorsCount}</span>
            <span className="text-[11px] text-slate-500 block">Cuentas activas</span>
          </div>
          <div className="bg-white p-3 rounded-xl border border-slate-200">
            <span className="text-[11px] font-medium text-slate-500 block">Total cobrado</span>
            <span className="text-lg font-mono font-bold text-emerald-700">
              ${kpis.totalRecuperado.toFixed(2)}
            </span>
            <span className="text-[11px] text-slate-500 block">Abonos recibidos</span>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-xl">
            {(
              [
                { id: 'pendientes', label: 'Pendientes' },
                { id: 'credito', label: 'A Crédito' },
                { id: 'contado_pendiente', label: 'Pago Único' },
                { id: 'vencidos', label: 'Vencidos' },
                { id: 'pagados', label: 'Pagados' },
                { id: 'todos', label: 'Todos' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  filter === tab.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por nombre, cédula, teléfono o Nro. factura..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>
        </div>

        <datalist id="fiados-products-datalist">
          {products.slice(0, 500).map((p) => (
            <option key={p.key} value={p.id} />
          ))}
        </datalist>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              No hay cuentas por cobrar en esta vista.
            </div>
          ) : (
            filtered
              .slice(0, 50)
              .map(
                ({
                  fiado,
                  items,
                  abonos,
                  totalUsd,
                  paidUsd,
                  remainingUsd,
                  isOverdue,
                  isPaid,
                }) => {
                  const progressPct =
                    totalUsd > 0 ? Math.min(100, (paidUsd / totalUsd) * 100) : 0;
                  const cuotaUsd = totalUsd / Math.max(1, Number(fiado.cuotas) || 1);
                  const keyId = `${fiado.cedula}_${fiado.ts}`;
                  const draft = addProdMap[keyId] || { prodName: '', qty: '1' };

                  return (
                    <div
                      key={keyId}
                      className={`rounded-xl border p-4 space-y-3 ${
                        isPaid
                          ? 'border-slate-200 bg-slate-50/60 opacity-80'
                          : isOverdue
                          ? 'border-rose-300 bg-rose-50/30'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="font-bold text-sm text-slate-900">{fiado.cliente}</h4>
                            {fiado.numero_factura && (
                              <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 font-mono text-[10px] font-bold">
                                {fiado.numero_factura}
                              </span>
                            )}
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                fiado.modalidad === 'contado_pendiente' || (Number(fiado.cuotas) || 1) <= 1
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-sky-100 text-sky-800'
                              }`}
                            >
                              {fiado.modalidad === 'contado_pendiente' || (Number(fiado.cuotas) || 1) <= 1
                                ? 'Factura Pendiente · Pago Único'
                                : `A Crédito · ${fiado.cuotas} cuotas`}
                            </span>
                            {isPaid ? (
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                                <CheckCircle2 className="w-3.5 h-3.5" /> Saldado
                              </span>
                            ) : isOverdue ? (
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700">
                                <AlertTriangle className="w-3.5 h-3.5" /> Vencido (
                                {fiado.fecha_vencimiento})
                              </span>
                            ) : fiado.fecha_vencimiento ? (
                              <span className="inline-flex items-center gap-1 text-xs text-slate-500">
                                <CalendarClock className="w-3.5 h-3.5" /> Vence{' '}
                                {fiado.fecha_vencimiento}
                              </span>
                            ) : null}
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 font-mono">
                            C.I. {fiado.cedula}
                            {fiado.telefono ? ` · Tel: ${fiado.telefono}` : ''}
                            {` · ${fiado.fecha}`}
                          </p>
                        </div>

                        <div className="text-right font-mono">
                          <span className="text-xs text-slate-500 block">Saldo pendiente</span>
                          <span
                            className={`text-base font-bold ${
                              isPaid ? 'text-emerald-700' : 'text-rose-600'
                            }`}
                          >
                            ${remainingUsd.toFixed(2)} ({(remainingUsd * bcvRate).toFixed(2)} Bs)
                          </span>
                        </div>
                      </div>

                      {/* Progress bar */}
                      <div className="space-y-1">
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 rounded-full transition-all"
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[11px] font-mono text-slate-500">
                          <span>
                            Total: ${totalUsd.toFixed(2)} · Abonado: ${paidUsd.toFixed(2)}
                          </span>
                          <span>
                            {fiado.cuotas || 1} cuota(s) de ${cuotaUsd.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      {/* Items list */}
                      <div className="border-t border-slate-100 pt-2 space-y-1">
                        {items.map((it, idx) => (
                          <div
                            key={`${it.key}_${idx}`}
                            className="flex items-center justify-between text-xs"
                          >
                            <span className="text-slate-700">
                              {it.nombre} × {it.cant}{' '}
                              <span className="font-mono text-slate-500">
                                (${Number(it.usd).toFixed(2)})
                              </span>
                            </span>
                            {!isPaid && (
                              <button
                                type="button"
                                onClick={() => void handleRemoveItem(fiado, items, idx)}
                                className="text-rose-600 hover:text-rose-800 p-1 cursor-pointer"
                                title="Quitar artículo"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>

                      {/* Abonos history */}
                      {abonos.length > 0 && (
                        <div className="bg-slate-50 rounded-lg p-2.5 text-[11px] space-y-1">
                          <span className="font-semibold text-slate-600 block">
                            Historial de abonos:
                          </span>
                          {abonos.map((a, idx) => (
                            <div key={idx} className="flex justify-between font-mono text-slate-600 gap-2">
                              <span className="truncate">
                                {a.fecha || '-'} · {a.metodo || a.tipo}
                                {a.referencia ? ` · Ref: ${a.referencia}` : ''}
                              </span>
                              <span className="font-bold text-emerald-700 shrink-0">
                                +${Number(a.usd).toFixed(2)}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Add item + Actions */}
                      {!isPaid && (
                        <div className="flex flex-wrap items-center gap-2 pt-1">
                          <input
                            list="fiados-products-datalist"
                            value={draft.prodName}
                            onChange={(e) =>
                              setAddProdMap((prev) => ({
                                ...prev,
                                [keyId]: { ...draft, prodName: e.target.value },
                              }))
                            }
                            placeholder="Agregar producto a esta cuenta..."
                            className="flex-1 min-w-[160px] px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                          />
                          <input
                            type="number"
                            step="0.01"
                            min="0.01"
                            value={draft.qty}
                            onChange={(e) =>
                              setAddProdMap((prev) => ({
                                ...prev,
                                [keyId]: { ...draft, qty: e.target.value },
                              }))
                            }
                            className="w-16 px-2 py-1.5 text-xs font-mono text-center bg-slate-50 border border-slate-200 rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={() => void handleAddProductToFiado(fiado, items)}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" /> Añadir
                          </button>
                        </div>
                      )}

                      <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                        {!isPaid && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setAbonoModal({ fiado, remainingUsd, cuotaUsd });
                                setAbonoAmount(Math.min(remainingUsd, cuotaUsd).toFixed(2));
                                setAbonoRef('');
                              }}
                              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                            >
                              Registrar Abono
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setAbonoModal({ fiado, remainingUsd, cuotaUsd });
                                setAbonoAmount(remainingUsd.toFixed(2));
                                setAbonoRef('');
                              }}
                              className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
                            >
                              Saldar Completo
                            </button>
                            <button
                              type="button"
                              onClick={() => handleWhatsAppReminder(fiado, remainingUsd)}
                              className="px-3 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                            >
                              <MessageCircle className="w-3.5 h-3.5" /> Recordar WhatsApp
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            generateFiadoStatementPDF(localName, fiado, bcvRate, totalUsd, paidUsd)
                          }
                          className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                        >
                          <FileDown className="w-3.5 h-3.5 text-sky-600" /> Estado de Cuenta PDF
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setDeleteTarget({ fiado, isPaid });
                            setDeleteRestoreStock(!isPaid);
                            setDeleteAuthSecret('');
                            setDeleteAuthError('');
                          }}
                          className="ml-auto px-3 py-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                          title="Requiere contraseña o PIN del administrador"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Eliminar Factura
                        </button>
                      </div>
                    </div>
                  );
                }
              )
          )}
        </div>
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>

      {/* Abono Modal */}
      {abonoModal && (
        <div className="fixed inset-0 z-[170] bg-slate-950/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmitAbono}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 relative"
          >
            <button
              type="button"
              onClick={() => setAbonoModal(null)}
              className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
            <h4 className="font-bold text-base text-slate-900 pr-7">
              Abonar a {abonoModal.fiado.cliente}
            </h4>
            <p className="text-xs text-slate-500">
              Saldo restante: <b className="font-mono">${abonoModal.remainingUsd.toFixed(2)}</b> (
              {(abonoModal.remainingUsd * bcvRate).toFixed(2)} Bs)
            </p>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Monto a abonar ($ USD)
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  step="0.01"
                  max={abonoModal.remainingUsd}
                  value={abonoAmount}
                  onChange={(e) => setAbonoAmount(e.target.value)}
                  className="flex-1 px-3 py-2 font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
                />
                <button
                  type="button"
                  onClick={() => setAbonoAmount(abonoModal.remainingUsd.toFixed(2))}
                  className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold cursor-pointer"
                >
                  Todo
                </button>
              </div>
              <span className="text-[11px] font-mono text-slate-500 mt-1 block">
                Equiv: {((Number(abonoAmount) || 0) * bcvRate).toFixed(2)} Bs
              </span>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Método de cobro
              </label>
              <select
                value={abonoMethod}
                onChange={(e) => setAbonoMethod(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
              >
                <option value="Pago Móvil">Pago Móvil</option>
                <option value="Efectivo Dolar">Dólar Físico</option>
                <option value="Efectivo Bs">Efectivo Bs</option>
                <option value="Débito">Débito</option>
                <option value="Biopago">Biopago</option>
              </select>
            </div>
            {abonoMethod === 'Pago Móvil' && (
              <div>
                <label className="block text-xs font-semibold text-sky-800 mb-1">
                  Nro. de Referencia Pago Móvil (Opcional)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={abonoRef}
                  onChange={(e) => setAbonoRef(e.target.value)}
                  placeholder="Ej. 00458912 (Opcional)"
                  className="w-full px-3 py-2 text-xs font-mono font-bold bg-sky-50 border border-sky-200 rounded-xl"
                />
              </div>
            )}
            <input
              type="text"
              value={abonoNote}
              onChange={(e) => setAbonoNote(e.target.value)}
              placeholder="Nota adicional (opcional)"
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setAbonoModal(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
              >
                Confirmar Abono
              </button>
            </div>
          </form>
        </div>
      )}
      {/* In-App Confirm Remove Fiado Item Modal */}
      {pendingRemoveItem && (
        <div className="fixed inset-0 z-[170] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <h4 className="font-bold text-sm text-slate-900">Quitar Artículo del Fiado</h4>
            <p className="text-xs text-slate-600">
              ¿Quitar <b>“{pendingRemoveItem.itemName}”</b> de la factura y devolver las unidades al stock?
            </p>
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setPendingRemoveItem(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => void confirmRemoveItem()}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
              >
                Sí, quitar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin-Authorized Delete Fiado Invoice Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-[180] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleConfirmDeleteFiado}
            className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">
                    Autorizar Eliminación de Factura Fiada
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    {deleteTarget.fiado.cliente} · {deleteTarget.fiado.numero_factura || `C.I. ${deleteTarget.fiado.cedula}`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                Para borrar esta factura pendiente o a crédito se requiere obligatoriamente el{' '}
                <b>PIN Administrativo</b> o la <b>Contraseña del Administrador</b>.
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => {
                  setDeleteAuthMode('pin');
                  setDeleteAuthSecret('');
                  setDeleteAuthError('');
                }}
                className={`py-1.5 rounded-lg font-semibold cursor-pointer ${
                  deleteAuthMode === 'pin' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                PIN Administrador
              </button>
              <button
                type="button"
                onClick={() => {
                  setDeleteAuthMode('password');
                  setDeleteAuthSecret('');
                  setDeleteAuthError('');
                }}
                className={`py-1.5 rounded-lg font-semibold cursor-pointer ${
                  deleteAuthMode === 'password' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Contraseña Admin
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {deleteAuthMode === 'pin' ? 'PIN Administrativo' : 'Contraseña de Administrador'}
              </label>
              <input
                type="password"
                autoFocus
                value={deleteAuthSecret}
                onChange={(e) => setDeleteAuthSecret(e.target.value)}
                placeholder={deleteAuthMode === 'pin' ? 'Ingresa el PIN del administrador' : 'Ingresa la contraseña de administrador'}
                className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
            </div>

            {!deleteTarget.isPaid && (
              <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={deleteRestoreStock}
                  onChange={(e) => setDeleteRestoreStock(e.target.checked)}
                  className="rounded border-slate-300"
                />
                Restablecer los artículos de esta factura al stock del inventario
              </label>
            )}

            {deleteAuthError && (
              <p className="text-xs font-semibold text-rose-600 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2">
                {deleteAuthError}
              </p>
            )}

            <div className="flex gap-2 justify-end pt-1">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={deletingFiado || !deleteAuthSecret.trim()}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer"
              >
                {deletingFiado ? 'Validando...' : 'Autorizar y Eliminar'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
